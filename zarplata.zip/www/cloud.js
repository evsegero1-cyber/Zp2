// Облако не настроено: нет ключей Firebase (см. FIREBASE_SETUP.md). Калькулятор работает локально.
window.Cloud = window.Cloud || { configured: false, ready: false, on: function () { return function () {}; } };
