# Иконки приложения из assets/icon-source.png (PWA + Android mipmap)
from PIL import Image, ImageDraw
import os
root = os.path.join(os.path.dirname(__file__), '..')
src = Image.open(os.path.join(root, 'assets', 'icon-source.png')).convert('RGB')
W = src.size[0]
bg = src.getpixel((W // 2, int(W * 0.06)))          # цвет фона иконки
# Исходник — скруглённый квадрат на чёрном: убираем чёрные углы, получаем «полотно» без углов
art = Image.new('RGB', src.size, bg)
m = Image.new('L', src.size, 0); ImageDraw.Draw(m).rounded_rectangle([6, 6, W - 7, W - 7], radius=int(W * 0.17), fill=255)
art.paste(src, (0, 0), m)

def shrink(k):  # рисунок меньше, вокруг — фон (для круглой и maskable иконки)
    out = Image.new('RGB', art.size, bg); s = int(W * k); out.paste(art.resize((s, s), Image.LANCZOS), ((W - s) // 2, (W - s) // 2)); return out
def shaped(img, size, shape):
    S = size * 4; big = img.resize((S, S), Image.LANCZOS).convert('RGBA')
    mask = Image.new('L', (S, S), 0); d = ImageDraw.Draw(mask)
    if shape == 'round': d.ellipse([0, 0, S - 1, S - 1], fill=255)
    elif shape == 'rounded': d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=255)
    else: d.rectangle([0, 0, S, S], fill=255)
    big.putalpha(mask); return big.resize((size, size), Image.LANCZOS)

out = os.path.join(root, 'www', 'icons'); os.makedirs(out, exist_ok=True)
shaped(art, 192, 'rounded').save(os.path.join(out, 'icon-192.png'))
shaped(art, 512, 'rounded').save(os.path.join(out, 'icon-512.png'))
shaped(shrink(0.8), 512, 'square').save(os.path.join(out, 'icon-maskable-512.png'))
for d, s in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    p = os.path.join(root, 'android-res', 'mipmap-' + d); os.makedirs(p, exist_ok=True)
    shaped(art, s, 'rounded').save(os.path.join(p, 'ic_launcher.png'))
    shaped(shrink(0.86), s, 'round').save(os.path.join(p, 'ic_launcher_round.png'))
print('Иконки готовы; фон', bg)

# ---------- iPhone: иконка «На экран Домой» и заставки при запуске ----------
# iOS сам скругляет иконку — нужна квадратная без прозрачности
shaped(art, 180, 'square').convert('RGB').save(os.path.join(out, 'apple-touch-icon.png'))
from PIL import ImageFont
SPLASH = [  # (ширина, высота в точках, плотность) — портретная ориентация
    (375, 667, 2), (414, 736, 3), (375, 812, 3), (414, 896, 2), (414, 896, 3), (390, 844, 3), (428, 926, 3),
    (393, 852, 3), (430, 932, 3), (402, 874, 3), (440, 956, 3), (420, 912, 3), (320, 568, 2),
]
sp = os.path.join(out, 'splash'); os.makedirs(sp, exist_ok=True)
font_path = '/usr/share/fonts/opentype/inter/Inter-Bold.otf'
links = []
for w, h, r in SPLASH:
    W2, H2 = w * r, h * r
    img = Image.new('RGB', (W2, H2), bg)
    s = int(min(W2, H2) * 0.34)
    ic = shaped(art, s, 'rounded')
    y = int(H2 * 0.40) - s // 2
    img.paste(ic, ((W2 - s) // 2, y), ic)
    try:
        f = ImageFont.truetype(font_path, int(s * 0.16))
        d = ImageDraw.Draw(img); t = 'Калькулятор ЗП'
        tw = d.textlength(t, font=f); d.text(((W2 - tw) / 2, y + s + int(s * 0.18)), t, font=f, fill=(241, 239, 234))
    except OSError: pass
    name = f'splash-{W2}x{H2}.png'
    img.quantize(colors=128, method=Image.Quantize.MEDIANCUT).save(os.path.join(sp, name), optimize=True)
    links.append(f'  <link rel="apple-touch-startup-image" media="(device-width: {w}px) and (device-height: {h}px) and (-webkit-device-pixel-ratio: {r}) and (orientation: portrait)" href="icons/splash/{name}">')
open(os.path.join(root, 'src', 'splash.html'), 'w').write('\n'.join(links) + '\n')
print('Иконки и', len(SPLASH), 'заставок для iPhone готовы')
