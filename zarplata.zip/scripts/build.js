// Собирает www/index.html (всё в одном файле — работает офлайн без внешних ресурсов)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const rd = (f) => fs.readFileSync(path.join(root, 'src', f), 'utf8');
const html = rd('index.html')
  .replace('/*CSS*/', () => rd('styles.css'))
  .replace('/*CORE*/', () => rd('core.js'))
  .replace('/*APP*/', () => rd('app.js'))
  .replace('/*CAPACITOR*/', () => {
    // Мост Capacitor для доступа к нативным плагинам (отпечаток, файлы, «поделиться») в APK. В браузере он неактивен.
    const f = path.join(root, 'node_modules', '@capacitor', 'core', 'dist', 'capacitor.js');
    if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8');
    console.warn('ВНИМАНИЕ: нет node_modules/@capacitor/core — выполните npm install (нужно для APK)');
    return '';
  });
fs.mkdirSync(path.join(root, 'www'), { recursive: true });
fs.writeFileSync(path.join(root, 'www', 'index.html'), html);
// Версия кэша service worker = хэш содержимого, чтобы обновления доходили до телефона
const hash = require('crypto').createHash('sha1').update(html).digest('hex').slice(0, 10);
const sw = fs.readFileSync(path.join(root, 'src', 'sw.js'), 'utf8').replace('__VERSION__', hash);
fs.writeFileSync(path.join(root, 'www', 'sw.js'), sw);
console.log('www/index.html собран,', (html.length / 1024).toFixed(1), 'КБ; кэш', hash);
