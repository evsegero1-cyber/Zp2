// Собирает www/index.html (всё в одном файле — работает офлайн без внешних ресурсов)
// и www/cloud.js — облачный слой Firebase (необязательный: без ключей собирается заглушка).
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const rd = (f) => fs.readFileSync(path.join(root, 'src', f), 'utf8');

// ---------- Ключи Firebase: переменные окружения или локальный файл .env (в git не попадает) ----------
function loadEnv() {
  const f = path.join(root, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}
loadEnv();
const env = (k) => (process.env[k] || '').trim();
const firebaseConfig = {
  apiKey: env('FIREBASE_API_KEY'),
  authDomain: env('FIREBASE_AUTH_DOMAIN'),
  projectId: env('FIREBASE_PROJECT_ID'),
  appId: env('FIREBASE_APP_ID'),
  messagingSenderId: env('FIREBASE_MESSAGING_SENDER_ID') || undefined,
  storageBucket: env('FIREBASE_STORAGE_BUCKET') || undefined,
};
const emulators = env('FIREBASE_EMULATORS'); // '1' или адрес хоста — подключиться к локальному эмулятору (тесты)
const cloudOn = !!(firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId && firebaseConfig.authDomain);

fs.mkdirSync(path.join(root, 'www'), { recursive: true });
let cloud;
if (cloudOn) {
  const esbuild = require('esbuild');
  const out = esbuild.buildSync({
    entryPoints: [path.join(root, 'src', 'cloud', 'index.js')],
    bundle: true, minify: true, format: 'iife', target: ['es2020', 'safari15', 'chrome90'], write: false, legalComments: 'none',
    define: {
      __FIREBASE_CONFIG__: JSON.stringify(firebaseConfig),
      __FIREBASE_EMULATORS__: JSON.stringify(emulators === '1' ? true : emulators || false),
    },
  });
  cloud = out.outputFiles[0].text;
} else {
  cloud = '// Облако не настроено: нет ключей Firebase (см. FIREBASE_SETUP.md). Калькулятор работает локально.\n' +
    'window.Cloud = window.Cloud || { configured: false, ready: false, on: function () { return function () {}; } };\n';
}
fs.writeFileSync(path.join(root, 'www', 'cloud.js'), cloud);
// Графики сравнения (Chart.js) — отдельный файл, загружается по требованию
let charts = '';
try {
  charts = require('esbuild').buildSync({ entryPoints: [path.join(root, 'src', 'cloud', 'charts.js')], bundle: true, minify: true, format: 'iife',
    target: ['es2020', 'safari15', 'chrome90'], write: false, legalComments: 'none' }).outputFiles[0].text;
} catch (e) { console.warn('ВНИМАНИЕ: charts.js не собран (нет esbuild/chart.js — выполните npm install)'); charts = '/* графики недоступны */'; }
fs.writeFileSync(path.join(root, 'www', 'charts.js'), charts);
// Чтение Excel- и Word-отчётов (только администратору) — отдельный файл, загружается по требованию
try {
  const x = require('esbuild').buildSync({ stdin: { contents: "import readXlsxFile from 'read-excel-file/browser'; import { unzipSync, strFromU8 } from 'fflate'; window.ReadExcel = { readAll: readXlsxFile, unzip: unzipSync, text: strFromU8 };", resolveDir: root },
    bundle: true, minify: true, format: 'iife', target: ['es2020', 'safari15', 'chrome90'], write: false, legalComments: 'none' }).outputFiles[0].text;
  fs.writeFileSync(path.join(root, 'www', 'excel.js'), x);
} catch (e) { console.warn('ВНИМАНИЕ: excel.js не собран (npm install)', e.message); }
// Распознавание фото отчёта (Tesseract, офлайн на устройстве): файлы с этого же сайта, без внешних CDN
const ocrDir = path.join(root, 'www', 'ocr');
const ocrFiles = [['tesseract.js/dist/tesseract.min.js', 'tesseract.min.js'], ['tesseract.js/dist/worker.min.js', 'worker.min.js'],
  ['tesseract.js-core/tesseract-core-simd-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js'], ['tesseract.js-core/tesseract-core-lstm.wasm.js', 'tesseract-core-lstm.wasm.js'],
  ['@tesseract.js-data/rus/4.0.0_best_int/rus.traineddata.gz', 'rus.traineddata.gz']];
if (ocrFiles.every(([f]) => fs.existsSync(path.join(root, 'node_modules', f)))) {
  fs.mkdirSync(ocrDir, { recursive: true });
  for (const [f, to] of ocrFiles) fs.copyFileSync(path.join(root, 'node_modules', f), path.join(ocrDir, to));
} else console.warn('ВНИМАНИЕ: файлы распознавания не найдены (npm install) — ввод отчёта с фото недоступен');

const html = rd('index.html')
  .replace('<!--SPLASH-->', () => (fs.existsSync(path.join(root, 'src', 'splash.html')) ? rd('splash.html') : ''))
  .replace('/*CSS*/', () => rd('styles.css'))
  .replace('/*CORE*/', () => rd('core.js'))
  .replace('/*PET*/', () => rd('pet-phrases.js') + '\n' + rd('pet.js'))
  .replace('/*VOICE*/', () => rd('voice.js'))
  .replace('/*REPORT*/', () => rd('report.js'))
  .replace('/*APP*/', () => rd('app.js'))
  .replace('/*CAPACITOR*/', () => {
    // Мост Capacitor для доступа к нативным плагинам (отпечаток, файлы, «поделиться») в APK. В браузере он неактивен.
    const f = path.join(root, 'node_modules', '@capacitor', 'core', 'dist', 'capacitor.js');
    if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8');
    console.warn('ВНИМАНИЕ: нет node_modules/@capacitor/core — выполните npm install (нужно для APK)');
    return '';
  });
// Версия = хэш содержимого: по ней service worker и APK («по воздуху») узнают, что вышло обновление
const hash = require('crypto').createHash('sha1').update(html).update(cloud).update(charts).digest('hex').slice(0, 10);
fs.writeFileSync(path.join(root, 'www', 'index.html'), html.replace("'__BUILD_ID__'", `'${hash}'`));
// Для обновления APK по воздуху: версия, архив (его собирает web.yml) и модули Android, без которых новая версия не заработает.
// Добавили новый нативный плагин — впишите его сюда: старые APK тогда попросят скачать новый APK.
const NATIVE_PLUGINS = ['NativeBiometric', 'Filesystem', 'Share', 'SpeechRecognition', 'CapacitorUpdater'];
fs.writeFileSync(path.join(root, 'www', 'version.json'), JSON.stringify({ version: hash, url: `ota/${hash}.zip`, plugins: NATIVE_PLUGINS }));
const sw = fs.readFileSync(path.join(root, 'src', 'sw.js'), 'utf8').replace('__VERSION__', hash);
fs.writeFileSync(path.join(root, 'www', 'sw.js'), sw);
console.log('www/index.html собран,', (html.length / 1024).toFixed(1), 'КБ; cloud.js', (cloud.length / 1024).toFixed(1), 'КБ',
  cloudOn ? `(Firebase: ${firebaseConfig.projectId}${emulators ? ', эмулятор' : ''})` : '(облако не настроено)', '; кэш', hash);
