// Собирает www/index.html (всё в одном файле — работает офлайн без внешних ресурсов)
// и www/cloud.js — облачный слой Firebase (необязательный: без ключей собирается заглушка).
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const rd = (f) => fs.readFileSync(path.join(root, 'src', f), 'utf8');

// ---------- Ключи Firebase: переменные окружения или локальный файл .env (в git не попадает) ----------
function loadEnv() {
  const f = path.join(root, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}
loadEnv();
const env = (k) => (process.env[k] || '').trim();
const firebaseConfig = {
  apiKey: env('FIREBASE_API_KEY'),
  authDomain: env('FIREBASE_AUTH_DOMAIN'),
  projectId: env('FIREBASE_PROJECT_ID'),
  appId: env('FIREBASE_APP_ID'),
  messagingSenderId: env('FIREBASE_MESSAGING_SENDER_ID') || undefined,
  storageBucket: env('FIREBASE_STORAGE_BUCKET') || undefined,
};
const emulators = env('FIREBASE_EMULATORS'); // '1' или адрес хоста — подключиться к локальному эмулятору (тесты)
const cloudOn = !!(firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId && firebaseConfig.authDomain);

fs.mkdirSync(path.join(root, 'www'), { recursive: true });
let cloud;
if (cloudOn) {
  const esbuild = require('esbuild');
  const out = esbuild.buildSync({
    entryPoints: [path.join(root, 'src', 'cloud', 'index.js')],
    bundle: true, minify: true, format: 'iife', target: ['es2020', 'safari15', 'chrome90'], write: false, legalComments: 'none',
    define: {
      __FIREBASE_CONFIG__: JSON.stringify(firebaseConfig),
      __FIREBASE_EMULATORS__: JSON.stringify(emulators === '1' ? true : emulators || false),
    },
  });
  cloud = out.outputFiles[0].text;
} else {
  cloud = '// Облако не настроено: нет ключей Firebase (см. FIREBASE_SETUP.md). Калькулятор работает локально.\n' +
    'window.Cloud = window.Cloud || { configured: false, ready: false, on: function () { return function () {}; } };\n';
}
fs.writeFileSync(path.join(root, 'www', 'cloud.js'), cloud);

const html = rd('index.html')
  .replace('/*CSS*/', () => rd('styles.css'))
  .replace('/*CORE*/', () => rd('core.js'))
  .replace('/*PET*/', () => rd('pet.js'))
  .replace('/*APP*/', () => rd('app.js'))
  .replace('/*CAPACITOR*/', () => {
    // Мост Capacitor для доступа к нативным плагинам (отпечаток, файлы, «поделиться») в APK. В браузере он неактивен.
    const f = path.join(root, 'node_modules', '@capacitor', 'core', 'dist', 'capacitor.js');
    if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8');
    console.warn('ВНИМАНИЕ: нет node_modules/@capacitor/core — выполните npm install (нужно для APK)');
    return '';
  });
fs.writeFileSync(path.join(root, 'www', 'index.html'), html);
// Версия кэша service worker = хэш содержимого, чтобы обновления доходили до телефона
const hash = require('crypto').createHash('sha1').update(html).update(cloud).digest('hex').slice(0, 10);
const sw = fs.readFileSync(path.join(root, 'src', 'sw.js'), 'utf8').replace('__VERSION__', hash);
fs.writeFileSync(path.join(root, 'www', 'sw.js'), sw);
console.log('www/index.html собран,', (html.length / 1024).toFixed(1), 'КБ; cloud.js', (cloud.length / 1024).toFixed(1), 'КБ',
  cloudOn ? `(Firebase: ${firebaseConfig.projectId}${emulators ? ', эмулятор' : ''})` : '(облако не настроено)', '; кэш', hash);
