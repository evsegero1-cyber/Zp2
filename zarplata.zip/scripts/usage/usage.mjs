// Расход бесплатных лимитов Firebase (тариф Spark) → документ adminMeta/usage, который видит только администратор.
// Запускается GitHub Actions раз в час с ключом сервисного аккаунта (секрет FIREBASE_SERVICE_ACCOUNT).
// Чтения/записи/удаления — из Cloud Monitoring (нужна роль «Monitoring Viewer» у сервисного аккаунта);
// объём базы — оценка по документам раз в сутки (Google не отдаёт его на бесплатном тарифе).
import { GoogleAuth } from 'google-auth-library';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

const sa = JSON.parse(process.env.SA || '{}');
if (!sa.project_id) { console.log('Нет ключа сервисного аккаунта — пропускаю'); process.exit(0); }
const project = sa.project_id;
initializeApp({ credential: cert(sa) });
const db = getFirestore();
const ref = db.doc('adminMeta/usage');

// Лимиты бесплатного тарифа (в сутки, сброс в полночь по тихоокеанскому времени)
const LIMITS = { reads: 50000, writes: 20000, deletes: 20000, storageBytes: 1024 ** 3 };

// Начало «суток Google» (полночь America/Los_Angeles) в UTC
function pacificMidnight(daysBack = 0) {
  const now = new Date();
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
    .formatToParts(now).map((p) => [p.type, p.value]));
  const sinceMidnight = (+parts.hour * 3600 + +parts.minute * 60 + +parts.second) * 1000;
  return new Date(now.getTime() - sinceMidnight - daysBack * 864e5 - (now.getMilliseconds()));
}

async function monitoring() {
  const auth = new GoogleAuth({ credentials: sa, scopes: ['https://www.googleapis.com/auth/monitoring.read'] });
  const client = await auth.getClient();
  const sum = async (metric, from, to) => {
    const secs = Math.max(60, Math.round((to - from) / 1000));
    const q = new URLSearchParams({
      filter: `metric.type="firestore.googleapis.com/document/${metric}"`,
      'interval.startTime': from.toISOString(), 'interval.endTime': to.toISOString(),
      'aggregation.alignmentPeriod': secs + 's', 'aggregation.perSeriesAligner': 'ALIGN_SUM', 'aggregation.crossSeriesReducer': 'REDUCE_SUM',
    });
    const r = await client.request({ url: `https://monitoring.googleapis.com/v3/projects/${project}/timeSeries?${q}` });
    let n = 0;
    for (const ts of r.data.timeSeries || []) for (const p of ts.points || []) n += Number(p.value.int64Value || p.value.doubleValue || 0);
    return n;
  };
  const now = new Date(), today = pacificMidnight(0), yesterday = pacificMidnight(1);
  const out = { today: {}, yesterday: {} };
  for (const [k, m] of [['reads', 'read_ops_count'], ['writes', 'write_ops_count'], ['deletes', 'delete_ops_count']]) {
    out.today[k] = await sum(m, today, now);
    out.yesterday[k] = await sum(m, yesterday, today);
  }
  out.resetAt = new Date(today.getTime() + 864e5);
  return out;
}

// Оценка объёма: размер документов по правилам Firestore (имя + поля + 32 байта)
function sizeOf(v) {
  if (v === null || v === undefined) return 1;
  if (typeof v === 'boolean') return 1;
  if (typeof v === 'number') return 8;
  if (typeof v === 'string') return Buffer.byteLength(v) + 1;
  if (v instanceof Date || (v && typeof v.toDate === 'function')) return 8;
  if (Array.isArray(v)) return v.reduce((a, x) => a + sizeOf(x), 0);
  if (typeof v === 'object') return Object.entries(v).reduce((a, [k, x]) => a + Buffer.byteLength(k) + 1 + sizeOf(x), 0);
  return 8;
}
async function storage() {
  let bytes = 0, docs = 0; const byCol = {};
  async function walk(cols, top) {
    for (const c of cols) {
      const snap = await c.get();
      for (const d of snap.docs) {
        const s = Buffer.byteLength(d.ref.path) + 16 + sizeOf(d.data()) + 32;
        bytes += s; docs++; byCol[top || c.id] = (byCol[top || c.id] || 0) + s;
        await walk(await d.ref.listCollections(), top || c.id);
      }
    }
  }
  await walk(await db.listCollections(), null);
  return { bytes, docs, byCol };
}

const prev = (await ref.get()).data() || {};
const res = { updatedAt: FieldValue.serverTimestamp(), limits: LIMITS };
try { Object.assign(res, await monitoring(), { monitoringError: FieldValue.delete() }); }
catch (e) {
  const code = e.response && e.response.status;
  res.monitoringError = code === 403 ? 'no-permission' : String(e.message || e).slice(0, 200);
  console.error('Monitoring:', code, e.message);
}
// объём — раз в сутки (обход всех документов сам тратит чтения)
const storageAge = prev.storage && prev.storage.at ? Date.now() - prev.storage.at.toMillis() : Infinity;
if (storageAge > 20 * 3600e3 || process.env.FORCE_STORAGE) {
  try { const s = await storage(); res.storage = { ...s, at: new Date() }; } catch (e) { console.error('Объём:', e.message); }
}
await ref.set(res, { merge: true });
console.log('Записано:', JSON.stringify({ ...res, updatedAt: undefined }, null, 1));
