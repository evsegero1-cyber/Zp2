// Копирует иконки приложения в Android-проект (после `npx cap add android`)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
if (!fs.existsSync(res)) { console.error('Нет папки android — сначала выполните npx cap add android'); process.exit(1); }
for (const dir of fs.readdirSync(path.join(root, 'android-res')).filter((d) => d.startsWith('mipmap-'))) {
  for (const f of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const dst = path.join(res, dir);
    fs.mkdirSync(dst, { recursive: true });
    fs.copyFileSync(path.join(root, 'android-res', dir, f), path.join(dst, f));
  }
  const fg = path.join(res, dir, 'ic_launcher_foreground.png');
  if (fs.existsSync(fg)) fs.unlinkSync(fg);
}
// Заставка: нейтральный фон вместо логотипа Capacitor
for (const dir of fs.readdirSync(res).filter((d) => d.startsWith('drawable'))) {
  const f = path.join(res, dir, 'splash.png');
  if (fs.existsSync(f)) fs.copyFileSync(path.join(root, 'android-res', 'splash.png'), f);
}
// Адаптивные иконки по умолчанию (логотип Capacitor) убираем, чтобы использовалась наша
const anydpi = path.join(res, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpi)) fs.rmSync(anydpi, { recursive: true, force: true });
// Цвет статус-бара и фон заставки
const colors = path.join(res, 'values', 'colors.xml');
if (fs.existsSync(colors)) {
  let x = fs.readFileSync(colors, 'utf8');
  x = x.replace(/(name="colorPrimary">)[^<]*/, '$1#E8590C').replace(/(name="colorPrimaryDark">)[^<]*/, '$1#C24A0A');
  fs.writeFileSync(colors, x);
}
// Разрешение на вход по отпечатку пальца
const manifest = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifest)) {
  let mx = fs.readFileSync(manifest, 'utf8');
  // отпечаток; микрофон — голосовые сообщения и голосовой ввод смены
  for (const perm of ['USE_BIOMETRIC', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS']) {
    if (!mx.includes('android.permission.' + perm)) mx = mx.replace('</manifest>', `    <uses-permission android:name="android.permission.${perm}" />\n</manifest>`);
  }
  // Android 11+: без этого приложению не видна служба распознавания речи
  if (!mx.includes('android.speech.RecognitionService')) {
    mx = mx.replace('</manifest>', '    <queries>\n        <intent>\n            <action android:name="android.speech.RecognitionService" />\n        </intent>\n    </queries>\n</manifest>');
  }
  fs.writeFileSync(manifest, mx);
}
// Файлы распознавания отчёта (≈10 МБ) в APK не кладём: администратор загружает их с сайта приложения
fs.rmSync(path.join(root, 'www', 'ocr'), { recursive: true, force: true });
console.log('Иконки и разрешения Android обновлены');
