const test = require('node:test');
const assert = require('node:assert');
const R = require('../src/report.js');

test('числа и даты из отчёта', () => {
  assert.strictEqual(R.parseNum('1 389,22 ₽'), 1389.22);
  assert.strictEqual(R.parseNum('145,54%'), 145.54);
  assert.strictEqual(R.parseNum('2 942'), 2942);
  assert.strictEqual(R.parseNum('—'), null);
  assert.strictEqual(R.parseDate('30.10.2026'), '2026-10-30');
  assert.strictEqual(R.parseDate('1.2.26'), '2026-02-01');
});

test('сопоставление ФИО: полное, инициалы, ошибки распознавания, однофамильцы', () => {
  const me = 'Иванов Пётр Сергеевич';
  assert.ok(R.matchScore(me, 'Иванов Петр Сергеевич') > 0.95);
  assert.ok(R.matchScore(me, 'Иванов П.С.') > 0.9);
  assert.ok(R.matchScore(me, 'Иванов ПС') > 0.9);
  assert.ok(R.matchScore(me, 'Иваноа П.С') > 0.75, 'одна ошибка в фамилии');
  assert.ok(R.matchScore('Евсюков Сергей Петрович', 'Евсюжов СП') >= 0.75);
  assert.strictEqual(R.matchScore(me, 'Иванов А.С.'), 0.3, 'однофамилец с другим именем — слабое совпадение');
  assert.strictEqual(R.matchScore(me, 'Петров П.С.'), 0);
  const rows = [{ name: 'Иванов А.С.' }, { name: 'Иванов П.С.' }, { name: 'Сидорова Анна Ивановна' }];
  const m = R.matchAccounts([{ uid: 'a', fio: me }, { uid: 'b', fio: 'Сидорова Анна' }, { uid: 'c', fio: '' }], rows);
  assert.deepStrictEqual(m.matches, { a: 1, b: 2 });
});

// Таблица как в «Расчет производительности по складу» (имена вымышленные)
const excel = [
  ['', 'Неделя', '(Все)'], ['', 'Склад', 'Склад А'], ['', 'Дата', '30.10.2026'], [],
  ['', 'ФИО', '% производительность в час', '% простоя', 'Время ФАКТ', 'Время ПЛАН', 'Количество линий', 'Вес линии_', 'Вес, кг', 'Кол-во линий в час', 'Кол-во часов переработки', 'Начислено за отбор', '_Начислено за переработку', 'Итого заработано'],
  ['', 'Иванов Пётр Сергеевич', '145,54%', '54,30%', 4, 8, 399, 10, '4 118,78', 109, '0,00', '2 058,84 ₽', '0,00 ₽', '2 058,84 ₽'],
  ['', 'Сидорова Анна Ивановна', 1.1658, 0.615, 3, 8, 272, 5, 1408.89, 88, 0, 1389.22, 0, 1389.22],
  ['', 'Общий итог', '119,09%', '', 7, 16, 671],
];

test('Excel: колонки по заголовкам, дата из фильтра, доли → проценты, итог не попадает', () => {
  const t = R.fromGrid(excel, 'Склад А');
  assert.strictEqual(t.date, '2026-10-30');
  assert.strictEqual(t.rows.length, 2);
  assert.deepStrictEqual(t.rows.map((r) => [r.name, r.lines, r.prod, r.actual]), [
    ['Иванов Пётр Сергеевич', 399, 145.54, 2058.84], ['Сидорова Анна Ивановна', 272, 116.58, 1389.22]]);
});

test('WMS: «Комплектовщик», «Итого по ставке», дата начала ночной смены', () => {
  const wms = [['Производительность отбора с 29.10.2026 20:00:00 по 30.10.2026 19:06:19'], ['Детализация Месяц'],
    ['', 'Комплектовщик', 'Количество наборов', 'Количество линий', 'Отобрано коробов', 'Скорость, л/ч', 'Итого по ставке, ставка/итог'],
    ['', 'Иванов П.С.', 77, 586, 282, 85, '2 942'], ['', 'Всего комплектовщиков:2', 100, 900]];
  const t = R.fromGrid(wms);
  assert.strictEqual(t.date, '2026-10-29');
  assert.deepStrictEqual(t.rows, [{ name: 'Иванов П.С.', lines: 586, prod: null, actual: 2942, date: '2026-10-29' }]);
});

test('Несколько складов: один человек в двух — линии и заработок суммируются', () => {
  const m = R.mergeTables([{ sheet: 'А', rows: [{ name: 'Иванов П.С.', lines: 100, prod: 100, actual: 500, date: 'd' }] },
    { sheet: 'Б', rows: [{ name: 'Иванов П.С.', lines: 300, prod: 140, actual: 1500, date: 'd' }] }]);
  assert.strictEqual(m.length, 1);
  assert.deepStrictEqual([m[0].lines, m[0].prod, m[0].actual], [400, 130, 2000]);
});

// Фото: слова с координатами (как после распознавания), цифры с ошибками
test('Фото: колонки по выравниванию чисел, исправление «1 831,80 ₽» → 1831,8', () => {
  const W = (t, x, y, w = 60) => ({ t, x0: x, x1: x + w, y0: y, y1: y + 30 });
  const head = { words: [W('ФИО', 100, 100), W('%', 400, 100, 20), W('производительность', 430, 100, 200), W('Время', 700, 100), W('ПЛАН', 700, 135),
    W('Количество', 850, 100, 120), W('линий', 860, 135), W('Итого', 1100, 100), W('заработано', 1100, 135, 120)], y0: 100, y1: 165 };
  const row = (y, name, p, plan, l, a) => ({ y0: y, y1: y + 30, words: [...name.split(' ').map((n, i) => W(n, 100 + i * 110, y, 100)), W(p, 480, y, 90), W(plan, 720, y, 20), W(l, 880, y, 50), ...a.split(' ').map((n, i) => W(n, 1100 + i * 50, y, 45))] });
  const lines = [{ y0: 40, y1: 70, words: [W('Дата', 100, 40), W('30.10.2026', 200, 40, 120)] }, head,
    row(200, 'Иванов Пётр Сергеевич', '145,21%', '8', '493', '2 543,88Р'),
    row(240, 'Сидорова Анна Ивановна', '118,02%', '8', '331', '1831800'),
    row(280, 'Петров Иван Ильич', '97,96%', '8', '93', '459,42'),
    { y0: 320, y1: 350, words: [W('Общий', 100, 320), W('итог', 170, 320), W('119,09%', 480, 320, 90)] }];
  const t = R.fromWords(lines);
  assert.strictEqual(t.date, '2026-10-30');
  assert.strictEqual(t.exact, false);
  assert.deepStrictEqual(t.rows.map((r) => [r.name, r.lines, r.prod, r.actual]), [
    ['Иванов Пётр Сергеевич', 493, 145.21, 2543.88], ['Сидорова Анна Ивановна', 331, 118.02, 1831.8], ['Петров Иван Ильич', 93, 97.96, 459.42]]);
});

test('Очистка фото: линии сетки убираются, буквы остаются', () => {
  const Wd = 300, H = 240, g = new Uint8Array(Wd * H).fill(230);
  for (let x = 0; x < Wd; x++) g[30 * Wd + x] = 20;           // горизонтальная линия
  for (let x = 0; x < Wd; x += 3) g[50 * Wd + x] = 20;         // пунктир
  for (let y = 10; y < 25; y++) for (let x = 50; x < 54; x++) g[y * Wd + x] = 20; // «буква»
  const out = R.cleanTable(g, Wd, H);
  assert.strictEqual(out[30 * Wd + 100], 255);
  assert.strictEqual(out[50 * Wd + 99], 255);
  assert.strictEqual(out[15 * Wd + 51], 0);
});

test('Word (.docx): таблица отчёта, дата над таблицей, объединённые ячейки', () => {
  const t = (s) => `<w:r><w:t xml:space="preserve">${s}</w:t></w:r>`;
  const p = (...parts) => `<w:p w:rsidR="1"><w:pPr/>${parts.join('')}</w:p>`;
  const tc = (s, extra = '') => `<w:tc><w:tcPr>${extra}</w:tcPr>${p(t(s))}</w:tc>`;
  const tr = (...cells) => `<w:tr w:rsidR="1">${cells.join('')}</w:tr>`;
  const xml = `<?xml version="1.0"?><w:document><w:body>
    ${p(t('Отчёт по производительности за '), t('29.10.2026'))}
    ${p(t('Склад &amp; комплектация'))}
    <w:tbl><w:tblPr/>
      ${tr(tc('ФИО'), tc('Количество линий'), tc('Производительность'), tc('Итого, ₽'))}
      ${tr(tc('Евгеньев Евгений Иванович'), tc('586'), tc('145,54%'), tc('2 942,00 ₽'))}
      ${tr(tc('Пет', ''), tc('400'), tc('120,5%'), tc('2 000'))}
      ${tr(tc('Сидоров Сидор'), tc('1 200', '<w:gridSpan w:val="2"/>'), tc('5 000'))}
      ${tr(tc('Итого'), tc('2 186'), tc(''), tc(''))}
    </w:tbl>
    ${p(t('Подпись'))}</w:body></w:document>`;
  // Word режет слова на куски: «Пет» + «ров Пётр»
  const xml2 = xml.replace(`${t('Пет')}`, `${t('Пет')}<w:r><w:t>ров Пётр</w:t></w:r>`);
  const tabs = R.fromDocx(xml2);
  assert.equal(tabs.length, 1);
  const rows = tabs[0].rows;
  assert.equal(tabs[0].date, '2026-10-29');
  assert.deepEqual(rows.map((r) => r.name), ['Евгеньев Евгений Иванович', 'Петров Пётр', 'Сидоров Сидор']);
  assert.equal(rows[0].lines, 586); assert.equal(rows[0].prod, 145.54); assert.equal(rows[0].actual, 2942);
  assert.equal(rows[0].date, '2026-10-29');
  assert.equal(rows[2].lines, 1200); assert.equal(rows[2].prod, null);   // объединённая ячейка — пустая рядом
  // дата прямо в шапке таблицы
  const xml3 = xml.replace(p(t('Отчёт по производительности за '), t('29.10.2026')), p(t('Дата: 30.10.2026')));
  assert.equal(R.fromDocx(xml3)[0].date, '2026-10-30');
});

test('Word (.docx): настоящий файл отчёта', () => {
  const { unzipSync, strFromU8 } = require('fflate');
  const buf = require('fs').readFileSync(require('path').join(__dirname, 'fixtures', 'report.docx'));
  const xml = strFromU8(unzipSync(new Uint8Array(buf), { filter: (f) => f.name === 'word/document.xml' })['word/document.xml']);
  const [t] = R.fromDocx(xml);
  assert.equal(t.date, '2026-10-29');
  assert.deepEqual(t.rows.map((r) => [r.name, r.lines, r.prod, r.actual]), [['Петров Иван Ильич', 300, 120, 1500], ['Евгеньев Евгений Иванович', 586, 145.54, 2942]]);
});

test('таблица из Excel с буквами столбцов вместо названий («№ | ФИО | C | D …»)', () => {
  const L = ['№', 'ФИО', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'];
  const row = (n, fio, prod, lines, total) => [n, fio, prod, '13,47%', '7', '8', lines, '3', '2 226,74', '112', '0,00', total, '0,00 ₽', total];
  const t = R.fromGrid([['Склад А'], L, row('9', 'Петров Пётр Петрович', '148,93%', '773', '3 988,68 ₽'), row('10', 'Иванова Анна Сергеевна', '96,90%', '465', '2 399,40 ₽'), row('29', 'Общий итог', '102,39%', '8 164', '41 142,58 ₽')]);
  assert.deepEqual(t.rows.map((r) => [r.name, r.lines, r.prod, r.actual]), [['Петров Пётр Петрович', 773, 148.93, 3988.68], ['Иванова Анна Сергеевна', 465, 96.9, 2399.4]]);
  // буквы есть, но данные не похожи на складской отчёт — не угадываем
  assert.equal(R.fromGrid([L, ['1', 'Петров Пётр', 'текст', 'x', 'y', 'z', 'не число', '', '', '', '', '', '', '']]), null);
});
