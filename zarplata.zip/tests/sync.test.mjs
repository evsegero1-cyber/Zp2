// Тесты логики синхронизации (src/cloud/sync-core.js): два устройства и облако без Firebase.
import test from 'node:test';
import assert from 'node:assert/strict';
import { splitState, joinState, diffLocal, applyRemote, hasLocalData, isEmptyCloud, same } from '../src/cloud/sync-core.js';

const e = (lines, t) => ({ lines, rate: 5, actual: null, updatedAt: t });
const st = (entries, settings = { target: 70000 }) => ({ version: 1, settings, entries, months: {}, marks: {}, payouts: {} });

// Облако: {doc, docUpdatedAt, entries}
function makeCloud() { return { doc: null, docUpdatedAt: 0, entries: {} }; }
// Устройство: локальное состояние + база
function makeDevice(state) { return { state, base: null, docTime: 0 }; }
function push(dev, cloud, now) {
  const d = diffLocal(splitState(dev.state), dev.base);
  for (const [k, v] of Object.entries(d.upserts)) cloud.entries[k] = JSON.parse(JSON.stringify(v));
  for (const k of d.deletes) delete cloud.entries[k];
  if (d.doc) { cloud.doc = JSON.parse(JSON.stringify(d.doc)); cloud.docUpdatedAt = now; dev.docTime = now; }
  dev.base = { doc: cloud.doc, entries: JSON.parse(JSON.stringify(cloud.entries)) };
  return d.count;
}
function pull(dev, cloud) {
  const r = applyRemote(splitState(dev.state), dev.base, cloud, dev.docTime);
  dev.state = joinState(dev.state, r.part); dev.base = r.base;
  return r.changed;
}

test('первая загрузка и вход со второго устройства', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({ '2026-11-02': e(1000, 1), '2026-11-03': e(1100, 2) }));
  assert.ok(isEmptyCloud(cloud) && hasLocalData(A.state));
  assert.equal(push(A, cloud, 10), 3); // 2 дня + документ
  const B = makeDevice(st({}));
  B.base = { doc: null, entries: {} };
  assert.ok(pull(B, cloud));
  assert.deepEqual(Object.keys(B.state.entries).sort(), ['2026-11-02', '2026-11-03']);
  assert.equal(B.state.settings.target, 70000);
  assert.equal(push(B, cloud, 11), 0); // нечего отправлять
});

test('правки разных дней на двух устройствах объединяются', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({ '2026-11-02': e(1000, 1) })); push(A, cloud, 1);
  const B = makeDevice(st({})); B.base = { doc: null, entries: {} }; pull(B, cloud);
  A.state.entries['2026-11-03'] = e(900, 5);           // A добавил день (офлайн)
  B.state.entries['2026-11-02'] = e(1200, 6);          // B поправил другой день
  push(B, cloud, 6);
  pull(A, cloud);                                      // A получил правку B, свой день сохранил
  assert.equal(A.state.entries['2026-11-02'].lines, 1200);
  assert.equal(A.state.entries['2026-11-03'].lines, 900);
  assert.equal(push(A, cloud, 7), 1);                  // и отправил его
  pull(B, cloud);
  assert.ok(same(A.state.entries, B.state.entries));
});

test('удаление дня на одном устройстве удаляет его на другом', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({ '2026-11-02': e(1000, 1), '2026-11-03': e(900, 1) })); push(A, cloud, 1);
  const B = makeDevice(st({})); B.base = { doc: null, entries: {} }; pull(B, cloud);
  delete A.state.entries['2026-11-03']; push(A, cloud, 2);
  pull(B, cloud);
  assert.deepEqual(Object.keys(B.state.entries), ['2026-11-02']);
});

test('один день изменён на обоих устройствах — побеждает более свежая запись', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({ '2026-11-02': e(1000, 1) })); push(A, cloud, 1);
  const B = makeDevice(st({})); B.base = { doc: null, entries: {} }; pull(B, cloud);
  A.state.entries['2026-11-02'] = e(1100, 50);
  B.state.entries['2026-11-02'] = e(1300, 60);         // позже
  push(A, cloud, 50);
  pull(B, cloud);
  assert.equal(B.state.entries['2026-11-02'].lines, 1300);
  push(B, cloud, 60); pull(A, cloud);
  assert.equal(A.state.entries['2026-11-02'].lines, 1300);
});

test('удаление против правки: правка не теряется', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({ '2026-11-02': e(1000, 1) })); push(A, cloud, 1);
  const B = makeDevice(st({})); B.base = { doc: null, entries: {} }; pull(B, cloud);
  delete A.state.entries['2026-11-02']; push(A, cloud, 5);
  B.state.entries['2026-11-02'] = e(1500, 6);           // B правил офлайн
  pull(B, cloud);
  assert.equal(B.state.entries['2026-11-02'].lines, 1500);
});

test('настройки: меняются целиком, своя несинхронизированная правка не затирается', () => {
  const cloud = makeCloud();
  const A = makeDevice(st({}, { target: 70000 })); push(A, cloud, 1);
  const B = makeDevice(st({}, { target: 1 })); B.base = { doc: null, entries: {} };
  B.base = { doc: cloud.doc, entries: {} }; B.state.settings = { target: 70000 };
  A.state.settings = { target: 80000 }; push(A, cloud, 10);
  pull(B, cloud);
  assert.equal(B.state.settings.target, 80000);
  B.state.settings = { target: 90000 };                // правка B ещё не отправлена
  pull(B, cloud);                                      // пришёл тот же снимок
  assert.equal(B.state.settings.target, 90000);
  push(B, cloud, 20); pull(A, cloud);
  assert.equal(A.state.settings.target, 90000);
});

test('пустое устройство: нечего переносить', () => {
  const def = st({});
  assert.equal(hasLocalData(def, def), false);
  assert.equal(hasLocalData(st({}, { target: 1 }), def), true);
  assert.equal(hasLocalData({ ...def, marks: { '2026-11-02': 'off' } }, def), true);
});
