// Проверка в движке Safari (WebKit, эмуляция iPhone 15) — запускается в GitHub Actions.
// Это движок Safari под Linux, а не настоящий iPhone: вёрстка, ввод, IndexedDB, вход и синхронизация — те же.
import { webkit, devices } from 'playwright';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';

const URL = process.env.APP_URL || 'http://127.0.0.1:5050/';
const SHOTS = process.env.SHOTS || '/tmp/e2e-shots';
mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];
const report = [];

async function phone(browser, name) {
  const ctx = await browser.newContext({ ...devices['iPhone 15'], locale: 'ru-RU' });
  const p = await ctx.newPage();
  // Сетевые сообщения о закрытых соединениях Firestore и предупреждение о viewport — служебный шум WebKit, не ошибки приложения
  const noise = /PERMISSION_DENIED|Failed to load resource|favicon|WebChannel|Fetch API cannot load|access control checks|interactive-widget|google\.firestore\.v1/i;
  p.on('pageerror', (e) => { if (!noise.test(e.message)) errors.push(`${name}: ${e.message}`); });
  p.on('console', (m) => { if (m.type() === 'error' && !noise.test(m.text())) errors.push(`${name}: ${m.text()}`); });
  await p.goto(URL, { waitUntil: 'load' });
  await p.waitForFunction(() => window.Cloud && window.Cloud.ready, null, { timeout: 20000 });
  return { ctx, p };
}
const tap = (p, sel) => p.evaluate((s) => document.querySelector(s).click(), sel);

const browser = await webkit.launch();
let step = 'старт';
try {
  const { ctx, p } = await phone(browser, 'iPhone');
  // 1. Вёрстка: на каждой вкладке нет горизонтальной прокрутки
  step = 'вёрстка';
  await p.evaluate(() => { localStorage.setItem('zarplata2027:v1', JSON.stringify({ settings: {}, entries: { '2026-11-02': { lines: 1000, rate: 5, updatedAt: 1 } } })); });
  await p.reload({ waitUntil: 'load' }); await p.waitForFunction(() => window.Cloud && window.Cloud.ready);
  for (const t of ['home', 'cal', 'stats', 'crew', 'settings']) {
    await tap(p, `.tabbar [data-tab="${t}"]`); await sleep(500);
    const m = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, w: window.innerWidth }));
    report.push(`вкладка ${t}: ширина ${m.sw}/${m.w}`);
    assert.ok(m.sw <= m.w + 1, `горизонтальная прокрутка на вкладке ${t}: ${m.sw} > ${m.w}`);
    await p.screenshot({ path: `${SHOTS}/webkit-${t}.png` });
  }
  await tap(p, '[data-act="sub-success"]').catch(() => {});
  // 2. Поля ввода ≥ 16px (иначе Safari увеличивает страницу при касании)
  step = 'поля ввода';
  const small = async () => p.evaluate(() => [...document.querySelectorAll('.sheet.show input:not([type=checkbox]):not([type=file]):not([hidden]), .sheet.show select, .sheet.show textarea, .view.active input:not([type=checkbox]):not([type=file]), .view.active select')]
    .filter((e) => e.offsetParent && parseFloat(getComputedStyle(e).fontSize) < 16).map((e) => '#' + (e.id || e.className)));
  await tap(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  let bad = await small(); assert.deepEqual(bad, [], 'мелкие поля в профиле: ' + bad);
  await p.evaluate(() => __app.openDay('2026-11-03')); await sleep(500);
  bad = await small(); assert.deepEqual(bad, [], 'мелкие поля в форме смены: ' + bad);
  await p.evaluate(() => { const i = document.querySelector('#f-lines'); i.value = '1200'; i.form.requestSubmit(); }); await sleep(400);
  // 3. Регистрация в Safari
  step = 'регистрация';
  await tap(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await tap(p, '[data-act="acc-register"]'); await sleep(500);
  bad = await small(); assert.deepEqual(bad, [], 'мелкие поля во входе: ' + bad);
  await p.fill('#a-name', 'Сафари'); await p.fill('#a-nick', 'safari_user'); await p.fill('#a-email', 'safari@test.ru'); await p.fill('#a-pass', 'secret123');
  await tap(p, '#a-submit');
  await p.waitForFunction(() => window.Cloud.account.profile && window.Cloud.sync.status === 'synced', null, { timeout: 25000 });
  await p.screenshot({ path: `${SHOTS}/webkit-account.png` });
  // 4. Вход сохраняется после перезапуска (IndexedDB)
  step = 'повторное открытие';
  await p.reload({ waitUntil: 'load' });
  await p.waitForFunction(() => window.Cloud && window.Cloud.account && window.Cloud.account.user, null, { timeout: 20000 });
  report.push('вход сохранился после перезапуска');
  // 5. Второй iPhone: вход → смены пришли
  step = 'второй iPhone';
  const two = await phone(browser, 'iPhone-2');
  await tap(two.p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await tap(two.p, '[data-act="acc-login"]'); await sleep(500);
  await two.p.fill('#a-email', 'safari@test.ru'); await two.p.fill('#a-pass', 'secret123'); await tap(two.p, '#a-submit');
  await two.p.waitForFunction(() => Object.keys(__app.state.entries).length === 2, null, { timeout: 25000 });
  report.push('смены синхронизировались между двумя «iPhone»');
  // 6. Рейтинг и графики сравнения в Safari
  step = 'сборщики';
  await p.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: true }));
  await p.waitForFunction(() => window.Cloud.social.my && window.Cloud.social.my.totals.lines === 2200 && !window.Cloud.social.progress, null, { timeout: 25000 });
  await tap(two.p, '.tabbar [data-tab="crew"]'); await sleep(500);
  await two.p.evaluate(() => document.querySelector('#rk-period [data-k="all"]').click()); // смены теста — прошлой недели
  await two.p.waitForSelector('.pod', { timeout: 20000 });
  await two.p.screenshot({ path: `${SHOTS}/webkit-rank.png` });
  const uid = await p.evaluate(() => window.Cloud.account.user.uid);
  await two.p.evaluate(() => document.querySelector('[data-crew-sub="compare"]').click()); await sleep(1500);
  report.push('графики Chart.js: ' + (await two.p.evaluate(() => document.querySelectorAll('#cmp-out canvas').length)) + ' (сравнение с собой не добавляется)');
  assert.ok(await two.p.evaluate(() => typeof window.Chart === 'function'), 'Chart.js загрузился в Safari');
  assert.ok(uid);
  // 7. Без сети приложение открывается (service worker) и сохраняет смену
  step = 'без сети';
  await sleep(1500);
  const sw = await p.evaluate(() => navigator.serviceWorker && navigator.serviceWorker.controller ? 'есть' : 'нет');
  report.push('service worker: ' + sw);
  if (sw === 'есть') {
    await ctx.setOffline(true);
    await p.reload({ waitUntil: 'load' }).catch(() => {});
    const ok = await p.evaluate(() => !!document.querySelector('.tabbar') && Object.keys(__app.state.entries).length >= 2).catch(() => false);
    report.push('открытие без сети: ' + (ok ? 'работает' : 'НЕ работает'));
    assert.ok(ok, 'приложение не открылось без сети');
    await ctx.setOffline(false);
  }
  assert.deepEqual(errors, [], 'ошибки в консоли Safari: ' + errors.join('; '));
  console.log('✔ Safari (WebKit, iPhone 15):\n  ' + report.join('\n  '));
} catch (e) {
  console.error(`✖ Safari, шаг «${step}»: ${e.message}\n  ${report.join('\n  ')}`);
  if (errors.length) console.error('Ошибки консоли:\n' + errors.join('\n'));
  process.exitCode = 1;
} finally {
  await browser.close();
}
