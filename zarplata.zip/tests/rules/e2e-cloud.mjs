// Сквозная проверка входа и синхронизации с настоящим Firebase (локальный эмулятор Auth + Firestore).
// Три «устройства» = три изолированных профиля браузера. Запуск — в GitHub Actions (web.yml).
import puppeteer from 'puppeteer-core';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

const URL = process.env.APP_URL || 'http://127.0.0.1:5050/';
const SHOTS = process.env.SHOTS || '/tmp/e2e-shots';
mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];

async function device(browser, name, entries) {
  const ctx = await browser.createBrowserContext();
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push(`${name}: ${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error' && !/PERMISSION_DENIED|ERR_CONNECTION_REFUSED|ERR_INTERNET_DISCONNECTED|Could not reach Cloud Firestore|WebChannelConnection|favicon|Failed to load resource: the server responded with a status of 40[039]/.test(m.text())) errors.push(`${name}: ${m.text()}`); });
  await p.setViewport({ width: 393, height: 852, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.goto(URL, { waitUntil: 'load' });
  await p.evaluate((ent) => { localStorage.clear(); if (ent) localStorage.setItem('zarplata2027:v1', JSON.stringify({ settings: {}, entries: ent })); }, entries);
  await p.reload({ waitUntil: 'load' });
  await waitFor(p, () => window.Cloud && window.Cloud.ready && window.Cloud.configured, 'облако загрузилось');
  p.shot = (n) => p.screenshot({ path: `${SHOTS}/${name}-${n}.png` });
  return p;
}
async function waitFor(p, fn, what, ms = 20000, arg) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { if (await p.evaluate(fn, arg)) return; } catch {}
    await sleep(250);
  }
  throw new Error('Не дождались: ' + what);
}
const click = (p, sel) => p.evaluate((s) => { const el = document.querySelector(s); if (!el) throw new Error('нет ' + s); el.click(); }, sel);
const clickText = (p, sel, text) => p.evaluate((s, t) => { const el = [...document.querySelectorAll(s)].find((x) => x.textContent.trim().startsWith(t)); if (!el) throw new Error('нет кнопки ' + t); el.click(); }, sel, text);
async function fill(p, sel, v) { await p.$eval(sel, (e) => (e.value = '')); await p.type(sel, v); }
const days = (p) => p.evaluate(() => Object.keys(__app.state.entries).sort());

async function openAuth(p, mode) {
  await click(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await click(p, `[data-act="acc-${mode}"]`); await sleep(400);
}
async function addShift(p, key, lines) {
  await p.evaluate((k) => __app.openDay(k), key); await sleep(400);
  await p.evaluate((l) => { const i = document.querySelector('#f-lines'); i.value = String(l); i.form.requestSubmit(); }, lines);
  await sleep(300);
}
// Запись «от имени сервера» (эмулятор пропускает правила с токеном owner) — открыть доступ к чату до появления администратора
async function ownerSet(path, fields) {
  const r = await fetch(`http://127.0.0.1:8080/v1/projects/demo-zarplata/databases/(default)/documents/${path}`, {
    method: 'PATCH', headers: { Authorization: 'Bearer owner', 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }) });
  if (!r.ok) throw new Error('ownerSet ' + r.status + ' ' + (await r.text()));
}
const grantChat = (uid) => ownerSet(`chatAccess/${uid}`, { at: { timestampValue: new Date().toISOString() } });
const synced = (p) => waitFor(p, () => window.Cloud.sync.status === 'synced', 'синхронизировано');

const EMAIL = 'picker@test.ru', PASS = 'secret123';
const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--lang=ru-RU', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'], headless: 'new' });
let step = 'старт';
try {
  // 1. Устройство A: две смены без аккаунта → регистрация → смены уходят в облако
  step = 'регистрация на A';
  const A = await device(browser, 'A', { '2026-11-02': { lines: 1000, rate: 5, updatedAt: 1 }, '2026-11-03': { lines: 1200, rate: 5, updatedAt: 1 } });
  await openAuth(A, 'register');
  await fill(A, '#a-name', 'Евгений'); await fill(A, '#a-nick', 'evgen_picker'); await fill(A, '#a-email', EMAIL); await fill(A, '#a-pass', PASS);
  await click(A, '#a-submit');
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль создан');
  await synced(A);
  await A.shot('1-registered');
  assert.match(await A.$eval('#view-settings .acc-card', (e) => e.innerText), /@evgen_picker/);

  // 2. Устройство B: пустое → вход → получает смены A
  step = 'вход на B';
  const B = await device(browser, 'B');
  await openAuth(B, 'login');
  await fill(B, '#a-email', EMAIL); await fill(B, '#a-pass', PASS); await click(B, '#a-submit');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 2, 'смены A появились на B');
  assert.deepEqual(await days(B), ['2026-11-02', '2026-11-03']);
  await B.shot('2-login');

  // 3. B добавляет смену → она появляется на A без перезагрузки
  step = 'B → A';
  await addShift(B, '2026-11-04', 1350);
  await waitFor(A, () => __app.state.entries['2026-11-04'] && __app.state.entries['2026-11-04'].lines === 1350, 'смена B дошла до A');

  // 4. A правит смену → правка доходит до B
  step = 'A → B';
  await addShift(A, '2026-11-02', 1111);
  await waitFor(B, () => __app.state.entries['2026-11-02'].lines === 1111, 'правка A дошла до B');

  // 5. Устройство C со своими данными → вход → выбор «Объединить» → у всех 4 смены
  step = 'объединение на C';
  const C = await device(browser, 'C', { '2026-11-05': { lines: 900, rate: 5, updatedAt: 5 } });
  await openAuth(C, 'login');
  await fill(C, '#a-email', EMAIL); await fill(C, '#a-pass', PASS); await click(C, '#a-submit');
  await waitFor(C, () => document.querySelector('#dialog.show') && /Данные есть/.test(document.querySelector('#dialog').innerText), 'диалог выбора');
  await C.shot('3-choice');
  await clickText(C, '#dialog button', 'Объединить');
  await waitFor(C, () => Object.keys(__app.state.entries).length === 4, 'на C 4 смены');
  await waitFor(A, () => Object.keys(__app.state.entries).length === 4, 'на A 4 смены');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 4, 'на B 4 смены');
  assert.ok(await C.evaluate(() => !!localStorage.getItem('zarplata2027:backup-before-sync')), 'копия до объединения сохранена');

  // 6. Удаление смены на A → исчезает на B
  step = 'удаление';
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-05']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-05'], 'удаление дошло до B');

  // 6б. Без сети: смена вносится, приложение перезапускается офлайн (профиль и смена на месте), потом сеть — смена доходит до B
  step = 'офлайн';
  const net = await A.createCDPSession(); await net.send('Network.enable');
  const offline = (on) => net.send('Network.emulateNetworkConditions', { offline: on, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
  await offline(true);
  await waitFor(A, () => !navigator.onLine, 'A без сети');
  await addShift(A, '2026-11-07', 444);
  await waitFor(A, () => window.Cloud.sync.status === 'offline', 'статус «нет сети»');
  const swOk = await A.evaluate(() => !!(navigator.serviceWorker && navigator.serviceWorker.controller));
  await A.reload({ waitUntil: 'load' }).catch((e) => console.log('reload:', e.message));   // перезапуск без интернета — из кэша приложения
  try { await waitFor(A, () => window.Cloud && window.Cloud.ready && window.Cloud.account.authReady && window.Cloud.account.user, 'вход восстановлен без сети'); }
  catch (e) {
    console.log('ДИАГНОСТИКА офлайн:', 'sw до перезапуска', swOk, JSON.stringify(await A.evaluate(() => ({ url: location.href, cloud: !!window.Cloud, ready: window.Cloud && window.Cloud.ready, err: window.Cloud && window.Cloud.error,
      authReady: window.Cloud && window.Cloud.account && window.Cloud.account.authReady, user: !!(window.Cloud && window.Cloud.account && window.Cloud.account.user),
      sw: !!(navigator.serviceWorker && navigator.serviceWorker.controller), app: !!window.__app, body: document.body ? document.body.innerText.slice(0, 200) : '' })).catch((x) => 'eval: ' + x.message)));
    console.log('ошибки:', errors.slice(-8).join(' | '));
    throw e;
  }
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль без сети');
  assert.equal(await A.evaluate(() => __app.state.entries['2026-11-07'] && __app.state.entries['2026-11-07'].lines), 444);
  assert.equal(await A.evaluate(() => !!document.getElementById('net-banner')), true, 'плашка «нет сети»');
  await A.shot('offline');
  await sleep(1500);
  assert.equal(await B.evaluate(() => !!__app.state.entries['2026-11-07']), false, 'без сети смена ещё не ушла');
  await offline(false);
  await waitFor(B, () => __app.state.entries['2026-11-07'] && __app.state.entries['2026-11-07'].lines === 444, 'после появления сети смена дошла до B', 30000);
  await synced(A);
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-07']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-07'], 'удаление после офлайна дошло до B');

  // 7. Второй пользователь не может взять тот же ник
  step = 'занятый ник';
  const D = await device(browser, 'D');
  await openAuth(D, 'register');
  await fill(D, '#a-name', 'Другой'); await fill(D, '#a-nick', 'evgen_picker'); await fill(D, '#a-email', 'other@test.ru'); await fill(D, '#a-pass', PASS);
  await click(D, '#a-submit');
  await waitFor(D, () => document.querySelector('#pe-form'), 'предложено выбрать другой ник');
  await fill(D, '#pe-nick', 'other_picker'); await D.evaluate(() => document.querySelector('#pe-form').requestSubmit());
  await waitFor(D, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'other_picker', 'второй профиль создан', 20000)
    .catch(async (e) => { throw new Error(e.message + ' — ошибка формы: ' + (await D.evaluate(() => (document.querySelector('#pe-error') || {}).textContent))); });
  assert.equal(await D.evaluate(() => window.Cloud.account.profile.name), 'Другой', 'имя из регистрации сохранилось');
  await D.shot('4-second-user');

  // 7б. Рейтинг и публичная статистика с настоящими правилами базы
  step = 'публикация статистики';
  const aUid = await A.evaluate(() => window.Cloud.account.user.uid);
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: false }));
  await waitFor(A, () => window.Cloud.social.my && window.Cloud.social.my.visible && window.Cloud.social.my.totals.lines === 3661 && !window.Cloud.social.progress, 'статистика A опубликована (3661 линия)');
  await D.evaluate(() => { window.__lb = null; window.__lbStop = window.Cloud.social.watchLeaderboard({ period: 'all', metric: 'lines' }, (e, rows) => { window.__lb = e ? { error: String(e.message || e) } : rows; }); });
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 3661 && r.totals.days === 3), 'D видит A в рейтинге', 20000, aUid);
  let pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => ({ vis: !!x.stats, earn: x.stats && x.stats.totals.earn })), aUid);
  assert.deepEqual(pub, { vis: true, earn: 0 }, 'заработок скрыт');
  let dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.deepEqual(Object.keys(dd).sort(), ['2026-11-02', '2026-11-03', '2026-11-04']);
  assert.ok(Object.values(dd).every((x) => x.earn === 0 && Object.keys(x).sort().join() === 'earn,lines'), 'в публичных днях только линии');
  step = 'заработок';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: true }));
  await waitFor(A, () => window.Cloud.social.my.showEarn && window.Cloud.social.my.totals.earn === 3661 * 5 && !window.Cloud.social.progress, 'заработок опубликован');
  dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.equal(dd['2026-11-02'].earn, 1111 * 5);
  step = 'новая смена → рейтинг';
  await addShift(A, '2026-11-06', 1500);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 5161 && r.totals.best === 1500), 'рейтинг обновился сам', 30000, aUid);
  await D.shot('5-leaderboard');

  // 8. Смена ника на A освобождает старый
  step = 'смена ника';
  await A.evaluate(() => window.Cloud.account.updateProfile({ nick: 'evgen_new' }));
  await waitFor(A, () => window.Cloud.account.profile.nick === 'evgen_new', 'ник изменён');
  assert.equal(await D.evaluate(() => window.Cloud.account.isNickFree('evgen_picker')), true);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.nick === 'evgen_new'), 'новый ник в рейтинге', 20000, aUid);
  step = 'скрытие статистики';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: false }));
  await waitFor(D, (id) => Array.isArray(window.__lb) && !window.__lb.some((r) => r.uid === id), 'A пропал из рейтинга', 20000, aUid);
  pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => !!x.stats), aUid);
  assert.equal(pub, false);
  assert.equal(await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30').then(() => 'прочитал', () => 'нет доступа'), aUid), 'нет доступа');
  await D.evaluate(() => window.__lbStop());

  // 8б. Чат: сообщения, ответ, реакция, «прочитано», фото, правка, удаление, непрочитанные
  step = 'чат';
  const openChat = async (p) => { await click(p, '.tabbar [data-tab="crew"]'); await sleep(400); await click(p, '[data-crew-sub="chat"]'); await sleep(500); };
  const say = async (p, text) => { await fill(p, '#chat-text', text); await p.evaluate(() => document.querySelector('#chat-compose').requestSubmit()); };
  const dUid0 = await D.evaluate(() => window.Cloud.account.user.uid);
  // без одобрения администратора чат закрыт
  await openChat(D);
  await waitFor(D, () => /Ждём одобрения администратора/.test(document.querySelector('#chat-list').innerText), 'D ждёт одобрения');
  assert.equal(await D.evaluate(() => document.querySelector('#chat-compose').hidden), true);
  await grantChat(aUid);
  await openChat(A); await waitFor(A, () => window.Cloud.chat.access === 'ok', 'A получил доступ'); await say(A, 'Привет из A');
  await grantChat(dUid0);
  await waitFor(D, () => window.Cloud.chat.access === 'ok', 'D получил доступ без перезагрузки');
  await waitFor(D, () => [...document.querySelectorAll('.m-text')].some((x) => x.textContent === 'Привет из A'), 'D получил сообщение');
  await waitFor(A, () => document.querySelector('.msg.me .st.read'), 'у A «прочитано» ✓✓');
  // D отвечает на сообщение A через меню
  await D.evaluate(() => [...document.querySelectorAll('.bubble')].find((b) => b.textContent.includes('Привет из A')).click()); await sleep(400);
  await click(D, '[data-a="reply"]'); await sleep(300);
  await say(D, 'Ответ от D');
  await waitFor(A, () => [...document.querySelectorAll('.msg')].some((m) => m.querySelector('.m-reply') && m.textContent.includes('Ответ от D')), 'ответ с цитатой у A');
  // A ставит реакцию на ответ D
  await A.evaluate(() => [...document.querySelectorAll('.bubble')].find((b) => b.textContent.includes('Ответ от D')).click()); await sleep(400);
  await A.evaluate(() => document.querySelector('[data-pick="🔥"]').click());
  await waitFor(D, () => [...document.querySelectorAll('.rx')].some((r) => r.textContent.includes('🔥')), 'D видит реакцию');
  // фото
  await A.evaluate(async () => {
    const c = document.createElement('canvas'); c.width = 1600; c.height = 1200; const g = c.getContext('2d');
    for (let i = 0; i < 40; i++) { g.fillStyle = `hsl(${i * 9},70%,50%)`; g.fillRect(i * 40, 0, 40, 1200); }
    const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
    const img = await window.Cloud.util.chatPhoto(new File([blob], 'x.png', { type: 'image/png' }));
    window.__imgLen = img.length;
    const p = window.Cloud.account.profile;
    await window.Cloud.chat.send({ text: 'Фото со склада', image: img, name: p.name, nick: p.nick });
  });
  await waitFor(D, () => document.querySelector('.m-img'), 'D видит фото', 25000);
  const imgLen = await A.evaluate(() => window.__imgLen);
  assert.ok(imgLen < 300000, 'фото сжато: ' + imgLen);
  // правка и удаление
  const firstId = await A.evaluate(() => window.Cloud.chat.messages.find((m) => m.text === 'Привет из A').id);
  await A.evaluate((id) => window.Cloud.chat.edit(id, 'Привет из A (исправлено)'), firstId);
  await waitFor(D, () => [...document.querySelectorAll('.m-text')].some((x) => x.textContent === 'Привет из A (исправлено)'), 'правка дошла');
  await A.evaluate((id) => window.Cloud.chat.remove(id), firstId);
  await waitFor(D, () => [...document.querySelectorAll('.bubble.deleted')].length === 1, 'удаление дошло');
  // упоминание: A пишет @other_picker — у D сообщение подсвечено
  await say(A, '@other_picker глянь фото');
  await waitFor(D, () => document.querySelector('.bubble.mentioned .mention.me'), 'D видит, что его упомянули');
  assert.deepEqual(await A.evaluate(() => window.Cloud.chat.messages.find((m) => m.text.startsWith('@other_picker')).mentions), [dUid0]);
  // голосовое: запись с микрофона (тестовое устройство Chrome) → D видит плеер
  await waitFor(A, () => { const m = document.querySelector('#chat-mic'); return m && !m.hidden; }, 'кнопка микрофона');
  await click(A, '#chat-mic');
  await waitFor(A, () => !document.querySelector('#chat-rec').hidden, 'идёт запись');
  await sleep(1800);
  await click(A, '#rec-send');
  await waitFor(D, () => document.querySelector('.m-voice'), 'D получил голосовое', 25000);
  const voice = await D.evaluate(() => { const m = window.Cloud.chat.messages.find((x) => x.audio); return { pre: m.audio.slice(0, 11), d: m.duration, len: m.audio.length }; });
  assert.equal(voice.pre, 'data:audio/'); assert.ok(voice.d >= 1 && voice.d < 5, 'длительность ' + voice.d);
  // непрочитанные: D ушёл из чата, A пишет
  await click(D, '.tabbar [data-tab="home"]'); await sleep(400);
  await say(A, 'Ещё одно');
  await waitFor(D, () => { const b = document.querySelector('.tabbar [data-tab="crew"] .tab-badge'); return b && b.textContent === '1'; }, 'значок «1 непрочитанное» у D')
    .catch(async (e) => { throw new Error(e.message + ' | ' + JSON.stringify(await D.evaluate(() => { const c = window.Cloud.chat, me = window.Cloud.account.user.uid;
      return { badge: (document.querySelector('.tabbar .tab-badge') || {}).textContent || null, unread: c.unread, active: c.active, hidden: document.hidden, lastRead: (c.members[me] || {}).lastRead,
        msgs: c.messages.map((m) => [m.text.slice(0, 12), m.uid === me, m.deleted, m.createdAt]) }; })) + ' | A: ' + JSON.stringify(await A.evaluate(() => window.Cloud.chat.messages.map((m) => m.text.slice(0, 12))))); });
  await A.shot('6-chat');

  // 8в. Администратор: почта evsegero.one@gmail.com → подтверждение → панель → блокировка
  step = 'администратор';
  const E = await device(browser, 'E');
  await openAuth(E, 'register');
  await fill(E, '#a-name', 'Сергей'); await fill(E, '#a-nick', 'sergey_admin'); await fill(E, '#a-email', 'evsegero.one@gmail.com'); await fill(E, '#a-pass', PASS);
  await click(E, '#a-submit');
  await waitFor(E, () => window.Cloud.account.profile, 'профиль администратора');
  await click(E, '.tabbar [data-tab="settings"]'); await sleep(500);
  await waitFor(E, () => document.querySelector('[data-act="adm-verify"]'), 'карточка «подтвердите почту»');
  await click(E, '[data-act="adm-verify"]'); await sleep(1500);
  const codes = await (await fetch('http://127.0.0.1:9099/emulator/v1/projects/demo-zarplata/oobCodes')).json();
  const link = codes.oobCodes.filter((c) => c.email === 'evsegero.one@gmail.com' && c.requestType === 'VERIFY_EMAIL').pop().oobLink;
  await fetch(link);
  await click(E, '[data-act="adm-verified"]');
  await waitFor(E, () => document.querySelector('[data-act="adm-open"]'), 'права администратора включились');
  await click(E, '[data-act="adm-open"]');
  await waitFor(E, () => document.querySelectorAll('[data-adm]').length >= 3, 'список сборщиков в панели');
  await E.shot('7-admin');
  const dUid = await D.evaluate(() => window.Cloud.account.user.uid);
  await E.evaluate((id) => window.Cloud.admin.ban(id, 'other_picker', 'проверка'), dUid);
  await openChat(D);
  await waitFor(D, () => /Доступ к чату закрыт/.test(document.querySelector('#chat-list').innerText), 'заблокированный не видит чат');
  await E.evaluate((id) => window.Cloud.admin.unban(id), dUid);
  await waitFor(D, () => [...document.querySelectorAll('.m-text')].some((x) => x.textContent === 'Ещё одно'), 'после разблокировки чат вернулся');
  // доступ к чату: закрыть и открыть снова
  await E.evaluate((id) => window.Cloud.admin.revokeChat(id), dUid);
  await waitFor(D, () => /Ждём одобрения/.test(document.querySelector('#chat-list').innerText), 'доступ закрыт администратором');
  await E.evaluate((id) => window.Cloud.admin.grantChat(id), dUid);
  await waitFor(D, () => [...document.querySelectorAll('.m-text')].some((x) => x.textContent === 'Ещё одно'), 'доступ открыт снова');

  // 8г. Отчёт склада: ФИО только у администратора → Excel → строка сборщика → данные сами вносятся в смену A
  step = 'отчёт склада';
  await E.evaluate((id) => window.Cloud.admin.setNote(id, { fio: 'Евгеньев Евгений Иванович', fields: { lines: true, prod: true, actual: true } }), aUid);
  await click(E, '[data-close]'); await sleep(500);
  await click(E, '[data-act="adm-open"]');
  await waitFor(E, () => document.querySelector('#adm-report'), 'кнопка «Загрузить отчёт»');
  await click(E, '#adm-report'); await sleep(300);
  const inp = await E.$('#rp-file');
  await inp.uploadFile(join(import.meta.dirname, 'fixtures', 'report.xlsx'));
  await waitFor(E, (id) => { const v = document.querySelector(`.rp-card[data-u="${id}"] [data-val="lines"]`); return v && v.value === '586'; }, 'строка A найдена по ФИО', 25000, aUid);
  assert.equal(await E.evaluate(() => document.querySelector('#rp-date').value), '2026-10-29');
  assert.equal(await E.evaluate((id) => document.querySelector(`.rp-card[data-u="${id}"] [data-val="prod"]`).value, aUid), '145,54');
  await E.shot('8-report');
  await click(E, '#rp-send'); await sleep(400);
  await clickText(E, '#dialog button', 'Отправить');
  await waitFor(A, () => { const e = __app.state.entries['2026-10-29']; return e && e.lines === 586 && e.prod === 145.54 && e.actual === 2942; }, 'данные из отчёта внесены в смену A', 25000);
  await waitFor(E, (id) => /уже внесено/.test((document.querySelector(`.rp-card[data-u="${id}"]`) || {}).innerText || ''), 'администратор видит «уже внесено»', 25000, aUid)
    .catch(() => {}); // статус обновляется при следующем открытии — не обязателен
  await synced(A);
  // обычный пользователь не администратор
  assert.equal(await A.evaluate(() => window.Cloud.admin.isAdmin()), false);
  assert.equal(await A.evaluate(() => !!document.querySelector('.admin-card')), false);

  // 9. Выход на B с очисткой устройства; данные в облаке остаются
  step = 'выход';
  await click(B, '[data-act="acc-logout"]'); await sleep(400);
  await clickText(B, '#dialog button', 'Выйти и очистить');
  await waitFor(B, () => !window.Cloud.account.user && Object.keys(__app.state.entries).length === 0, 'B вышел и очистил данные');
  await sleep(500);
  assert.equal((await days(A)).length, 5); // + смена из отчёта

  // 10. Удаление аккаунта D
  step = 'удаление аккаунта';
  await D.evaluate((pw) => window.Cloud.account.deleteAccount(pw), PASS);
  await waitFor(D, () => !window.Cloud.account.user, 'аккаунт D удалён');
  assert.equal(await A.evaluate(() => window.Cloud.account.isNickFree('other_picker')), true);

  assert.deepEqual(errors, [], 'ошибки в консоли: ' + errors.join('; '));
  console.log('✔ Вход, регистрация, синхронизация трёх устройств, работа без сети и перезапуск офлайн, объединение, ники, рейтинг, публикация/скрытие статистики, чат (одобрение, ответы, реакции, фото, голосовые, упоминания, прочитано, правка, удаление, непрочитанные), админ-панель, блокировка и доступ к чату, отчёт склада из Excel, выход и удаление аккаунта работают');
} catch (e) {
  console.error(`✖ Шаг «${step}»: ${e.message}`);
  if (errors.length) console.error('Ошибки консоли:\n' + errors.join('\n'));
  for (const pg of await browser.pages()) { try { await pg.screenshot({ path: `${SHOTS}/fail-${Math.random().toString(36).slice(2, 6)}.png` }); } catch {} }
  process.exitCode = 1;
} finally {
  await browser.close();
}
