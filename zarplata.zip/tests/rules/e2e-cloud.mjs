// Сквозная проверка входа и синхронизации с настоящим Firebase (локальный эмулятор Auth + Firestore).
// Три «устройства» = три изолированных профиля браузера. Запуск — в GitHub Actions (web.yml).
import puppeteer from 'puppeteer-core';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';

const URL = process.env.APP_URL || 'http://127.0.0.1:5050/';
const SHOTS = process.env.SHOTS || '/tmp/e2e-shots';
mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];

async function device(browser, name, entries) {
  const ctx = await browser.createBrowserContext();
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push(`${name}: ${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error' && !/PERMISSION_DENIED|ERR_CONNECTION_REFUSED|favicon|Failed to load resource: the server responded with a status of 400/.test(m.text())) errors.push(`${name}: ${m.text()}`); });
  await p.setViewport({ width: 393, height: 852, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.goto(URL, { waitUntil: 'load' });
  await p.evaluate((ent) => { localStorage.clear(); if (ent) localStorage.setItem('zarplata2027:v1', JSON.stringify({ settings: {}, entries: ent })); }, entries);
  await p.reload({ waitUntil: 'load' });
  await waitFor(p, () => window.Cloud && window.Cloud.ready && window.Cloud.configured, 'облако загрузилось');
  p.shot = (n) => p.screenshot({ path: `${SHOTS}/${name}-${n}.png` });
  return p;
}
async function waitFor(p, fn, what, ms = 20000, arg) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { if (await p.evaluate(fn, arg)) return; } catch {}
    await sleep(250);
  }
  throw new Error('Не дождались: ' + what);
}
const click = (p, sel) => p.evaluate((s) => { const el = document.querySelector(s); if (!el) throw new Error('нет ' + s); el.click(); }, sel);
const clickText = (p, sel, text) => p.evaluate((s, t) => { const el = [...document.querySelectorAll(s)].find((x) => x.textContent.trim().startsWith(t)); if (!el) throw new Error('нет кнопки ' + t); el.click(); }, sel, text);
async function fill(p, sel, v) { await p.$eval(sel, (e) => (e.value = '')); await p.type(sel, v); }
const days = (p) => p.evaluate(() => Object.keys(__app.state.entries).sort());

async function openAuth(p, mode) {
  await click(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await click(p, `[data-act="acc-${mode}"]`); await sleep(400);
}
async function addShift(p, key, lines) {
  await p.evaluate((k) => __app.openDay(k), key); await sleep(400);
  await p.evaluate((l) => { const i = document.querySelector('#f-lines'); i.value = String(l); i.form.requestSubmit(); }, lines);
  await sleep(300);
}
const synced = (p) => waitFor(p, () => window.Cloud.sync.status === 'synced', 'синхронизировано');

const EMAIL = 'picker@test.ru', PASS = 'secret123';
const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--lang=ru-RU'], headless: 'new' });
let step = 'старт';
try {
  // 1. Устройство A: две смены без аккаунта → регистрация → смены уходят в облако
  step = 'регистрация на A';
  const A = await device(browser, 'A', { '2026-11-02': { lines: 1000, rate: 5, updatedAt: 1 }, '2026-11-03': { lines: 1200, rate: 5, updatedAt: 1 } });
  await openAuth(A, 'register');
  await fill(A, '#a-name', 'Евгений'); await fill(A, '#a-nick', 'evgen_picker'); await fill(A, '#a-email', EMAIL); await fill(A, '#a-pass', PASS);
  await click(A, '#a-submit');
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль создан');
  await synced(A);
  await A.shot('1-registered');
  assert.match(await A.$eval('#view-settings .acc-card', (e) => e.innerText), /@evgen_picker/);

  // 2. Устройство B: пустое → вход → получает смены A
  step = 'вход на B';
  const B = await device(browser, 'B');
  await openAuth(B, 'login');
  await fill(B, '#a-email', EMAIL); await fill(B, '#a-pass', PASS); await click(B, '#a-submit');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 2, 'смены A появились на B');
  assert.deepEqual(await days(B), ['2026-11-02', '2026-11-03']);
  await B.shot('2-login');

  // 3. B добавляет смену → она появляется на A без перезагрузки
  step = 'B → A';
  await addShift(B, '2026-11-04', 1350);
  await waitFor(A, () => __app.state.entries['2026-11-04'] && __app.state.entries['2026-11-04'].lines === 1350, 'смена B дошла до A');

  // 4. A правит смену → правка доходит до B
  step = 'A → B';
  await addShift(A, '2026-11-02', 1111);
  await waitFor(B, () => __app.state.entries['2026-11-02'].lines === 1111, 'правка A дошла до B');

  // 5. Устройство C со своими данными → вход → выбор «Объединить» → у всех 4 смены
  step = 'объединение на C';
  const C = await device(browser, 'C', { '2026-11-05': { lines: 900, rate: 5, updatedAt: 5 } });
  await openAuth(C, 'login');
  await fill(C, '#a-email', EMAIL); await fill(C, '#a-pass', PASS); await click(C, '#a-submit');
  await waitFor(C, () => document.querySelector('#dialog.show') && /Данные есть/.test(document.querySelector('#dialog').innerText), 'диалог выбора');
  await C.shot('3-choice');
  await clickText(C, '#dialog button', 'Объединить');
  await waitFor(C, () => Object.keys(__app.state.entries).length === 4, 'на C 4 смены');
  await waitFor(A, () => Object.keys(__app.state.entries).length === 4, 'на A 4 смены');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 4, 'на B 4 смены');
  assert.ok(await C.evaluate(() => !!localStorage.getItem('zarplata2027:backup-before-sync')), 'копия до объединения сохранена');

  // 6. Удаление смены на A → исчезает на B
  step = 'удаление';
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-05']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-05'], 'удаление дошло до B');

  // 7. Второй пользователь не может взять тот же ник
  step = 'занятый ник';
  const D = await device(browser, 'D');
  await openAuth(D, 'register');
  await fill(D, '#a-name', 'Другой'); await fill(D, '#a-nick', 'evgen_picker'); await fill(D, '#a-email', 'other@test.ru'); await fill(D, '#a-pass', PASS);
  await click(D, '#a-submit');
  await waitFor(D, () => document.querySelector('#pe-form'), 'предложено выбрать другой ник');
  await fill(D, '#pe-nick', 'other_picker'); await D.evaluate(() => document.querySelector('#pe-form').requestSubmit());
  await waitFor(D, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'other_picker', 'второй профиль создан', 20000)
    .catch(async (e) => { throw new Error(e.message + ' — ошибка формы: ' + (await D.evaluate(() => (document.querySelector('#pe-error') || {}).textContent))); });
  assert.equal(await D.evaluate(() => window.Cloud.account.profile.name), 'Другой', 'имя из регистрации сохранилось');
  await D.shot('4-second-user');

  // 7б. Рейтинг и публичная статистика с настоящими правилами базы
  step = 'публикация статистики';
  const aUid = await A.evaluate(() => window.Cloud.account.user.uid);
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: false }));
  await waitFor(A, () => window.Cloud.social.my && window.Cloud.social.my.visible && window.Cloud.social.my.totals.lines === 3661 && !window.Cloud.social.progress, 'статистика A опубликована (3661 линия)');
  await D.evaluate(() => { window.__lb = null; window.__lbStop = window.Cloud.social.watchLeaderboard({ period: 'all', metric: 'lines' }, (e, rows) => { window.__lb = e ? { error: String(e.message || e) } : rows; }); });
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 3661 && r.totals.days === 3), 'D видит A в рейтинге', 20000, aUid);
  let pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => ({ vis: !!x.stats, earn: x.stats && x.stats.totals.earn })), aUid);
  assert.deepEqual(pub, { vis: true, earn: 0 }, 'заработок скрыт');
  let dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.deepEqual(Object.keys(dd).sort(), ['2026-11-02', '2026-11-03', '2026-11-04']);
  assert.ok(Object.values(dd).every((x) => x.earn === 0 && Object.keys(x).sort().join() === 'earn,lines'), 'в публичных днях только линии');
  step = 'заработок';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: true }));
  await waitFor(A, () => window.Cloud.social.my.showEarn && window.Cloud.social.my.totals.earn === 3661 * 5 && !window.Cloud.social.progress, 'заработок опубликован');
  dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.equal(dd['2026-11-02'].earn, 1111 * 5);
  step = 'новая смена → рейтинг';
  await addShift(A, '2026-11-06', 1500);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 5161 && r.totals.best === 1500), 'рейтинг обновился сам', 30000, aUid);
  await D.shot('5-leaderboard');

  // 8. Смена ника на A освобождает старый
  step = 'смена ника';
  await A.evaluate(() => window.Cloud.account.updateProfile({ nick: 'evgen_new' }));
  await waitFor(A, () => window.Cloud.account.profile.nick === 'evgen_new', 'ник изменён');
  assert.equal(await D.evaluate(() => window.Cloud.account.isNickFree('evgen_picker')), true);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.nick === 'evgen_new'), 'новый ник в рейтинге', 20000, aUid);
  step = 'скрытие статистики';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: false }));
  await waitFor(D, (id) => Array.isArray(window.__lb) && !window.__lb.some((r) => r.uid === id), 'A пропал из рейтинга', 20000, aUid);
  pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => !!x.stats), aUid);
  assert.equal(pub, false);
  assert.equal(await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30').then(() => 'прочитал', () => 'нет доступа'), aUid), 'нет доступа');
  await D.evaluate(() => window.__lbStop());

  // 9. Выход на B с очисткой устройства; данные в облаке остаются
  step = 'выход';
  await click(B, '[data-act="acc-logout"]'); await sleep(400);
  await clickText(B, '#dialog button', 'Выйти и очистить');
  await waitFor(B, () => !window.Cloud.account.user && Object.keys(__app.state.entries).length === 0, 'B вышел и очистил данные');
  await sleep(500);
  assert.equal((await days(A)).length, 4);

  // 10. Удаление аккаунта D
  step = 'удаление аккаунта';
  await D.evaluate((pw) => window.Cloud.account.deleteAccount(pw), PASS);
  await waitFor(D, () => !window.Cloud.account.user, 'аккаунт D удалён');
  assert.equal(await A.evaluate(() => window.Cloud.account.isNickFree('other_picker')), true);

  assert.deepEqual(errors, [], 'ошибки в консоли: ' + errors.join('; '));
  console.log('✔ Вход, регистрация, синхронизация трёх устройств, объединение, ники, рейтинг, публикация/скрытие статистики, выход и удаление аккаунта работают');
} catch (e) {
  console.error(`✖ Шаг «${step}»: ${e.message}`);
  if (errors.length) console.error('Ошибки консоли:\n' + errors.join('\n'));
  for (const pg of await browser.pages()) { try { await pg.screenshot({ path: `${SHOTS}/fail-${Math.random().toString(36).slice(2, 6)}.png` }); } catch {} }
  process.exitCode = 1;
} finally {
  await browser.close();
}
