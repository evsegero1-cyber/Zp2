// Сквозная проверка входа и синхронизации с настоящим Firebase (локальный эмулятор Auth + Firestore).
// Три «устройства» = три изолированных профиля браузера. Запуск — в GitHub Actions (web.yml).
import puppeteer from 'puppeteer-core';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';

const URL = process.env.APP_URL || 'http://127.0.0.1:5050/';
const SHOTS = process.env.SHOTS || '/tmp/e2e-shots';
mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];

async function device(browser, name, entries) {
  const ctx = await browser.createBrowserContext();
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push(`${name}: ${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error' && !/PERMISSION_DENIED|ERR_CONNECTION_REFUSED|favicon/.test(m.text())) errors.push(`${name}: ${m.text()}`); });
  await p.setViewport({ width: 393, height: 852, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.goto(URL, { waitUntil: 'load' });
  await p.evaluate((ent) => { localStorage.clear(); if (ent) localStorage.setItem('zarplata2027:v1', JSON.stringify({ settings: {}, entries: ent })); }, entries);
  await p.reload({ waitUntil: 'load' });
  await waitFor(p, () => window.Cloud && window.Cloud.ready && window.Cloud.configured, 'облако загрузилось');
  p.shot = (n) => p.screenshot({ path: `${SHOTS}/${name}-${n}.png` });
  return p;
}
async function waitFor(p, fn, what, ms = 20000, arg) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { if (await p.evaluate(fn, arg)) return; } catch {}
    await sleep(250);
  }
  throw new Error('Не дождались: ' + what);
}
const click = (p, sel) => p.evaluate((s) => { const el = document.querySelector(s); if (!el) throw new Error('нет ' + s); el.click(); }, sel);
const clickText = (p, sel, text) => p.evaluate((s, t) => { const el = [...document.querySelectorAll(s)].find((x) => x.textContent.trim().startsWith(t)); if (!el) throw new Error('нет кнопки ' + t); el.click(); }, sel, text);
async function fill(p, sel, v) { await p.$eval(sel, (e) => (e.value = '')); await p.type(sel, v); }
const days = (p) => p.evaluate(() => Object.keys(__app.state.entries).sort());

async function openAuth(p, mode) {
  await click(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await click(p, `[data-act="acc-${mode}"]`); await sleep(400);
}
async function addShift(p, key, lines) {
  await p.evaluate((k) => __app.openDay(k), key); await sleep(400);
  await p.evaluate((l) => { const i = document.querySelector('#f-lines'); i.value = String(l); i.form.requestSubmit(); }, lines);
  await sleep(300);
}
const synced = (p) => waitFor(p, () => window.Cloud.sync.status === 'synced', 'синхронизировано');

const EMAIL = 'picker@test.ru', PASS = 'secret123';
const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--lang=ru-RU'], headless: 'new' });
let step = 'старт';
try {
  // 1. Устройство A: две смены без аккаунта → регистрация → смены уходят в облако
  step = 'регистрация на A';
  const A = await device(browser, 'A', { '2026-11-02': { lines: 1000, rate: 5, updatedAt: 1 }, '2026-11-03': { lines: 1200, rate: 5, updatedAt: 1 } });
  await openAuth(A, 'register');
  await fill(A, '#a-name', 'Евгений'); await fill(A, '#a-nick', 'evgen_picker'); await fill(A, '#a-email', EMAIL); await fill(A, '#a-pass', PASS);
  await click(A, '#a-submit');
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль создан');
  await synced(A);
  await A.shot('1-registered');
  assert.match(await A.$eval('#view-settings .acc-card', (e) => e.innerText), /@evgen_picker/);

  // 2. Устройство B: пустое → вход → получает смены A
  step = 'вход на B';
  const B = await device(browser, 'B');
  await openAuth(B, 'login');
  await fill(B, '#a-email', EMAIL); await fill(B, '#a-pass', PASS); await click(B, '#a-submit');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 2, 'смены A появились на B');
  assert.deepEqual(await days(B), ['2026-11-02', '2026-11-03']);
  await B.shot('2-login');

  // 3. B добавляет смену → она появляется на A без перезагрузки
  step = 'B → A';
  await addShift(B, '2026-11-04', 1350);
  await waitFor(A, () => __app.state.entries['2026-11-04'] && __app.state.entries['2026-11-04'].lines === 1350, 'смена B дошла до A');

  // 4. A правит смену → правка доходит до B
  step = 'A → B';
  await addShift(A, '2026-11-02', 1111);
  await waitFor(B, () => __app.state.entries['2026-11-02'].lines === 1111, 'правка A дошла до B');

  // 5. Устройство C со своими данными → вход → выбор «Объединить» → у всех 4 смены
  step = 'объединение на C';
  const C = await device(browser, 'C', { '2026-11-05': { lines: 900, rate: 5, updatedAt: 5 } });
  await openAuth(C, 'login');
  await fill(C, '#a-email', EMAIL); await fill(C, '#a-pass', PASS); await click(C, '#a-submit');
  await waitFor(C, () => document.querySelector('#dialog.show') && /Данные есть/.test(document.querySelector('#dialog').innerText), 'диалог выбора');
  await C.shot('3-choice');
  await clickText(C, '#dialog button', 'Объединить');
  await waitFor(C, () => Object.keys(__app.state.entries).length === 4, 'на C 4 смены');
  await waitFor(A, () => Object.keys(__app.state.entries).length === 4, 'на A 4 смены');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 4, 'на B 4 смены');
  assert.ok(await C.evaluate(() => !!localStorage.getItem('zarplata2027:backup-before-sync')), 'копия до объединения сохранена');

  // 6. Удаление смены на A → исчезает на B
  step = 'удаление';
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-05']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-05'], 'удаление дошло до B');

  // 7. Второй пользователь не может взять тот же ник
  step = 'занятый ник';
  const D = await device(browser, 'D');
  await openAuth(D, 'register');
  await fill(D, '#a-name', 'Другой'); await fill(D, '#a-nick', 'evgen_picker'); await fill(D, '#a-email', 'other@test.ru'); await fill(D, '#a-pass', PASS);
  await click(D, '#a-submit');
  await waitFor(D, () => document.querySelector('#pe-form'), 'предложено выбрать другой ник');
  await fill(D, '#pe-nick', 'other_picker'); await D.evaluate(() => document.querySelector('#pe-form').requestSubmit());
  await waitFor(D, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'other_picker', 'второй профиль создан');
  await D.shot('4-second-user');

  // 8. Смена ника на A освобождает старый
  step = 'смена ника';
  await A.evaluate(() => window.Cloud.account.updateProfile({ nick: 'evgen_new' }));
  await waitFor(A, () => window.Cloud.account.profile.nick === 'evgen_new', 'ник изменён');
  assert.equal(await D.evaluate(() => window.Cloud.account.isNickFree('evgen_picker')), true);

  // 9. Выход на B с очисткой устройства; данные в облаке остаются
  step = 'выход';
  await click(B, '[data-act="acc-logout"]'); await sleep(400);
  await clickText(B, '#dialog button', 'Выйти и очистить');
  await waitFor(B, () => !window.Cloud.account.user && Object.keys(__app.state.entries).length === 0, 'B вышел и очистил данные');
  await sleep(500);
  assert.equal((await days(A)).length, 3);

  // 10. Удаление аккаунта D
  step = 'удаление аккаунта';
  await D.evaluate((pw) => window.Cloud.account.deleteAccount(pw), PASS);
  await waitFor(D, () => !window.Cloud.account.user, 'аккаунт D удалён');
  assert.equal(await A.evaluate(() => window.Cloud.account.isNickFree('other_picker')), true);

  assert.deepEqual(errors, [], 'ошибки в консоли: ' + errors.join('; '));
  console.log('✔ Вход, регистрация, синхронизация трёх устройств, объединение, ники, выход и удаление аккаунта работают');
} catch (e) {
  console.error(`✖ Шаг «${step}»: ${e.message}`);
  if (errors.length) console.error('Ошибки консоли:\n' + errors.join('\n'));
  for (const pg of await browser.pages()) { try { await pg.screenshot({ path: `${SHOTS}/fail-${Math.random().toString(36).slice(2, 6)}.png` }); } catch {} }
  process.exitCode = 1;
} finally {
  await browser.close();
}
