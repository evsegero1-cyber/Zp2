// Сквозная проверка входа и синхронизации с настоящим Firebase (локальный эмулятор Auth + Firestore).
// Три «устройства» = три изолированных профиля браузера. Запуск — в GitHub Actions (web.yml).
import puppeteer from 'puppeteer-core';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

const URL = process.env.APP_URL || 'http://127.0.0.1:5050/';
const SHOTS = process.env.SHOTS || '/tmp/e2e-shots';
mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];

async function device(browser, name, entries) {
  const ctx = await browser.createBrowserContext();
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push(`${name}: ${e.message}`));
  p.on('console', (m) => { if (m.type() === 'error' && !/PERMISSION_DENIED|ERR_CONNECTION_REFUSED|ERR_INTERNET_DISCONNECTED|Could not reach Cloud Firestore|WebChannelConnection|favicon|Failed to load resource: the server responded with a status of 40[039]/.test(m.text())) errors.push(`${name}: ${m.text()}`); });
  await p.setViewport({ width: 393, height: 852, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  await p.goto(URL, { waitUntil: 'load' });
  await p.evaluate((ent) => { localStorage.clear(); if (ent) localStorage.setItem('zarplata2027:v1', JSON.stringify({ settings: {}, entries: ent })); }, entries);
  await p.reload({ waitUntil: 'load' });
  await waitFor(p, () => window.Cloud && window.Cloud.ready && window.Cloud.configured, 'облако загрузилось');
  p.shot = (n) => p.screenshot({ path: `${SHOTS}/${name}-${n}.png` });
  return p;
}
async function waitFor(p, fn, what, ms = 20000, arg) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { if (await p.evaluate(fn, arg)) return; } catch {}
    await sleep(250);
  }
  throw new Error('Не дождались: ' + what);
}
const click = (p, sel) => p.evaluate((s) => { const el = document.querySelector(s); if (!el) throw new Error('нет ' + s); el.click(); }, sel);
const clickText = (p, sel, text) => p.evaluate((s, t) => { const el = [...document.querySelectorAll(s)].find((x) => x.textContent.trim().startsWith(t)); if (!el) throw new Error('нет кнопки ' + t); el.click(); }, sel, text);
async function fill(p, sel, v) { await p.$eval(sel, (e) => (e.value = '')); await p.type(sel, v); }
const days = (p) => p.evaluate(() => Object.keys(__app.state.entries).sort());

async function openAuth(p, mode) {
  await click(p, '.tabbar [data-tab="settings"]'); await sleep(300);
  await click(p, `[data-act="acc-${mode}"]`); await sleep(400);
}
async function addShift(p, key, lines) {
  await p.evaluate((k) => __app.openDay(k), key); await sleep(400);
  await p.evaluate((l) => { const i = document.querySelector('#f-lines'); i.value = String(l); i.form.requestSubmit(); }, lines);
  await sleep(300);
}
// Запись «от имени сервера» (эмулятор пропускает правила с токеном owner) — открыть доступ к чату до появления администратора
async function ownerSet(path, fields) {
  const r = await fetch(`http://127.0.0.1:8080/v1/projects/demo-zarplata/databases/(default)/documents/${path}`, {
    method: 'PATCH', headers: { Authorization: 'Bearer owner', 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }) });
  if (!r.ok) throw new Error('ownerSet ' + r.status + ' ' + (await r.text()));
}
const ownerMeta = (uid, sex, zone) => ownerSet(`userMeta/${uid}`, { ...(sex ? { sex: { stringValue: sex } } : {}), ...(zone ? { zone: { stringValue: zone } } : {}), updatedAt: { timestampValue: new Date().toISOString() } });
const grantChat = (uid) => ownerSet(`chatAccess/${uid}`, { at: { timestampValue: new Date().toISOString() } });
const synced = (p) => waitFor(p, () => window.Cloud.sync.status === 'synced', 'синхронизировано');

const EMAIL = 'picker@test.ru', PASS = 'secret123';
const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--lang=ru-RU', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'], headless: 'new' });
let step = 'старт';
try {
  // 1. Устройство A: две смены без аккаунта → регистрация → смены уходят в облако
  step = 'регистрация на A';
  const A = await device(browser, 'A', { '2026-11-02': { lines: 1000, rate: 5, updatedAt: 1 }, '2026-11-03': { lines: 1200, rate: 5, updatedAt: 1 } });
  await openAuth(A, 'register');
  await fill(A, '#a-name', 'Евгений'); await fill(A, '#a-nick', 'evgen_picker'); await fill(A, '#a-email', EMAIL); await fill(A, '#a-pass', PASS);
  await click(A, '#a-submit');
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль создан');
  await synced(A);
  await A.shot('1-registered');
  assert.match(await A.$eval('#view-settings .acc-card', (e) => e.innerText), /@evgen_picker/);

  // 2. Устройство B: пустое → вход → получает смены A
  step = 'вход на B';
  const B = await device(browser, 'B');
  await openAuth(B, 'login');
  await fill(B, '#a-email', EMAIL); await fill(B, '#a-pass', PASS); await click(B, '#a-submit');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 2, 'смены A появились на B');
  assert.deepEqual(await days(B), ['2026-11-02', '2026-11-03']);
  await B.shot('2-login');

  // 3. B добавляет смену → она появляется на A без перезагрузки
  step = 'B → A';
  await addShift(B, '2026-11-04', 1350);
  await waitFor(A, () => __app.state.entries['2026-11-04'] && __app.state.entries['2026-11-04'].lines === 1350, 'смена B дошла до A');

  // 4. A правит смену → правка доходит до B
  step = 'A → B';
  await addShift(A, '2026-11-02', 1111);
  await waitFor(B, () => __app.state.entries['2026-11-02'].lines === 1111, 'правка A дошла до B');

  // 5. Устройство C со своими данными → вход → выбор «Объединить» → у всех 4 смены
  step = 'объединение на C';
  const C = await device(browser, 'C', { '2026-11-05': { lines: 900, rate: 5, updatedAt: 5 } });
  await openAuth(C, 'login');
  await fill(C, '#a-email', EMAIL); await fill(C, '#a-pass', PASS); await click(C, '#a-submit');
  await waitFor(C, () => document.querySelector('#dialog.show') && /Данные есть/.test(document.querySelector('#dialog').innerText), 'диалог выбора');
  await C.shot('3-choice');
  await clickText(C, '#dialog button', 'Объединить');
  await waitFor(C, () => Object.keys(__app.state.entries).length === 4, 'на C 4 смены');
  await waitFor(A, () => Object.keys(__app.state.entries).length === 4, 'на A 4 смены');
  await waitFor(B, () => Object.keys(__app.state.entries).length === 4, 'на B 4 смены');
  assert.ok(await C.evaluate(() => !!localStorage.getItem('zarplata2027:backup-before-sync')), 'копия до объединения сохранена');

  // 6. Удаление смены на A → исчезает на B
  step = 'удаление';
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-05']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-05'], 'удаление дошло до B');

  // 6б. Без сети: смена вносится, приложение перезапускается офлайн (профиль и смена на месте), потом сеть — смена доходит до B
  step = 'офлайн';
  const net = await A.createCDPSession(); await net.send('Network.enable');
  const offline = (on) => net.send('Network.emulateNetworkConditions', { offline: on, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
  await offline(true);
  await waitFor(A, () => !navigator.onLine, 'A без сети');
  await addShift(A, '2026-11-07', 444);
  await waitFor(A, () => window.Cloud.sync.status === 'offline', 'статус «нет сети»');
  // точка «в облаке» у дня: красная без сети, у уже отправленных — зелёная
  await A.evaluate(() => { __app.setTab('cal'); });
  await waitFor(A, () => !!document.querySelector('[data-key="2026-11-07"] .cs-offline'), 'красная точка у смены без сети');
  await waitFor(A, () => !!document.querySelector('[data-key="2026-11-04"] .cs-ok'), 'зелёная точка у отправленной смены');
  const swOk = await A.evaluate(() => !!(navigator.serviceWorker && navigator.serviceWorker.controller));
  const tOff = Date.now();
  await A.reload({ waitUntil: 'load' }).catch((e) => console.log('reload:', e.message));
  console.log('перезагрузка заняла', Date.now() - tOff, 'мс');   // перезапуск без интернета — из кэша приложения
  try { await waitFor(A, () => !!(window.Cloud && window.Cloud.ready && window.Cloud.account.authReady && window.Cloud.account.user), 'вход восстановлен без сети', 6000); console.log('Вход без сети восстановлен за', Date.now() - tOff, 'мс', await A.evaluate(() => JSON.stringify({ cloudLoaded: window.Cloud.loadedAt, auth: window.Cloud.account.authAt }))); }
  catch (e) {
    console.log('ДИАГНОСТИКА офлайн:', 'sw до перезапуска', swOk, JSON.stringify(await A.evaluate(() => ({ url: location.href, cloud: !!window.Cloud, ready: window.Cloud && window.Cloud.ready, err: window.Cloud && window.Cloud.error,
      authReady: window.Cloud && window.Cloud.account && window.Cloud.account.authReady, cloudLoaded: window.Cloud && window.Cloud.loadedAt, authAt: window.Cloud && window.Cloud.account && window.Cloud.account.authAt, nav: Math.round(performance.now()), user: !!(window.Cloud && window.Cloud.account && window.Cloud.account.user),
      sw: !!(navigator.serviceWorker && navigator.serviceWorker.controller), app: !!window.__app, body: document.body ? document.body.innerText.slice(0, 200) : '' })).catch((x) => 'eval: ' + x.message)));
    console.log('ошибки:', errors.slice(-8).join(' | '));
    throw e;
  }
  await waitFor(A, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'evgen_picker', 'профиль без сети');
  assert.equal(await A.evaluate(() => __app.state.entries['2026-11-07'] && __app.state.entries['2026-11-07'].lines), 444);
  assert.equal(await A.evaluate(() => !!document.getElementById('net-banner')), true, 'плашка «нет сети»');
  await A.shot('offline');
  await sleep(1500);
  assert.equal(await B.evaluate(() => !!__app.state.entries['2026-11-07']), false, 'без сети смена ещё не ушла');
  await offline(false);
  await waitFor(B, () => __app.state.entries['2026-11-07'] && __app.state.entries['2026-11-07'].lines === 444, 'после появления сети смена дошла до B', 30000);
  await synced(A);
  await A.evaluate(() => { __app.setTab('cal'); });
  await waitFor(A, () => !!document.querySelector('[data-key="2026-11-07"] .cs-ok'), 'точка стала зелёной после отправки');
  await A.evaluate(() => { const st = __app.state; delete st.entries['2026-11-07']; localStorage.setItem('zarplata2027:v1', JSON.stringify(st)); window.Cloud.sync.changed(); });
  await waitFor(B, () => !__app.state.entries['2026-11-07'], 'удаление после офлайна дошло до B');

  // 7. Второй пользователь не может взять тот же ник
  step = 'занятый ник';
  const D = await device(browser, 'D');
  await openAuth(D, 'register');
  await fill(D, '#a-name', 'Другой'); await fill(D, '#a-nick', 'evgen_picker'); await fill(D, '#a-email', 'other@test.ru'); await fill(D, '#a-pass', PASS);
  await click(D, '#a-submit');
  await waitFor(D, () => document.querySelector('#pe-form'), 'предложено выбрать другой ник');
  await fill(D, '#pe-nick', 'other_picker'); await D.evaluate(() => document.querySelector('#pe-form').requestSubmit());
  await waitFor(D, () => window.Cloud.account.profile && window.Cloud.account.profile.nick === 'other_picker', 'второй профиль создан', 20000)
    .catch(async (e) => { throw new Error(e.message + ' — ошибка формы: ' + (await D.evaluate(() => (document.querySelector('#pe-error') || {}).textContent))); });
  assert.equal(await D.evaluate(() => window.Cloud.account.profile.name), 'Другой', 'имя из регистрации сохранилось');
  await D.shot('4-second-user');

  // 7а. Без пола от администратора общие разделы закрыты; чата нет
  step = 'ожидание группы';
  const aUid = await A.evaluate(() => window.Cloud.account.user.uid);
  const dUidEarly = await D.evaluate(() => window.Cloud.account.user.uid);
  await click(D, '.tabbar [data-tab="crew"]'); await sleep(500);
  await waitFor(D, () => /Ожидает подтверждения/.test(document.querySelector('#view-crew').innerText), 'D без группы ждёт подтверждения');
  assert.equal(await D.evaluate(() => !!document.querySelector('[data-crew-sub]')), false, 'без группы — нет рейтинга и людей');
  await ownerMeta(aUid, 'm'); await ownerMeta(dUidEarly, 'm');
  await waitFor(A, () => window.Cloud.social.meta && window.Cloud.social.meta.sex === 'm' && window.Cloud.account.profile.sex === 'm', 'A получил группу');
  await waitFor(D, () => !!document.querySelector('[data-crew-sub="rank"]'), 'D увидел рейтинг после выдачи группы');
  assert.equal(await D.evaluate(() => !!document.querySelector('[data-crew-sub="chat"]')), false, 'чат скрыт');
  await click(D, '.tabbar [data-tab="settings"]'); await sleep(300);

  // 7б. Рейтинг и публичная статистика с настоящими правилами базы
  step = 'публикация статистики';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: false }));
  await waitFor(A, () => window.Cloud.social.my && window.Cloud.social.my.visible && window.Cloud.social.my.totals.lines === 3661 && !window.Cloud.social.progress, 'статистика A опубликована (3661 линия)');
  assert.equal(await A.evaluate(() => window.Cloud.social.my.sex), 'm', 'группа в статистике');
  await D.evaluate(() => { window.__lb = null; window.__lbStop = window.Cloud.social.watchLeaderboard({ period: 'all', metric: 'lines' }, (e, rows) => { window.__lb = e ? { error: String(e.message || e) } : rows; }); });
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 3661 && r.totals.days === 3), 'D видит A в рейтинге', 20000, aUid);
  let pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => ({ vis: !!x.stats, earn: x.stats && x.stats.totals.earn })), aUid);
  assert.deepEqual(pub, { vis: true, earn: 0 }, 'заработок скрыт');
  let dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.deepEqual(Object.keys(dd).sort(), ['2026-11-02', '2026-11-03', '2026-11-04']);
  assert.ok(Object.values(dd).every((x) => x.earn === 0 && Object.keys(x).sort().join() === 'earn,lines'), 'в публичных днях только линии');
  step = 'заработок';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: true }));
  await waitFor(A, () => window.Cloud.social.my.showEarn && window.Cloud.social.my.totals.earn === 3661 * 5 && !window.Cloud.social.progress, 'заработок опубликован');
  dd = await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30'), aUid);
  assert.equal(dd['2026-11-02'].earn, 1111 * 5);
  step = 'новая смена → рейтинг';
  await addShift(A, '2026-11-06', 1500);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.totals.lines === 5161 && r.totals.best === 1500), 'рейтинг обновился сам', 30000, aUid);
  await D.shot('5-leaderboard');
  step = 'рейтинг недели: дни на карточке';
  const todayK = await A.evaluate(() => window.Cloud.util.dayKey());
  await addShift(A, todayK, 700);
  await waitFor(A, (k) => window.Cloud.social.my && window.Cloud.social.my.lastDay === k && !window.Cloud.social.progress, 'смена сегодня опубликована', 20000, todayK);
  await click(D, '.tabbar [data-tab="crew"]'); await sleep(400); await click(D, '[data-crew-sub="rank"]'); await sleep(300);
  await D.evaluate(() => document.querySelector('#rk-period [data-k="week"]').click());
  await sleep(300);
  // в понедельник по умолчанию открыта прошлая неделя — переходим на текущую
  await D.evaluate(() => { const n = document.querySelector('#rk-wk [data-wk="1"]'); if (n && !n.disabled) n.click(); });
  await waitFor(D, (id) => { const el = document.querySelector(`[data-wd="${id}"]`); return !!(el && el.classList.contains('ready') && el.querySelector('.wd.on.today')); }, 'на карточке рейтинга закрашен сегодняшний день', 20000, aUid);
  await D.evaluate((id) => document.querySelector(`.pod[data-uid="${id}"], .rank-row[data-uid="${id}"]`).click(), aUid);
  await waitFor(D, () => !!document.querySelector('#pp-week .wd.on.today b') && document.querySelector('#pp-week .wd.on.today b').textContent.replace(/\s/g, '') === '700', 'в профиле линии по дням', 20000);
  await D.shot('5b-week-days');
  await D.evaluate(() => document.querySelector('#sheet [data-close]').click()); await sleep(300);
  step = 'рейтинг прошлых недель';
  const backN = await D.evaluate(() => { const U = window.Cloud.util, a = new Date(U.mondayOf(U.dayKey()) + 'T00:00:00Z'), b = new Date('2026-11-02T00:00:00Z'); return Math.round((a - b) / 604800000); });
  if (backN > 0 && backN <= 26) {
    for (let i = 0; i < backN; i++) { await D.evaluate(() => document.querySelector('#rk-wk [data-wk="-1"]').click()); await sleep(150); }
    await waitFor(D, (id) => { const el = document.querySelector(`.pod[data-uid="${id}"] .pod-val`); return !!(el && el.textContent.replace(/\s/g, '').startsWith('5161')); }, 'неделя 2–8 ноября: линии A посчитаны по дням', 20000, aUid);
    await D.shot('5c-past-week');
    while (await D.evaluate(() => { const n = document.querySelector('#rk-wk [data-wk="1"]'); if (n && !n.disabled) { n.click(); return true; } return false; })) await sleep(150);
  }

  // 8. Смена ника на A освобождает старый
  step = 'смена ника';
  await A.evaluate(() => window.Cloud.account.updateProfile({ nick: 'evgen_new' }));
  await waitFor(A, () => window.Cloud.account.profile.nick === 'evgen_new', 'ник изменён');
  assert.equal(await D.evaluate(() => window.Cloud.account.isNickFree('evgen_picker')), true);
  await waitFor(D, (id) => Array.isArray(window.__lb) && window.__lb.some((r) => r.uid === id && r.nick === 'evgen_new'), 'новый ник в рейтинге', 20000, aUid);
  step = 'скрытие статистики';
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: false }));
  await waitFor(D, (id) => Array.isArray(window.__lb) && !window.__lb.some((r) => r.uid === id), 'A пропал из рейтинга', 20000, aUid);
  pub = await D.evaluate((id) => window.Cloud.social.getPublic(id).then((x) => !!x.stats), aUid);
  assert.equal(pub, false);
  assert.equal(await D.evaluate((id) => window.Cloud.social.days(id, '2026-11-01', '2026-11-30').then(() => 'прочитал', () => 'нет доступа'), aUid), 'нет доступа');
  await D.evaluate(() => window.__lbStop());

  // 8б. Чат временно скрыт
  step = 'чат скрыт';
  await click(D, '.tabbar [data-tab="crew"]'); await sleep(400);
  assert.equal(await D.evaluate(() => !!document.querySelector('[data-crew-sub="chat"]') || !!document.querySelector('#chat-list')), false, 'чата нет');
  assert.equal(await D.evaluate(() => window.Cloud.chat._on || false), false, 'к чату не подключаемся');

  // 8в. Администратор: почта evsegero.one@gmail.com → подтверждение → панель → блокировка
  step = 'администратор';
  const E = await device(browser, 'E');
  await openAuth(E, 'register');
  await fill(E, '#a-name', 'Сергей'); await fill(E, '#a-nick', 'sergey_admin'); await fill(E, '#a-email', 'evsegero.one@gmail.com'); await fill(E, '#a-pass', PASS);
  await click(E, '#a-submit');
  await waitFor(E, () => window.Cloud.account.profile, 'профиль администратора');
  await click(E, '.tabbar [data-tab="settings"]'); await sleep(500);
  await waitFor(E, () => document.querySelector('[data-act="adm-verify"]'), 'карточка «подтвердите почту»');
  await click(E, '[data-act="adm-verify"]'); await sleep(1500);
  const codes = await (await fetch('http://127.0.0.1:9099/emulator/v1/projects/demo-zarplata/oobCodes')).json();
  const link = codes.oobCodes.filter((c) => c.email === 'evsegero.one@gmail.com' && c.requestType === 'VERIFY_EMAIL').pop().oobLink;
  await fetch(link);
  await click(E, '[data-act="adm-verified"]');
  await waitFor(E, () => document.querySelector('[data-act="adm-open"]'), 'права администратора включились');
  await click(E, '[data-act="adm-open"]');
  await waitFor(E, () => document.querySelectorAll('[data-adm]').length >= 3, 'список сборщиков в панели');
  await E.shot('7-admin');
  const dUid = await D.evaluate(() => window.Cloud.account.user.uid);
  await E.evaluate((id) => window.Cloud.admin.ban(id, 'other_picker', 'проверка'), dUid);
  await E.evaluate((id) => window.Cloud.admin.unban(id), dUid);
  // пол и зона: администратор переводит D к девочкам (Марс) → D не видит ребят, тариф 5,16 с 2 ноября
  step = 'пол и зона';
  await addShift(D, '2026-11-05', 500); await addShift(D, '2026-10-30', 400);
  await waitFor(D, () => window.Cloud.sync.status === 'synced', 'смены D в облаке');
  await waitFor(E, (id) => document.querySelector(`[data-adm="${id}"]`), 'D в списке', 15000, dUid);
  await click(E, `[data-adm="${dUid}"]`); await sleep(400);
  await clickText(E, '#dialog button', 'Пол и зона');
  await sleep(300);
  await E.evaluate(() => { document.querySelector('.meta-seg[data-m="sex"] [data-v="f"]').click(); document.querySelector('.meta-seg[data-m="zone"] [data-v="mars"]').click(); });
  await clickText(E, '#dialog button', 'Сохранить');
  await waitFor(D, () => window.Cloud.social.meta && window.Cloud.social.meta.sex === 'f' && window.Cloud.social.meta.zone === 'mars', 'D получил пол и зону', 20000);
  await waitFor(D, () => { const e = __app.state.entries; return e['2026-11-05'] && e['2026-11-05'].rate === 5.16 && e['2026-10-30'].rate === 5; }, 'тариф Марса с 2 ноября', 20000);
  assert.equal(await D.evaluate(() => __app.state.settings.rateHistory.find((x) => x.from === '2026-11-02').rate), 5.16);
  assert.equal(await D.evaluate((id) => window.Cloud.social.getPublic(id).then(() => 'видит', () => 'нет доступа'), aUid), 'нет доступа', 'девочка не видит профиль парня');
  assert.equal(await D.evaluate(() => window.Cloud.social.listProfiles('').then((l) => l.map((x) => x.nick).join())), 'other_picker', 'в списке людей — только своя группа');
  assert.equal(await A.evaluate((id) => window.Cloud.social.getPublic(id).then(() => 'видит', () => 'нет доступа'), dUid), 'нет доступа', 'парень не видит профиль девочки');
  await E.shot('7b-meta');
  await E.evaluate((id) => window.Cloud.admin.setMeta(id, { sex: 'm' }), dUid);
  await waitFor(D, () => window.Cloud.social.meta && window.Cloud.social.meta.sex === 'm', 'D снова у ребят', 20000);

  // 8г. Отчёт склада: ФИО только у администратора → Excel → строка сборщика → данные сами вносятся в смену A
  step = 'отчёт склада';
  await E.evaluate((id) => window.Cloud.admin.setNote(id, { fio: 'Евгеньев Евгений Иванович', fields: { lines: true, prod: true, actual: true } }), aUid);
  await E.evaluate(() => { const b = document.querySelector('#sheet [data-close]'); if (b) b.click(); }); await sleep(500);
  await click(E, '[data-act="adm-open"]');
  await waitFor(E, () => document.querySelector('#adm-report'), 'кнопка «Загрузить отчёт»');
  await click(E, '#adm-report'); await sleep(300);
  const inp = await E.$('#rp-file');
  await inp.uploadFile(join(import.meta.dirname, 'fixtures', 'report.xlsx'));
  await waitFor(E, (id) => { const v = document.querySelector(`.rp-card[data-u="${id}"] [data-val="lines"]`); return v && v.value === '586'; }, 'строка A найдена по ФИО', 25000, aUid);
  assert.equal(await E.evaluate(() => document.querySelector('#rp-date').value), '2026-10-29');
  assert.equal(await E.evaluate((id) => document.querySelector(`.rp-card[data-u="${id}"] [data-val="prod"]`).value, aUid), '145,54');
  await E.shot('8-report');
  await click(E, '#rp-send'); await sleep(400);
  await clickText(E, '#dialog button', 'Внести');
  await waitFor(A, () => { const e = __app.state.entries['2026-10-29']; return e && e.lines === 586 && e.prod === 145.54 && e.actual === 2942; }, 'данные из отчёта внесены в смену A', 25000);
  await waitFor(E, (id) => /уже внесено/.test((document.querySelector(`.rp-card[data-u="${id}"]`) || {}).innerText || ''), 'администратор видит «уже внесено»', 25000, aUid);
  await synced(A);
  // 8д. Календарь сборщика в админ-панели: администратор правит смену A → она приходит на телефон A
  step = 'календарь сборщика (админ)';
  // A снова участвует в рейтинге (выше по сценарию он скрывал статистику)
  await A.evaluate(() => window.Cloud.social.setVisibility({ visible: true, showEarn: true }));
  await waitFor(A, () => window.Cloud.social.my && window.Cloud.social.my.visible && !window.Cloud.social.progress, 'статистика A снова опубликована', 30000);
  await E.evaluate(() => { const b = document.querySelector('#sheet [data-close]'); if (b) b.click(); }); await sleep(500);
  await click(E, '[data-act="adm-open"]');
  await waitFor(E, (id) => document.querySelector(`[data-adm="${id}"]`), 'список сборщиков', 15000, aUid);
  await click(E, `[data-adm="${aUid}"]`); await sleep(400);
  await clickText(E, '#dialog button', '📅 Календарь смен');
  await waitFor(E, () => document.querySelector('.ucal'), 'календарь A открылся', 15000);
  for (let i = 0; i < 4 && !(await E.$('[data-ud="2026-10-29"]')); i++) { await click(E, '[data-um="-1"]'); await sleep(200); }
  await waitFor(E, () => { const d = document.querySelector('[data-ud="2026-10-29"]'); return !!(d && d.classList.contains('has')); }, 'смена 29 октября видна в календаре A');
  await click(E, '[data-ud="2026-10-29"]'); await sleep(200);
  assert.equal(await E.evaluate(() => document.querySelector('#ud-lines').value), '586');
  await E.evaluate(() => { document.querySelector('#ud-lines').value = '600'; document.querySelector('#ud-weight').value = '3 100,5'; document.querySelector('#ud-form').requestSubmit(); });
  await waitFor(E, () => document.querySelector('.ucal'), 'вернулись к календарю после сохранения', 15000);
  await waitFor(E, async (id) => { const d = await window.Cloud.social.days(id, '2026-10-29', '2026-10-29'); const x = d['2026-10-29']; return !!(x && x.lines === 600 && x.kg === 3100.5); }, 'рейтинг A пересчитан администратором', 20000, aUid);
  assert.ok(await E.evaluate(() => [...document.querySelectorAll('.ucal-d em')].some((x) => x.textContent === '3,1т')), 'вес виден в календаре администратора');
  await E.shot('8b-user-cal');
  await waitFor(A, () => { const e = __app.state.entries['2026-10-29']; return !!(e && e.lines === 600 && e.weight === 3100.5 && e.prod === 145.54); }, 'правка администратора пришла на телефон A', 25000);
  await synced(A);
  await E.evaluate(() => { const b = document.querySelector('#sheet [data-close]'); if (b) b.click(); }); await sleep(300);
  // обычный пользователь не администратор
  assert.equal(await A.evaluate(() => window.Cloud.admin.isAdmin()), false);
  assert.equal(await A.evaluate(() => !!document.querySelector('.admin-card')), false);

  // 9. Выход на B с очисткой устройства; данные в облаке остаются
  step = 'выход';
  await click(B, '[data-act="acc-logout"]'); await sleep(400);
  await clickText(B, '#dialog button', 'Выйти и очистить');
  await waitFor(B, () => !window.Cloud.account.user && Object.keys(__app.state.entries).length === 0, 'B вышел и очистил данные');
  await sleep(500);
  assert.equal((await days(A)).length, 6); // + смена из отчёта и сегодняшняя (проверка недели)

  // 10. Удаление аккаунта D
  step = 'удаление аккаунта';
  await D.evaluate((pw) => window.Cloud.account.deleteAccount(pw), PASS);
  await waitFor(D, () => !window.Cloud.account.user, 'аккаунт D удалён');
  assert.equal(await A.evaluate(() => window.Cloud.account.isNickFree('other_picker')), true);

  assert.deepEqual(errors, [], 'ошибки в консоли: ' + errors.join('; '));
  console.log('✔ Вход, регистрация, синхронизация трёх устройств, работа без сети и перезапуск офлайн, объединение, ники, рейтинг, публикация/скрытие статистики, разделение по полу и зоны с тарифом, чат скрыт, админ-панель, блокировка и доступ к чату, отчёт склада из Excel, выход и удаление аккаунта работают');
} catch (e) {
  console.error(`✖ Шаг «${step}»: ${e.message}`);
  if (errors.length) console.error('Ошибки консоли:\n' + errors.join('\n'));
  for (const pg of await browser.pages()) { try { await pg.screenshot({ path: `${SHOTS}/fail-${Math.random().toString(36).slice(2, 6)}.png` }); } catch {} }
  process.exitCode = 1;
} finally {
  await browser.close();
}
