// Тесты правил Firestore (firestore.rules) на локальном эмуляторе.
// Запуск: cd tests/rules && npm install && npm test   (в GitHub Actions — автоматически, workflow web.yml)
import test, { before, after, beforeEach } from 'node:test';
import { readFileSync } from 'node:fs';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { emptyStats, applyDay, mondayOf } from '../../src/cloud/stats.js';

const TS = () => firebase.firestore.FieldValue.serverTimestamp();
let env;

before(async () => {
  env = await initializeTestEnvironment({
    projectId: 'demo-zarplata',
    firestore: { rules: readFileSync(new URL('../../firestore.rules', import.meta.url), 'utf8'), host: '127.0.0.1', port: 8080 },
  });
});
after(async () => { if (env) await env.cleanup(); });
beforeEach(async () => { await env.clearFirestore(); });

const as = (uid) => env.authenticatedContext(uid).firestore();
const anon = () => env.unauthenticatedContext().firestore();
const AV = { kind: 'preset', v: 'cat' };

// Регистрация «как в приложении»: профиль + ник одной транзакцией (batch)
async function register(uid, nick, name = 'Сборщик') {
  const db = as(uid), b = db.batch();
  b.set(db.doc(`publicProfiles/${uid}`), { nick, name, avatar: AV, createdAt: TS(), updatedAt: TS() });
  b.set(db.doc(`usernames/${nick}`), { uid });
  await b.commit();
  return { nick, name, avatar: AV };
}
// Опубликовать статистику (пустую) и вернуть её
async function publish(uid, prof, showEarn = true) {
  const st = { ...emptyStats(prof, showEarn), visible: true };
  await as(uid).doc(`publicStats/${uid}`).set({ ...st, updatedAt: TS() });
  return st;
}
// Изменить день: batch {день, статистика}
function dayBatch(uid, st, day, next, prev, best, tamper) {
  const db = as(uid), b = db.batch();
  let n = applyDay(st, day, next, prev, best);
  if (tamper) n = tamper(n);
  const ref = db.doc(`publicDays/${uid}/days/${day}`);
  if (next) b.set(ref, next); else b.delete(ref);
  b.set(db.doc(`publicStats/${uid}`), { ...n, updatedAt: TS() });
  return { commit: () => b.commit(), next: n };
}
// Группа (пол) от администратора: userMeta + отметка в уже существующих публичных документах (как делает приложение)
async function group(uid, sex) {
  await env.withSecurityRulesDisabled(async (c) => {
    const db = c.firestore();
    await db.doc(`userMeta/${uid}`).set({ sex, updatedAt: TS() });
    for (const p of [`publicProfiles/${uid}`, `publicStats/${uid}`]) { const d = await db.doc(p).get(); if (d.exists) await db.doc(p).update({ sex }); }
  });
}
const today = () => new Date().toISOString().slice(0, 10);
const daysAgo = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);

// ---------- Личные данные ----------
test('личные данные видит и меняет только владелец', async () => {
  await assertSucceeds(as('alice').doc('users/alice').set({ settings: { target: 70000 }, updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('users/alice/entries/2026-11-09').set({ lines: 1200, rate: 5, actual: 9000, comment: 'x' }));
  await assertFails(as('bob').doc('users/alice').get());
  await assertFails(as('bob').doc('users/alice/entries/2026-11-09').get());
  await assertFails(as('bob').collection('users/alice/entries').get());
  await assertFails(as('bob').doc('users/alice/entries/2026-11-10').set({ lines: 1 }));
  await assertFails(anon().doc('users/alice').get());
  await assertFails(as('alice').doc('users/alice/entries/не-дата').set({ lines: 1 }));
  await assertFails(as('alice').doc('users/alice').set({ hack: true }));
  await assertSucceeds(as('alice').doc('users/alice/entries/2026-11-09').delete());
});

// ---------- Ники и профили ----------
test('регистрация: уникальный ник, нельзя занять чужой', async () => {
  await assertSucceeds(register('alice', 'alice_1'));
  await assertFails(register('bob', 'alice_1'));                         // ник занят
  await assertFails(as('bob').doc('usernames/alice_1').set({ uid: 'bob' }));
  await assertFails(as('bob').doc('usernames/alice_1').delete());
  await assertFails(as('bob').doc('usernames/free_nick').set({ uid: 'bob' })); // ник без профиля
  const db = as('bob');                                                    // профиль без ника
  await assertFails(db.doc('publicProfiles/bob').set({ nick: 'bob_x', name: 'Боб', avatar: AV, createdAt: TS(), updatedAt: TS() }));
  await assertFails(register('bob', 'Плохой Ник'));                        // формат ника
  await assertFails(as('bob').doc('publicProfiles/alice').get());          // без группы от администратора — не видны
  await register('bob', 'bob_1'); await group('alice', 'm'); await group('bob', 'm');
  await assertSucceeds(as('bob').doc('publicProfiles/alice').get());       // своя группа — видны
  await assertFails(anon().doc('publicProfiles/alice').get());
  await assertFails(as('bob').doc('publicProfiles/alice').update({ name: 'Взлом', updatedAt: TS() }));
});

test('смена ника освобождает старый в той же операции', async () => {
  await register('alice', 'alice_1');
  const db = as('alice');
  let b = db.batch();                                                      // без освобождения старого — нельзя
  b.update(db.doc('publicProfiles/alice'), { nick: 'alice_2', updatedAt: TS() });
  b.set(db.doc('usernames/alice_2'), { uid: 'alice' });
  await assertFails(b.commit());
  b = db.batch();
  b.update(db.doc('publicProfiles/alice'), { nick: 'alice_2', updatedAt: TS() });
  b.set(db.doc('usernames/alice_2'), { uid: 'alice' });
  b.delete(db.doc('usernames/alice_1'));
  await assertSucceeds(b.commit());
  await assertSucceeds(register('bob', 'alice_1'));                        // старый ник теперь свободен
});

// ---------- Публичная статистика ----------
test('статистика: только пустая при создании, видна другим только при visible', async () => {
  const p = await register('alice', 'alice_1');
  const bad = { ...emptyStats(p, true), visible: true, totals: { lines: 99999, days: 1, earn: 0, best: 99999, avg: 99999 } };
  await assertFails(as('alice').doc('publicStats/alice').set({ ...bad, updatedAt: TS() }));
  const st = { ...emptyStats(p, true), visible: false };
  await assertSucceeds(as('alice').doc('publicStats/alice').set({ ...st, updatedAt: TS() }));
  await assertFails(as('bob').doc('publicStats/alice').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').update({ visible: true, updatedAt: TS() }));
  await assertFails(as('bob').doc('publicStats/alice').get());                // группы не выданы
  await group('alice', 'm'); await group('bob', 'm');
  await assertSucceeds(as('bob').doc('publicStats/alice').get());
  await assertSucceeds(as('bob').collection('publicStats').where('visible', '==', true).where('sex', '==', 'm').get());
  await assertFails(as('bob').collection('publicStats').where('visible', '==', true).get());   // без фильтра группы — нельзя
  await assertFails(as('bob').collection('publicStats').limit(10).get());   // без фильтра visible — нельзя
  await assertFails(as('bob').doc('publicStats/alice').update({ visible: false, updatedAt: TS() }));
});

test('нельзя выдать себя за другого в рейтинге', async () => {
  await register('alice', 'alice_1');
  const p = await register('bob', 'bob_1');
  await assertFails(as('bob').doc('publicStats/bob').set({ ...emptyStats({ ...p, nick: 'alice_1' }, true), updatedAt: TS() }));
});

test('публикация дней: итог всегда равен сумме дней', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const d1 = daysAgo(2), d2 = daysAgo(1), d3 = today();
  let op = dayBatch('alice', st, d1, { lines: 1000, earn: 5000 }, null, 1000);
  await assertSucceeds(op.commit()); st = op.next;
  op = dayBatch('alice', st, d2, { lines: 1200, earn: 6000 }, null, 1200);
  await assertSucceeds(op.commit()); st = op.next;
  // приписать себе лишние линии
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, totals: { ...n.totals, lines: n.totals.lines + 500, avg: (n.totals.lines + 500) / n.totals.days } })).commit());
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, month: { ...n.month, lines: n.month.lines + 500, avg: (n.month.lines + 500) / n.month.days } })).commit());
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, week: { ...n.week, days: n.week.days + 3, avg: n.week.lines / (n.week.days + 3) } })).commit());
  // день без пересчёта статистики (в том числе последний изменённый — lastDay совпадает)
  await assertFails(as('alice').doc(`publicDays/alice/days/${d3}`).set({ lines: 900, earn: 4500 }));
  await assertFails(as('alice').doc(`publicDays/alice/days/${d2}`).delete());
  await assertFails(as('alice').doc(`publicDays/alice/days/${d2}`).set({ lines: 1500, earn: 7500 }));
  // вес товара: только число в разумных пределах, тоже вместе с пересчётом статистики
  await assertFails(dayBatch('alice', st, d2, { lines: 1200, earn: 6000, kg: -1 }, { lines: 1200, earn: 6000 }, 1200).commit());
  await assertFails(dayBatch('alice', st, d2, { lines: 1200, earn: 6000, kg: 'много' }, { lines: 1200, earn: 6000 }, 1200).commit());
  op = dayBatch('alice', st, d2, { lines: 1200, earn: 6000, kg: 1850.5 }, { lines: 1200, earn: 6000 }, 1200);
  await assertSucceeds(op.commit()); st = op.next;
  // правка и удаление дня
  op = dayBatch('alice', st, d2, { lines: 1300, earn: 6500 }, { lines: 1200, earn: 6000, kg: 1850.5 }, 1300);
  await assertSucceeds(op.commit()); st = op.next;
  op = dayBatch('alice', st, d1, null, { lines: 1000, earn: 5000 }, 1300);
  await assertSucceeds(op.commit()); st = op.next;
  await group('alice', 'f'); await group('bob', 'f');
  const snap = await as('bob').doc('publicStats/alice').get();
  if (snap.data().totals.lines !== 1300 || snap.data().totals.days !== 1) throw new Error('итоги не сошлись: ' + JSON.stringify(snap.data().totals));
  if (snap.data().lastWeek !== mondayOf(d1)) throw new Error('неделя посчитана неверно');
});

test('нельзя публиковать будущие дни и нереальные значения', async () => {
  const p = await register('alice', 'alice_1');
  const st = await publish('alice', p, true);
  const future = new Date(Date.now() + 5 * 864e5).toISOString().slice(0, 10);
  await assertFails(dayBatch('alice', st, future, { lines: 1000, earn: 5000 }, null, 1000).commit());
  await assertFails(dayBatch('alice', st, today(), { lines: 9000, earn: 45000 }, null, 9000).commit());
  await assertFails(dayBatch('alice', st, today(), { lines: 1000, earn: 999999 }, null, 1000).commit());
});

test('скрытый заработок хранится нулём', async () => {
  const p = await register('alice', 'alice_1');
  const st = await publish('alice', p, false);
  await assertFails(dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000).commit());
  await assertSucceeds(dayBatch('alice', st, today(), { lines: 1000, earn: 0 }, null, 1000).commit());
});

test('графики сравнения: дни видны только при открытой статистике', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const op = dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000);
  await op.commit(); st = op.next;
  await assertFails(as('bob').collection('publicDays/alice/days').get());   // без группы
  await group('alice', 'm'); await group('bob', 'f');
  await assertFails(as('bob').collection('publicDays/alice/days').get());   // другая группа
  await group('bob', 'm');
  await assertSucceeds(as('bob').collection('publicDays/alice/days').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').update({ visible: false, updatedAt: TS() }));
  await assertFails(as('bob').collection('publicDays/alice/days').get());
  await assertFails(anon().collection('publicDays/alice/days').get());
});

test('снятие с публикации и удаление аккаунта', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const d = today();
  const op = dayBatch('alice', st, d, { lines: 1000, earn: 5000 }, null, 1000);
  await op.commit(); st = op.next;
  await assertFails(as('alice').doc(`publicDays/alice/days/${d}`).delete());   // без пересчёта — нельзя
  const db = as('alice'), b = db.batch();
  b.delete(db.doc('publicStats/alice'));
  b.delete(db.doc(`publicDays/alice/days/${d}`));
  b.delete(db.doc('publicProfiles/alice'));
  b.delete(db.doc('usernames/alice_1'));
  b.delete(db.doc('users/alice'));
  await assertSucceeds(b.commit());
  await assertSucceeds(register('bob', 'alice_1'));
});

// ---------- Чат ----------
const adminDb = () => env.authenticatedContext('boss', { email: 'evsegero.one@gmail.com', email_verified: true }).firestore();
// Доступ к чату открывает администратор
const grant = (uid) => adminDb().doc(`chatAccess/${uid}`).set({ at: TS() });
const msg = (uid, extra = {}) => ({ uid, name: 'Имя', nick: uid + '_n', text: 'Привет', createdAt: TS(), reactions: {}, deleted: false, ...extra });

test('чат: без одобрения администратора нельзя ни читать, ни писать', async () => {
  await register('alice', 'alice_1');
  await assertFails(as('alice').collection('chats/general/messages').get());
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').doc('chats/general/members/alice').set({ lastSeen: TS() }));
  await assertFails(as('alice').doc('chatAccess/alice').set({ at: TS() }));                 // сам себе не открыть
  await assertSucceeds(as('alice').doc('chatAccess/alice').get());                          // но может проверить
  await grant('alice');
  await assertSucceeds(as('alice').collection('chats/general/messages').get());
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').collection('chatAccess').get());                            // список — только админу
  await assertSucceeds(adminDb().doc('chatAccess/alice').delete());
  await assertFails(as('alice').collection('chats/general/messages').get());               // доступ закрыт
  await assertSucceeds(adminDb().collection('chats/general/messages').get());               // админу — всегда
});

test('чат: голосовые и упоминания', async () => {
  await register('alice', 'alice_1'); await grant('alice');
  const col = as('alice').collection('chats/general/messages');
  await assertSucceeds(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 3.5 })));
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA' })));                 // без длительности
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:image/png;base64,AAAA', duration: 2 })));   // не звук
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,' + 'A'.repeat(600001), duration: 2 })));
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 300 })));
  await assertFails(col.add(msg('alice', { duration: 3 })));                                                  // длительность без звука
  await assertSucceeds(col.add(msg('alice', { text: '@bob_1 привет', mentions: ['bob'] })));
  await assertFails(col.add(msg('alice', { mentions: Array.from({ length: 11 }, (_, i) => 'u' + i) })));
  // удаление стирает и звук
  const ref = await col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 1 }));
  await assertFails(as('alice').doc(ref.path).update({ deleted: true, text: '', editedAt: TS() }));            // звук остался
  await assertSucceeds(as('alice').doc(ref.path).update({ deleted: true, text: '', audio: firebase.firestore.FieldValue.delete(), duration: firebase.firestore.FieldValue.delete(), editedAt: TS() }));
});

test('чат: писать может только сборщик с профилем, от своего имени', async () => {
  await register('alice', 'alice_1'); await grant('alice'); await grant('bob');
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('bob').collection('chats/general/messages').add(msg('bob')));          // нет профиля
  await assertFails(as('alice').collection('chats/general/messages').add(msg('bob')));        // от чужого имени
  await assertFails(anon().collection('chats/general/messages').get());
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { text: 'x'.repeat(2001) })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { text: '' })));       // пустое
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice', { text: '', image: 'data:image/jpeg;base64,AAAA' })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { image: 'javascript:alert(1)' })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { reactions: { bob: '👍' } })));
  await assertFails(as('alice').collection('chats/other/messages').add(msg('alice')));
});

test('чат: реакции — только свои, правка и удаление — только своих', async () => {
  await register('alice', 'alice_1'); await register('bob', 'bob_1'); await grant('alice'); await grant('bob');
  const ref = await as('alice').collection('chats/general/messages').add(msg('alice'));
  const path = `chats/general/messages/${ref.id}`;
  await assertSucceeds(as('bob').doc(path).update({ 'reactions.bob': '🔥' }));
  await assertFails(as('bob').doc(path).update({ 'reactions.alice': '🔥' }));               // чужая реакция
  await assertFails(as('bob').doc(path).update({ 'reactions.bob': '💩' }));                 // не из списка
  await assertSucceeds(as('bob').doc(path).update({ 'reactions.bob': firebase.firestore.FieldValue.delete() }));
  await assertFails(as('bob').doc(path).update({ text: 'взлом', editedAt: TS() }));         // чужое не править
  await assertSucceeds(as('alice').doc(path).update({ text: 'исправлено', editedAt: TS() }));
  await assertFails(as('bob').doc(path).update({ deleted: true, text: '', editedAt: TS() }));
  await assertFails(as('alice').doc(path).update({ deleted: true, text: 'не стёрто', editedAt: TS() }));
  await assertSucceeds(as('alice').doc(path).update({ deleted: true, text: '', editedAt: TS() }));
  await assertFails(as('alice').doc(path).delete());                                        // насовсем — только админ
});

test('чат: «прочитано» и «печатает» — только свои', async () => {
  await register('alice', 'alice_1'); await grant('alice'); await grant('bob');
  await assertSucceeds(as('alice').doc('chats/general/members/alice').set({ lastRead: TS(), lastSeen: TS() }));
  await assertFails(as('bob').doc('chats/general/members/alice').set({ lastRead: TS() }));
  await assertSucceeds(as('bob').doc('chats/general/members/alice').get());
  await assertFails(as('alice').doc('chats/general/members/alice').set({ typingUntil: firebase.firestore.Timestamp.fromMillis(Date.now() + 3600e3) }));
});

// ---------- Администратор ----------
test('администратор: только подтверждённая почта evsegero.one@gmail.com', async () => {
  const p = await register('alice', 'alice_1');
  await publish('alice', p, true);
  const fake = env.authenticatedContext('fake', { email: 'evsegero.one@gmail.com', email_verified: false }).firestore();
  await assertFails(fake.doc('banned/alice').set({ at: TS(), reason: '', nick: 'alice_1' }));
  await assertFails(as('bob').doc('banned/alice').set({ at: TS(), reason: '', nick: 'alice_1' }));
  await assertSucceeds(adminDb().collection('publicStats').get());                         // видит и скрытые
  await assertFails(as('bob').collection('publicStats').get());
  await assertSucceeds(adminDb().doc('banned/alice').set({ at: TS(), reason: 'спам', nick: 'alice_1' }));
  await assertSucceeds(as('alice').doc('banned/alice').get());                              // свою блокировку видно
  await assertFails(as('alice').doc('banned/alice').delete());
});

test('блокировка: нет чата и рейтинга, админ удаляет статистику и сообщения', async () => {
  const p = await register('alice', 'alice_1'); await register('bob', 'bob_1'); await grant('alice');
  const ref = await as('alice').collection('chats/general/messages').add(msg('alice'));
  let st = await publish('alice', p, true);
  const op = dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000); await op.commit();
  await adminDb().doc('banned/alice').set({ at: TS(), reason: 'спам', nick: 'alice_1' });
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').collection('chats/general/messages').get());
  // админ убирает из рейтинга: статистика и дни
  const ad = adminDb(), b = ad.batch(); b.delete(ad.doc('publicStats/alice')); b.delete(ad.doc(`publicDays/alice/days/${today()}`));
  await assertSucceeds(b.commit());
  await assertFails(as('alice').doc('publicStats/alice').set({ ...emptyStats(p, true), visible: true, updatedAt: TS() })); // заблокирован — не опубликовать
  // админ удаляет чужое сообщение
  await assertSucceeds(adminDb().doc(`chats/general/messages/${ref.id}`).update({ deleted: true, text: '', editedAt: TS() }));
  await assertSucceeds(adminDb().doc(`chats/general/messages/${ref.id}`).delete());
  await assertSucceeds(adminDb().doc('banned/alice').delete());
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));  // разблокирован
});

// ---------- Значки, заметки администратора, данные из отчёта ----------
test('значки в рейтинге: свои, не больше 40, денежные — только с показом заработка', async () => {
  const p = await register('alice', 'alice_1');
  await publish('alice', p, false);
  const ref = as('alice').doc('publicStats/alice');
  await assertSucceeds(ref.update({ badges: ['first', 's10'], updatedAt: TS() }));
  await assertFails(ref.update({ badges: ['first', 'm100'], updatedAt: TS() }));            // заработок скрыт
  await assertFails(ref.update({ badges: Array.from({ length: 81 }, (_, i) => 'b' + i), updatedAt: TS() }));
  await assertSucceeds(ref.update({ badges: Array.from({ length: 69 }, (_, i) => 'b' + i), updatedAt: TS() }));
  await assertFails(ref.update({ badges: ['first', 'day5k'], updatedAt: TS() }));             // по значку видно заработок
  await assertFails(as('bob').doc('publicStats/alice').update({ badges: [], updatedAt: TS() }));
});

test('ФИО сборщиков видит и меняет только администратор', async () => {
  await register('alice', 'alice_1');
  const note = { fio: 'Иванов Пётр Сергеевич', fields: { lines: true, prod: true, actual: false }, updatedAt: TS() };
  await assertFails(as('alice').doc('adminNotes/alice').set(note));
  await assertSucceeds(adminDb().doc('adminNotes/alice').set(note));
  await assertFails(as('alice').doc('adminNotes/alice').get());                              // даже свою не видно
  await assertFails(as('bob').collection('adminNotes').get());
  await assertSucceeds(adminDb().collection('adminNotes').get());
  await assertFails(adminDb().doc('adminNotes/alice').set({ ...note, fields: { lines: 'да' } }));
});

test('календарь сборщика: смотрит и правит только он сам и администратор', async () => {
  const e = { lines: 400, actual: null, hours: null, prod: 120, start: null, end: null, mood: null, comment: '', weight: 3200, rate: 5, updatedAt: 1 };
  await assertSucceeds(as('alice').doc('users/alice').set({ settings: {}, updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('users/alice/entries/2026-11-02').set(e));
  await assertFails(as('bob').doc('users/alice/entries/2026-11-02').get());
  await assertFails(as('bob').doc('users/alice/entries/2026-11-03').set(e));
  await assertFails(as('bob').doc('users/alice').get());
  await assertSucceeds(adminDb().doc('users/alice').get());
  await assertSucceeds(adminDb().collection('users/alice/entries').get());
  await assertSucceeds(adminDb().doc('users/alice/entries/2026-11-03').set({ ...e, lines: 350 }));
  await assertFails(adminDb().doc('users/alice/entries/завтра').set(e));
  await assertSucceeds(adminDb().doc('users/alice/entries/2026-11-03').delete());
  await assertFails(adminDb().doc('users/alice').update({ settings: { hack: 1 } }));              // настройки сборщика — только он сам
});

test('администратор пересчитывает рейтинг сборщика после правки смены', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const d = daysAgo(1), ad = adminDb();
  const mk = (db, next, prev, best, tamper) => { let n = applyDay(st, d, next, prev, best); if (tamper) n = tamper(n); const b = db.batch();
    if (next) b.set(db.doc(`publicDays/alice/days/${d}`), next); else b.delete(db.doc(`publicDays/alice/days/${d}`));
    b.set(db.doc('publicStats/alice'), { ...n, updatedAt: TS() }); return { b, n }; };
  let op = mk(ad, { lines: 500, earn: 2500, kg: 900 }, null, 500);
  await assertSucceeds(op.b.commit()); st = op.n;
  // администратор не может приписать линии и не может менять имя
  await assertFails(mk(ad, { lines: 600, earn: 3000 }, { lines: 500, earn: 2500, kg: 900 }, 600, (n) => ({ ...n, totals: { ...n.totals, lines: n.totals.lines + 100, avg: (n.totals.lines + 100) / n.totals.days } })).b.commit());
  await assertFails(mk(ad, { lines: 600, earn: 3000 }, { lines: 500, earn: 2500, kg: 900 }, 600, (n) => ({ ...n, name: 'Другое имя' })).b.commit());
  // другой сборщик — нельзя
  await assertFails(mk(as('bob'), { lines: 600, earn: 3000 }, { lines: 500, earn: 2500, kg: 900 }, 600).b.commit());
  op = mk(ad, { lines: 600, earn: 3000 }, { lines: 500, earn: 2500, kg: 900 }, 600);
  await assertSucceeds(op.b.commit());
});

test('подмена имени: задаёт только администратор, читают вошедшие', async () => {
  const al = { alias: 'Аня', allow: ['bob'], updatedAt: TS() };
  await assertFails(as('alice').doc('nameAlias/alice').set(al));                          // себе — нельзя
  await assertFails(as('bob').doc('nameAlias/alice').set(al));
  await assertSucceeds(adminDb().doc('nameAlias/alice').set(al));
  await assertSucceeds(as('bob').collection('nameAlias').get());
  await assertFails(anon().doc('nameAlias/alice').get());
  await assertFails(adminDb().doc('nameAlias/alice').set({ ...al, alias: '' }));
  await assertFails(adminDb().doc('nameAlias/alice').set({ ...al, alias: 'x'.repeat(41) }));
  await assertFails(adminDb().doc('nameAlias/alice').set({ ...al, extra: 1 }));
  await assertFails(as('alice').doc('nameAlias/alice').delete());
  await assertSucceeds(adminDb().doc('nameAlias/alice').delete());
});

test('данные из отчёта: пишет только админ, сборщик видит свои и отмечает «внесено»', async () => {
  const day = '2026-10-29', imp = (x = {}) => ({ lines: 586, prod: 145.54, actual: 2942, source: 'отчёт', at: TS(), applied: false, ...x });
  await assertFails(as('alice').doc(`imports/alice/days/${day}`).set(imp()));                // сам себе не прислать
  await assertFails(adminDb().doc(`imports/alice/days/${day}`).set(imp({ lines: 586.5 })));  // линии — целые
  await assertFails(adminDb().doc(`imports/alice/days/${day}`).set(imp({ lines: 9000 })));
  await assertFails(adminDb().doc('imports/alice/days/вчера').set(imp()));
  await assertSucceeds(adminDb().doc(`imports/alice/days/${day}`).set(imp()));
  await assertSucceeds(adminDb().doc('imports/alice/days/2026-10-30').set({ lines: 10, source: '', at: TS(), applied: false })); // только линии
  await assertSucceeds(as('alice').collection('imports/alice/days').where('applied', '==', false).get());
  await assertFails(as('bob').doc(`imports/alice/days/${day}`).get());
  await assertFails(as('alice').doc(`imports/alice/days/${day}`).update({ lines: 9999 }));   // цифры не подделать
  await assertSucceeds(as('alice').doc(`imports/alice/days/${day}`).update({ applied: true, appliedAt: TS() }));
  await assertSucceeds(as('alice').doc(`imports/alice/days/${day}`).delete());
});

test('оформление профиля: статус и эффекты — короткие строки, только свои', async () => {
  await register('alice', 'alice_1');
  const ref = as('alice').doc('publicProfiles/alice');
  await assertSucceeds(ref.update({ status: '🔥', fx: { bg: 'stars', frame: 'fire', name: 'gold', theme: 'violet' }, updatedAt: TS() }));
  await assertFails(ref.update({ fx: { bg: 'stars', hack: 'x' }, updatedAt: TS() }));
  await assertSucceeds(ref.update({ fx: { bg: 'galaxy', frame: 'love', name: 'gold', theme: 'violet', cover: 'night' }, updatedAt: TS() }));
  await assertFails(ref.update({ fx: { cover: 'x'.repeat(17) }, updatedAt: TS() }));
  await assertFails(ref.update({ status: 'x'.repeat(40), updatedAt: TS() }));
  await assertFails(as('bob').doc('publicProfiles/alice').update({ status: '😴', updatedAt: TS() }));
});

test('публикация дня у сборщика с оформлением, статусом, значками и фото (как в жизни)', async () => {
  const look = { status: '🔥', fx: { bg: 'stars', frame: 'fire', name: 'gold', theme: 'violet', cover: 'sklad' } };
  const photo = { kind: 'photo', v: 'data:image/jpeg;base64,' + 'A'.repeat(25000) };
  const db = as('alice'), b = db.batch();
  b.set(db.doc('publicProfiles/alice'), { nick: 'alice_1', name: 'Алиса', avatar: photo, ...look, createdAt: TS(), updatedAt: TS() });
  b.set(db.doc('usernames/alice_1'), { uid: 'alice' });
  await assertSucceeds(b.commit());
  const prof = { nick: 'alice_1', name: 'Алиса', avatar: photo };
  let st = { ...emptyStats(prof, true), visible: true, ...look, badges: ['first', 's10', 's50', 'p140', 'l400', 'st5', 'green'] };
  await assertSucceeds(as('alice').doc('publicStats/alice').set({ ...st, updatedAt: TS() }));
  // несколько дней подряд, как при сверке после офлайна
  for (const [i, lines] of [[3, 400], [2, 450], [1, 500]]) {
    const r = dayBatch('alice', st, daysAgo(i), { lines, earn: lines * 5 }, null, Math.max(400, lines));
    await assertSucceeds(r.commit()); st = r.next;
  }
  // правка уже опубликованного дня
  const r = dayBatch('alice', st, daysAgo(2), { lines: 610, earn: 3050 }, { lines: 450, earn: 2250 }, 610);
  await assertSucceeds(r.commit());
});

// ---------- Группы (пол) и зоны ----------
test('группы: выдаёт только администратор, девочки и ребята не видят друг друга', async () => {
  const pa = await register('alice', 'alice_1'), pb = await register('bob', 'bob_1'), pc = await register('carl', 'carl_1');
  // сам себе группу не выдать
  await assertFails(as('alice').doc('userMeta/alice').set({ sex: 'f', updatedAt: TS() }));
  await assertFails(as('alice').doc('publicProfiles/alice').update({ sex: 'f', updatedAt: TS() }));
  await assertFails(adminDb().doc('userMeta/alice').set({ sex: 'x', updatedAt: TS() }));
  await assertFails(adminDb().doc('userMeta/alice').set({ zone: 'луна', updatedAt: TS() }));
  await assertSucceeds(adminDb().doc('userMeta/alice').set({ sex: 'f', zone: 'mars', updatedAt: TS() }));
  await assertSucceeds(adminDb().doc('userMeta/bob').set({ sex: 'm', zone: 'korm', updatedAt: TS() }));
  await assertSucceeds(adminDb().doc('userMeta/carl').set({ sex: 'm', updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('userMeta/alice').get());          // свою читает
  await assertFails(as('bob').doc('userMeta/alice').get());               // чужую — нет
  await assertFails(as('bob').collection('userMeta').get());
  // администратор проставляет группу в профиль (и ничего другого не меняет)
  await assertSucceeds(adminDb().doc('publicProfiles/alice').update({ sex: 'f' }));
  await assertFails(adminDb().doc('publicProfiles/alice').update({ sex: 'm', name: 'Другое' }));
  // сборщик проставляет себе только выданную группу
  await assertFails(as('bob').doc('publicProfiles/bob').update({ sex: 'f', updatedAt: TS() }));
  await assertSucceeds(as('bob').doc('publicProfiles/bob').update({ sex: 'm', updatedAt: TS() }));
  await assertSucceeds(as('carl').doc('publicProfiles/carl').update({ sex: 'm', updatedAt: TS() }));
  await assertFails(as('alice').doc('publicProfiles/alice').update({ sex: 'm', updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('publicProfiles/alice').update({ name: 'Алиса', updatedAt: TS() })); // остальное — как раньше
  // профили: только своя группа
  await assertSucceeds(as('bob').doc('publicProfiles/carl').get());
  await assertFails(as('bob').doc('publicProfiles/alice').get());
  await assertFails(as('alice').doc('publicProfiles/bob').get());
  await assertSucceeds(as('bob').collection('publicProfiles').where('sex', '==', 'm').get());
  await assertFails(as('bob').collection('publicProfiles').where('sex', '==', 'f').get());
  await assertFails(as('bob').collection('publicProfiles').get());
  // статистика: создать можно только со своей группой
  await assertFails(as('alice').doc('publicStats/alice').set({ ...emptyStats(pa, true), visible: true, sex: 'm', updatedAt: TS() }));
  await assertFails(as('alice').doc('publicStats/alice').set({ ...emptyStats(pa, true), visible: true, updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('publicStats/alice').set({ ...emptyStats(pa, true), visible: true, sex: 'f', updatedAt: TS() }));
  await assertSucceeds(as('bob').doc('publicStats/bob').set({ ...emptyStats(pb, true), visible: true, sex: 'm', updatedAt: TS() }));
  await assertSucceeds(as('carl').doc('publicStats/carl').set({ ...emptyStats(pc, true), visible: true, sex: 'm', updatedAt: TS() }));
  await assertFails(as('alice').doc('publicStats/alice').update({ sex: 'm', updatedAt: TS() }));      // поменять группу — нельзя
  // рейтинг: только своя группа
  await assertSucceeds(as('bob').collection('publicStats').where('visible', '==', true).where('sex', '==', 'm').get());
  await assertFails(as('bob').collection('publicStats').where('visible', '==', true).where('sex', '==', 'f').get());
  await assertFails(as('alice').collection('publicStats').where('visible', '==', true).where('sex', '==', 'm').get());
  await assertSucceeds(as('alice').collection('publicStats').where('visible', '==', true).where('sex', '==', 'f').get());
  await assertFails(as('bob').doc('publicStats/alice').get());
  await assertSucceeds(as('bob').doc('publicStats/carl').get());
  // публикация дня с группой проходит
  const st = { ...emptyStats(pa, true), visible: true, sex: 'f' };
  await assertSucceeds(dayBatch('alice', st, today(), { lines: 1000, earn: 5160 }, null, 1000).commit());
  await assertFails(as('bob').collection('publicDays/alice/days').get());
  // администратор видит всех и переводит группу
  await assertSucceeds(adminDb().collection('publicStats').get());
  await assertSucceeds(adminDb().collection('userMeta').get());
  await assertSucceeds(adminDb().doc('publicStats/alice').update({ sex: 'm', updatedAt: TS() }));
  // без группы — никого не видит
  await register('dan', 'dan_1');
  await assertFails(as('dan').collection('publicProfiles').where('sex', '==', 'm').get());
  await assertFails(as('dan').doc('publicProfiles/bob').get());
});
