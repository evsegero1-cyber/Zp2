// Тесты правил Firestore (firestore.rules) на локальном эмуляторе.
// Запуск: cd tests/rules && npm install && npm test   (в GitHub Actions — автоматически, workflow web.yml)
import test, { before, after, beforeEach } from 'node:test';
import { readFileSync } from 'node:fs';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { emptyStats, applyDay, mondayOf } from '../../src/cloud/stats.js';

const TS = () => firebase.firestore.FieldValue.serverTimestamp();
let env;

before(async () => {
  env = await initializeTestEnvironment({
    projectId: 'demo-zarplata',
    firestore: { rules: readFileSync(new URL('../../firestore.rules', import.meta.url), 'utf8'), host: '127.0.0.1', port: 8080 },
  });
});
after(async () => { if (env) await env.cleanup(); });
beforeEach(async () => { await env.clearFirestore(); });

const as = (uid) => env.authenticatedContext(uid).firestore();
const anon = () => env.unauthenticatedContext().firestore();
const AV = { kind: 'preset', v: 'cat' };

// Регистрация «как в приложении»: профиль + ник одной транзакцией (batch)
async function register(uid, nick, name = 'Сборщик') {
  const db = as(uid), b = db.batch();
  b.set(db.doc(`publicProfiles/${uid}`), { nick, name, avatar: AV, createdAt: TS(), updatedAt: TS() });
  b.set(db.doc(`usernames/${nick}`), { uid });
  await b.commit();
  return { nick, name, avatar: AV };
}
// Опубликовать статистику (пустую) и вернуть её
async function publish(uid, prof, showEarn = true) {
  const st = { ...emptyStats(prof, showEarn), visible: true };
  await as(uid).doc(`publicStats/${uid}`).set({ ...st, updatedAt: TS() });
  return st;
}
// Изменить день: batch {день, статистика}
function dayBatch(uid, st, day, next, prev, best, tamper) {
  const db = as(uid), b = db.batch();
  let n = applyDay(st, day, next, prev, best);
  if (tamper) n = tamper(n);
  const ref = db.doc(`publicDays/${uid}/days/${day}`);
  if (next) b.set(ref, next); else b.delete(ref);
  b.set(db.doc(`publicStats/${uid}`), { ...n, updatedAt: TS() });
  return { commit: () => b.commit(), next: n };
}
const today = () => new Date().toISOString().slice(0, 10);
const daysAgo = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);

// ---------- Личные данные ----------
test('личные данные видит и меняет только владелец', async () => {
  await assertSucceeds(as('alice').doc('users/alice').set({ settings: { target: 70000 }, updatedAt: TS() }));
  await assertSucceeds(as('alice').doc('users/alice/entries/2026-11-09').set({ lines: 1200, rate: 5, actual: 9000, comment: 'x' }));
  await assertFails(as('bob').doc('users/alice').get());
  await assertFails(as('bob').doc('users/alice/entries/2026-11-09').get());
  await assertFails(as('bob').collection('users/alice/entries').get());
  await assertFails(as('bob').doc('users/alice/entries/2026-11-10').set({ lines: 1 }));
  await assertFails(anon().doc('users/alice').get());
  await assertFails(as('alice').doc('users/alice/entries/не-дата').set({ lines: 1 }));
  await assertFails(as('alice').doc('users/alice').set({ hack: true }));
  await assertSucceeds(as('alice').doc('users/alice/entries/2026-11-09').delete());
});

// ---------- Ники и профили ----------
test('регистрация: уникальный ник, нельзя занять чужой', async () => {
  await assertSucceeds(register('alice', 'alice_1'));
  await assertFails(register('bob', 'alice_1'));                         // ник занят
  await assertFails(as('bob').doc('usernames/alice_1').set({ uid: 'bob' }));
  await assertFails(as('bob').doc('usernames/alice_1').delete());
  await assertFails(as('bob').doc('usernames/free_nick').set({ uid: 'bob' })); // ник без профиля
  const db = as('bob');                                                    // профиль без ника
  await assertFails(db.doc('publicProfiles/bob').set({ nick: 'bob_x', name: 'Боб', avatar: AV, createdAt: TS(), updatedAt: TS() }));
  await assertFails(register('bob', 'Плохой Ник'));                        // формат ника
  await assertSucceeds(as('bob').doc('publicProfiles/alice').get());       // профили видны вошедшим
  await assertFails(anon().doc('publicProfiles/alice').get());
  await assertFails(as('bob').doc('publicProfiles/alice').update({ name: 'Взлом', updatedAt: TS() }));
});

test('смена ника освобождает старый в той же операции', async () => {
  await register('alice', 'alice_1');
  const db = as('alice');
  let b = db.batch();                                                      // без освобождения старого — нельзя
  b.update(db.doc('publicProfiles/alice'), { nick: 'alice_2', updatedAt: TS() });
  b.set(db.doc('usernames/alice_2'), { uid: 'alice' });
  await assertFails(b.commit());
  b = db.batch();
  b.update(db.doc('publicProfiles/alice'), { nick: 'alice_2', updatedAt: TS() });
  b.set(db.doc('usernames/alice_2'), { uid: 'alice' });
  b.delete(db.doc('usernames/alice_1'));
  await assertSucceeds(b.commit());
  await assertSucceeds(register('bob', 'alice_1'));                        // старый ник теперь свободен
});

// ---------- Публичная статистика ----------
test('статистика: только пустая при создании, видна другим только при visible', async () => {
  const p = await register('alice', 'alice_1');
  const bad = { ...emptyStats(p, true), visible: true, totals: { lines: 99999, days: 1, earn: 0, best: 99999, avg: 99999 } };
  await assertFails(as('alice').doc('publicStats/alice').set({ ...bad, updatedAt: TS() }));
  const st = { ...emptyStats(p, true), visible: false };
  await assertSucceeds(as('alice').doc('publicStats/alice').set({ ...st, updatedAt: TS() }));
  await assertFails(as('bob').doc('publicStats/alice').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').update({ visible: true, updatedAt: TS() }));
  await assertSucceeds(as('bob').doc('publicStats/alice').get());
  await assertSucceeds(as('bob').collection('publicStats').where('visible', '==', true).orderBy('totals.lines', 'desc').limit(10).get());
  await assertFails(as('bob').collection('publicStats').limit(10).get());   // без фильтра visible — нельзя
  await assertFails(as('bob').doc('publicStats/alice').update({ visible: false, updatedAt: TS() }));
});

test('нельзя выдать себя за другого в рейтинге', async () => {
  await register('alice', 'alice_1');
  const p = await register('bob', 'bob_1');
  await assertFails(as('bob').doc('publicStats/bob').set({ ...emptyStats({ ...p, nick: 'alice_1' }, true), updatedAt: TS() }));
});

test('публикация дней: итог всегда равен сумме дней', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const d1 = daysAgo(2), d2 = daysAgo(1), d3 = today();
  let op = dayBatch('alice', st, d1, { lines: 1000, earn: 5000 }, null, 1000);
  await assertSucceeds(op.commit()); st = op.next;
  op = dayBatch('alice', st, d2, { lines: 1200, earn: 6000 }, null, 1200);
  await assertSucceeds(op.commit()); st = op.next;
  // приписать себе лишние линии
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, totals: { ...n.totals, lines: n.totals.lines + 500, avg: (n.totals.lines + 500) / n.totals.days } })).commit());
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, month: { ...n.month, lines: n.month.lines + 500, avg: (n.month.lines + 500) / n.month.days } })).commit());
  await assertFails(dayBatch('alice', st, d3, { lines: 900, earn: 4500 }, null, 1200, (n) => ({ ...n, week: { ...n.week, days: n.week.days + 3, avg: n.week.lines / (n.week.days + 3) } })).commit());
  // день без пересчёта статистики (в том числе последний изменённый — lastDay совпадает)
  await assertFails(as('alice').doc(`publicDays/alice/days/${d3}`).set({ lines: 900, earn: 4500 }));
  await assertFails(as('alice').doc(`publicDays/alice/days/${d2}`).delete());
  await assertFails(as('alice').doc(`publicDays/alice/days/${d2}`).set({ lines: 1500, earn: 7500 }));
  // правка и удаление дня
  op = dayBatch('alice', st, d2, { lines: 1300, earn: 6500 }, { lines: 1200, earn: 6000 }, 1300);
  await assertSucceeds(op.commit()); st = op.next;
  op = dayBatch('alice', st, d1, null, { lines: 1000, earn: 5000 }, 1300);
  await assertSucceeds(op.commit()); st = op.next;
  const snap = await as('bob').doc('publicStats/alice').get();
  if (snap.data().totals.lines !== 1300 || snap.data().totals.days !== 1) throw new Error('итоги не сошлись: ' + JSON.stringify(snap.data().totals));
  if (snap.data().lastWeek !== mondayOf(d1)) throw new Error('неделя посчитана неверно');
});

test('нельзя публиковать будущие дни и нереальные значения', async () => {
  const p = await register('alice', 'alice_1');
  const st = await publish('alice', p, true);
  const future = new Date(Date.now() + 5 * 864e5).toISOString().slice(0, 10);
  await assertFails(dayBatch('alice', st, future, { lines: 1000, earn: 5000 }, null, 1000).commit());
  await assertFails(dayBatch('alice', st, today(), { lines: 9000, earn: 45000 }, null, 9000).commit());
  await assertFails(dayBatch('alice', st, today(), { lines: 1000, earn: 999999 }, null, 1000).commit());
});

test('скрытый заработок хранится нулём', async () => {
  const p = await register('alice', 'alice_1');
  const st = await publish('alice', p, false);
  await assertFails(dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000).commit());
  await assertSucceeds(dayBatch('alice', st, today(), { lines: 1000, earn: 0 }, null, 1000).commit());
});

test('графики сравнения: дни видны только при открытой статистике', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const op = dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000);
  await op.commit(); st = op.next;
  await assertSucceeds(as('bob').collection('publicDays/alice/days').get());
  await assertSucceeds(as('alice').doc('publicStats/alice').update({ visible: false, updatedAt: TS() }));
  await assertFails(as('bob').collection('publicDays/alice/days').get());
  await assertFails(anon().collection('publicDays/alice/days').get());
});

test('снятие с публикации и удаление аккаунта', async () => {
  const p = await register('alice', 'alice_1');
  let st = await publish('alice', p, true);
  const d = today();
  const op = dayBatch('alice', st, d, { lines: 1000, earn: 5000 }, null, 1000);
  await op.commit(); st = op.next;
  await assertFails(as('alice').doc(`publicDays/alice/days/${d}`).delete());   // без пересчёта — нельзя
  const db = as('alice'), b = db.batch();
  b.delete(db.doc('publicStats/alice'));
  b.delete(db.doc(`publicDays/alice/days/${d}`));
  b.delete(db.doc('publicProfiles/alice'));
  b.delete(db.doc('usernames/alice_1'));
  b.delete(db.doc('users/alice'));
  await assertSucceeds(b.commit());
  await assertSucceeds(register('bob', 'alice_1'));
});

// ---------- Чат ----------
const adminDb = () => env.authenticatedContext('boss', { email: 'evsegero.one@gmail.com', email_verified: true }).firestore();
// Доступ к чату открывает администратор
const grant = (uid) => adminDb().doc(`chatAccess/${uid}`).set({ at: TS() });
const msg = (uid, extra = {}) => ({ uid, name: 'Имя', nick: uid + '_n', text: 'Привет', createdAt: TS(), reactions: {}, deleted: false, ...extra });

test('чат: без одобрения администратора нельзя ни читать, ни писать', async () => {
  await register('alice', 'alice_1');
  await assertFails(as('alice').collection('chats/general/messages').get());
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').doc('chats/general/members/alice').set({ lastSeen: TS() }));
  await assertFails(as('alice').doc('chatAccess/alice').set({ at: TS() }));                 // сам себе не открыть
  await assertSucceeds(as('alice').doc('chatAccess/alice').get());                          // но может проверить
  await grant('alice');
  await assertSucceeds(as('alice').collection('chats/general/messages').get());
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').collection('chatAccess').get());                            // список — только админу
  await assertSucceeds(adminDb().doc('chatAccess/alice').delete());
  await assertFails(as('alice').collection('chats/general/messages').get());               // доступ закрыт
  await assertSucceeds(adminDb().collection('chats/general/messages').get());               // админу — всегда
});

test('чат: голосовые и упоминания', async () => {
  await register('alice', 'alice_1'); await grant('alice');
  const col = as('alice').collection('chats/general/messages');
  await assertSucceeds(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 3.5 })));
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA' })));                 // без длительности
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:image/png;base64,AAAA', duration: 2 })));   // не звук
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,' + 'A'.repeat(600001), duration: 2 })));
  await assertFails(col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 300 })));
  await assertFails(col.add(msg('alice', { duration: 3 })));                                                  // длительность без звука
  await assertSucceeds(col.add(msg('alice', { text: '@bob_1 привет', mentions: ['bob'] })));
  await assertFails(col.add(msg('alice', { mentions: Array.from({ length: 11 }, (_, i) => 'u' + i) })));
  // удаление стирает и звук
  const ref = await col.add(msg('alice', { text: '', audio: 'data:audio/mp4;base64,AAAA', duration: 1 }));
  await assertFails(as('alice').doc(ref.path).update({ deleted: true, text: '', editedAt: TS() }));            // звук остался
  await assertSucceeds(as('alice').doc(ref.path).update({ deleted: true, text: '', audio: firebase.firestore.FieldValue.delete(), duration: firebase.firestore.FieldValue.delete(), editedAt: TS() }));
});

test('чат: писать может только сборщик с профилем, от своего имени', async () => {
  await register('alice', 'alice_1'); await grant('alice'); await grant('bob');
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('bob').collection('chats/general/messages').add(msg('bob')));          // нет профиля
  await assertFails(as('alice').collection('chats/general/messages').add(msg('bob')));        // от чужого имени
  await assertFails(anon().collection('chats/general/messages').get());
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { text: 'x'.repeat(2001) })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { text: '' })));       // пустое
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice', { text: '', image: 'data:image/jpeg;base64,AAAA' })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { image: 'javascript:alert(1)' })));
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice', { reactions: { bob: '👍' } })));
  await assertFails(as('alice').collection('chats/other/messages').add(msg('alice')));
});

test('чат: реакции — только свои, правка и удаление — только своих', async () => {
  await register('alice', 'alice_1'); await register('bob', 'bob_1'); await grant('alice'); await grant('bob');
  const ref = await as('alice').collection('chats/general/messages').add(msg('alice'));
  const path = `chats/general/messages/${ref.id}`;
  await assertSucceeds(as('bob').doc(path).update({ 'reactions.bob': '🔥' }));
  await assertFails(as('bob').doc(path).update({ 'reactions.alice': '🔥' }));               // чужая реакция
  await assertFails(as('bob').doc(path).update({ 'reactions.bob': '💩' }));                 // не из списка
  await assertSucceeds(as('bob').doc(path).update({ 'reactions.bob': firebase.firestore.FieldValue.delete() }));
  await assertFails(as('bob').doc(path).update({ text: 'взлом', editedAt: TS() }));         // чужое не править
  await assertSucceeds(as('alice').doc(path).update({ text: 'исправлено', editedAt: TS() }));
  await assertFails(as('bob').doc(path).update({ deleted: true, text: '', editedAt: TS() }));
  await assertFails(as('alice').doc(path).update({ deleted: true, text: 'не стёрто', editedAt: TS() }));
  await assertSucceeds(as('alice').doc(path).update({ deleted: true, text: '', editedAt: TS() }));
  await assertFails(as('alice').doc(path).delete());                                        // насовсем — только админ
});

test('чат: «прочитано» и «печатает» — только свои', async () => {
  await register('alice', 'alice_1'); await grant('alice'); await grant('bob');
  await assertSucceeds(as('alice').doc('chats/general/members/alice').set({ lastRead: TS(), lastSeen: TS() }));
  await assertFails(as('bob').doc('chats/general/members/alice').set({ lastRead: TS() }));
  await assertSucceeds(as('bob').doc('chats/general/members/alice').get());
  await assertFails(as('alice').doc('chats/general/members/alice').set({ typingUntil: firebase.firestore.Timestamp.fromMillis(Date.now() + 3600e3) }));
});

// ---------- Администратор ----------
test('администратор: только подтверждённая почта evsegero.one@gmail.com', async () => {
  const p = await register('alice', 'alice_1');
  await publish('alice', p, true);
  const fake = env.authenticatedContext('fake', { email: 'evsegero.one@gmail.com', email_verified: false }).firestore();
  await assertFails(fake.doc('banned/alice').set({ at: TS(), reason: '', nick: 'alice_1' }));
  await assertFails(as('bob').doc('banned/alice').set({ at: TS(), reason: '', nick: 'alice_1' }));
  await assertSucceeds(adminDb().collection('publicStats').get());                         // видит и скрытые
  await assertFails(as('bob').collection('publicStats').get());
  await assertSucceeds(adminDb().doc('banned/alice').set({ at: TS(), reason: 'спам', nick: 'alice_1' }));
  await assertSucceeds(as('alice').doc('banned/alice').get());                              // свою блокировку видно
  await assertFails(as('alice').doc('banned/alice').delete());
});

test('блокировка: нет чата и рейтинга, админ удаляет статистику и сообщения', async () => {
  const p = await register('alice', 'alice_1'); await register('bob', 'bob_1'); await grant('alice');
  const ref = await as('alice').collection('chats/general/messages').add(msg('alice'));
  let st = await publish('alice', p, true);
  const op = dayBatch('alice', st, today(), { lines: 1000, earn: 5000 }, null, 1000); await op.commit();
  await adminDb().doc('banned/alice').set({ at: TS(), reason: 'спам', nick: 'alice_1' });
  await assertFails(as('alice').collection('chats/general/messages').add(msg('alice')));
  await assertFails(as('alice').collection('chats/general/messages').get());
  // админ убирает из рейтинга: статистика и дни
  const ad = adminDb(), b = ad.batch(); b.delete(ad.doc('publicStats/alice')); b.delete(ad.doc(`publicDays/alice/days/${today()}`));
  await assertSucceeds(b.commit());
  await assertFails(as('alice').doc('publicStats/alice').set({ ...emptyStats(p, true), visible: true, updatedAt: TS() })); // заблокирован — не опубликовать
  // админ удаляет чужое сообщение
  await assertSucceeds(adminDb().doc(`chats/general/messages/${ref.id}`).update({ deleted: true, text: '', editedAt: TS() }));
  await assertSucceeds(adminDb().doc(`chats/general/messages/${ref.id}`).delete());
  await assertSucceeds(adminDb().doc('banned/alice').delete());
  await assertSucceeds(as('alice').collection('chats/general/messages').add(msg('alice')));  // разблокирован
});

// ---------- Значки, заметки администратора, данные из отчёта ----------
test('значки в рейтинге: свои, не больше 40, денежные — только с показом заработка', async () => {
  const p = await register('alice', 'alice_1');
  await publish('alice', p, false);
  const ref = as('alice').doc('publicStats/alice');
  await assertSucceeds(ref.update({ badges: ['first', 's10'], updatedAt: TS() }));
  await assertFails(ref.update({ badges: ['first', 'm100'], updatedAt: TS() }));            // заработок скрыт
  await assertFails(ref.update({ badges: Array.from({ length: 41 }, (_, i) => 'b' + i), updatedAt: TS() }));
  await assertFails(as('bob').doc('publicStats/alice').update({ badges: [], updatedAt: TS() }));
});

test('ФИО сборщиков видит и меняет только администратор', async () => {
  await register('alice', 'alice_1');
  const note = { fio: 'Иванов Пётр Сергеевич', fields: { lines: true, prod: true, actual: false }, updatedAt: TS() };
  await assertFails(as('alice').doc('adminNotes/alice').set(note));
  await assertSucceeds(adminDb().doc('adminNotes/alice').set(note));
  await assertFails(as('alice').doc('adminNotes/alice').get());                              // даже свою не видно
  await assertFails(as('bob').collection('adminNotes').get());
  await assertSucceeds(adminDb().collection('adminNotes').get());
  await assertFails(adminDb().doc('adminNotes/alice').set({ ...note, fields: { lines: 'да' } }));
});

test('данные из отчёта: пишет только админ, сборщик видит свои и отмечает «внесено»', async () => {
  const day = '2026-10-29', imp = (x = {}) => ({ lines: 586, prod: 145.54, actual: 2942, source: 'отчёт', at: TS(), applied: false, ...x });
  await assertFails(as('alice').doc(`imports/alice/days/${day}`).set(imp()));                // сам себе не прислать
  await assertFails(adminDb().doc(`imports/alice/days/${day}`).set(imp({ lines: 586.5 })));  // линии — целые
  await assertFails(adminDb().doc(`imports/alice/days/${day}`).set(imp({ lines: 9000 })));
  await assertFails(adminDb().doc('imports/alice/days/вчера').set(imp()));
  await assertSucceeds(adminDb().doc(`imports/alice/days/${day}`).set(imp()));
  await assertSucceeds(adminDb().doc('imports/alice/days/2026-10-30').set({ lines: 10, source: '', at: TS(), applied: false })); // только линии
  await assertSucceeds(as('alice').collection('imports/alice/days').where('applied', '==', false).get());
  await assertFails(as('bob').doc(`imports/alice/days/${day}`).get());
  await assertFails(as('alice').doc(`imports/alice/days/${day}`).update({ lines: 9999 }));   // цифры не подделать
  await assertSucceeds(as('alice').doc(`imports/alice/days/${day}`).update({ applied: true, appliedAt: TS() }));
  await assertSucceeds(as('alice').doc(`imports/alice/days/${day}`).delete());
});
