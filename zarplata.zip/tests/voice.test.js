const test = require('node:test');
const assert = require('node:assert');
const V = require('../src/voice.js');
const P = V.parseShift;
const eq = (s, exp) => { const r = P(s); for (const k of Object.keys(exp)) assert.strictEqual(r[k], exp[k], `${s} → ${k}: ${r[k]} ≠ ${exp[k]}`); };

test('числа словами', () => {
  assert.strictEqual(V.wordsToDigits('триста сорок четыре линии'), '344 линии');
  assert.strictEqual(V.wordsToDigits('сто пятьдесят три и тридцать два'), '153 и 32');
  assert.strictEqual(V.wordsToDigits('тысяча двести'), '1200');
  assert.strictEqual(V.wordsToDigits('две тысячи сорок'), '2040');
  assert.strictEqual(V.wordsToDigits('девятнадцать'), '19');
});
test('пример из приложения', () => {
  eq('344 линии 153,32 производительность', { lines: 344, prod: 153.32 });
  eq('344 линии 153.32 производительность', { lines: 344, prod: 153.32 });
  eq('Триста сорок четыре линии сто пятьдесят три и тридцать два производительность', { lines: 344, prod: 153.32 });
  eq('сто пятьдесят три целых тридцать две процента триста сорок четыре линии', { lines: 344, prod: 153.32 });
});
test('порядок слов и проценты', () => {
  eq('производительность 120 процентов линий 410', { lines: 410, prod: 120 });
  eq('линий 410, производительность 98,5', { lines: 410, prod: 98.5 });
  eq('сто двадцать пять процентов', { prod: 125, lines: null });
  eq('125% 300 линий', { prod: 125, lines: 300 });
});
test('без ключевых слов', () => {
  eq('344 153,32', { lines: 344, prod: 153.32 });
  eq('344', { lines: 344, prod: null });
});
test('заработок, часы, комментарий', () => {
  eq('500 линий заработал 2 750 рублей 10 часов', { lines: 500, actual: 2750, hours: 10 });
  eq('300 линий комментарий тяжёлая смена', { lines: 300, comment: 'тяжелая смена' });
  eq('тысяча двести линий', { lines: 1200 });
});
test('пустая фраза', () => { eq('', { lines: null, prod: null }); eq('привет', { lines: null }); });
