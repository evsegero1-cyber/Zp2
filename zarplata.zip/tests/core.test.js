const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');

test('календарь 2027: 365 дней, 247 рабочих, неделя с понедельника', () => {
  const all = C.yearKeys();
  assert.equal(all.length, 365);
  assert.equal(all.filter((k) => !C.dayInfo(k).off).length, 261); // все будни рабочие
  assert.equal(C.weekdayMon('2027-01-01'), 4); // пятница
  assert.equal(C.weekdayMon('2027-03-01'), 0); // понедельник
  const g = C.calendarGrid(0);
  assert.equal(g[0].filter((x) => x === null).length, 4);
  assert.equal(g.flat().filter(Boolean).length, 31);
  assert.ok(g.every((w) => w.length === 7));
  assert.equal(C.calendarGrid(1).flat().filter(Boolean).length, 28);
});

test('выходные только сб и вс, праздники рабочие (сделка / ИП)', () => {
  assert.equal(C.workdaysInMonth(0), 21);                 // январь 2027
  assert.equal(C.dayInfo('2027-01-01').off, false);      // 1 января — пятница, рабочий
  assert.equal(C.dayInfo('2027-03-08').off, false);
  assert.equal(C.dayInfo('2027-02-20').off, true);       // суббота — выходной
  assert.equal(C.dayInfo('2027-03-14').off, true);       // воскресенье
  assert.equal(C.workdaysInMonth(2), 23);
});

test('три года: 2026, 2027, 2028', () => {
  assert.deepEqual(C.YEARS, [2026, 2027, 2028]);
  assert.equal(C.yearKeys(2026).length, 365);
  assert.equal(C.yearKeys(2028).length, 366);            // високосный
  assert.equal(C.calendarGrid(1, 2028).flat().filter(Boolean).length, 29);
  assert.ok(C.inYear('2026-11-09') && C.inYear('2028-12-31') && !C.inYear('2029-01-01') && !C.inYear('2025-12-31'));
  assert.ok(C.inYear('2026-11-09', 2026) && !C.inYear('2026-11-09', 2027));
  assert.deepEqual(C.ymOf(0), { y: 2026, m: 0 });
  assert.deepEqual(C.ymOf(35), { y: 2028, m: 11 });
  assert.equal(C.indexOf(2027, 0), 12);
  const st = C.defaultState();
  assert.equal(C.rateFor(st.settings.rateHistory, '2026-05-01'), 5);
  C.saveEntry(st, '2026-12-01', { lines: 100, prod: 130 });
  C.saveEntry(st, '2028-02-29', { lines: 50 });
  C.setMonthData(st, 11, { service: 99.99, penalty: 100 }, 2026);
  const dec = C.monthSummary(st, 11, '2027-01-05', 2026);
  assert.equal(dec.grand, 500 - 100);            // в итоге: смены − штраф
  assert.equal(dec.pending, 30000);              // обе премии — отдельно, «ожидается»
  assert.equal(C.monthSummary(st, 11, '2027-01-05').grand, 0); // декабрь 2027 — отдельно
  assert.equal(C.yearByMonths(st, 2028)[1].total, 250);
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.months['2026-12'].penalty, 100);
  assert.equal(back.entries['2028-02-29'].lines, 50);
});

test('цветовая гамма сохраняется в копии', () => {
  const st = C.defaultState();
  assert.equal(st.settings.palette.accent, '#e8590c');
  st.settings.palette = { id: 'custom', accent: '#123456', accent2: '#abcdef' };
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.settings.palette.accent, '#123456');
  const bad = C.normalizeState({ settings: { palette: { accent: 'red', accent2: '#000000' } }, entries: {} }).state;
  assert.equal(bad.settings.palette.accent, '#e8590c');
  assert.equal(C.PALETTES.length, 8);
});

test('расчёт: линии × тариф, факт отдельно', () => {
  const st = C.defaultState();
  assert.ok(C.saveEntry(st, '2027-03-01', { lines: '250' }).ok);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1250);
  C.saveEntry(st, '2027-03-02', { lines: 300, actual: '1600,50' });
  const e = st.entries['2027-03-02'];
  assert.equal(C.estimated(e), 1500);
  assert.equal(C.total(e), 1600.5);
  const s = C.summarize(st.entries, C.monthKeys(2));
  assert.equal(s.shifts, 2);
  assert.equal(s.lines, 550);
  assert.equal(s.estimated, 2750);
  assert.equal(s.actual, 1600.5);
  assert.equal(s.total, 2850.5);
  assert.equal(s.diff, 100.5);
  assert.equal(s.avgLines, 275);
  assert.equal(s.avgPerShift, 1425.25);
  assert.equal(s.best.key, '2027-03-02');
});

test('валидация', () => {
  const st = C.defaultState();
  assert.equal(C.saveEntry(st, '2027-03-01', {}).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: -1 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 2.5 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 'abc' }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 10, hours: 30 }).ok, false);
  assert.ok(C.saveEntry(st, '2027-03-01', { actual: 2000 }).ok); // только факт
  assert.equal(C.total(st.entries['2027-03-01']), 2000);
  assert.equal(C.saveEntry(st, '2027-02-30', { lines: 1 }).ok, false);
});

test('смена тарифа не пересчитывает старые записи', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 });
  C.setRate(st, '2027-04-01', 6);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-03-31'), 5);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-04-01'), 6);
  assert.equal(C.estimated(st.entries['2027-03-01']), 500);
  C.saveEntry(st, '2027-04-02', { lines: 100 });
  assert.equal(C.estimated(st.entries['2027-04-02']), 600);
  // редактирование старой записи сохраняет её тариф
  C.saveEntry(st, '2027-03-01', { lines: 200 });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000);
  // запись задним числом в марте берёт мартовский тариф
  C.setRate(st, '2027-01-01', 5.5);
  C.saveEntry(st, '2027-03-05', { lines: 3 });
  assert.equal(C.estimated(st.entries['2027-03-05']), 16.5);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000); // старая не изменилась
  // явный пересчёт по тарифу даты
  C.saveEntry(st, '2027-03-01', { lines: 200 }, { useCurrentRate: true });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1100);
  assert.throws(() => C.setRate(st, '2027-05-01', 0));
});

test('дробный тариф без ошибок округления', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-01-01', 5.1);
  for (let d = 1; d <= 10; d++) C.saveEntry(st, C.key(2027, 2, d), { lines: 3 });
  assert.equal(C.summarize(st.entries, C.monthKeys(2)).estimated, 153);
});

test('прогноз месяца', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 }); // 1000
  C.saveEntry(st, '2027-03-02', { lines: 400 }); // 2000
  // сегодня 2 марта: будних дней в марте 23, после 2 марта без записей — 21
  let s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.remainingShifts, 21);
  assert.equal(s.projected, 3000 + 1500 * 21);
  // план 15 смен
  st.settings.plannedShifts = 15;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.remainingShifts, 13);
  assert.equal(s.projected, 3000 + 1500 * 13);
  // месяц прошёл — прогноз = факт
  s = C.monthSummary(st, 2, '2027-04-10');
  assert.equal(s.projected, 3000);
  // цель
  st.settings.target = 30000;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.targetProgress, 0.1);
  assert.equal(s.needPerShift, C.round2(27000 / 13));
  // будущий месяц без данных — по средней года
  s = C.monthSummary(st, 4, '2026-11-08');
  assert.equal(s.projectionBasis, 'year');
  assert.equal(s.projected, 1500 * 15); // план 15 смен
  // пустой год — прогноз неизвестен
  assert.equal(C.monthSummary(C.defaultState(), 0, '2026-11-08').projected, null);
});

test('недели и месяцы', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 }); // неделя 1 марта
  C.saveEntry(st, '2027-03-03', { lines: 100 });
  C.saveEntry(st, '2027-03-10', { lines: 200 }); // неделя 8 марта
  const w = C.weekly(st.entries, C.monthKeys(2));
  assert.equal(w.workedWeeks, 2);
  assert.equal(w.avgWeekly, 1000);
  assert.equal(w.weeks[0].monday, '2027-03-01');
  C.saveEntry(st, '2027-04-01', { lines: 300 });
  const ym = C.yearByMonths(st);
  assert.equal(ym[2].total, 2000);
  assert.equal(ym[3].total, 1500);
  assert.equal(ym[3].change, -0.25);
  assert.equal(ym[0].change, null);
  assert.equal(C.rangeKeys('2027-03-05', '2027-03-01').length, 5);
});

test('резервная копия: экспорт → импорт, слияние, CSV', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-06-01', 7);
  C.saveEntry(st, '2027-03-01', { lines: 100, actual: 600, hours: 8, comment: 'ночь; "склад"' });
  st.settings.target = 50000;
  const back = C.normalizeState(JSON.parse(C.exportData(st)));
  assert.equal(back.skipped, 0);
  assert.deepEqual(back.state.settings.rateHistory, st.settings.rateHistory);
  assert.equal(back.state.settings.target, 50000);
  assert.equal(back.state.entries['2027-03-01'].actual, 600);
  assert.equal(back.state.entries['2027-03-01'].rate, 5);
  assert.throws(() => C.normalizeState(null));
  assert.throws(() => C.normalizeState({ foo: 1 }));
  const other = C.defaultState();
  C.saveEntry(other, '2027-03-02', { lines: 5 });
  const merged = C.mergeStates(other, back.state);
  assert.equal(Object.keys(merged.entries).length, 2);
  const csv = C.toCSV(st);
  assert.ok(csv.includes('"ночь; ""склад"""'));
  assert.ok(csv.split('\r\n').length === 2);
});

test('форматирование (неразрывные пробелы, чтобы суммы не переносились)', () => {
  assert.equal(C.fmtMoney(1250), '1\u00a0250\u00a0₽');
    assert.equal(C.fmtMoney(1600.5), '1\u00a0600,5\u00a0₽');
  assert.equal(C.fmtMoneyShort(1250), '1,3к');
  assert.equal(C.fmtMoneyShort(450), '450');
  assert.equal(C.fmtDateLong('2027-03-08'), '8 марта 2027');
});

test('производительность: за день и средняя за месяц', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: '115,5' });
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 130 });
  C.saveEntry(st, '2027-03-03', { lines: 200 }); // без производительности — не влияет на среднюю
  const s = C.summarize(st.entries, C.monthKeys(2));
  assert.equal(s.prodDays, 2);
  assert.equal(s.prodAvg, 122.75);
  assert.equal(C.saveEntry(st, '2027-03-04', { lines: 1, prod: -5 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-04', { lines: 1, prod: 'x' }).ok, false);
});

test('премия за производительность: средняя ≥ 120% → 15 000 ₽', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 110 });
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 130 }); // средняя ровно 120
  let s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.prodOk, true);
  assert.equal(s.extras.prodBonus, 15000);
  assert.equal(s.grand, 2000);                 // премия за производительность НЕ входит в итог
  assert.equal(s.pending, 15000);              // а показывается отдельно как ожидаемая
  assert.equal(s.grandWithPending, 17000);
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 129.98 }); // 119,99 — премии нет
  s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.prodBonus, 0);
  assert.equal(s.grand, 2000);
});

test('сервис по зонам и штраф за месяц', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 });
  const z = (v) => C.serviceZone(v, C.DEFAULT_BONUS);
  assert.equal(z(99.95), 'green');
  assert.equal(z(100), 'green');
  assert.equal(z(99.949), 'yellow');
  assert.equal(z(99.9), 'yellow');
  assert.equal(z(99.89), 'red');
  assert.equal(z(null), null);
  assert.ok(C.setMonthData(st, 2, { service: '99,97', penalty: '1500' }).ok);
  let s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.zone, 'green');
  assert.equal(s.extras.serviceBonus, 15000);
  assert.equal(s.extras.penalty, 1500);
  assert.equal(s.grand, 1000 - 1500);          // премия за сервис не в итоге
  assert.equal(s.pending, 15000);
  // жёлтая зона — сумма из настроек (по умолчанию 0)
  C.setMonthData(st, 2, { service: 99.92, penalty: 0 });
  assert.equal(C.monthSummary(st, 2, '2027-04-01').grand, 1000);
  st.settings.bonus.yellowAmount = 7000;
  assert.equal(C.monthSummary(st, 2, '2027-04-01').grand, 1000);
  assert.equal(C.monthSummary(st, 2, '2027-04-01').pending, 7000);
  assert.equal(C.setMonthData(st, 2, { service: 101 }).ok, false);
  assert.equal(C.setMonthData(st, 2, { penalty: -1 }).ok, false);
  // пустые значения удаляют данные месяца
  C.setMonthData(st, 2, { service: '', penalty: '' });
  assert.equal(st.months['2027-03'], undefined);
});

test('прогноз и годовая статистика учитывают премии и штраф', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 125 }); // 1000
  C.setMonthData(st, 2, { service: 99.96, penalty: 500 });
  const s = C.monthSummary(st, 2, '2027-03-01');
  // смены: 1000 + 1000 × 22 оставшихся будних дня; + сервис 15000 − 500 (производительность — отдельно)
  assert.equal(s.remainingShifts, 22);
  assert.equal(s.projected, 23000 - 500);
  assert.equal(s.pending, 30000);
  const ym = C.yearByMonths(st);
  assert.equal(ym[2].grand, 500);
  assert.equal(ym[2].pending, 30000);
  // нужная производительность до премии
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 100 });
  const s2 = C.monthSummary(st, 2, '2027-03-01');
  assert.equal(s2.needProd, C.round2((120 * 23 - 100) / 22));
});

test('резервная копия сохраняет премии, сервис, штраф и производительность', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-05-04', { lines: 10, prod: 121 });
  C.setMonthData(st, 4, { service: 99.95, penalty: 300 });
  st.settings.bonus.yellowAmount = 5000;
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.entries['2027-05-04'].prod, 121);
  assert.equal(back.months['2027-05'].service, 99.95);
  assert.equal(back.months['2027-05'].penalty, 300);
  assert.equal(back.settings.bonus.yellowAmount, 5000);
  // старые копии без новых полей читаются
  const old = C.normalizeState({ settings: {}, entries: { '2027-01-11': { lines: 5, rate: 5 } } }).state;
  assert.equal(old.entries['2027-01-11'].prod, null);
  assert.deepEqual(old.months, {});
  const merged = C.mergeStates(C.defaultState(), back);
  assert.equal(merged.months['2027-05'].penalty, 300);
});

test('свои отметки: выходной, больничный, отпуск, рабочая суббота', () => {
  const st = C.defaultState();
  // январь 2027: 21 будний день
  assert.equal(C.workdaysInMonth(0, 2027, st), 21);
  C.saveEntry(st, '2027-01-04', { lines: 100 });
  assert.ok(C.setMark(st, '2027-01-04', 'sick').ok);
  assert.equal(st.entries['2027-01-04'], undefined, 'смена удалена — был больничный');
  C.setMark(st, '2027-01-05', 'vacation');
  C.setMark(st, '2027-01-01', 'off');
  assert.equal(C.workdaysInMonth(0, 2027, st), 18);
  assert.equal(C.dayStatus(st, '2027-01-05').label, 'Отпуск');
  assert.equal(C.dayStatus(st, '2027-01-05').off, true);
  // рабочая суббота
  C.setMark(st, '2027-01-09', 'work');
  assert.equal(C.dayStatus(st, '2027-01-09').off, false);
  assert.equal(C.workdaysInMonth(0, 2027, st), 19);
  // бессмысленные отметки не сохраняются
  C.setMark(st, '2027-01-10', 'off');  // воскресенье и так выходной
  C.setMark(st, '2027-01-11', 'work'); // понедельник и так рабочий
  assert.equal(st.marks['2027-01-10'], undefined);
  assert.equal(st.marks['2027-01-11'], undefined);
  // прогноз: сегодня 31 декабря 2026 — оставшиеся смены = рабочие дни января с учётом отметок
  C.saveEntry(st, '2027-01-12', { lines: 200 }); // 1000 ₽
  let s = C.monthSummary(st, 0, '2026-12-31', 2027);
  assert.equal(s.plannedTotal, 19);
  assert.equal(s.remainingShifts, 18);
  assert.deepEqual(s.marks, { off: 1, sick: 1, vacation: 1, work: 1 });
  // свой план 20 смен: −3 нерабочих отметки +1 рабочая суббота = 18
  st.settings.plannedShifts = 20;
  s = C.monthSummary(st, 0, '2026-12-31', 2027);
  assert.equal(s.plannedTotal, 18);
  assert.equal(s.remainingShifts, 17);
  // внесли смену в день отпуска — отметка снимается
  C.saveEntry(st, '2027-01-05', { lines: 10 });
  assert.equal(st.marks['2027-01-05'], undefined);
  // снять отметку
  C.setMark(st, '2027-01-01', null);
  assert.equal(st.marks['2027-01-01'], undefined);
  // копия
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.marks['2027-01-04'], 'sick');
  assert.equal(back.marks['2027-01-09'], 'work');
  assert.equal(C.normalizeState({ entries: {}, marks: { '2027-01-04': 'bad', 'x': 'sick' } }).state.marks['2027-01-04'], undefined);
});

test('ручной итог месяца: фактическая сумма и разница с расчётом', () => {
  const st = C.defaultState();
  for (let d = 1; d <= 5; d++) C.saveEntry(st, C.key(2027, 2, d), { lines: 2000, prod: 125 }); // 5 × 10 000 = 50 000
  C.setMonthData(st, 2, { penalty: 1000 });
  let s = C.monthSummary(st, 2, '2027-03-05');
  assert.equal(s.calc, 49000);
  assert.equal(s.manual, null);
  assert.ok(C.setMonthData(st, 2, { actualTotal: '60 000' }).ok);
  s = C.monthSummary(st, 2, '2027-03-05');
  assert.equal(s.grand, 60000);
  assert.equal(s.manualDiff, 11000);          // на 11 000 больше, чем ожидалось
  assert.equal(s.projected, 60000);
  assert.equal(st.months['2027-03'].penalty, 1000, 'штраф не затёрся');
  C.setMonthData(st, 2, { actualTotal: 45000 });
  assert.equal(C.monthSummary(st, 2, '2027-03-05').manualDiff, -4000);
  assert.equal(C.yearByMonths(st)[2].grand, 45000);
  C.setMonthData(st, 2, { actualTotal: '' });  // очистить — снова расчёт
  assert.equal(C.monthSummary(st, 2, '2027-03-05').grand, 49000);
  assert.equal(C.setMonthData(st, 2, { actualTotal: -5 }).ok, false);
  C.setMonthData(st, 2, { actualTotal: 50000 });
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.months['2027-03'].actualTotal, 50000);
});

test('рейтинг смен, серии, рекорды', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 300, prod: 118 });
  C.saveEntry(st, '2027-03-02', { lines: 250, prod: 125 });
  C.saveEntry(st, '2027-03-03', { lines: 280, prod: 121 });
  C.saveEntry(st, '2027-03-04', { lines: 400 });             // без % — в конце рейтинга
  C.saveEntry(st, '2027-03-05', { lines: 260, prod: 130 });
  C.saveEntry(st, '2027-03-08', { lines: 270, prod: 122 });  // через выходные — серия продолжается? нет: 4-го не было %
  const r = C.rankShifts(st);
  assert.deepEqual(r.map((x) => x.key), ['2027-03-05', '2027-03-02', '2027-03-08', '2027-03-03', '2027-03-01', '2027-03-04']);
  assert.equal(r[0].place, 1);
  const sk = C.streaks(st, 120);
  assert.equal(sk.best, 2);      // 2–3 марта и 5, 8 марта
  assert.equal(sk.current, 2);
  const rec = C.records(st);
  assert.equal(rec.lines.key, '2027-03-04');
  assert.equal(rec.prod.value, 130);
  assert.equal(rec.shifts, 6);
  assert.equal(rec.linesTotal, 1760);
  assert.equal(rec.week.key, '2027-03-01');
  assert.equal(rec.month.m, 2);
});

test('выгодность дней недели', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 }); // пн 1000
  C.saveEntry(st, '2027-03-08', { lines: 400 }); // пн 2000 → среднее 1500
  C.saveEntry(st, '2027-03-04', { lines: 300 }); // чт 1500
  C.saveEntry(st, '2027-03-05', { lines: 100 }); // пт 500
  const w = C.weekdayStats(st);
  assert.equal(w.rows[0].avg, 1500);
  assert.equal(w.rows[0].shifts, 2);
  assert.equal(w.rows[4].avg, 500);
  assert.equal(w.best.wd, 0);    // при равенстве — первый (пн)
  assert.equal(w.worst.wd, 4);
  assert.equal(w.overall, 1250);
  assert.equal(C.round2(w.rows[4].vsAvg), -0.6);
});

test('планировщик накоплений', () => {
  const st = C.defaultState();
  for (let d = 1; d <= 5; d++) C.saveEntry(st, C.key(2027, 2, d), { lines: 400 }); // по 2000 ₽
  let p = C.savingsPlan(st, { goal: 100000, saved: 10000, percent: 100 }, '2027-03-05');
  assert.equal(p.perShift, 2000);
  assert.equal(p.left, 90000);
  assert.equal(p.shifts, 45);
  // 45 рабочих дней с 8 марта (пн): 9 полных недель → пятница 7 мая
  assert.equal(p.date, '2027-05-07');
  p = C.savingsPlan(st, { goal: 100000, saved: 0, percent: 50 }, '2027-03-05');
  assert.equal(p.perShiftSaved, 1000);
  assert.equal(p.shifts, 100);
  // больничный сдвигает дату
  C.setMark(st, '2027-03-08', 'sick');
  assert.equal(C.savingsPlan(st, { goal: 100000, saved: 10000 }, '2027-03-05').date, '2027-05-10');
  assert.equal(C.savingsPlan(st, { goal: 5000, saved: 6000 }, '2027-03-05').done, true);
  assert.equal(C.savingsPlan(C.defaultState(), { goal: 1000 }, '2027-03-05').reason, 'nodata');
});

test('достижения', () => {
  const st = C.defaultState();
  let a = C.achievements(st);
  assert.ok(a.every((x) => !x.done));
  for (let d = 1; d <= 12; d++) if (C.weekdayMon(C.key(2027, 2, d)) < 5) C.saveEntry(st, C.key(2027, 2, d), { lines: 300, prod: 141 });
  a = Object.fromEntries(C.achievements(st).map((x) => [x.id, x]));
  assert.ok(a.first.done && a.p120.done && a.p140.done && a.st5.done && a.bm.done);
  assert.equal(a.s10.done, true); assert.equal(a.s10.value, 10);   // 1–12 марта: 10 будних дней
  assert.equal(a.st10.done, true);
  assert.equal(a.s50.done, false); assert.equal(a.s50.value, 10);
});

test('ночная смена: часы через полночь', () => {
  assert.equal(C.shiftHours('21:00', '06:00'), 9);
  assert.equal(C.shiftHours('21:00', '07:30'), 10.5);
  assert.equal(C.shiftHours('21:00', '08:00'), 11);
  assert.equal(C.shiftHours('08:00', '20:00'), 12);
  assert.equal(C.shiftHours('21:00', 'x'), null);
  const st = C.defaultState();
  assert.equal(st.settings.shiftStart, '21:00');
  C.saveEntry(st, '2027-03-01', { lines: 300, start: '21:00', end: '07:00', mood: 4 });
  const e = st.entries['2027-03-01'];
  assert.equal(e.hours, 10, 'часы посчитаны по времени');
  assert.equal(e.mood, 4);
  C.saveEntry(st, '2027-03-02', { lines: 300, start: '21:00', end: '07:00', hours: 9.5 });
  assert.equal(st.entries['2027-03-02'].hours, 9.5, 'введённые вручную часы важнее');
  assert.equal(C.saveEntry(st, '2027-03-03', { lines: 1, start: '25:00' }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-03', { lines: 1, mood: 7 }).ok, false);
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.entries['2027-03-01'].end, '07:00');
  assert.equal(back.entries['2027-03-01'].mood, 4);
});

test('выплаты: зарплата 15 (за прошлый месяц), конверт 20–25, аванс 30 (за текущий), перенос на рабочий день раньше', () => {
  const st = C.defaultState();
  let p = C.payoutSchedule(st, 10, 2026, '2026-11-09'); // ноябрь 2026
  assert.equal(p[0].date, '2026-11-13');  // 15 ноября — вс → пт 13
  assert.equal(p[0].shifted, true);
  assert.deepEqual(p.map((x) => x.id), ['salary', 'envelope', 'advance']); assert.equal(p[0].name, 'Зарплата'); assert.equal(p[2].name, 'Аванс');
  assert.equal(p[1].date, '2026-11-20'); assert.equal(p[1].dateTo, '2026-11-25');
  assert.equal(p[2].date, '2026-11-30');  // пн
  assert.equal(p[0].daysLeft, 4);
  assert.equal(p[0].status, 'upcoming');
  assert.equal(C.payoutSchedule(st, 0, 2027)[2].date, '2027-01-29');  // 30 января — сб → пт 29
  assert.equal(C.payoutSchedule(st, 1, 2027)[2].date, '2027-02-26');  // февраль: 28 (вс) → пт 26
  st.settings.paydays.salary = 8;
  assert.equal(C.payoutSchedule(st, 2, 2027)[0].date, '2027-03-05');  // 8 марта — праздник → пт 5
  st.settings.paydays.salary = 15;
  // ближайшая выплата
  assert.equal(C.nextPayout(st, '2026-11-09').id, 'salary');
  assert.ok(C.setPayout(st, 10, 2026, 'salary', { received: true, amount: '20000', date: '2026-11-13' }).ok);
  const n = C.nextPayout(st, '2026-11-14');
  assert.equal(n.id, 'envelope');
  assert.equal(C.nextPayout(st, '2026-12-01').id, 'salary');
  assert.equal(C.nextPayout(st, '2026-12-01').m, 11);
  C.setPayout(st, 10, 2026, 'advance', { received: true, amount: 30000 });
  assert.equal(C.payoutsTotal(st, 10, 2026), 50000);
  assert.equal(C.payoutSchedule(st, 10, 2026, '2026-11-26')[1].status, 'late');
  assert.equal(C.setPayout(st, 10, 2026, 'bonus', {}).ok, false);
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.payouts['2026-11'].salary.amount, 20000);
  C.setPayout(st, 10, 2026, 'salary', { received: false, amount: '' });
  assert.equal(st.payouts['2026-11'].salary, undefined);
});

test('самочувствие и усталость по сменам подряд', () => {
  const st = C.defaultState();
  // неделя 5/2: пн–пт, производительность падает к концу недели
  const prods = [130, 126, 122, 118, 112], moods = [5, 4, 4, 2, 1];
  for (let i = 0; i < 5; i++) C.saveEntry(st, C.key(2027, 2, 1 + i), { lines: 300, prod: prods[i], mood: moods[i] });
  const w = C.wellbeingStats(st);
  assert.equal(w.byIdx[0].avgProd, 130);
  assert.equal(w.byIdx[4].avgProd, 112);
  assert.equal(w.byIdx[4].avgMood, 1);
  assert.equal(w.moodDays, 5);
  assert.equal(w.avgMood, 3.2);
  assert.equal(w.goodProd, C.round2((130 + 126 + 122) / 3));
  assert.equal(w.badProd, 115);
});

test('итоги месяца (сторис)', () => {
  const st = C.defaultState();
  assert.equal(C.monthWrapped(st, 2, 2027), null);
  C.saveEntry(st, '2027-02-01', { lines: 200 });                              // февраль: 1000
  const prods = [125, 130, 118, 121, 122];
  for (let i = 0; i < 5; i++) C.saveEntry(st, C.key(2027, 2, 1 + i), { lines: 300 + i * 10, prod: prods[i], mood: i < 3 ? 5 : 3, start: '21:00', end: '07:00' });
  const w = C.monthWrapped(st, 2, 2027);
  assert.equal(w.shifts, 5);
  assert.equal(w.lines, 1600);
  assert.equal(w.hours, 50);
  assert.equal(w.earned, 8000);
  assert.equal(w.prodAvg, 123.2);
  assert.equal(w.prodOk, true);
  assert.equal(w.bestRun, 2);                 // 1–2 и 4–5 марта
  assert.equal(w.top.key, '2027-03-02');      // 130%
  assert.equal(w.mood.icon, '😄');
  assert.equal(w.prev.name, 'Февраль');
  assert.equal(C.round2(w.prev.change), 7);   // 8000 против 1000 → +700%
  assert.equal(w.rankInYear, 1);
  assert.deepEqual(C.wrappedMonths(st).map((x) => x.m), [1, 2]);
});

test('выплаты: старые данные, где аванс и зарплата были перепутаны, переносятся на те же даты', () => {
  const old = { settings: { paydays: { advance: 14, envelopeFrom: 20, envelopeTo: 25, salary: 29 } }, entries: {}, payouts: { '2026-11': { advance: { received: true, amount: 41000, date: '2026-11-13' }, salary: { received: true, amount: 15000, date: '2026-11-30' } } } };
  const st = C.normalizeState(old).state;
  assert.equal(st.settings.paydays.salary, 14); assert.equal(st.settings.paydays.advance, 29);
  assert.equal(st.payouts['2026-11'].salary.amount, 41000, 'то, что пришло 13-го, — зарплата');
  assert.equal(st.payouts['2026-11'].advance.amount, 15000);
  assert.equal(st.settings.payV, C.PAY_V);
  const again = C.normalizeState(JSON.parse(C.exportData(st))).state; // повторно не меняется
  assert.equal(again.payouts['2026-11'].salary.amount, 41000); assert.equal(again.settings.paydays.salary, 14);
  const withGame = C.normalizeState({ settings: {}, entries: {}, game: { v: 1, battleXp: 5 } }).state; assert.equal(withGame.game, undefined, 'данные удалённой игры не сохраняются');
});

test('Питомец: по умолчанию выключен, старые сохранения выключаются один раз', () => {
  const st = C.defaultState();
  assert.deepEqual(st.settings.pet, { on: false, name: 'Мурка', v: 2 });
  // старое сохранение: «on: true» стояло по умолчанию → выключаем
  assert.equal(C.normalizeState({ settings: { pet: { on: true, name: 'Мурка' } } }).state.settings.pet.on, false);
  // включил сам после обновления → остаётся включённой
  assert.equal(C.normalizeState({ settings: { pet: { on: true, name: 'Мурка', v: 2 } } }).state.settings.pet.on, true);
  const n = C.normalizeState({ settings: { pet: { on: false, name: '  Барсик очень-очень длинное имя кота  ', v: 2 } } }).state;
  assert.equal(n.settings.pet.name, 'Барсик очень-очень д');
  assert.deepEqual(C.normalizeState({ settings: { pet: { name: '' } } }).state.settings.pet, { on: false, name: 'Мурка', v: 2 });
  assert.deepEqual(C.normalizeState({ settings: {} }).state.settings.pet, { on: false, name: 'Мурка', v: 2 });
});
