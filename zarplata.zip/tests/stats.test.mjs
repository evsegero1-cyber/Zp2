// Тесты публичной статистики (src/cloud/stats.js). Запуск: npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import { mondayOf, emptyStats, publicDay, applyDay, diffDays, bestOf, MAX_DAY_LINES } from '../src/cloud/stats.js';

const prof = { nick: 'murka', name: 'Мурка', avatar: { kind: 'preset', v: 'cat' } };

// Копия проверки deltaOk из firestore.rules — чтобы клиент гарантированно проходил правила
function rulesAccept(o, n, nl, ol) {
  const w = (l) => (l > 0 ? 1 : 0);
  const avgOk = (b) => (b.days === 0 && b.avg === 0) || (b.days > 0 && Math.abs(b.avg * b.days - b.lines) < 0.05);
  const bucketOk = (ob, nb, key) =>
    (key === ob.key && nb.key === ob.key && nb.lines === ob.lines + nl - ol && nb.days === ob.days + w(nl) - w(ol)) ||
    (key > ob.key && nb.key === key && nb.lines === nl && nb.days === w(nl)) ||
    (key < ob.key && nb.key === ob.key && nb.lines === ob.lines && nb.days === ob.days);
  const d = n.lastDay;
  const dayOk = (d >= o.day.key && n.day.key === d && n.day.lines === nl) || (d < o.day.key && n.day.key === o.day.key && n.day.lines === o.day.lines);
  const earnOk = (b) => b.earn >= 0 && b.earn <= b.lines * 50 && (n.showEarn || b.earn === 0);
  return n.lastWeek === mondayOf(d)
    && n.totals.lines === o.totals.lines + nl - ol && n.totals.days === o.totals.days + w(nl) - w(ol)
    && n.totals.best >= nl && n.totals.best <= n.totals.lines && avgOk(n.totals)
    && dayOk && bucketOk(o.week, n.week, n.lastWeek) && bucketOk(o.month, n.month, d.slice(0, 7))
    && avgOk(n.week) && avgOk(n.month)
    && [n.totals, n.day, n.week, n.month].every(earnOk);
}

test('понедельник недели', () => {
  assert.equal(mondayOf('2026-11-09'), '2026-11-09'); // понедельник
  assert.equal(mondayOf('2026-11-15'), '2026-11-09'); // воскресенье
  assert.equal(mondayOf('2026-11-01'), '2026-10-26'); // переход месяца
  assert.equal(mondayOf('2027-01-01'), '2026-12-28'); // переход года
  assert.equal(mondayOf('2024-03-01'), '2024-02-26'); // високосный
});

test('публикуется только линии и оценка «линии × ставка»', () => {
  const e = { lines: 1200, rate: 5, actual: 99999, prod: 130, comment: 'секрет', mood: 2 };
  assert.deepEqual(publicDay(e, true), { lines: 1200, earn: 6000 });
  assert.deepEqual(publicDay(e, false), { lines: 1200, earn: 0 });
  assert.equal(publicDay({ lines: 0, actual: 5000 }, true), null);          // день только с суммой — не публикуется
  assert.equal(publicDay({ lines: MAX_DAY_LINES + 1, rate: 5 }, true), null); // опечатка
});

test('пересчёт по дням проходит правила и всегда равен сумме дней', () => {
  let rnd = 7; const rand = (n) => { rnd = (rnd * 1103515245 + 12345) % 2147483648; return rnd % n; };
  for (const showEarn of [true, false]) {
    let st = { ...emptyStats(prof, showEarn), visible: true };
    const pub = {}; // опубликованные дни
    const days = [];
    for (let i = 0; i < 120; i++) { const d = new Date(Date.UTC(2026, 8, 1 + i)); days.push(d.toISOString().slice(0, 10)); }
    for (let step = 0; step < 600; step++) {
      // в основном идём вперёд по календарю, иногда правим/удаляем старые дни
      const idx = Math.min(days.length - 1, Math.floor(step / 5) + (rand(10) < 3 ? -rand(40) : 0));
      const day = days[Math.max(0, idx)];
      const next = rand(8) === 0 ? null : publicDay({ lines: 300 + rand(1500), rate: 5 }, showEarn);
      const prev = pub[day] || null;
      if (!next && !prev) continue;
      const after = { ...pub }; if (next) after[day] = next; else delete after[day];
      const best = Math.max(0, ...Object.values(after).map((x) => x.lines));
      const n = applyDay(st, day, next, prev, best);
      assert.ok(rulesAccept(st, n, next ? next.lines : 0, prev ? prev.lines : 0), `правила отклонили шаг ${step} (${day})`);
      st = n; Object.assign(pub, {}); if (next) pub[day] = next; else delete pub[day];
      const sum = Object.values(pub).reduce((a, x) => a + x.lines, 0);
      assert.equal(st.totals.lines, sum);
      assert.equal(st.totals.days, Object.keys(pub).length);
      // текущий месяц/неделя равны сумме своих дней, если корзина «живая»
      const m = Object.entries(pub).filter(([k]) => k.slice(0, 7) === st.month.key).reduce((a, [, x]) => a + x.lines, 0);
      assert.ok(st.month.lines <= m || st.month.key < st.lastDay.slice(0, 7));
      if (!showEarn) assert.equal(st.totals.earn, 0);
    }
  }
});

test('подделку итогов правила не пропускают', () => {
  const st = { ...emptyStats(prof, true), visible: true };
  const n = applyDay(st, '2026-11-09', { lines: 1000, earn: 5000 }, null, 1000);
  assert.ok(rulesAccept(st, n, 1000, 0));
  const fake = { ...n, totals: { ...n.totals, lines: 5000, avg: 5000 } };
  assert.ok(!rulesAccept(st, fake, 1000, 0));
  const fakeWeek = { ...n, week: { ...n.week, lines: 3000, avg: 3000 } };
  assert.ok(!rulesAccept(st, fakeWeek, 1000, 0));
});

test('сравнение локальных записей с опубликованными', () => {
  const entries = { '2026-11-02': { lines: 1000, rate: 5 }, '2026-11-03': { lines: 900, rate: 5 }, '2026-11-04': { lines: 0, actual: 3000 } };
  const published = { '2026-11-02': { lines: 1000, earn: 5000 }, '2026-11-01': { lines: 700, earn: 3500 } };
  const ops = diffDays(entries, published, true);
  assert.deepEqual(ops.map((o) => [o.day, o.next && o.next.lines, o.prev && o.prev.lines]), [['2026-11-01', null, 700], ['2026-11-03', 900, null]]);
  assert.equal(bestOf(entries), 1000);
  // заработок скрыт → все опубликованные дни нужно перезаписать с earn = 0
  assert.equal(diffDays(entries, published, false).length, 3);
});

test('вес товара публикуется вместе с днём', () => {
  assert.deepEqual(publicDay({ lines: 400, rate: 5, weight: 3250.46 }, false), { lines: 400, earn: 0, kg: 3250.5 });
  assert.deepEqual(publicDay({ lines: 400, rate: 5, weight: null }, false), { lines: 400, earn: 0 });
  assert.deepEqual(publicDay({ lines: 400, rate: 5, weight: 200000 }, false), { lines: 400, earn: 0 });
  // поменялся только вес — день нужно переопубликовать
  const ops = diffDays({ '2026-11-02': { lines: 400, rate: 5, weight: 900 } }, { '2026-11-02': { lines: 400, earn: 0 } }, false);
  assert.equal(ops.length, 1); assert.equal(ops[0].next.kg, 900);
  assert.equal(diffDays({ '2026-11-02': { lines: 400, rate: 5, weight: 900 } }, { '2026-11-02': { lines: 400, earn: 0, kg: 900 } }, false).length, 0);
});
