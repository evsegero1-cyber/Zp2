/* Ядро расчётов: календарь 2026–2028 (основной 2027), тарифы, статистика. Без зависимостей от DOM. */
const Core = (() => {
  'use strict';
  const YEAR = 2027;                 // основной год (открывается по умолчанию)
  const YEARS = [2026, 2027, 2028];  // доступные годы
  const FIRST_DAY = `${YEARS[0]}-01-01`, LAST_DAY = `${YEARS[YEARS.length - 1]}-12-31`;
  // Цветовые гаммы: основной цвет (кнопки, календарь, главная карточка) и дополнительный (графики)
  const PALETTES = [
    { id: 'orange', name: 'Оранжевая', accent: '#e8590c', accent2: '#1c7ed6' },
    { id: 'blue', name: 'Синяя', accent: '#1c7ed6', accent2: '#f76707' },
    { id: 'green', name: 'Зелёная', accent: '#2b8a3e', accent2: '#7048e8' },
    { id: 'violet', name: 'Фиолетовая', accent: '#7048e8', accent2: '#0ca678' },
    { id: 'red', name: 'Красная', accent: '#e03131', accent2: '#1971c2' },
    { id: 'teal', name: 'Бирюзовая', accent: '#0c8599', accent2: '#e8590c' },
    { id: 'pink', name: 'Розовая', accent: '#d6336c', accent2: '#3b5bdb' },
    { id: 'graphite', name: 'Графит', accent: '#495057', accent2: '#e8590c' },
  ];
  const isHex = (c) => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c);
  const DEFAULT_RATE = 5;
  // Премии: за среднюю производительность за месяц и за сервис (качество без ошибок) по зонам
  const DEFAULT_BONUS = { prodThreshold: 120, prodAmount: 15000, greenThreshold: 99.95, greenAmount: 15000, yellowThreshold: 99.9, yellowAmount: 0, redAmount: 0 };

  const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
  const MONTHS_GEN = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  const MONTHS_SHORT = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
  const WEEKDAYS_FULL = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];

  // ---------- Даты (строковые ключи YYYY-MM-DD, без часовых поясов) ----------
  const pad = (n) => String(n).padStart(2, '0');
  const key = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`; // m: 0..11
  const parseKey = (k) => { const [y, m, d] = k.split('-').map(Number); return { y, m: m - 1, d }; };
  const dateOf = (k) => { const p = parseKey(k); return new Date(p.y, p.m, p.d, 12); };
  const keyOfDate = (dt) => key(dt.getFullYear(), dt.getMonth(), dt.getDate());
  const addDays = (k, n) => { const dt = dateOf(k); dt.setDate(dt.getDate() + n); return keyOfDate(dt); };
  const weekdayMon = (k) => (dateOf(k).getDay() + 6) % 7; // Пн=0 … Вс=6
  const daysInMonth = (y, m) => new Date(y, m + 1, 0).getDate();
  const isValidKey = (k) => typeof k === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(k) && keyOfDate(dateOf(k)) === k;
  // В пределах доступных лет (2026–2028); с указанием года — в пределах этого года
  const inYear = (k, y) => (y ? k >= `${y}-01-01` && k <= `${y}-12-31` : k >= FIRST_DAY && k <= LAST_DAY);

  // ---------- Рабочие и выходные дни ----------
  // Сделка / ИП: работаем в любой будний день, праздники и переносы не учитываются. Выходные — только сб и вс.
  function dayInfo(k) {
    const wd = weekdayMon(k);
    if (wd >= 5) return { off: true, holiday: false, weekend: true, label: 'Выходной' };
    return { off: false, holiday: false, weekend: false, label: 'Рабочий день' };
  }

  const monthKeys = (m, y = YEAR) => Array.from({ length: daysInMonth(y, m) }, (_, i) => key(y, m, i + 1));
  const yearKeys = (y = YEAR) => { const r = []; for (let m = 0; m < 12; m++) r.push(...monthKeys(m, y)); return r; };
  function rangeKeys(from, to) {
    if (!isValidKey(from) || !isValidKey(to)) return [];
    if (from > to) [from, to] = [to, from];
    const r = []; let k = from; let guard = 0;
    while (k <= to && guard++ < 4000) { r.push(k); k = addDays(k, 1); }
    return r;
  }
  // Сетка месяца: массив недель по 7 ячеек (null — пустая ячейка), неделя с понедельника
  function calendarGrid(m, y = YEAR) {
    const keys = monthKeys(m, y);
    const cells = Array(weekdayMon(keys[0])).fill(null).concat(keys);
    while (cells.length % 7) cells.push(null);
    const weeks = [];
    for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
    return weeks;
  }
  const workdaysInMonth = (m, y = YEAR) => monthKeys(m, y).filter((k) => !dayInfo(k).off).length;
  // Сквозной номер месяца: 0 = январь 2026 … 35 = декабрь 2028
  const MONTH_COUNT = YEARS.length * 12;
  const ymOf = (i) => ({ y: YEARS[0] + Math.floor(i / 12), m: i % 12 });
  const indexOf = (y, m) => (y - YEARS[0]) * 12 + m;

  // ---------- Деньги ----------
  const round2 = (x) => Math.round((Number(x) + Number.EPSILON) * 100) / 100;
  const nf0 = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });
  const nf2 = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
  const fmtNum = (x, digits = 0) => (digits ? new Intl.NumberFormat('ru-RU', { maximumFractionDigits: digits }) : nf0).format(Number(x) || 0).replace(/[\u00a0\u202f ]/g, '\u00a0');
  const fmtMoney = (x) => nf2.format(round2(x) || 0).replace(/[\u00a0\u202f ]/g, '\u00a0') + '\u00a0₽';
  const fmtMoneyShort = (x) => {
    x = Number(x) || 0;
    if (Math.abs(x) >= 1e6) return fmtNum(x / 1e6, 1) + 'м';
    if (Math.abs(x) >= 1e4) return fmtNum(x / 1e3, 0) + 'к';
    if (Math.abs(x) >= 1e3) return fmtNum(x / 1e3, 1) + 'к';
    return fmtNum(x, 0);
  };
  const fmtDateLong = (k) => { const p = parseKey(k); return `${p.d} ${MONTHS_GEN[p.m]} ${p.y}`; };
  const fmtDateShort = (k) => { const p = parseKey(k); return `${p.d} ${MONTHS_SHORT[p.m]}`; };

  // ---------- Состояние ----------
  function defaultState() {
    return {
      version: 1,
      settings: {
        rateHistory: [{ from: FIRST_DAY, rate: DEFAULT_RATE }],
        target: 0,          // целевая зарплата за месяц, ₽ (0 — не задана)
        plannedShifts: 0,   // планируемое число смен в месяц (0 — по будним дням)
        theme: 'system',
        palette: { id: 'orange', accent: PALETTES[0].accent, accent2: PALETTES[0].accent2 },
        bonus: { ...DEFAULT_BONUS },
      },
      entries: {},          // 'YYYY-MM-DD' -> { lines, actual, hours, prod, comment, rate, updatedAt }
      months: {},           // 'YYYY-MM' -> { service (%), penalty (₽), updatedAt }
    };
  }

  // Тариф, действующий на дату: последняя запись истории с from <= дата
  function rateFor(history, k) {
    const h = [...(history || [])].sort((a, b) => (a.from < b.from ? -1 : 1));
    let r = h.length ? h[0].rate : DEFAULT_RATE;
    for (const it of h) if (it.from <= k) r = it.rate;
    return Number(r);
  }
  function setRate(state, from, rate) {
    rate = round2(rate);
    if (!(rate > 0)) throw new Error('Стоимость линии должна быть больше нуля');
    if (!isValidKey(from)) throw new Error('Некорректная дата');
    const h = state.settings.rateHistory.filter((x) => x.from !== from);
    h.push({ from, rate });
    h.sort((a, b) => (a.from < b.from ? -1 : 1));
    state.settings.rateHistory = h;
    return state; // записи (entries) намеренно НЕ трогаем: у каждой свой сохранённый тариф
  }
  function removeRate(state, from) {
    if (state.settings.rateHistory.length <= 1) throw new Error('Должен остаться хотя бы один тариф');
    state.settings.rateHistory = state.settings.rateHistory.filter((x) => x.from !== from);
    return state;
  }

  const numOrNull = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(String(v).replace(',', '.').replace(/\s/g, ''));
    return Number.isFinite(n) ? n : NaN;
  };

  // Проверка и нормализация данных формы. Возвращает {ok, entry, error}
  function buildEntry(input, rate) {
    const lines = numOrNull(input.lines);
    const actual = numOrNull(input.actual);
    const hours = numOrNull(input.hours);
    const prod = numOrNull(input.prod);
    if (Number.isNaN(lines) || (lines !== null && (lines < 0 || !Number.isInteger(lines)))) return { ok: false, error: 'Количество линий — целое число не меньше 0' };
    if (Number.isNaN(actual) || (actual !== null && actual < 0)) return { ok: false, error: 'Фактическая сумма должна быть числом не меньше 0' };
    if (Number.isNaN(hours) || (hours !== null && (hours < 0 || hours > 24))) return { ok: false, error: 'Часы — число от 0 до 24' };
    if (Number.isNaN(prod) || (prod !== null && (prod < 0 || prod > 1000))) return { ok: false, error: 'Производительность — число от 0 до 1000 %' };
    if ((lines === null || lines === 0) && (actual === null || actual === 0)) return { ok: false, error: 'Укажите количество линий или фактическую сумму' };
    if (lines !== null && lines > 100000) return { ok: false, error: 'Слишком большое количество линий' };
    return {
      ok: true,
      entry: {
        lines: lines === null ? 0 : lines,
        actual: actual === null ? null : round2(actual),
        hours: hours === null || hours === 0 ? null : round2(hours),
        prod: prod === null ? null : round2(prod),
        comment: String(input.comment || '').trim().slice(0, 500),
        rate: round2(rate),
        updatedAt: Date.now(),
      },
    };
  }

  // Сохранение записи. keepRate: при редактировании сохраняем тариф записи (без пересчёта задним числом)
  function saveEntry(state, k, input, opts = {}) {
    if (!isValidKey(k)) return { ok: false, error: 'Некорректная дата' };
    const prev = state.entries[k];
    const rate = prev && !opts.useCurrentRate ? prev.rate : rateFor(state.settings.rateHistory, k);
    const res = buildEntry(input, rate);
    if (res.ok) state.entries[k] = res.entry;
    return res;
  }
  function deleteEntry(state, k) { delete state.entries[k]; }

  const estimated = (e) => round2((e.lines || 0) * (e.rate || 0));
  const total = (e) => (e.actual !== null && e.actual !== undefined ? round2(e.actual) : estimated(e));

  // ---------- Статистика ----------
  function summarize(entries, keys) {
    const s = { shifts: 0, lines: 0, estimated: 0, actual: 0, actualCount: 0, total: 0, hours: 0, hoursLines: 0, hoursTotal: 0, diff: 0, diffCount: 0, prodSum: 0, prodDays: 0, best: null, days: [] };
    for (const k of keys) {
      const e = entries[k];
      if (!e) continue;
      const est = estimated(e), tot = total(e);
      s.shifts++;
      s.lines += e.lines || 0;
      s.estimated += est;
      s.total += tot;
      if (e.actual !== null && e.actual !== undefined) { s.actual += e.actual; s.actualCount++; if (e.lines) { s.diff += e.actual - est; s.diffCount++; } }
      if (e.prod !== null && e.prod !== undefined) { s.prodSum += e.prod; s.prodDays++; }
      if (e.hours) { s.hours += e.hours; s.hoursLines += e.lines || 0; s.hoursTotal += tot; }
      if (!s.best || (e.lines || 0) > s.best.lines || ((e.lines || 0) === s.best.lines && tot > s.best.total)) s.best = { key: k, lines: e.lines || 0, total: tot };
      s.days.push({ key: k, lines: e.lines || 0, estimated: est, total: tot, prod: e.prod ?? null });
    }
    ['estimated', 'actual', 'total', 'diff', 'hours', 'hoursTotal'].forEach((f) => (s[f] = round2(s[f])));
    s.prodSum = round2(s.prodSum);
    s.prodAvg = s.prodDays ? round2(s.prodSum / s.prodDays) : null;
    s.avgLines = s.shifts ? s.lines / s.shifts : 0;
    s.avgPerShift = s.shifts ? round2(s.total / s.shifts) : 0;
    s.linesPerHour = s.hours ? s.hoursLines / s.hours : 0;
    s.earnPerHour = s.hours ? round2(s.hoursTotal / s.hours) : 0;
    return s;
  }

  // ---------- Премии и штрафы за месяц ----------
  const monthId = (m, y = YEAR) => `${y}-${pad(m + 1)}`;
  const bonusCfg = (state) => ({ ...DEFAULT_BONUS, ...((state.settings && state.settings.bonus) || {}) });
  function serviceZone(service, b) {
    if (service === null || service === undefined) return null;
    const v = Math.round(service * 10000) / 10000; // защита от ошибок округления (99.95 и т.п.)
    if (v >= b.greenThreshold) return 'green';
    if (v >= b.yellowThreshold) return 'yellow';
    return 'red';
  }
  // Премии и штраф месяца. sum — результат summarize за месяц (для средней производительности)
  function monthExtras(state, m, sum, y = YEAR) {
    const b = bonusCfg(state);
    const md = (state.months || {})[monthId(m, y)] || {};
    const service = md.service ?? null;
    const penalty = round2(md.penalty || 0);
    const prodAvg = sum.prodAvg;
    const prodOk = prodAvg !== null && prodAvg >= b.prodThreshold;
    const zone = serviceZone(service, b);
    const serviceBonus = zone ? Number(b[zone + 'Amount']) || 0 : 0;
    const prodBonus = prodOk ? Number(b.prodAmount) || 0 : 0;
    return { prodAvg, prodDays: sum.prodDays, prodOk, prodBonus, service, zone, serviceBonus, penalty,
      bonuses: round2(prodBonus + serviceBonus), net: round2(prodBonus + serviceBonus - penalty), cfg: b };
  }
  function setMonthData(state, m, input, y = YEAR) {
    const service = numOrNull(input.service), penalty = numOrNull(input.penalty);
    if (Number.isNaN(service) || (service !== null && (service < 0 || service > 100))) return { ok: false, error: 'Сервис — процент от 0 до 100' };
    if (Number.isNaN(penalty) || (penalty !== null && penalty < 0)) return { ok: false, error: 'Штраф — сумма не меньше 0' };
    state.months = state.months || {};
    if (service === null && !penalty) delete state.months[monthId(m, y)];
    else state.months[monthId(m, y)] = { service: service === null ? null : Math.round(service * 10000) / 10000, penalty: round2(penalty || 0), updatedAt: Date.now() };
    return { ok: true };
  }

  // Сводка за месяц + прогноз. today — ключ «сегодня».
  function monthSummary(state, m, today, y = YEAR) {
    const keys = monthKeys(m, y);
    const s = summarize(state.entries, keys);
    const first = keys[0], last = keys[keys.length - 1];
    const planned = Number(state.settings.plannedShifts) || 0;
    let remaining;
    if (today > last) remaining = 0; // месяц прошёл — прогноз равен факту
    else if (planned > 0) remaining = Math.max(0, planned - s.shifts);
    else remaining = keys.filter((k) => k > today && !dayInfo(k).off && !state.entries[k]).length;
    // Если смен ещё нет, оцениваем смену по средней прошлых месяцев года (если есть) — иначе прогноз неизвестен
    let perShift = s.avgPerShift, basis = 'month';
    if (!s.shifts) {
      const all = summarize(state.entries, yearKeys(y));
      perShift = all.avgPerShift; basis = all.shifts ? 'year' : 'none';
    }
    s.remainingShifts = remaining;
    s.plannedTotal = planned > 0 ? planned : workdaysInMonth(m, y);
    s.projected = basis === 'none' ? (s.shifts ? s.total : null) : round2(s.total + perShift * remaining);
    s.projectionBasis = basis;
    s.target = Number(state.settings.target) || 0;
    s.targetProgress = s.target ? s.total / s.target : 0;
    s.needPerShift = s.target && remaining ? round2(Math.max(0, s.target - s.total) / remaining) : 0;
    s.month = m; s.year = y; s.first = first; s.last = last;
    // Премии, штраф и общий итог месяца
    s.extras = monthExtras(state, m, s, y);
    s.grand = round2(s.total + s.extras.net);
    if (s.projected !== null) s.projected = round2(s.projected + s.extras.net);
    else if (s.extras.bonuses || s.extras.penalty) s.projected = s.grand;
    // Какая средняя производительность нужна в оставшиеся смены, чтобы выйти на премию
    const thr = s.extras.cfg.prodThreshold;
    s.needProd = s.prodDays && remaining && !s.extras.prodOk ? round2((thr * (s.prodDays + remaining) - s.prodSum) / remaining) : null;
    s.targetProgress = s.target ? s.grand / s.target : 0;
    s.needPerShift = s.target && remaining ? round2(Math.max(0, s.target - s.grand) / remaining) : 0;
    return s;
  }

  // Группировка по календарным неделям (пн–вс). Неделя на стыке периодов учитывается только днями периода.
  function weekly(entries, keys) {
    const map = new Map();
    for (const k of keys) {
      const mon = addDays(k, -weekdayMon(k));
      if (!map.has(mon)) map.set(mon, []);
      map.get(mon).push(k);
    }
    const weeks = [...map.entries()].map(([mon, ks]) => ({ monday: mon, sunday: addDays(mon, 6), ...summarize(entries, ks) }));
    const worked = weeks.filter((w) => w.shifts > 0);
    const sum = worked.reduce((a, w) => a + w.total, 0);
    return { weeks, workedWeeks: worked.length, avgWeekly: worked.length ? round2(sum / worked.length) : 0 };
  }

  function yearByMonths(state, y = YEAR) {
    const months = MONTHS.map((_, m) => {
      const s = summarize(state.entries, monthKeys(m, y));
      s.extras = monthExtras(state, m, s, y);
      s.grand = round2(s.total + s.extras.net);
      return s;
    });
    months.forEach((s, m) => {
      const prev = months[m - 1];
      s.change = prev && prev.grand > 0 ? (s.grand - prev.grand) / prev.grand : null;
    });
    return months;
  }

  // ---------- Резервное копирование ----------
  function exportData(state) {
    return JSON.stringify({ app: 'zarplata-komplektovshchika', exportedAt: new Date().toISOString(), ...state }, null, 2);
  }
  // Проверка импортируемых данных. Бросает ошибку при неверном формате.
  function normalizeState(obj) {
    if (!obj || typeof obj !== 'object') throw new Error('Файл не похож на резервную копию');
    const st = defaultState();
    const set = obj.settings || {};
    if (Array.isArray(set.rateHistory) && set.rateHistory.length) {
      const h = set.rateHistory.filter((x) => x && isValidKey(x.from) && Number(x.rate) > 0).map((x) => ({ from: x.from, rate: round2(x.rate) }));
      if (h.length) st.settings.rateHistory = h.sort((a, b) => (a.from < b.from ? -1 : 1));
    }
    if (Number(set.target) >= 0) st.settings.target = Number(set.target) || 0;
    if (Number(set.plannedShifts) >= 0) st.settings.plannedShifts = Math.round(Number(set.plannedShifts)) || 0;
    if (['system', 'light', 'dark'].includes(set.theme)) st.settings.theme = set.theme;
    if (set.palette && isHex(set.palette.accent) && isHex(set.palette.accent2)) st.settings.palette = { id: String(set.palette.id || 'custom'), accent: set.palette.accent, accent2: set.palette.accent2 };
    if (set.bonus && typeof set.bonus === 'object') {
      for (const k of Object.keys(DEFAULT_BONUS)) if (set.bonus[k] !== undefined && Number(set.bonus[k]) >= 0) st.settings.bonus[k] = Number(set.bonus[k]);
    }
    if (obj.months && typeof obj.months === 'object') {
      for (const [mk, v] of Object.entries(obj.months)) {
        const mm = /^(\d{4})-(\d{2})$/.exec(mk);
        if (!mm || !YEARS.includes(+mm[1]) || +mm[2] < 1 || +mm[2] > 12 || !v) continue;
        const r = setMonthData(st, +mm[2] - 1, { service: v.service, penalty: v.penalty }, +mm[1]);
        if (r.ok && st.months[mk]) st.months[mk].updatedAt = Number(v.updatedAt) || Date.now();
      }
    }
    const ents = obj.entries && typeof obj.entries === 'object' ? obj.entries : {};
    let bad = 0;
    for (const [k, e] of Object.entries(ents)) {
      if (!isValidKey(k) || !e || typeof e !== 'object') { bad++; continue; }
      const rate = Number(e.rate) > 0 ? Number(e.rate) : rateFor(st.settings.rateHistory, k);
      const r = buildEntry({ lines: e.lines, actual: e.actual, hours: e.hours, prod: e.prod, comment: e.comment }, rate);
      if (r.ok) { r.entry.updatedAt = Number(e.updatedAt) || Date.now(); st.entries[k] = r.entry; } else bad++;
    }
    if (!obj.entries && !obj.settings) throw new Error('В файле нет данных приложения');
    return { state: st, skipped: bad };
  }
  function mergeStates(base, incoming) {
    const out = JSON.parse(JSON.stringify(base));
    for (const [k, e] of Object.entries(incoming.entries)) {
      const cur = out.entries[k];
      if (!cur || (e.updatedAt || 0) >= (cur.updatedAt || 0)) out.entries[k] = e;
    }
    out.months = out.months || {};
    for (const [k, v] of Object.entries(incoming.months || {})) {
      const cur = out.months[k];
      if (!cur || (v.updatedAt || 0) >= (cur.updatedAt || 0)) out.months[k] = v;
    }
    return out;
  }
  function toCSV(state) {
    const rows = [['Дата', 'День недели', 'Линии', 'Тариф, ₽', 'Расчёт, ₽', 'Факт, ₽', 'Итог, ₽', 'Производительность, %', 'Часы', 'Комментарий']];
    Object.keys(state.entries).sort().forEach((k) => {
      const e = state.entries[k];
      rows.push([k, WEEKDAYS_FULL[weekdayMon(k)], e.lines, e.rate, estimated(e), e.actual ?? '', total(e), e.prod ?? '', e.hours ?? '', e.comment || '']);
    });
    return '﻿' + rows.map((r) => r.map((c) => {
      const v = String(c).replace('.', ',');
      return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
    }).join(';')).join('\r\n');
  }

  return {
    YEAR, YEARS, FIRST_DAY, LAST_DAY, MONTH_COUNT, ymOf, indexOf, PALETTES, isHex, DEFAULT_RATE, MONTHS, MONTHS_GEN, MONTHS_SHORT, WEEKDAYS, WEEKDAYS_FULL,
    key, parseKey, dateOf, keyOfDate, addDays, weekdayMon, daysInMonth, isValidKey, inYear,
    dayInfo, monthKeys, yearKeys, rangeKeys, calendarGrid, workdaysInMonth,
    round2, fmtNum, fmtMoney, fmtMoneyShort, fmtDateLong, fmtDateShort,
    defaultState, rateFor, setRate, removeRate, buildEntry, saveEntry, deleteEntry, estimated, total,
    DEFAULT_BONUS, monthId, serviceZone, monthExtras, setMonthData,
    summarize, monthSummary, weekly, yearByMonths, exportData, normalizeState, mergeStates, toCSV,
  };
})();
if (typeof module !== 'undefined') module.exports = Core;
