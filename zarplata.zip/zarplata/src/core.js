/* Ядро расчётов: календарь 2026–2028 (основной 2027), тарифы, статистика. Без зависимостей от DOM. */
const Core = (() => {
  'use strict';
  const YEAR = 2027;                 // основной год (открывается по умолчанию)
  const YEARS = [2026, 2027, 2028];  // доступные годы
  const FIRST_DAY = `${YEARS[0]}-01-01`, LAST_DAY = `${YEARS[YEARS.length - 1]}-12-31`;
  // Цветовые гаммы: основной цвет (кнопки, календарь, главная карточка) и дополнительный (графики)
  const PALETTES = [
    { id: 'orange', name: 'Оранжевая', accent: '#e8590c', accent2: '#1c7ed6' },
    { id: 'blue', name: 'Синяя', accent: '#1c7ed6', accent2: '#f76707' },
    { id: 'green', name: 'Зелёная', accent: '#2b8a3e', accent2: '#7048e8' },
    { id: 'violet', name: 'Фиолетовая', accent: '#7048e8', accent2: '#0ca678' },
    { id: 'red', name: 'Красная', accent: '#e03131', accent2: '#1971c2' },
    { id: 'teal', name: 'Бирюзовая', accent: '#0c8599', accent2: '#e8590c' },
    { id: 'pink', name: 'Розовая', accent: '#d6336c', accent2: '#3b5bdb' },
    { id: 'graphite', name: 'Графит', accent: '#495057', accent2: '#e8590c' },
  ];
  const isHex = (c) => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c);
  const DEFAULT_RATE = 5;
  // Премии: за среднюю производительность за месяц и за сервис (качество без ошибок) по зонам
  const DEFAULT_BONUS = { prodThreshold: 120, prodAmount: 15000, greenThreshold: 99.95, greenAmount: 15000, yellowThreshold: 99.9, yellowAmount: 0, redAmount: 0 };

  const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
  const MONTHS_GEN = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  const MONTHS_SHORT = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
  const WEEKDAYS_FULL = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];

  // ---------- Даты (строковые ключи YYYY-MM-DD, без часовых поясов) ----------
  const pad = (n) => String(n).padStart(2, '0');
  const key = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`; // m: 0..11
  const parseKey = (k) => { const [y, m, d] = k.split('-').map(Number); return { y, m: m - 1, d }; };
  const dateOf = (k) => { const p = parseKey(k); return new Date(p.y, p.m, p.d, 12); };
  const keyOfDate = (dt) => key(dt.getFullYear(), dt.getMonth(), dt.getDate());
  const addDays = (k, n) => { const dt = dateOf(k); dt.setDate(dt.getDate() + n); return keyOfDate(dt); };
  const weekdayMon = (k) => (dateOf(k).getDay() + 6) % 7; // Пн=0 … Вс=6
  const daysInMonth = (y, m) => new Date(y, m + 1, 0).getDate();
  const isValidKey = (k) => typeof k === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(k) && keyOfDate(dateOf(k)) === k;
  // В пределах доступных лет (2026–2028); с указанием года — в пределах этого года
  const inYear = (k, y) => (y ? k >= `${y}-01-01` && k <= `${y}-12-31` : k >= FIRST_DAY && k <= LAST_DAY);

  // ---------- Рабочие и выходные дни ----------
  // Сделка / ИП: работаем в любой будний день, праздники и переносы не учитываются. Выходные — только сб и вс.
  function dayInfo(k) {
    const wd = weekdayMon(k);
    if (wd >= 5) return { off: true, holiday: false, weekend: true, label: 'Выходной' };
    return { off: false, holiday: false, weekend: false, label: 'Рабочий день' };
  }

  const monthKeys = (m, y = YEAR) => Array.from({ length: daysInMonth(y, m) }, (_, i) => key(y, m, i + 1));
  const yearKeys = (y = YEAR) => { const r = []; for (let m = 0; m < 12; m++) r.push(...monthKeys(m, y)); return r; };
  function rangeKeys(from, to) {
    if (!isValidKey(from) || !isValidKey(to)) return [];
    if (from > to) [from, to] = [to, from];
    const r = []; let k = from; let guard = 0;
    while (k <= to && guard++ < 4000) { r.push(k); k = addDays(k, 1); }
    return r;
  }
  // Сетка месяца: массив недель по 7 ячеек (null — пустая ячейка), неделя с понедельника
  function calendarGrid(m, y = YEAR) {
    const keys = monthKeys(m, y);
    const cells = Array(weekdayMon(keys[0])).fill(null).concat(keys);
    while (cells.length % 7) cells.push(null);
    const weeks = [];
    for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
    return weeks;
  }
  // ---------- Свои отметки дней: выходной, больничный, отпуск, рабочий (для сб/вс) ----------
  const MARKS = {
    off: { label: 'Выходной', short: 'вых', off: true },
    sick: { label: 'Больничный', short: 'бол', off: true },
    vacation: { label: 'Отпуск', short: 'отп', off: true },
    work: { label: 'Рабочий день', short: 'раб', off: false },
  };
  // Статус дня с учётом отметки пользователя. state может быть не передан — тогда только сб/вс.
  function dayStatus(state, k) {
    const base = dayInfo(k);
    const mark = state && state.marks ? state.marks[k] : null;
    if (mark && MARKS[mark]) return { off: MARKS[mark].off, mark, weekend: base.weekend, label: MARKS[mark].label, short: MARKS[mark].short };
    return { off: base.off, mark: null, weekend: base.weekend, label: base.label, short: '' };
  }
  // Отметить день. Отметка «нерабочий» удаляет смену за этот день (её не было).
  function setMark(state, k, kind) {
    if (!isValidKey(k)) return { ok: false, error: 'Некорректная дата' };
    state.marks = state.marks || {};
    if (!kind) { delete state.marks[k]; return { ok: true }; }
    if (!MARKS[kind]) return { ok: false, error: 'Неизвестная отметка' };
    if (kind === 'work' && !dayInfo(k).weekend) { delete state.marks[k]; return { ok: true }; } // будни и так рабочие
    if (kind === 'off' && dayInfo(k).weekend) { delete state.marks[k]; return { ok: true }; }   // сб/вс и так выходные
    state.marks[k] = kind;
    if (MARKS[kind].off) delete state.entries[k];
    return { ok: true };
  }
  const workdaysInMonth = (m, y = YEAR, state = null) => monthKeys(m, y).filter((k) => !dayStatus(state, k).off).length;
  // Сколько отметок в месяце: { off, sick, vacation, work }
  function marksInMonth(state, m, y = YEAR) {
    const r = { off: 0, sick: 0, vacation: 0, work: 0 };
    for (const k of monthKeys(m, y)) { const mk = state.marks && state.marks[k]; if (mk && r[mk] !== undefined) r[mk]++; }
    return r;
  }
  // Сквозной номер месяца: 0 = январь 2026 … 35 = декабрь 2028
  const MONTH_COUNT = YEARS.length * 12;
  const ymOf = (i) => ({ y: YEARS[0] + Math.floor(i / 12), m: i % 12 });
  const indexOf = (y, m) => (y - YEARS[0]) * 12 + m;

  // ---------- Деньги ----------
  const round2 = (x) => Math.round((Number(x) + Number.EPSILON) * 100) / 100;
  const nf0 = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });
  const nf2 = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
  const fmtNum = (x, digits = 0) => (digits ? new Intl.NumberFormat('ru-RU', { maximumFractionDigits: digits }) : nf0).format(Number(x) || 0).replace(/[\u00a0\u202f ]/g, '\u00a0');
  const fmtMoney = (x) => nf2.format(round2(x) || 0).replace(/[\u00a0\u202f ]/g, '\u00a0') + '\u00a0₽';
  const fmtMoneyShort = (x) => {
    x = Number(x) || 0;
    if (Math.abs(x) >= 1e6) return fmtNum(x / 1e6, 1) + 'м';
    if (Math.abs(x) >= 1e4) return fmtNum(x / 1e3, 0) + 'к';
    if (Math.abs(x) >= 1e3) return fmtNum(x / 1e3, 1) + 'к';
    return fmtNum(x, 0);
  };
  const fmtDateLong = (k) => { const p = parseKey(k); return `${p.d} ${MONTHS_GEN[p.m]} ${p.y}`; };
  const fmtDateShort = (k) => { const p = parseKey(k); return `${p.d} ${MONTHS_SHORT[p.m]}`; };

  // ---------- Состояние ----------
  function defaultState() {
    return {
      version: 1,
      settings: {
        rateHistory: [{ from: FIRST_DAY, rate: DEFAULT_RATE }],
        target: 0,          // целевая зарплата за месяц, ₽ (0 — не задана)
        plannedShifts: 0,   // планируемое число смен в месяц (0 — по будним дням)
        theme: 'system',
        savings: { goal: 100000, saved: 0, percent: 100 },
        paydays: { ...DEFAULT_PAYDAYS },
        shiftStart: '21:00',
        palette: { id: 'orange', accent: PALETTES[0].accent, accent2: PALETTES[0].accent2 },
        bonus: { ...DEFAULT_BONUS },
      },
      entries: {},          // 'YYYY-MM-DD' -> { lines, actual, hours, prod, comment, rate, updatedAt }
      months: {},           // 'YYYY-MM' -> { service (%), penalty (₽), updatedAt }
      marks: {},            // 'YYYY-MM-DD' -> 'off' | 'sick' | 'vacation' | 'work'
      payouts: {},          // 'YYYY-MM' -> { advance|envelope|salary: { received, amount, date } }
    };
  }

  // Тариф, действующий на дату: последняя запись истории с from <= дата
  function rateFor(history, k) {
    const h = [...(history || [])].sort((a, b) => (a.from < b.from ? -1 : 1));
    let r = h.length ? h[0].rate : DEFAULT_RATE;
    for (const it of h) if (it.from <= k) r = it.rate;
    return Number(r);
  }
  function setRate(state, from, rate) {
    rate = round2(rate);
    if (!(rate > 0)) throw new Error('Стоимость линии должна быть больше нуля');
    if (!isValidKey(from)) throw new Error('Некорректная дата');
    const h = state.settings.rateHistory.filter((x) => x.from !== from);
    h.push({ from, rate });
    h.sort((a, b) => (a.from < b.from ? -1 : 1));
    state.settings.rateHistory = h;
    return state; // записи (entries) намеренно НЕ трогаем: у каждой свой сохранённый тариф
  }
  function removeRate(state, from) {
    if (state.settings.rateHistory.length <= 1) throw new Error('Должен остаться хотя бы один тариф');
    state.settings.rateHistory = state.settings.rateHistory.filter((x) => x.from !== from);
    return state;
  }

  const numOrNull = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(String(v).replace(',', '.').replace(/\s/g, ''));
    return Number.isFinite(n) ? n : NaN;
  };

  // ---------- Время смены (ночные: 21:00 → 06:00 следующего дня) ----------
  const isTime = (t) => typeof t === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(t);
  const toMin = (t) => +t.slice(0, 2) * 60 + +t.slice(3, 5);
  // Длительность в часах; если конец раньше начала — смена через полночь
  function shiftHours(start, end) {
    if (!isTime(start) || !isTime(end)) return null;
    let d = toMin(end) - toMin(start);
    if (d <= 0) d += 24 * 60;
    return round2(d / 60);
  }
  const MOODS = [
    { v: 1, icon: '😫', label: 'Тяжело' }, { v: 2, icon: '😕', label: 'Так себе' }, { v: 3, icon: '😐', label: 'Нормально' },
    { v: 4, icon: '🙂', label: 'Хорошо' }, { v: 5, icon: '😄', label: 'Отлично' },
  ];

  // Проверка и нормализация данных формы. Возвращает {ok, entry, error}
  function buildEntry(input, rate) {
    const lines = numOrNull(input.lines);
    const actual = numOrNull(input.actual);
    let hours = numOrNull(input.hours);
    if ((hours === null || hours === 0) && input.start && input.end) hours = shiftHours(String(input.start), String(input.end)); // часы по времени
    const prod = numOrNull(input.prod);
    const start = input.start ? String(input.start) : null, end = input.end ? String(input.end) : null;
    const mood = numOrNull(input.mood);
    if ((start && !isTime(start)) || (end && !isTime(end))) return { ok: false, error: 'Время — в формате ЧЧ:ММ' };
    if (Number.isNaN(mood) || (mood !== null && ![1, 2, 3, 4, 5].includes(mood))) return { ok: false, error: 'Самочувствие — от 1 до 5' };
    if (Number.isNaN(lines) || (lines !== null && (lines < 0 || !Number.isInteger(lines)))) return { ok: false, error: 'Количество линий — целое число не меньше 0' };
    if (Number.isNaN(actual) || (actual !== null && actual < 0)) return { ok: false, error: 'Фактическая сумма должна быть числом не меньше 0' };
    if (Number.isNaN(hours) || (hours !== null && (hours < 0 || hours > 24))) return { ok: false, error: 'Часы — число от 0 до 24' };
    if (Number.isNaN(prod) || (prod !== null && (prod < 0 || prod > 1000))) return { ok: false, error: 'Производительность — число от 0 до 1000 %' };
    if ((lines === null || lines === 0) && (actual === null || actual === 0)) return { ok: false, error: 'Укажите количество линий или фактическую сумму' };
    if (lines !== null && lines > 100000) return { ok: false, error: 'Слишком большое количество линий' };
    return {
      ok: true,
      entry: {
        lines: lines === null ? 0 : lines,
        actual: actual === null ? null : round2(actual),
        hours: hours === null || hours === 0 ? null : round2(hours),
        prod: prod === null ? null : round2(prod),
        start: start || null,
        end: end || null,
        mood: mood === null ? null : mood,
        comment: String(input.comment || '').trim().slice(0, 500),
        rate: round2(rate),
        updatedAt: Date.now(),
      },
    };
  }

  // Сохранение записи. keepRate: при редактировании сохраняем тариф записи (без пересчёта задним числом)
  function saveEntry(state, k, input, opts = {}) {
    if (!isValidKey(k)) return { ok: false, error: 'Некорректная дата' };
    const prev = state.entries[k];
    const rate = prev && !opts.useCurrentRate ? prev.rate : rateFor(state.settings.rateHistory, k);
    const res = buildEntry(input, rate);
    if (res.ok) {
      state.entries[k] = res.entry;
      // Смена внесена — значит день рабочий: снимаем отметку «выходной/больничный/отпуск»
      if (state.marks && state.marks[k] && MARKS[state.marks[k]].off) delete state.marks[k];
    }
    return res;
  }
  function deleteEntry(state, k) { delete state.entries[k]; }

  const estimated = (e) => round2((e.lines || 0) * (e.rate || 0));
  const total = (e) => (e.actual !== null && e.actual !== undefined ? round2(e.actual) : estimated(e));

  // ---------- Статистика ----------
  function summarize(entries, keys) {
    const s = { shifts: 0, lines: 0, estimated: 0, actual: 0, actualCount: 0, total: 0, hours: 0, hoursLines: 0, hoursTotal: 0, diff: 0, diffCount: 0, prodSum: 0, prodDays: 0, best: null, days: [] };
    for (const k of keys) {
      const e = entries[k];
      if (!e) continue;
      const est = estimated(e), tot = total(e);
      s.shifts++;
      s.lines += e.lines || 0;
      s.estimated += est;
      s.total += tot;
      if (e.actual !== null && e.actual !== undefined) { s.actual += e.actual; s.actualCount++; if (e.lines) { s.diff += e.actual - est; s.diffCount++; } }
      if (e.prod !== null && e.prod !== undefined) { s.prodSum += e.prod; s.prodDays++; }
      if (e.hours) { s.hours += e.hours; s.hoursLines += e.lines || 0; s.hoursTotal += tot; }
      if (!s.best || (e.lines || 0) > s.best.lines || ((e.lines || 0) === s.best.lines && tot > s.best.total)) s.best = { key: k, lines: e.lines || 0, total: tot };
      s.days.push({ key: k, lines: e.lines || 0, estimated: est, total: tot, prod: e.prod ?? null });
    }
    ['estimated', 'actual', 'total', 'diff', 'hours', 'hoursTotal'].forEach((f) => (s[f] = round2(s[f])));
    s.prodSum = round2(s.prodSum);
    s.prodAvg = s.prodDays ? round2(s.prodSum / s.prodDays) : null;
    s.avgLines = s.shifts ? s.lines / s.shifts : 0;
    s.avgPerShift = s.shifts ? round2(s.total / s.shifts) : 0;
    s.linesPerHour = s.hours ? s.hoursLines / s.hours : 0;
    s.earnPerHour = s.hours ? round2(s.hoursTotal / s.hours) : 0;
    return s;
  }

  // ---------- Премии и штрафы за месяц ----------
  const monthId = (m, y = YEAR) => `${y}-${pad(m + 1)}`;
  const bonusCfg = (state) => ({ ...DEFAULT_BONUS, ...((state.settings && state.settings.bonus) || {}) });
  function serviceZone(service, b) {
    if (service === null || service === undefined) return null;
    const v = Math.round(service * 10000) / 10000; // защита от ошибок округления (99.95 и т.п.)
    if (v >= b.greenThreshold) return 'green';
    if (v >= b.yellowThreshold) return 'yellow';
    return 'red';
  }
  // Премии и штраф месяца. sum — результат summarize за месяц (для средней производительности)
  function monthExtras(state, m, sum, y = YEAR) {
    const b = bonusCfg(state);
    const md = (state.months || {})[monthId(m, y)] || {};
    const service = md.service ?? null;
    const penalty = round2(md.penalty || 0);
    const prodAvg = sum.prodAvg;
    const prodOk = prodAvg !== null && prodAvg >= b.prodThreshold;
    const zone = serviceZone(service, b);
    const serviceBonus = zone ? Number(b[zone + 'Amount']) || 0 : 0;
    const prodBonus = prodOk ? Number(b.prodAmount) || 0 : 0;
    const manual = md.actualTotal ?? null;
    return { prodAvg, prodDays: sum.prodDays, prodOk, prodBonus, service, zone, serviceBonus, penalty, manual,
      bonuses: round2(prodBonus + serviceBonus),
      net: round2(-penalty),                        // входит в расчётный итог: только штраф
      pending: round2(prodBonus + serviceBonus),    // не входят в итог: ожидаемые премии (производительность + сервис)
      cfg: b };
  }
  // Данные месяца: сервис %, штраф ₽, фактически получено ₽ (ручной итог). Поле, которого нет во input, не меняется.
  function setMonthData(state, m, input, y = YEAR) {
    state.months = state.months || {};
    const id = monthId(m, y), cur = state.months[id] || {};
    const pick = (f) => (f in input ? numOrNull(input[f]) : (cur[f] ?? null));
    const service = pick('service'), penalty = pick('penalty'), actualTotal = pick('actualTotal');
    if (Number.isNaN(service) || (service !== null && (service < 0 || service > 100))) return { ok: false, error: 'Сервис — процент от 0 до 100' };
    if (Number.isNaN(penalty) || (penalty !== null && penalty < 0)) return { ok: false, error: 'Штраф — сумма не меньше 0' };
    if (Number.isNaN(actualTotal) || (actualTotal !== null && actualTotal < 0)) return { ok: false, error: 'Сумма — число не меньше 0' };
    if (service === null && !penalty && actualTotal === null) delete state.months[id];
    else state.months[id] = { service: service === null ? null : Math.round(service * 10000) / 10000, penalty: round2(penalty || 0),
      actualTotal: actualTotal === null ? null : round2(actualTotal), updatedAt: Date.now() };
    return { ok: true };
  }

  // Итоги месяца: расчёт (смены − штраф), ручной факт (если введён), разница, ожидаемые премии
  function applyTotals(s) {
    s.calc = round2(s.total + s.extras.net);
    s.manual = s.extras.manual;
    s.grand = s.manual !== null ? s.manual : s.calc;
    s.manualDiff = s.manual !== null ? round2(s.manual - s.calc) : null;
    s.pending = s.extras.pending;
    s.grandWithPending = round2(s.grand + (s.manual !== null ? 0 : s.pending)); // в ручной итог премии уже могли войти
    return s;
  }

  // Сводка за месяц + прогноз. today — ключ «сегодня».
  function monthSummary(state, m, today, y = YEAR) {
    const keys = monthKeys(m, y);
    const s = summarize(state.entries, keys);
    const first = keys[0], last = keys[keys.length - 1];
    const plannedBase = Number(state.settings.plannedShifts) || 0;
    // План смен уменьшают отмеченные нерабочие будни (выходной/больничный/отпуск) и увеличивают рабочие сб/вс
    const mk = marksInMonth(state, m, y);
    const planned = plannedBase > 0 ? Math.max(0, plannedBase - mk.off - mk.sick - mk.vacation + mk.work) : 0;
    let remaining;
    if (today > last) remaining = 0; // месяц прошёл — прогноз равен факту
    else if (plannedBase > 0) remaining = Math.max(0, planned - s.shifts);
    else remaining = keys.filter((k) => k > today && !dayStatus(state, k).off && !state.entries[k]).length;
    s.marks = mk;
    // Если смен ещё нет, оцениваем смену по средней прошлых месяцев года (если есть) — иначе прогноз неизвестен
    let perShift = s.avgPerShift, basis = 'month';
    if (!s.shifts) {
      const all = summarize(state.entries, yearKeys(y));
      perShift = all.avgPerShift; basis = all.shifts ? 'year' : 'none';
    }
    s.remainingShifts = remaining;
    s.plannedTotal = plannedBase > 0 ? planned : workdaysInMonth(m, y, state);
    s.plannedByUser = plannedBase > 0;
    s.projected = basis === 'none' ? (s.shifts ? s.total : null) : round2(s.total + perShift * remaining);
    s.projectionBasis = basis;
    s.target = Number(state.settings.target) || 0;
    s.targetProgress = s.target ? s.total / s.target : 0;
    s.needPerShift = s.target && remaining ? round2(Math.max(0, s.target - s.total) / remaining) : 0;
    s.month = m; s.year = y; s.first = first; s.last = last;
    // Итог месяца = смены + премия за сервис − штраф. Премия за производительность — отдельно, «ожидается».
    s.extras = monthExtras(state, m, s, y);
    applyTotals(s);
    if (s.manual !== null) s.projected = s.manual;   // фактическая сумма известна — прогноз не нужен
    else if (s.projected !== null) s.projected = round2(s.projected + s.extras.net);
    else if (s.extras.penalty) s.projected = s.grand;
    // Какая средняя производительность нужна в оставшиеся смены, чтобы выйти на премию
    const thr = s.extras.cfg.prodThreshold;
    s.needProd = s.prodDays && remaining && !s.extras.prodOk ? round2((thr * (s.prodDays + remaining) - s.prodSum) / remaining) : null;
    s.targetProgress = s.target ? s.grand / s.target : 0;
    s.needPerShift = s.target && remaining ? round2(Math.max(0, s.target - s.grand) / remaining) : 0;
    return s;
  }

  // Группировка по календарным неделям (пн–вс). Неделя на стыке периодов учитывается только днями периода.
  function weekly(entries, keys) {
    const map = new Map();
    for (const k of keys) {
      const mon = addDays(k, -weekdayMon(k));
      if (!map.has(mon)) map.set(mon, []);
      map.get(mon).push(k);
    }
    const weeks = [...map.entries()].map(([mon, ks]) => ({ monday: mon, sunday: addDays(mon, 6), ...summarize(entries, ks) }));
    const worked = weeks.filter((w) => w.shifts > 0);
    const sum = worked.reduce((a, w) => a + w.total, 0);
    return { weeks, workedWeeks: worked.length, avgWeekly: worked.length ? round2(sum / worked.length) : 0 };
  }

  function yearByMonths(state, y = YEAR) {
    const months = MONTHS.map((_, m) => {
      const s = summarize(state.entries, monthKeys(m, y));
      s.extras = monthExtras(state, m, s, y);
      applyTotals(s);
      return s;
    });
    months.forEach((s, m) => {
      const prev = months[m - 1];
      s.change = prev && prev.grand > 0 ? (s.grand - prev.grand) / prev.grand : null;
    });
    return months;
  }

  // ---------- Выплаты: аванс, конверт, зарплата ----------
  // Если дата выплаты попадает на выходной или праздник — выплата раньше, в ближайший рабочий день.
  // Праздники РФ (ст. 112 ТК) — только для сдвига выплат; сама работа по ним идёт как обычно.
  const FIXED_HOLIDAYS = ['01-01', '01-02', '01-03', '01-04', '01-05', '01-06', '01-07', '01-08', '02-23', '03-08', '05-01', '05-09', '06-12', '11-04'];
  const isBankOff = (k) => weekdayMon(k) >= 5 || FIXED_HOLIDAYS.includes(k.slice(5));
  function shiftEarlier(k) { let g = 0; while (isBankOff(k) && g++ < 20) k = addDays(k, -1); return k; }
  const PAYOUTS = [
    { id: 'advance', name: 'Аванс', icon: '💳' },
    { id: 'envelope', name: 'Конверт', icon: '✉️' },
    { id: 'salary', name: 'Зарплата', icon: '💰' },
  ];
  const DEFAULT_PAYDAYS = { advance: 15, envelopeFrom: 20, envelopeTo: 25, salary: 30 };
  const dayIn = (y, m, d) => key(y, m, Math.min(d, daysInMonth(y, m)));
  // План выплат на месяц: даты (с переносом) и полученные суммы
  function payoutSchedule(state, m, y = YEAR, today = '') {
    const pd = { ...DEFAULT_PAYDAYS, ...((state.settings && state.settings.paydays) || {}) };
    const got = ((state.payouts || {})[monthId(m, y)]) || {};
    const plan = {
      advance: { date: shiftEarlier(dayIn(y, m, pd.advance)) },
      envelope: { date: shiftEarlier(dayIn(y, m, pd.envelopeFrom)), dateTo: shiftEarlier(dayIn(y, m, pd.envelopeTo)) },
      salary: { date: shiftEarlier(dayIn(y, m, pd.salary)) },
    };
    return PAYOUTS.map((p) => {
      const g = got[p.id] || null, pl = plan[p.id];
      const received = !!(g && g.received);
      const due = pl.dateTo || pl.date;
      const status = received ? 'received' : today && today > due ? 'late' : today && today >= pl.date ? 'today' : 'upcoming';
      return { ...p, date: pl.date, dateTo: pl.dateTo || null, shifted: pl.date !== dayIn(y, m, p.id === 'envelope' ? pd.envelopeFrom : pd[p.id]),
        received, amount: g && g.amount != null ? g.amount : null, receivedOn: g && g.date ? g.date : null, status,
        daysLeft: today ? Math.round((dateOf(pl.date) - dateOf(today)) / 864e5) : null, y, m };
    });
  }
  function setPayout(state, m, y, id, input) {
    if (!PAYOUTS.find((p) => p.id === id)) return { ok: false, error: 'Неизвестная выплата' };
    const amount = numOrNull(input.amount);
    if (Number.isNaN(amount) || (amount !== null && amount < 0)) return { ok: false, error: 'Сумма — число не меньше 0' };
    if (input.date && !isValidKey(input.date)) return { ok: false, error: 'Некорректная дата' };
    state.payouts = state.payouts || {};
    const mid = monthId(m, y);
    const cur = { ...(state.payouts[mid] || {}) };
    if (!input.received && amount === null) delete cur[id];
    else cur[id] = { received: !!input.received, amount: amount === null ? null : round2(amount), date: input.date || null };
    if (Object.keys(cur).length) state.payouts[mid] = cur; else delete state.payouts[mid];
    return { ok: true };
  }
  // Ближайшая неполученная выплата начиная с сегодняшнего дня (смотрим этот и следующий месяц)
  function nextPayout(state, today) {
    const p = parseKey(today);
    for (let i = 0; i < 3; i++) {
      const dt = new Date(p.y, p.m + i, 1);
      const y = dt.getFullYear(), m = dt.getMonth();
      const list = payoutSchedule(state, m, y, today).filter((x) => !x.received && (x.dateTo || x.date) >= today);
      if (list.length) return list[0];
    }
    return null;
  }
  const payoutsTotal = (state, m, y = YEAR) => round2(payoutSchedule(state, m, y).reduce((a, x) => a + (x.received && x.amount ? x.amount : 0), 0));

  // ---------- Самочувствие и усталость ----------
  // Средняя производительность/заработок по самочувствию и по номеру смены подряд (1-я, 2-я … 5-я ночь)
  function wellbeingStats(state, keys) {
    const ks = (keys || allShiftKeys(state)).filter((k) => state.entries[k]);
    const byMood = MOODS.map((md) => ({ ...md, shifts: 0, prodSum: 0, prodDays: 0, total: 0 }));
    const byIdx = [1, 2, 3, 4, 5].map((n) => ({ n, shifts: 0, prodSum: 0, prodDays: 0, moodSum: 0, moodDays: 0, total: 0 }));
    for (const k of ks) {
      const e = state.entries[k];
      if (e.mood) { const r = byMood[e.mood - 1]; r.shifts++; r.total += total(e); if (e.prod != null) { r.prodSum += e.prod; r.prodDays++; } }
      let n = 1, d = addDays(k, -1);
      while (state.entries[d] && n < 5) { n++; d = addDays(d, -1); }
      const r = byIdx[n - 1]; r.shifts++; r.total += total(e);
      if (e.prod != null) { r.prodSum += e.prod; r.prodDays++; }
      if (e.mood) { r.moodSum += e.mood; r.moodDays++; }
    }
    const fin = (r) => { r.avgProd = r.prodDays ? round2(r.prodSum / r.prodDays) : null; r.avg = r.shifts ? round2(r.total / r.shifts) : 0; if ('moodSum' in r) r.avgMood = r.moodDays ? round2(r.moodSum / r.moodDays) : null; return r; };
    byMood.forEach(fin); byIdx.forEach(fin);
    const moodDays = byMood.reduce((a, r) => a + r.shifts, 0);
    const avgMood = moodDays ? round2(byMood.reduce((a, r) => a + r.v * r.shifts, 0) / moodDays) : null;
    const good = byMood.slice(3), bad = byMood.slice(0, 2);
    const agg = (rs) => { const d = rs.reduce((a, r) => a + r.prodDays, 0); return d ? round2(rs.reduce((a, r) => a + r.prodSum, 0) / d) : null; };
    return { byMood, byIdx, moodDays, avgMood, goodProd: agg(good), badProd: agg(bad) };
  }

  // ---------- Успехи: рейтинг, рекорды, серии, дни недели, накопления, достижения ----------
  const allShiftKeys = (state) => Object.keys(state.entries).filter((k) => state.entries[k]).sort();
  // Рейтинг смен по продуктивности: сначала по производительности %, затем по линиям, затем по заработку
  function rankShifts(state, keys) {
    const list = (keys || allShiftKeys(state)).filter((k) => state.entries[k]).map((k) => {
      const e = state.entries[k];
      return { key: k, prod: e.prod ?? null, lines: e.lines || 0, total: total(e) };
    });
    list.sort((a, b) => ((b.prod ?? -1) - (a.prod ?? -1)) || (b.lines - a.lines) || (b.total - a.total) || (a.key < b.key ? -1 : 1));
    list.forEach((x, i) => (x.place = i + 1));
    return list;
  }
  // Серии продуктивных смен подряд (по сменам, выходные не прерывают). Смена без % или ниже порога — прерывает.
  function streaks(state, thr) {
    const ks = allShiftKeys(state);
    let best = 0, bestEnd = null, cur = 0;
    for (const k of ks) {
      const p = state.entries[k].prod;
      if (p !== null && p !== undefined && p >= thr) { cur++; if (cur > best) { best = cur; bestEnd = k; } } else cur = 0;
    }
    return { best, bestEnd, current: cur };
  }
  function records(state) {
    const ks = allShiftKeys(state);
    const max = (f) => ks.reduce((b, k) => { const v = f(state.entries[k]); return v !== null && v !== undefined && (!b || v > b.value) ? { key: k, value: v } : b; }, null);
    const r = { lines: max((e) => e.lines || 0), total: max((e) => total(e)), prod: max((e) => e.prod ?? null) };
    let bestWeek = null, bestMonth = null;
    for (const y of YEARS) {
      const wk = weekly(state.entries, yearKeys(y)).weeks;
      for (const w of wk) if (w.shifts && (!bestWeek || w.total > bestWeek.value)) bestWeek = { key: w.monday, value: w.total, shifts: w.shifts };
      yearByMonths(state, y).forEach((ms, m) => { if ((ms.shifts || ms.manual !== null) && (!bestMonth || ms.grand > bestMonth.value)) bestMonth = { y, m, value: ms.grand }; });
    }
    r.week = bestWeek; r.month = bestMonth;
    r.shifts = ks.length;
    r.linesTotal = ks.reduce((a, k) => a + (state.entries[k].lines || 0), 0);
    r.earned = round2(ks.reduce((a, k) => a + total(state.entries[k]), 0));
    return r;
  }
  // Выгодность дней недели: средний заработок, линии и производительность по Пн…Вс
  function weekdayStats(state, keys) {
    const rows = WEEKDAYS.map((n, i) => ({ wd: i, name: WEEKDAYS_FULL[i], shifts: 0, total: 0, lines: 0, prodSum: 0, prodDays: 0 }));
    for (const k of keys || allShiftKeys(state)) {
      const e = state.entries[k]; if (!e) continue;
      const r = rows[weekdayMon(k)];
      r.shifts++; r.total += total(e); r.lines += e.lines || 0;
      if (e.prod !== null && e.prod !== undefined) { r.prodSum += e.prod; r.prodDays++; }
    }
    const allShifts = rows.reduce((a, r) => a + r.shifts, 0), allTotal = rows.reduce((a, r) => a + r.total, 0);
    const overall = allShifts ? allTotal / allShifts : 0;
    rows.forEach((r) => {
      r.total = round2(r.total);
      r.avg = r.shifts ? round2(r.total / r.shifts) : 0;
      r.avgLines = r.shifts ? r.lines / r.shifts : 0;
      r.avgProd = r.prodDays ? round2(r.prodSum / r.prodDays) : null;
      r.vsAvg = r.shifts && overall ? r.avg / overall - 1 : null;
    });
    const worked = rows.filter((r) => r.shifts);
    const best = worked.length ? worked.reduce((a, b) => (b.avg > a.avg ? b : a)) : null;
    const worst = worked.length > 1 ? worked.reduce((a, b) => (b.avg < a.avg ? b : a)) : null;
    return { rows, best, worst, overall: round2(overall), shifts: allShifts };
  }
  // Планировщик накоплений: сколько смен нужно, чтобы накопить цель, и к какой дате (по рабочим дням с учётом отметок)
  function savingsPlan(state, { goal, saved = 0, percent = 100 }, today) {
    goal = Number(goal) || 0; saved = Number(saved) || 0; percent = Math.min(100, Math.max(1, Number(percent) || 100));
    const ks = allShiftKeys(state);
    const recent = ks.filter((k) => k <= today).slice(-30); // средняя по последним 30 сменам — точнее отражает текущий темп
    const base = recent.length >= 3 ? recent : ks;
    const perShift = base.length ? round2(base.reduce((a, k) => a + total(state.entries[k]), 0) / base.length) : 0;
    const perShiftSaved = round2(perShift * percent / 100);
    const left = Math.max(0, round2(goal - saved));
    if (!goal) return { ok: false, reason: 'goal' };
    if (!left) return { ok: true, done: true, left: 0, perShift, perShiftSaved, shifts: 0, basis: base.length };
    if (!perShiftSaved) return { ok: false, reason: 'nodata' };
    const shifts = Math.ceil(left / perShiftSaved);
    // Дата: идём по дням от завтра, считаем рабочие дни (будни, отметки учитываются)
    let k = addDays(today, 1), n = 0, guard = 0;
    while (guard++ < 5000) { if (!dayStatus(state, k).off && !state.entries[k]) { n++; if (n >= shifts) break; } k = addDays(k, 1); }
    const weeks = Math.ceil(shifts / 5);
    return { ok: true, done: false, left, perShift, perShiftSaved, shifts, date: k, weeks, basis: base.length, percent };
  }
  function achievements(state) {
    const b = bonusCfg(state);
    const r = records(state), st = streaks(state, b.prodThreshold);
    let bonusMonths = 0, greenMonths = 0, cleanMonths = 0;
    for (const y of YEARS) yearByMonths(state, y).forEach((ms) => {
      if (ms.extras.prodOk) bonusMonths++;
      if (ms.extras.zone === 'green') greenMonths++;
      if (ms.extras.service !== null && !ms.extras.penalty) cleanMonths++;
    });
    const maxProd = r.prod ? r.prod.value : 0, maxLines = r.lines ? r.lines.value : 0;
    const A = (id, icon, title, desc, value, target) => ({ id, icon, title, desc, value: Math.min(value, target), target, done: value >= target });
    return [
      A('first', '🚀', 'Первая смена', 'Внести первую смену', r.shifts, 1),
      A('s10', '🔟', 'Разогрев', '10 смен', r.shifts, 10),
      A('s50', '💪', 'Опытный', '50 смен', r.shifts, 50),
      A('s100', '🏅', 'Ветеран склада', '100 смен', r.shifts, 100),
      A('s200', '🏆', 'Легенда склада', '200 смен', r.shifts, 200),
      A('l10k', '📦', '10 000 линий', 'Всего собрано линий', r.linesTotal, 10000),
      A('l50k', '🚚', '50 000 линий', 'Всего собрано линий', r.linesTotal, 50000),
      A('m100', '💰', 'Первые 100 тысяч', 'Заработано за смены', r.earned, 100000),
      A('m500', '💎', 'Полмиллиона', 'Заработано за смены', r.earned, 500000),
      A('p120', '⚡', 'На премию', `Смена с производительностью от ${b.prodThreshold}%`, maxProd >= b.prodThreshold ? 1 : 0, 1),
      A('p140', '🔥', 'Огонь', 'Смена с производительностью от 140%', maxProd >= 140 ? 1 : 0, 1),
      A('st5', '📈', 'Серия ×5', `5 смен подряд от ${b.prodThreshold}%`, st.best, 5),
      A('st10', '🌟', 'Серия ×10', `10 смен подряд от ${b.prodThreshold}%`, st.best, 10),
      A('st20', '👑', 'Серия ×20', `20 смен подряд от ${b.prodThreshold}%`, st.best, 20),
      A('bm', '🎯', 'Премиальный месяц', 'Месяц со средней производительностью на премию', bonusMonths, 1),
      A('bm3', '🥇', 'Три премии', '3 месяца с премией за производительность', bonusMonths, 3),
      A('green', '🟢', 'Зелёная зона', 'Месяц с сервисом в зелёной зоне', greenMonths, 1),
      A('clean', '✨', 'Без ошибок', 'Месяц без штрафа (сервис указан)', cleanMonths, 1),
      A('l400', '🦾', 'Машина', 'Смена от 400 линий', maxLines, 400),
    ];
  }

  // ---------- Итоги месяца (сторис) ----------
  function monthWrapped(state, m, y = YEAR) {
    const keys = monthKeys(m, y);
    const sum = summarize(state.entries, keys);
    if (!sum.shifts) return null;
    const ms = yearByMonths(state, y), cur = ms[m];
    // предыдущий месяц (с переходом через год)
    const pd = new Date(y, m - 1, 1), py = pd.getFullYear(), pm = pd.getMonth();
    const prev = YEARS.includes(py) ? (py === y ? ms[pm] : yearByMonths(state, py)[pm]) : null;
    const b = bonusCfg(state);
    // лучшая серия продуктивных смен внутри месяца
    let run = 0, bestRun = 0;
    for (const k of keys) { const e = state.entries[k]; if (!e) continue; if (e.prod != null && e.prod >= b.prodThreshold) { run++; bestRun = Math.max(bestRun, run); } else run = 0; }
    const top = rankShifts(state, keys)[0];
    const topE = state.entries[top.key];
    const wd = weekdayStats(state, keys);
    const wb = wellbeingStats(state, keys);
    const moodTop = wb.moodDays ? wb.byMood.reduce((a, r) => (r.shifts > a.shifts ? r : a)) : null;
    const worked = ms.filter((x) => x.shifts);
    const rankInYear = 1 + ms.filter((x, i) => i !== m && x.shifts && x.grand > cur.grand).length;
    const pay = payoutSchedule(state, m, y).filter((p) => p.received && p.amount);
    return {
      m, y, name: MONTHS[m], shifts: sum.shifts, lines: sum.lines, hours: sum.hours, hoursShifts: summarize(state.entries, keys.filter((k) => state.entries[k] && state.entries[k].hours)).shifts,
      earned: cur.grand, calc: cur.calc, manual: cur.manual, pending: cur.manual !== null ? 0 : cur.pending, perShift: round2(cur.grand / sum.shifts),
      avgLines: sum.avgLines, prodAvg: sum.prodAvg, prodOk: cur.extras.prodOk, prodThreshold: b.prodThreshold, prodBonus: cur.extras.prodBonus,
      service: cur.extras.service, zone: cur.extras.zone, serviceBonus: cur.extras.serviceBonus, penalty: cur.extras.penalty,
      prev: prev && prev.shifts ? { name: MONTHS[pm], earned: prev.grand, lines: prev.lines, change: prev.grand ? (cur.grand - prev.grand) / prev.grand : null } : null,
      top: { key: top.key, lines: top.lines, prod: top.prod, total: top.total, mood: topE.mood || null },
      bestRun, bestWeekday: wd.best && wd.shifts >= 3 ? { name: wd.best.name, avg: wd.best.avg, vs: wd.best.vsAvg } : null,
      mood: moodTop ? { icon: moodTop.icon, label: moodTop.label, count: moodTop.shifts, avg: wb.avgMood, total: wb.moodDays } : null,
      rankInYear, monthsInYear: worked.length, marks: marksInMonth(state, m, y), payouts: pay.reduce((a, p) => a + p.amount, 0),
    };
  }
  // Месяцы, за которые есть данные для итогов
  const wrappedMonths = (state) => {
    const r = [];
    for (const y of YEARS) for (let m = 0; m < 12; m++) if (monthKeys(m, y).some((k) => state.entries[k])) r.push({ y, m });
    return r;
  };

  // ---------- Резервное копирование ----------
  function exportData(state) {
    return JSON.stringify({ app: 'zarplata-komplektovshchika', exportedAt: new Date().toISOString(), ...state }, null, 2);
  }
  // Проверка импортируемых данных. Бросает ошибку при неверном формате.
  function normalizeState(obj) {
    if (!obj || typeof obj !== 'object') throw new Error('Файл не похож на резервную копию');
    const st = defaultState();
    const set = obj.settings || {};
    if (Array.isArray(set.rateHistory) && set.rateHistory.length) {
      const h = set.rateHistory.filter((x) => x && isValidKey(x.from) && Number(x.rate) > 0).map((x) => ({ from: x.from, rate: round2(x.rate) }));
      if (h.length) st.settings.rateHistory = h.sort((a, b) => (a.from < b.from ? -1 : 1));
    }
    if (Number(set.target) >= 0) st.settings.target = Number(set.target) || 0;
    if (Number(set.plannedShifts) >= 0) st.settings.plannedShifts = Math.round(Number(set.plannedShifts)) || 0;
    if (['system', 'light', 'dark'].includes(set.theme)) st.settings.theme = set.theme;
    if (set.paydays && typeof set.paydays === 'object') {
      for (const k of Object.keys(DEFAULT_PAYDAYS)) { const v = Math.round(Number(set.paydays[k])); if (v >= 1 && v <= 31) st.settings.paydays[k] = v; }
    }
    if (isTime(set.shiftStart)) st.settings.shiftStart = set.shiftStart;
    if (obj.payouts && typeof obj.payouts === 'object') {
      for (const [mk, v] of Object.entries(obj.payouts)) {
        const mm = /^(\d{4})-(\d{2})$/.exec(mk);
        if (!mm || !v || typeof v !== 'object') continue;
        for (const p of PAYOUTS) if (v[p.id]) setPayout(st, +mm[2] - 1, +mm[1], p.id, v[p.id]);
      }
    }
    if (set.savings && typeof set.savings === 'object') {
      const g = Number(set.savings.goal), sv = Number(set.savings.saved), pc = Number(set.savings.percent);
      st.settings.savings = { goal: g >= 0 ? g : 100000, saved: sv >= 0 ? sv : 0, percent: pc >= 1 && pc <= 100 ? pc : 100 };
    }
    if (set.palette && isHex(set.palette.accent) && isHex(set.palette.accent2)) st.settings.palette = { id: String(set.palette.id || 'custom'), accent: set.palette.accent, accent2: set.palette.accent2 };
    if (set.bonus && typeof set.bonus === 'object') {
      for (const k of Object.keys(DEFAULT_BONUS)) if (set.bonus[k] !== undefined && Number(set.bonus[k]) >= 0) st.settings.bonus[k] = Number(set.bonus[k]);
    }
    if (obj.months && typeof obj.months === 'object') {
      for (const [mk, v] of Object.entries(obj.months)) {
        const mm = /^(\d{4})-(\d{2})$/.exec(mk);
        if (!mm || !YEARS.includes(+mm[1]) || +mm[2] < 1 || +mm[2] > 12 || !v) continue;
        const r = setMonthData(st, +mm[2] - 1, { service: v.service, penalty: v.penalty, actualTotal: v.actualTotal }, +mm[1]);
        if (r.ok && st.months[mk]) st.months[mk].updatedAt = Number(v.updatedAt) || Date.now();
      }
    }
    if (obj.marks && typeof obj.marks === 'object') {
      for (const [k, v] of Object.entries(obj.marks)) if (isValidKey(k) && MARKS[v]) st.marks[k] = v;
    }
    const ents = obj.entries && typeof obj.entries === 'object' ? obj.entries : {};
    let bad = 0;
    for (const [k, e] of Object.entries(ents)) {
      if (!isValidKey(k) || !e || typeof e !== 'object') { bad++; continue; }
      const rate = Number(e.rate) > 0 ? Number(e.rate) : rateFor(st.settings.rateHistory, k);
      const r = buildEntry({ lines: e.lines, actual: e.actual, hours: e.hours, prod: e.prod, start: isTime(e.start) ? e.start : null, end: isTime(e.end) ? e.end : null, mood: e.mood, comment: e.comment }, rate);
      if (r.ok) { r.entry.updatedAt = Number(e.updatedAt) || Date.now(); st.entries[k] = r.entry; } else bad++;
    }
    if (!obj.entries && !obj.settings) throw new Error('В файле нет данных приложения');
    return { state: st, skipped: bad };
  }
  function mergeStates(base, incoming) {
    const out = JSON.parse(JSON.stringify(base));
    for (const [k, e] of Object.entries(incoming.entries)) {
      const cur = out.entries[k];
      if (!cur || (e.updatedAt || 0) >= (cur.updatedAt || 0)) out.entries[k] = e;
    }
    out.marks = { ...(out.marks || {}), ...(incoming.marks || {}) };
    out.payouts = out.payouts || {};
    for (const [k, v] of Object.entries(incoming.payouts || {})) out.payouts[k] = { ...(out.payouts[k] || {}), ...v };
    for (const k of Object.keys(out.marks)) if (MARKS[out.marks[k]] && MARKS[out.marks[k]].off && out.entries[k]) delete out.marks[k];
    out.months = out.months || {};
    for (const [k, v] of Object.entries(incoming.months || {})) {
      const cur = out.months[k];
      if (!cur || (v.updatedAt || 0) >= (cur.updatedAt || 0)) out.months[k] = v;
    }
    return out;
  }
  function toCSV(state) {
    const rows = [['Дата', 'День недели', 'Линии', 'Тариф, ₽', 'Расчёт, ₽', 'Факт, ₽', 'Итог, ₽', 'Производительность, %', 'Часы', 'Начало', 'Конец', 'Самочувствие', 'Комментарий']];
    Object.keys(state.entries).sort().forEach((k) => {
      const e = state.entries[k];
      rows.push([k, WEEKDAYS_FULL[weekdayMon(k)], e.lines, e.rate, estimated(e), e.actual ?? '', total(e), e.prod ?? '', e.hours ?? '', e.start || '', e.end || '', e.mood ? MOODS[e.mood - 1].label : '', e.comment || '']);
    });
    return '﻿' + rows.map((r) => r.map((c) => {
      const v = String(c).replace('.', ',');
      return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
    }).join(';')).join('\r\n');
  }

  return {
    YEAR, YEARS, FIRST_DAY, LAST_DAY, MONTH_COUNT, ymOf, indexOf, PALETTES, isHex, DEFAULT_RATE, MONTHS, MONTHS_GEN, MONTHS_SHORT, WEEKDAYS, WEEKDAYS_FULL,
    key, parseKey, dateOf, keyOfDate, addDays, weekdayMon, daysInMonth, isValidKey, inYear,
    dayInfo, MARKS, dayStatus, setMark, marksInMonth, monthKeys, yearKeys, rangeKeys, calendarGrid, workdaysInMonth,
    round2, fmtNum, fmtMoney, fmtMoneyShort, fmtDateLong, fmtDateShort,
    defaultState, rateFor, setRate, removeRate, buildEntry, saveEntry, deleteEntry, estimated, total,
    DEFAULT_BONUS, monthId, serviceZone, monthExtras, setMonthData,
    isTime, shiftHours, MOODS, PAYOUTS, DEFAULT_PAYDAYS, isBankOff, payoutSchedule, setPayout, nextPayout, payoutsTotal, wellbeingStats,
    monthWrapped, wrappedMonths,
    rankShifts, streaks, records, weekdayStats, savingsPlan, achievements,
    summarize, monthSummary, weekly, yearByMonths, exportData, normalizeState, mergeStates, toCSV,
  };
})();
if (typeof module !== 'undefined') module.exports = Core;
