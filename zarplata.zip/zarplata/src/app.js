/* Интерфейс приложения. Зависит от Core (core.js). */
(() => {
  'use strict';
  const C = Core;
  const STORE_KEY = 'zarplata2027:v1';
  const META_KEY = 'zarplata2027:meta';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const M = C.fmtMoney, N = C.fmtNum;

  // ---------- Хранилище ----------
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) return C.normalizeState(JSON.parse(raw)).state;
    } catch (e) { console.warn('Не удалось прочитать данные', e); }
    return C.defaultState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); return true; }
    catch (e) { toast('Ошибка сохранения: память устройства недоступна'); return false; }
  }
  const meta = (() => { try { return JSON.parse(localStorage.getItem(META_KEY)) || {}; } catch { return {}; } })();
  const saveMeta = () => { try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch {} };

  let state = load();
  const todayKey = () => C.keyOfDate(new Date());
  const defaultMonth = () => { const t = todayKey(); return C.inYear(t) ? C.parseKey(t).m : (t > `${C.YEAR}-12-31` ? 11 : 0); };
  const ui = {
    tab: 'home', homeMonth: defaultMonth(), calMonth: defaultMonth(),
    stats: { mode: 'month', month: defaultMonth(), from: `${C.YEAR}-01-01`, to: `${C.YEAR}-12-31` },
  };
  const prevHero = {};

  // ---------- Тема ----------
  const mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  function applyTheme() {
    const t = state.settings.theme === 'system' ? (mq && mq.matches ? 'dark' : 'light') : state.settings.theme;
    document.documentElement.dataset.theme = t;
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = t === 'dark' ? '#121212' : '#f4f3ef';
  }
  if (mq) (mq.addEventListener ? mq.addEventListener('change', applyTheme) : mq.addListener(applyTheme));

  // ---------- Иконки ----------
  const ICONS = {
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
    stats: '<path d="M4 20V11M10 20V4M16 20v-7M22 20H2"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;

  // ---------- Модальные окна + кнопка «Назад» Android ----------
  const modalStack = [];
  function openModal(el, backdrop) {
    modalStack.push({ el, backdrop });
    backdrop.classList.add('show'); el.classList.add('show');
    try { history.pushState({ modal: modalStack.length }, ''); } catch {}
  }
  function hideTop() {
    const m = modalStack.pop();
    if (!m) return;
    m.el.classList.remove('show'); m.backdrop.classList.remove('show');
    if (m.onClose) m.onClose();
    if (document.activeElement && m.el.contains(document.activeElement)) document.activeElement.blur();
  }
  function closeModal() {
    if (!modalStack.length) return;
    if (history.state && history.state.modal) history.back(); else hideTop();
  }
  window.addEventListener('popstate', () => { if (modalStack.length) hideTop(); });

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }

  // Диалог с произвольными кнопками. buttons: [{text, cls, value}]
  function dialog({ title, text = '', buttons, html = '' }) {
    return new Promise((resolve) => {
      const d = $('#dialog');
      d.innerHTML = `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${html}` +
        buttons.map((b, i) => `<button class="btn ${b.cls || 'btn-secondary'}" data-i="${i}">${esc(b.text)}</button>`).join('');
      let result = null;
      d.onclick = (e) => {
        const b = e.target.closest('button[data-i]');
        if (!b) return;
        const btn = buttons[+b.dataset.i];
        result = btn.value;
        if (btn.read) result = btn.read(d);
        closeModal();
      };
      openModal(d, $('#dlg-backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(result);
    });
  }
  const confirmDlg = (title, text, okText = 'Да', danger = false) =>
    dialog({ title, text, buttons: [{ text: okText, cls: danger ? 'btn-danger' : 'btn-primary', value: true }, { text: 'Отмена', value: false }] });

  // ---------- Переключатель месяца ----------
  const monthSwitch = (m, id) => `
    <div class="month-switch">
      <button class="arrow" data-act="${id}-prev" ${m === 0 ? 'disabled' : ''} aria-label="Предыдущий месяц">‹</button>
      <button class="title" data-act="${id}-pick">${C.MONTHS[m]} ${C.YEAR}</button>
      <button class="arrow" data-act="${id}-next" ${m === 11 ? 'disabled' : ''} aria-label="Следующий месяц">›</button>
    </div>`;

  function pickMonth(current) {
    return new Promise((resolve) => {
      const months = C.yearByMonths(state);
      const sh = $('#sheet');
      sh.innerHTML = `<div class="grabber"></div>
        <div class="sheet-head"><div class="grow"><div class="sheet-title">Выберите месяц</div><div class="sheet-sub">${C.YEAR} год</div></div><button class="icon-btn" data-close>×</button></div>
        <div class="month-picker">${C.MONTHS.map((n, i) => `<button data-m="${i}" class="${i === current ? 'current' : ''}"><b>${n}</b><small>${months[i].shifts ? M(months[i].total) : '—'}</small></button>`).join('')}</div>`;
      let chosen = null;
      sh.onclick = (e) => {
        if (e.target.closest('[data-close]')) return closeModal();
        const b = e.target.closest('[data-m]');
        if (b) { chosen = +b.dataset.m; closeModal(); }
      };
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(chosen);
    });
  }

  // ---------- Анимация чисел ----------
  function countUp(el, to, fmt) {
    const id = el.id, from = prevHero[id] ?? 0;
    prevHero[id] = to;
    if (from === to || matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 500;
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(p < 1 ? Math.round(from + (to - from) * e) : to);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---------- Главная ----------
  function renderHome() {
    const m = ui.homeMonth, today = todayKey();
    const s = C.monthSummary(state, m, today);
    const tgt = s.target;
    const best = s.best ? `${C.fmtDateShort(s.best.key)}` : '—';
    const recent = s.days.slice().reverse().slice(0, 5);
    const canToday = C.inYear(today);
    const projHint = s.projected === null ? 'внесите первую смену'
      : s.projectionBasis === 'year' ? 'по средней за год'
      : s.remainingShifts ? `ещё ~${s.remainingShifts} ${plural(s.remainingShifts, 'смена', 'смены', 'смен')}` : 'месяц завершён';

    $('#view-home').innerHTML = `
      ${monthSwitch(m, 'home')}
      <div class="hero">
        <div class="label">Заработок за ${C.MONTHS[m].toLowerCase()}</div>
        <div class="big num" id="hero-total">${M(s.total)}</div>
        <div class="sub num">Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт указан в ${s.actualCount} ${plural(s.actualCount, 'смене', 'сменах', 'сменах')}` : ''}</div>
        ${tgt ? `<div class="progress"><i style="width:${Math.min(100, s.targetProgress * 100).toFixed(1)}%"></i></div>
          <div class="progress-label num"><span>${Math.round(s.targetProgress * 100)}% от цели ${M(tgt)}</span><span>${s.total >= tgt ? 'Цель достигнута 🎉' : s.needPerShift ? `нужно ≈${M(s.needPerShift)}/смену` : `осталось ${M(tgt - s.total)}`}</span></div>` : ''}
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Отработано смен</div><div class="t-value num">${s.shifts}</div><div class="t-sub">из ${s.plannedTotal} ${state.settings.plannedShifts ? 'по плану' : 'рабочих дней'}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div><div class="t-sub">в среднем</div></div>
        <div class="tile"><div class="t-label">Заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div><div class="t-sub">в среднем</div></div>
        <button class="tile clickable" data-act="open-day" data-key="${s.best ? s.best.key : ''}" ${s.best ? '' : 'disabled'} style="text-align:left">
          <div class="t-label">Самый продуктивный день</div><div class="t-value num">${best}</div>
          <div class="t-sub num">${s.best ? `${N(s.best.lines)} линий · ${M(s.best.total)}` : 'нет данных'}</div></button>
        <div class="tile"><div class="t-label">Прогноз на месяц</div><div class="t-value num">${s.projected === null ? '—' : M(s.projected)}</div><div class="t-sub">${projHint}</div></div>
      </div>
      <button class="btn btn-primary" data-act="${canToday ? 'open-today' : 'go-cal'}">＋ ${canToday ? 'Записать сегодняшнюю смену' : 'Записать смену'}</button>
      ${recent.length ? `<div class="card" style="margin-top:14px"><h2>Смены за месяц <small>${s.shifts}</small></h2>
        ${recent.map(rowHtml).join('')}
        ${s.shifts > 5 ? `<button class="btn btn-secondary" data-act="go-cal" style="margin-top:6px">Все смены в календаре</button>` : ''}</div>`
      : `<p class="hint" style="text-align:center;margin-top:18px">${canToday ? '' : `Календарь рассчитан на ${C.YEAR} год. `}Нажмите на любой день в календаре, чтобы внести смену.</p>`}`;
    countUp($('#hero-total'), Math.round(s.total), (v) => (v === Math.round(s.total) ? M(s.total) : M(v)));
  }
  function rowHtml(d) {
    const e = state.entries[d.key], p = C.parseKey(d.key);
    return `<button class="list-row" data-act="open-day" data-key="${d.key}">
      <div class="date-badge num">${p.d}<small>${C.WEEKDAYS[C.weekdayMon(d.key)]}</small></div>
      <div class="grow"><div>${N(e.lines)} линий${e.hours ? ` · ${N(e.hours, 2)} ч` : ''}</div><div>${e.actual !== null ? `факт · расчёт ${M(C.estimated(e))}` : `${N(e.lines)} × ${M(e.rate)}`}${e.comment ? ' · ' + esc(e.comment) : ''}</div></div>
      <div class="amount num">${M(C.total(e))}</div></button>`;
  }
  const plural = (n, a, b, c) => { n = Math.abs(n) % 100; const n1 = n % 10; return n > 10 && n < 20 ? c : n1 > 1 && n1 < 5 ? b : n1 === 1 ? a : c; };

  // ---------- Календарь ----------
  function renderCal(anim) {
    const m = ui.calMonth, today = todayKey();
    const s = C.summarize(state.entries, C.monthKeys(m));
    $('#view-cal').innerHTML = `
      ${monthSwitch(m, 'cal')}
      <div class="cal" id="cal-swipe">
        <div class="cal-head">${C.WEEKDAYS.map((w) => `<div>${w}</div>`).join('')}</div>
        <div class="cal-grid ${anim ? 'anim-' + anim : ''}">
          ${C.calendarGrid(m).flat().map((k) => {
            if (!k) return '<div class="day empty"></div>';
            const info = C.dayInfo(k), e = state.entries[k];
            const cls = ['day', info.off ? 'off' : '', k === today ? 'today' : '', e ? 'has' : '', e && e.actual !== null ? 'actual' : ''].join(' ');
            return `<button class="${cls}" data-act="open-day" data-key="${k}" aria-label="${C.fmtDateLong(k)}${info.holiday ? ', ' + info.label : ''}">
              <span class="num">${C.parseKey(k).d}</span>
              ${e ? `<span class="d-lines num">${e.lines ? N(e.lines) : '₽'}</span><span class="d-money num">${C.fmtMoneyShort(C.total(e))}</span>` : ''}
            </button>`;
          }).join('')}
        </div>
        <div class="legend">
          <span><i style="background:var(--accent-soft);border:1px solid var(--accent)"></i>Смена внесена</span>
          <span><i style="background:var(--weekend)"></i>Выходной / праздник</span>
          <span><i style="background:var(--good);border-radius:50%;width:8px;height:8px"></i>Указан факт</span>
        </div>
      </div>
      <div class="cal-summary">
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Итого</div><div class="t-value num">${C.fmtMoneyShort(s.total)} ₽</div></div>
      </div>
      <p class="hint" style="text-align:center">Рабочих дней в месяце по производственному календарю: ${C.workdaysInMonth(m)}. Листайте календарь свайпом.</p>`;
    bindSwipe();
  }
  function bindSwipe() {
    const el = $('#cal-swipe');
    let x0 = null, y0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dy) < 50) shiftCal(dx < 0 ? 1 : -1);
    }, { passive: true });
  }
  function shiftCal(d) {
    const m = ui.calMonth + d;
    if (m < 0 || m > 11) return;
    ui.calMonth = m; renderCal(d > 0 ? 'left' : 'right');
  }

  // ---------- Форма дня ----------
  function openDay(k) {
    if (!C.isValidKey(k) || !C.inYear(k)) return;
    const sh = $('#sheet');
    const already = modalStack.length && modalStack[modalStack.length - 1].el === sh;
    fillDaySheet(k);
    if (!already) {
      openModal(sh, $('#backdrop'));
      if (!state.entries[k]) setTimeout(() => { const i = $('#f-lines'); if (i) i.focus(); }, 320);
    }
  }
  function fillDaySheet(k) {
    const sh = $('#sheet');
    const e = state.entries[k];
    const info = C.dayInfo(k);
    const curRate = C.rateFor(state.settings.rateHistory, k);
    const rate = e ? e.rate : curRate;
    const v = (x) => (x === null || x === undefined ? '' : String(x).replace('.', ','));
    const prevK = C.addDays(k, -1), nextK = C.addDays(k, 1);
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head">
        <button class="icon-btn" data-day="${prevK}" ${C.inYear(prevK) ? '' : 'disabled style="opacity:.3"'} aria-label="Предыдущий день">‹</button>
        <div class="grow"><div class="sheet-title">${C.fmtDateLong(k).replace(' ' + C.YEAR, '')}</div>
          <div class="sheet-sub ${info.holiday ? 'holiday' : ''}">${C.WEEKDAYS_FULL[C.weekdayMon(k)]} · ${esc(info.label)}</div></div>
        <button class="icon-btn" data-day="${nextK}" ${C.inYear(nextK) ? '' : 'disabled style="opacity:.3"'} aria-label="Следующий день">›</button>
      </div>
      <form id="day-form" autocomplete="off" novalidate>
        <div class="field"><label for="f-lines">Количество собранных линий</label>
          <input class="input big num" id="f-lines" inputmode="numeric" pattern="[0-9]*" placeholder="0" value="${e ? v(e.lines || '') : ''}">
          <div class="quick">${[10, 50, 100].map((n) => `<button type="button" data-add="${n}">+${n}</button>`).join('')}<button type="button" data-add="0">Сброс</button></div>
        </div>
        <div class="calc"><div><div class="formula num" id="f-formula"></div><div class="formula">расчётный заработок</div></div><div class="res num" id="f-est"></div></div>
        ${e && e.rate !== curRate ? `<label class="check"><input type="checkbox" id="f-rerate"><span>Запись сохранена по тарифу <b>${M(e.rate)}</b>. Пересчитать по тарифу на эту дату — <b>${M(curRate)}</b>?</span></label>` : ''}
        <div class="field"><label for="f-actual">Фактически заработано, ₽ <span>необязательно</span></label>
          <input class="input num" id="f-actual" inputmode="decimal" placeholder="Например, по расчётному листу" value="${e ? v(e.actual) : ''}"></div>
        <div class="note" id="f-diff"></div>
        <div class="field"><label for="f-hours">Отработано часов <span>необязательно</span></label>
          <input class="input num" id="f-hours" inputmode="decimal" placeholder="Например, 11" value="${e ? v(e.hours) : ''}"></div>
        <div class="note" id="f-perhour"></div>
        <div class="field"><label for="f-comment">Комментарий <span>необязательно</span></label>
          <textarea class="input" id="f-comment" maxlength="500" placeholder="Ночная смена, переработка…">${e ? esc(e.comment) : ''}</textarea></div>
        <p class="error" id="f-error"></p>
        <button class="btn btn-primary" type="submit">${e ? 'Сохранить изменения' : 'Сохранить смену'}</button>
        ${e ? '<button class="btn btn-danger" type="button" data-del>Удалить запись</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const f = $('#day-form');
    const rateNow = () => ($('#f-rerate') && $('#f-rerate').checked ? curRate : rate);
    const parse = (s) => { const n = Number(String(s).replace(',', '.').replace(/\s/g, '')); return s.trim() === '' || !Number.isFinite(n) ? null : n; };
    const update = () => {
      const lines = parse($('#f-lines').value), actual = parse($('#f-actual').value), hours = parse($('#f-hours').value);
      const r = rateNow(), est = C.round2((lines || 0) * r);
      $('#f-formula').textContent = `${N(lines || 0)} × ${M(r)}`;
      $('#f-est').textContent = M(est);
      const diff = $('#f-diff');
      if (actual !== null && lines) {
        const d = C.round2(actual - est);
        diff.className = 'note ' + (d >= 0 ? 'good' : 'bad');
        diff.textContent = d === 0 ? 'Факт совпадает с расчётом' : `Факт ${d > 0 ? 'больше' : 'меньше'} расчёта на ${M(Math.abs(d))}. В итог пойдёт фактическая сумма.`;
      } else { diff.className = 'note'; diff.textContent = actual !== null ? 'В итог пойдёт фактическая сумма.' : ''; }
      const total = actual !== null ? actual : est;
      $('#f-perhour').textContent = hours ? `≈ ${N((lines || 0) / hours, 1)} линий/час · ${M(C.round2(total / hours))}/час` : '';
    };
    f.addEventListener('input', update);
    f.addEventListener('change', update);
    update();
    sh.onclick = async (ev) => {
      const t = ev.target;
      if (t.closest('[data-close]')) return closeModal();
      const dayBtn = t.closest('[data-day]');
      if (dayBtn && !dayBtn.disabled) return fillDaySheet(dayBtn.dataset.day);
      const add = t.closest('[data-add]');
      if (add) {
        const inp = $('#f-lines'), n = +add.dataset.add;
        inp.value = n ? String((parseInt(inp.value, 10) || 0) + n) : '';
        update(); return;
      }
      if (t.closest('[data-del]')) {
        if (await confirmDlg('Удалить запись?', `Смена за ${C.fmtDateLong(k)} будет удалена.`, 'Удалить', true)) {
          C.deleteEntry(state, k); save(); closeModal(); renderAll(); toast('Запись удалена');
        }
      }
    };
    f.onsubmit = (ev) => {
      ev.preventDefault();
      const res = C.saveEntry(state, k, { lines: $('#f-lines').value, actual: $('#f-actual').value, hours: $('#f-hours').value, comment: $('#f-comment').value },
        { useCurrentRate: !!($('#f-rerate') && $('#f-rerate').checked) });
      if (!res.ok) { $('#f-error').textContent = res.error; return; }
      if (save()) { closeModal(); renderAll(); toast(`Сохранено: ${M(C.total(res.entry))}`); }
    };
  }

  // ---------- Графики (SVG без библиотек) ----------
  const W = 340, H = 170, PL = 34, PR = 6, PT = 10, PB = 22;
  function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
  function axes(max, fmtAxis) {
    let s = '';
    for (let i = 0; i <= 3; i++) {
      const y = PT + (H - PT - PB) * (1 - i / 3);
      s += `<line class="gridline" x1="${PL}" x2="${W - PR}" y1="${y}" y2="${y}"/><text x="${PL - 5}" y="${y + 3}" text-anchor="end">${fmtAxis((max * i) / 3)}</text>`;
    }
    return s;
  }
  function xLabels(labels, xs) {
    const step = Math.ceil(labels.filter(Boolean).length / 8);
    let c = 0;
    return labels.map((l, i) => (l && c++ % step === 0 ? `<text x="${xs(i)}" y="${H - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  }
  // Возвращает HTML карточки графика. items: [{label, tip, value}]
  let chartSeq = 0;
  function chartCard({ title, items, kind = 'bar', fmt = M, fmtAxis = C.fmtMoneyShort, avg = null, alt = false, summary }) {
    const id = 'ch' + ++chartSeq;
    const has = items.some((it) => it.value > 0);
    if (!has) return `<div class="card chart-card"><h2>${esc(title)}</h2><div class="empty-chart">Нет данных за выбранный период</div></div>`;
    const max = niceMax(Math.max(...items.map((i) => i.value), avg || 0));
    const iw = (W - PL - PR) / items.length;
    const xs = (i) => PL + iw * i + iw / 2;
    const ys = (v) => PT + (H - PT - PB) * (1 - v / max);
    let body = '';
    if (kind === 'bar') {
      const bw = Math.max(1.5, Math.min(26, iw * 0.68));
      body = items.map((it, i) => it.value > 0
        ? `<rect class="bar ${alt ? 'alt' : ''}" data-i="${i}" x="${xs(i) - bw / 2}" y="${ys(it.value)}" width="${bw}" height="${Math.max(0, H - PB - ys(it.value))}" rx="${Math.min(4, bw / 3)}" style="animation-delay:${Math.min(i * 12, 400)}ms"/>` : '').join('');
    } else {
      const pts = items.map((it, i) => [xs(i), ys(it.value)]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
      body = `<path class="area" d="${d}L${pts[pts.length - 1][0].toFixed(1)} ${H - PB}L${pts[0][0].toFixed(1)} ${H - PB}Z"/><path class="line" d="${d}"/>` +
        (items.length <= 40 ? items.map((it, i) => (it.value > 0 ? `<circle class="dot" data-i="${i}" cx="${xs(i)}" cy="${ys(it.value)}" r="3"/>` : '')).join('') : '');
    }
    const hits = items.map((_, i) => `<rect class="hit" data-i="${i}" x="${PL + iw * i}" y="${PT}" width="${iw}" height="${H - PT}"/>`).join('');
    const avgLine = avg ? `<line class="avg" x1="${PL}" x2="${W - PR}" y1="${ys(avg)}" y2="${ys(avg)}"/>` : '';
    chartData[id] = { items, fmt, summary };
    return `<div class="card chart-card"><h2>${esc(title)}</h2>
      <div class="readout" id="${id}-ro">${summary}</div>
      <svg class="chart" id="${id}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px">
        ${axes(max, fmtAxis)}${body}${avgLine}${xLabels(items.map((i) => i.label), xs)}${hits}</svg></div>`;
  }
  const chartData = {};
  document.addEventListener('click', (e) => {
    const hit = e.target.closest('svg.chart [data-i]');
    if (!hit) return;
    const svg = hit.closest('svg'), cd = chartData[svg.id], i = +hit.dataset.i, it = cd.items[i];
    svg.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel'));
    svg.querySelectorAll(`.bar[data-i="${i}"], .dot[data-i="${i}"]`).forEach((x) => x.classList.add('sel'));
    $('#' + svg.id + '-ro').innerHTML = `<b class="num">${cd.fmt(it.value)}</b><span>${esc(it.tip || it.label)}</span>`;
  });

  // ---------- Статистика ----------
  function periodKeys() {
    const st = ui.stats;
    if (st.mode === 'month') return C.monthKeys(st.month);
    if (st.mode === 'year') return C.yearKeys();
    return C.rangeKeys(st.from, st.to).filter(C.inYear);
  }
  function periodTitle() {
    const st = ui.stats;
    if (st.mode === 'month') return `${C.MONTHS[st.month]} ${C.YEAR}`;
    if (st.mode === 'year') return `${C.YEAR} год`;
    return `${C.fmtDateShort(st.from <= st.to ? st.from : st.to)} — ${C.fmtDateShort(st.from <= st.to ? st.to : st.from)}`;
  }
  function renderStats() {
    chartSeq = 0;
    const st = ui.stats, keys = periodKeys();
    const s = C.summarize(state.entries, keys);
    const wk = C.weekly(state.entries, keys);
    const months = C.yearByMonths(state);
    const yearTotal = C.round2(months.reduce((a, x) => a + x.total, 0));
    const yearLines = months.reduce((a, x) => a + x.lines, 0);
    const yearShifts = months.reduce((a, x) => a + x.shifts, 0);
    const daily = keys.length <= 62;
    const dayItems = keys.map((k) => { const e = state.entries[k]; return { label: daily ? String(C.parseKey(k).d) : C.MONTHS_SHORT[C.parseKey(k).m], tip: `${C.fmtDateLong(k)}, ${C.WEEKDAYS_FULL[C.weekdayMon(k)].toLowerCase()}`, value: e ? C.total(e) : 0, lines: e ? e.lines : 0 }; });
    if (!daily) dayItems.forEach((it, i) => { if (C.parseKey(keys[i]).d !== 1) it.label = ''; });
    const opt = (v, cur, t) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${t}</option>`;
    const maxMonth = months.reduce((b, x, i) => (x.total > (months[b] || { total: -1 }).total ? i : b), 0);

    $('#view-stats').innerHTML = `
      <div class="seg" role="tablist">
        ${[['month', 'Месяц'], ['year', 'Весь год'], ['range', 'Период']].map(([v, t]) => `<button data-mode="${v}" class="${st.mode === v ? 'active' : ''}">${t}</button>`).join('')}
      </div>
      ${st.mode === 'month' ? `<div class="field"><select class="input" id="st-month">${C.MONTHS.map((n, i) => opt(i, st.month, `${n} ${C.YEAR}`)).join('')}</select></div>` : ''}
      ${st.mode === 'range' ? `<div class="period-inputs">
          <div><label for="st-from">С</label><input class="input" type="date" id="st-from" min="${C.YEAR}-01-01" max="${C.YEAR}-12-31" value="${st.from}"></div>
          <div><label for="st-to">По</label><input class="input" type="date" id="st-to" min="${C.YEAR}-01-01" max="${C.YEAR}-12-31" value="${st.to}"></div></div>` : ''}

      <div class="card"><h2>${esc(periodTitle())}</h2>
        <div class="year-total num">${M(s.total)}</div>
        <p class="hint" style="margin-top:2px">Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт ${M(s.actual)} (${s.actualCount} ${plural(s.actualCount, 'смена', 'смены', 'смен')})` : ''}${s.diffCount ? ` · разница факт−расчёт ${s.diff >= 0 ? '+' : '−'}${M(Math.abs(s.diff))}` : ''}</p>
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за неделю</div><div class="t-value num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</div><div class="t-sub">${wk.workedWeeks ? `по ${wk.workedWeeks} ${plural(wk.workedWeeks, 'неделе', 'неделям', 'неделям')} со сменами` : ''}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div></div>
        <div class="tile"><div class="t-label">Лучший день</div><div class="t-value num">${s.best ? C.fmtDateShort(s.best.key) : '—'}</div><div class="t-sub num">${s.best ? `${N(s.best.lines)} линий` : ''}</div></div>
        ${s.hours ? `<div class="tile wide"><div class="t-label">Производительность (по сменам с указанными часами)</div><div class="t-value num">${N(s.linesPerHour, 1)} линий/ч · ${M(s.earnPerHour)}/ч</div><div class="t-sub num">${N(s.hours, 1)} ч всего</div></div>` : ''}
      </div>

      ${chartCard({ title: 'Ежедневный заработок', items: dayItems, kind: daily ? 'bar' : 'line', avg: s.shifts ? s.avgPerShift : null,
        summary: `<b class="num">${M(s.total)}</b><span>${daily ? 'пунктир — среднее за смену · нажмите на столбец' : 'нажмите на график'}</span>` })}
      ${chartCard({ title: 'Собранные линии по дням', items: dayItems.map((d) => ({ ...d, value: d.lines })), kind: 'line', fmt: (v) => N(v) + ' линий', fmtAxis: (v) => N(v),
        summary: `<b class="num">${N(s.lines)}</b><span>линий за период</span>` })}
      ${wk.weeks.length > 1 ? chartCard({ title: 'Заработок по неделям', items: wk.weeks.map((w) => ({ label: C.fmtDateShort(w.monday).split(' ')[0], tip: `Неделя ${C.fmtDateShort(w.monday)} — ${C.fmtDateShort(w.sunday)}, ${w.shifts} ${plural(w.shifts, 'смена', 'смены', 'смен')}`, value: w.total })),
        avg: wk.avgWeekly || null, alt: true, summary: `<b class="num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</b><span>в среднем за неделю</span>` }) : ''}

      <h2 style="margin:22px 4px 10px;font-size:20px">${C.YEAR} год целиком</h2>
      <div class="card"><div class="muted" style="font-size:14px">Общая сумма заработка за ${C.YEAR} год</div>
        <div class="year-total num">${M(yearTotal)}</div>
        <p class="hint" style="margin-top:2px">${N(yearLines)} линий · ${yearShifts} ${plural(yearShifts, 'смена', 'смены', 'смен')}${yearShifts ? ` · ${M(C.round2(yearTotal / yearShifts))} за смену` : ''}</p></div>
      ${chartCard({ title: 'Заработок по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.total })),
        summary: yearShifts ? `<b class="num">${M(months[maxMonth].total)}</b><span>лучший месяц — ${C.MONTHS[maxMonth].toLowerCase()}</span>` : '' })}
      ${chartCard({ title: 'Линии по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.lines })), alt: true, fmt: (v) => N(v) + ' линий', fmtAxis: (v) => C.fmtMoneyShort(v),
        summary: `<b class="num">${N(yearLines)}</b><span>линий за год</span>` })}
      <div class="card"><h2>Сравнение месяцев</h2>
        <table class="table num"><thead><tr><th>Месяц</th><th>Смен</th><th>Линий</th><th>Заработок</th><th>к пред.</th></tr></thead><tbody>
        ${months.map((x, i) => `<tr class="${x.shifts ? '' : 'zero'}"><td>${C.MONTHS[i]}</td><td>${x.shifts || '—'}</td><td>${x.lines ? N(x.lines) : '—'}</td><td>${x.shifts ? M(x.total) : '—'}</td>
          <td class="${x.change > 0 ? 'up' : x.change < 0 ? 'down' : ''}">${x.change === null || !x.shifts ? '—' : (x.change > 0 ? '+' : '') + N(x.change * 100, 0) + '%'}</td></tr>`).join('')}
        </tbody><tfoot><tr><td>Итого</td><td>${yearShifts}</td><td>${N(yearLines)}</td><td>${M(yearTotal)}</td><td></td></tr></tfoot></table></div>`;

    $('#view-stats .seg').onclick = (e) => { const b = e.target.closest('[data-mode]'); if (b) { st.mode = b.dataset.mode; renderStats(); } };
    const sm = $('#st-month'); if (sm) sm.onchange = () => { st.month = +sm.value; renderStats(); };
    const f = $('#st-from'), t = $('#st-to');
    if (f) {
      const upd = () => { if (C.isValidKey(f.value) && C.isValidKey(t.value)) { st.from = f.value; st.to = t.value; renderStats(); } };
      f.onchange = upd; t.onchange = upd;
    }
  }

  // ---------- Настройки ----------
  function renderSettings() {
    const set = state.settings, today = todayKey();
    const refKey = C.inYear(today) ? today : `${C.YEAR}-01-01`;
    const count = Object.keys(state.entries).length;
    const hist = [...set.rateHistory].sort((a, b) => (a.from < b.from ? 1 : -1));
    $('#view-settings').innerHTML = `
      <div class="card"><h2>Стоимость одной линии</h2>
        <div class="rate-now"><b class="num">${M(C.rateFor(set.rateHistory, refKey))}</b><span class="muted">${C.inYear(today) ? 'действует сегодня' : `на ${C.fmtDateLong(refKey)}`}</span></div>
        <div class="inline-form">
          <div><label for="s-rate">Новая стоимость, ₽</label><input class="input num" id="s-rate" inputmode="decimal" placeholder="5"></div>
          <div><label for="s-from">Действует с</label><input class="input" type="date" id="s-from" min="${C.YEAR}-01-01" max="${C.YEAR}-12-31" value="${refKey}"></div>
        </div>
        <button class="btn btn-primary" data-act="set-rate">Применить тариф</button>
        <p class="hint">Новые записи с этой даты считаются по новой стоимости. Уже сохранённые смены не пересчитываются — у каждой хранится свой тариф.</p>
        <div style="margin-top:12px">${hist.map((h) => `<div class="hist-row num"><span>с ${C.fmtDateLong(h.from)} — <b>${M(h.rate)}</b></span>${hist.length > 1 ? `<button data-act="del-rate" data-from="${h.from}">Удалить</button>` : ''}</div>`).join('')}</div>
      </div>
      <div class="card"><h2>Цели на месяц</h2>
        <div class="field"><label for="s-target">Целевая зарплата за месяц, ₽ <span>0 — без цели</span></label><input class="input num" id="s-target" inputmode="decimal" value="${set.target || ''}" placeholder="Например, 60000"></div>
        <div class="field"><label for="s-planned">Планируемое количество смен в месяц <span>0 — по календарю</span></label><input class="input num" id="s-planned" inputmode="numeric" value="${set.plannedShifts || ''}" placeholder="Например, 15"></div>
        <button class="btn btn-primary" data-act="save-goals">Сохранить цели</button>
        <p class="hint">Прогноз = уже заработано + средний заработок за смену × оставшиеся смены. Без плана оставшиеся смены считаются по рабочим дням производственного календаря.</p>
      </div>
      <div class="card"><h2>Оформление</h2>
        <div class="seg" id="s-theme">${[['system', 'Как в системе'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, t]) => `<button data-theme="${v}" class="${set.theme === v ? 'active' : ''}">${t}</button>`).join('')}</div>
      </div>
      <div class="card"><h2>Резервная копия <small>${count} ${plural(count, 'запись', 'записи', 'записей')}</small></h2>
        <button class="btn btn-primary" data-act="export">Сохранить копию в файл</button>
        <button class="btn btn-secondary" data-act="import">Восстановить из файла</button>
        <div class="btn-row" style="margin-top:10px"><button class="btn btn-secondary" data-act="export-text">Копировать текстом</button><button class="btn btn-secondary" data-act="import-text">Вставить текст</button></div>
        <button class="btn btn-secondary" data-act="csv">Таблица для Excel (CSV)</button>
        <p class="hint">${meta.lastBackup ? `Последняя копия: ${new Date(meta.lastBackup).toLocaleString('ru-RU')}.` : 'Копия ещё не создавалась.'} Данные хранятся только на этом телефоне — сохраняйте копию раз в неделю (например, в Telegram «Избранное» или на Google Диск).</p>
        <input type="file" id="s-file" accept=".json,application/json,text/plain" hidden>
      </div>
      <div class="card"><h2>Данные</h2><button class="btn btn-danger" data-act="wipe">Удалить все записи</button></div>
      <div class="about">Калькулятор зарплаты комплектовщика · версия 1.0<br>Производственный календарь РФ на ${C.YEAR} год (пост. Правительства № 1187)<br>Работает без интернета · данные хранятся на устройстве</div>`;
  }

  async function settingsAction(act, el) {
    const set = state.settings;
    if (act === 'set-rate') {
      const r = Number(String($('#s-rate').value).replace(',', '.'));
      const from = $('#s-from').value;
      try {
        if (!C.inYear(from)) throw new Error(`Укажите дату в ${C.YEAR} году`);
        C.setRate(state, from, r); save(); renderAll(); toast(`Тариф ${M(r)} с ${C.fmtDateLong(from)}`);
      } catch (e) { toast(e.message || 'Введите стоимость больше нуля'); }
    } else if (act === 'del-rate') {
      if (await confirmDlg('Удалить тариф?', 'Сохранённые смены не изменятся.', 'Удалить', true)) {
        try { C.removeRate(state, el.dataset.from); save(); renderAll(); } catch (e) { toast(e.message); }
      }
    } else if (act === 'save-goals') {
      const t = Number(String($('#s-target').value || 0).replace(',', '.').replace(/\s/g, ''));
      const p = Number($('#s-planned').value || 0);
      if (!(t >= 0) || !(p >= 0) || !Number.isInteger(p) || p > 31) return toast('Проверьте значения: смен от 0 до 31');
      set.target = C.round2(t); set.plannedShifts = p; save(); renderAll(); toast('Цели сохранены');
    } else if (act === 'export') {
      await saveFile(`zarplata-${C.YEAR}-backup-${todayKey()}.json`, C.exportData(state), 'application/json');
      meta.lastBackup = Date.now(); saveMeta(); renderSettings();
    } else if (act === 'csv') {
      await saveFile(`zarplata-${C.YEAR}-${todayKey()}.csv`, C.toCSV(state), 'text/csv');
    } else if (act === 'import') {
      const inp = $('#s-file'); inp.value = '';
      inp.onchange = () => { const file = inp.files[0]; if (!file) return; const rd = new FileReader(); rd.onload = () => importText(String(rd.result)); rd.readAsText(file); };
      inp.click();
    } else if (act === 'export-text') {
      const txt = C.exportData(state);
      let copied = false;
      try { await navigator.clipboard.writeText(txt); copied = true; } catch {}
      if (copied) { meta.lastBackup = Date.now(); saveMeta(); renderSettings(); toast('Копия скопирована — вставьте её в заметки или мессенджер'); }
      else dialog({ title: 'Резервная копия', text: 'Выделите весь текст и скопируйте:', html: `<textarea class="input" readonly>${esc(txt)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    } else if (act === 'import-text') {
      const txt = await dialog({ title: 'Вставьте резервную копию', html: '<textarea class="input" id="imp-text" placeholder="{ ... }"></textarea>',
        buttons: [{ text: 'Восстановить', cls: 'btn-primary', read: (d) => $('#imp-text', d).value }, { text: 'Отмена', value: null }] });
      if (txt) importText(txt);
    } else if (act === 'wipe') {
      if (await confirmDlg('Удалить все записи?', 'Все смены будут удалены без возможности восстановления. Сначала сохраните резервную копию.', 'Удалить всё', true)
        && await confirmDlg('Точно удалить?', `${Object.keys(state.entries).length} записей будет удалено.`, 'Да, удалить', true)) {
        state.entries = {}; save(); renderAll(); toast('Все записи удалены');
      }
    }
  }
  async function importText(txt) {
    let parsed;
    try { parsed = C.normalizeState(JSON.parse(txt)); } catch (e) { return toast('Не удалось прочитать копию: ' + (e.message || 'неверный формат')); }
    const n = Object.keys(parsed.state.entries).length;
    const choice = await dialog({ title: 'Восстановление', text: `В копии ${n} ${plural(n, 'запись', 'записи', 'записей')}${parsed.skipped ? `, пропущено повреждённых: ${parsed.skipped}` : ''}.\nЗаменить текущие данные или объединить?`,
      buttons: [{ text: 'Заменить всё', cls: 'btn-primary', value: 'replace' }, { text: 'Объединить', value: 'merge' }, { text: 'Отмена', value: null }] });
    if (!choice) return;
    state = choice === 'replace' ? parsed.state : C.mergeStates(state, parsed.state);
    save(); applyTheme(); renderAll(); toast('Данные восстановлены');
  }
  async function saveFile(name, text, mime) {
    const cap = window.Capacitor;
    if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
      const P = cap.Plugins || {};
      if (P.Filesystem && P.Share) {
        try {
          const r = await P.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
          await P.Share.share({ title: name, files: [r.uri], url: r.uri, dialogTitle: 'Сохранить или отправить копию' });
          return;
        } catch (e) { if (String(e && e.message).match(/cancel/i)) return; console.warn(e); }
      }
      return dialog({ title: name, text: 'Скопируйте текст и сохраните его в надёжном месте:', html: `<textarea class="input" readonly>${esc(text)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    }
    const file = new File([text], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android/i.test(navigator.userAgent)) {
      try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Файл сохранён в «Загрузки»');
  }

  // ---------- Навигация ----------
  const TITLES = { home: 'Главная', cal: 'Календарь', stats: 'Статистика', settings: 'Настройки' };
  function setTab(tab) {
    ui.tab = tab;
    document.querySelectorAll('.tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + tab));
    $('#title').textContent = TITLES[tab];
    renderTab(tab);
    window.scrollTo({ top: 0 });
  }
  function renderTab(tab) { ({ home: renderHome, cal: renderCal, stats: renderStats, settings: renderSettings })[tab](); }
  function renderAll() { renderTab(ui.tab); }

  document.addEventListener('click', async (e) => {
    const tabBtn = e.target.closest('.tabbar button');
    if (tabBtn) return setTab(tabBtn.dataset.tab);
    const el = e.target.closest('[data-act]');
    if (!el || el.closest('#sheet') || el.disabled) return;
    const act = el.dataset.act;
    if (act === 'open-day') return el.dataset.key && openDay(el.dataset.key);
    if (act === 'open-today') return openDay(todayKey());
    if (act === 'go-cal') { ui.calMonth = ui.homeMonth; return setTab('cal'); }
    if (act === 'home-prev' || act === 'home-next') { ui.homeMonth += act.endsWith('next') ? 1 : -1; ui.homeMonth = Math.max(0, Math.min(11, ui.homeMonth)); return renderHome(); }
    if (act === 'cal-prev' || act === 'cal-next') return shiftCal(act.endsWith('next') ? 1 : -1);
    if (act === 'home-pick' || act === 'cal-pick') {
      const cur = act === 'home-pick' ? ui.homeMonth : ui.calMonth;
      const m = await pickMonth(cur);
      if (m === null) return;
      if (act === 'home-pick') { ui.homeMonth = m; renderHome(); } else { ui.calMonth = m; renderCal(m > cur ? 'left' : 'right'); }
      return;
    }
    if (el.closest('#view-settings')) return settingsAction(act, el);
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-theme [data-theme]');
    if (!b) return;
    state.settings.theme = b.dataset.theme; save(); applyTheme(); renderSettings();
  });
  $('#backdrop').addEventListener('click', closeModal);
  $('#dlg-backdrop').addEventListener('click', closeModal);
  // Свайп вниз по шапке листа закрывает его
  (() => {
    const sh = $('#sheet'); let y0 = null;
    sh.addEventListener('touchstart', (e) => { y0 = sh.scrollTop <= 0 && e.target.closest('.grabber, .sheet-head') ? e.touches[0].clientY : null; }, { passive: true });
    sh.addEventListener('touchend', (e) => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 70) closeModal(); y0 = null; }, { passive: true });
  })();

  // ---------- Запуск ----------
  function init() {
    document.querySelectorAll('.tabbar button').forEach((b) => b.insertAdjacentHTML('afterbegin', icon(b.dataset.icon)));
    applyTheme();
    setTab('home');
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const cap = window.Capacitor;
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !(cap && cap.isNativePlatform && cap.isNativePlatform())) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
    // Обновляем «сегодня» при возврате в приложение (например, на следующий день)
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !modalStack.length) renderAll(); });
    window.__app = { get state() { return state; }, openDay, setTab, ui };
  }
  init();
})();
