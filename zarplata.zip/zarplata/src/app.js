/* Интерфейс приложения. Зависит от Core (core.js). */
(() => {
  'use strict';
  const C = Core;
  const STORE_KEY = 'zarplata2027:v1';
  const META_KEY = 'zarplata2027:meta';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const M = C.fmtMoney, N = C.fmtNum;

  // ---------- Хранилище ----------
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) return C.normalizeState(JSON.parse(raw)).state;
    } catch (e) { console.warn('Не удалось прочитать данные', e); }
    return C.defaultState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); return true; }
    catch (e) { toast('Ошибка сохранения: память устройства недоступна'); return false; }
  }
  const meta = (() => { try { return JSON.parse(localStorage.getItem(META_KEY)) || {}; } catch { return {}; } })();
  const saveMeta = () => { try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch {} };

  let state = load();
  const todayKey = () => C.keyOfDate(new Date());
  // Сквозной номер месяца (0 = январь 2026 … 35 = декабрь 2028). Основной год — 2027:
  // если сегодня 2027 год, открываем текущий месяц, иначе январь 2027.
  const defaultMonth = () => { const t = todayKey(); return C.inYear(t, C.YEAR) ? C.indexOf(C.YEAR, C.parseKey(t).m) : C.indexOf(C.YEAR, 0); };
  const monthName = (i) => { const { y, m } = C.ymOf(i); return `${C.MONTHS[m]} ${y}`; };
  const ui = {
    tab: 'home', homeMonth: defaultMonth(), calMonth: defaultMonth(),
    stats: { mode: 'month', month: defaultMonth(), year: C.YEAR, from: `${C.YEAR}-01-01`, to: `${C.YEAR}-12-31` },
  };
  const prevHero = {};

  // ---------- Тема ----------
  const mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  // Цвета: смешивание hex и яркость — чтобы гамма читалась и в светлой, и в тёмной теме
  const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const rgbHex = (a) => '#' + a.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  const mixHex = (a, b, t) => { const x = hexRgb(a), y = hexRgb(b); return rgbHex(x.map((v, i) => v + (y[i] - v) * t)); };
  const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  function applyTheme() {
    const t = state.settings.theme === 'system' ? (mq && mq.matches ? 'dark' : 'light') : state.settings.theme;
    document.documentElement.dataset.theme = t;
    const pal = state.settings.palette || C.PALETTES[0], dark = t === 'dark';
    const acc = dark ? mixHex(pal.accent, '#ffffff', 0.18) : pal.accent;
    const acc2 = dark ? mixHex(pal.accent2, '#ffffff', 0.22) : pal.accent2;
    const rs = document.documentElement.style;
    rs.setProperty('--accent', acc);
    rs.setProperty('--chart', acc);
    rs.setProperty('--chart-2', acc2);
    rs.setProperty('--accent-ink', lum(acc) > 0.45 ? '#1a1a1a' : '#ffffff');
    rs.setProperty('--accent-soft', dark ? mixHex(acc, '#1d1d1c', 0.74) : mixHex(acc, '#ffffff', 0.85));
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = t === 'dark' ? '#121212' : '#f4f3ef';
  }
  if (mq) (mq.addEventListener ? mq.addEventListener('change', applyTheme) : mq.addListener(applyTheme));

  // ---------- Иконки ----------
  const ICONS = {
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
    stats: '<path d="M4 20V11M10 20V4M16 20v-7M22 20H2"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;

  // ---------- Модальные окна + кнопка «Назад» Android ----------
  const modalStack = [];
  function openModal(el, backdrop) {
    modalStack.push({ el, backdrop });
    backdrop.classList.add('show'); el.classList.add('show');
    try { history.pushState({ modal: modalStack.length }, ''); } catch {}
  }
  function hideTop() {
    const m = modalStack.pop();
    if (!m) return;
    m.el.classList.remove('show'); m.backdrop.classList.remove('show');
    if (m.onClose) m.onClose();
    if (document.activeElement && m.el.contains(document.activeElement)) document.activeElement.blur();
  }
  function closeModal() {
    if (!modalStack.length) return;
    if (history.state && history.state.modal) history.back(); else hideTop();
  }
  window.addEventListener('popstate', () => { if (modalStack.length) hideTop(); });

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }

  // Диалог с произвольными кнопками. buttons: [{text, cls, value}]
  function dialog({ title, text = '', buttons, html = '' }) {
    return new Promise((resolve) => {
      const d = $('#dialog');
      d.innerHTML = `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${html}` +
        buttons.map((b, i) => `<button class="btn ${b.cls || 'btn-secondary'}" data-i="${i}">${esc(b.text)}</button>`).join('');
      let result = null;
      d.onclick = (e) => {
        const b = e.target.closest('button[data-i]');
        if (!b) return;
        const btn = buttons[+b.dataset.i];
        result = btn.value;
        if (btn.read) result = btn.read(d);
        closeModal();
      };
      openModal(d, $('#dlg-backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(result);
    });
  }
  const confirmDlg = (title, text, okText = 'Да', danger = false) =>
    dialog({ title, text, buttons: [{ text: okText, cls: danger ? 'btn-danger' : 'btn-primary', value: true }, { text: 'Отмена', value: false }] });

  // ---------- Переключатель месяца ----------
  const monthSwitch = (i, id) => `
    <div class="month-switch">
      <button class="arrow" data-act="${id}-prev" ${i === 0 ? 'disabled' : ''} aria-label="Предыдущий месяц">‹</button>
      <button class="title" data-act="${id}-pick">${monthName(i)}</button>
      <button class="arrow" data-act="${id}-next" ${i === C.MONTH_COUNT - 1 ? 'disabled' : ''} aria-label="Следующий месяц">›</button>
    </div>`;

  function pickMonth(current) {
    return new Promise((resolve) => {
      const sh = $('#sheet');
      let year = C.ymOf(current).y;
      const draw = () => {
        const months = C.yearByMonths(state, year);
        sh.innerHTML = `<div class="grabber"></div>
          <div class="sheet-head"><div class="grow"><div class="sheet-title">Выберите месяц</div></div><button class="icon-btn" data-close>×</button></div>
          <div class="seg">${C.YEARS.map((y) => `<button data-y="${y}" class="${y === year ? 'active' : ''}">${y}${y === C.YEAR ? ' ★' : ''}</button>`).join('')}</div>
          <div class="month-picker">${C.MONTHS.map((n, m) => { const i = C.indexOf(year, m); return `<button data-m="${i}" class="${i === current ? 'current' : ''}"><b>${n}</b><small>${months[m].shifts || months[m].grand ? M(months[m].grand) : '—'}</small></button>`; }).join('')}</div>`;
      };
      draw();
      let chosen = null;
      sh.onclick = (e) => {
        if (e.target.closest('[data-close]')) return closeModal();
        const yb = e.target.closest('[data-y]');
        if (yb) { year = +yb.dataset.y; return draw(); }
        const b = e.target.closest('[data-m]');
        if (b) { chosen = +b.dataset.m; closeModal(); }
      };
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(chosen);
    });
  }

  // ---------- Анимация чисел ----------
  function countUp(el, to, fmt) {
    const id = el.id, from = prevHero[id] ?? 0;
    prevHero[id] = to;
    if (from === to || matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 500;
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(p < 1 ? Math.round(from + (to - from) * e) : to);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---------- Главная ----------
  function renderHome() {
    const idx = ui.homeMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.monthSummary(state, m, today, y);
    const x = s.extras, b = x.cfg;
    const tgt = s.target;
    const best = s.best ? `${C.fmtDateShort(s.best.key)}` : '—';
    const recent = s.days.slice().reverse().slice(0, 5);
    const canToday = C.inYear(today);
    const projHint = s.projected === null ? 'внесите первую смену'
      : s.projectionBasis === 'year' ? 'по средней за год'
      : s.remainingShifts ? `ещё ~${s.remainingShifts} ${plural(s.remainingShifts, 'смена', 'смены', 'смен')}` : 'месяц завершён';

    $('#view-home').innerHTML = `
      ${monthSwitch(idx, 'home')}
      <div class="hero">
        <div class="label">Заработок за ${C.MONTHS[m].toLowerCase()}</div>
        <div class="big num" id="hero-total">${M(s.grand)}</div>
        <div class="sub num">${x.bonuses || x.penalty ? `Смены ${M(s.total)}${x.bonuses ? ` + премии ${M(x.bonuses)}` : ''}${x.penalty ? ` − штраф ${M(x.penalty)}` : ''}` : `Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт указан в ${s.actualCount} ${plural(s.actualCount, 'смене', 'сменах', 'сменах')}` : ''}`}</div>
        ${tgt ? `<div class="progress"><i style="width:${Math.min(100, s.targetProgress * 100).toFixed(1)}%"></i></div>
          <div class="progress-label num"><span>${Math.round(s.targetProgress * 100)}% от цели ${M(tgt)}</span><span>${s.grand >= tgt ? 'Цель достигнута 🎉' : s.needPerShift ? `нужно ≈${M(s.needPerShift)}/смену` : `осталось ${M(tgt - s.grand)}`}</span></div>` : ''}
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Отработано смен</div><div class="t-value num">${s.shifts}</div><div class="t-sub">из ${s.plannedTotal} ${state.settings.plannedShifts ? 'по плану' : 'рабочих дней'}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div><div class="t-sub">в среднем</div></div>
        <div class="tile"><div class="t-label">Заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div><div class="t-sub">в среднем</div></div>
        <button class="tile clickable" data-act="open-day" data-key="${s.best ? s.best.key : ''}" ${s.best ? '' : 'disabled'} style="text-align:left">
          <div class="t-label">Самый продуктивный день</div><div class="t-value num">${best}</div>
          <div class="t-sub num">${s.best ? `${N(s.best.lines)} линий · ${M(s.best.total)}` : 'нет данных'}</div></button>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${x.prodAvg === null ? '' : x.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</div><div class="t-sub">${x.prodAvg === null ? 'не указана' : `по ${x.prodDays} ${plural(x.prodDays, 'смене', 'сменам', 'сменам')}`}</div></div>
        <div class="tile"><div class="t-label">Прогноз на месяц</div><div class="t-value num">${s.projected === null ? '—' : M(s.projected)}</div><div class="t-sub">${projHint}</div></div>
      </div>
      ${bonusCard(s, idx)}
      <button class="btn btn-primary" data-act="${canToday ? 'open-today' : 'go-cal'}">＋ ${canToday ? 'Записать сегодняшнюю смену' : 'Записать смену'}</button>
      ${recent.length ? `<div class="card" style="margin-top:14px"><h2>Смены за месяц <small>${s.shifts}</small></h2>
        ${recent.map(rowHtml).join('')}
        ${s.shifts > 5 ? `<button class="btn btn-secondary" data-act="go-cal" style="margin-top:6px">Все смены в календаре</button>` : ''}</div>`
      : `<p class="hint" style="text-align:center;margin-top:18px">${canToday ? '' : `Календарь рассчитан на ${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]} годы. `}Нажмите на любой день в календаре, чтобы внести смену.</p>`}`;
    countUp($('#hero-total'), Math.round(s.grand), (v) => (v === Math.round(s.grand) ? M(s.grand) : M(v)));
    updateChip();
  }
  const ZONES = { green: ['Зелёная', 'zone-green'], yellow: ['Жёлтая', 'zone-yellow'], red: ['Красная', 'zone-red'] };
  function bonusCard(s, idx) {
    const x = s.extras, b = x.cfg, m = C.ymOf(idx).m;
    const prodLine = x.prodAvg === null
      ? `<span class="muted">укажите производительность в сменах</span>`
      : x.prodOk ? `<b class="up">+${M(x.prodBonus)}</b>`
      : `<span class="muted">${s.needProd !== null && s.needProd <= 300 ? `нужно в среднем ${N(s.needProd, 1)}% в оставшиеся смены` : `ниже ${N(b.prodThreshold, 0)}%`}</span>`;
    const zone = x.zone ? ZONES[x.zone] : null;
    return `<div class="card bonus-card"><h2>Премии и штраф <small>${C.MONTHS[m].toLowerCase()}</small></h2>
      <div class="bonus-row"><div><div>За производительность</div><div class="hint" style="margin:2px 0 0">средняя ${x.prodAvg === null ? '—' : N(x.prodAvg, 2) + '%'} · нужно от ${N(b.prodThreshold, 0)}%</div>
        ${x.prodAvg !== null ? `<div class="meter"><i style="width:${Math.min(100, (x.prodAvg / (b.prodThreshold * 1.25)) * 100).toFixed(1)}%" class="${x.prodOk ? 'ok' : ''}"></i><s style="left:${(100 / 1.25).toFixed(1)}%"></s></div>` : ''}</div>
        <div class="bonus-val">${prodLine}</div></div>
      <div class="bonus-row"><div><div>За сервис ${zone ? `<span class="zone ${zone[1]}">${zone[0]}</span>` : ''}</div><div class="hint" style="margin:2px 0 0">${x.service === null ? 'качество за месяц не указано' : `качество ${N(x.service, 3)}%`} · зелёная от ${N(b.greenThreshold, 2)}%</div></div>
        <div class="bonus-val">${x.service === null ? '<span class="muted">—</span>' : x.serviceBonus ? `<b class="up">+${M(x.serviceBonus)}</b>` : '<span class="muted">0 ₽</span>'}</div></div>
      <div class="bonus-row"><div><div>Штраф за ошибки (сервис)</div><div class="hint" style="margin:2px 0 0">за месяц, вносится вручную</div></div>
        <div class="bonus-val">${x.penalty ? `<b class="down">−${M(x.penalty)}</b>` : '<span class="muted">0 ₽</span>'}</div></div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}">${x.service === null && !x.penalty ? 'Указать сервис и штраф' : 'Изменить сервис и штраф'}</button></div>`;
  }
  function openMonthSheet(idx) {
    const { y, m } = C.ymOf(idx);
    const sh = $('#sheet');
    const md = (state.months || {})[C.monthId(m, y)] || {};
    const b = { ...C.DEFAULT_BONUS, ...state.settings.bonus };
    const v = (x) => (x === null || x === undefined || x === 0 ? '' : String(x).replace('.', ','));
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${C.MONTHS[m]} ${y}</div><div class="sheet-sub">Сервис и штраф за ошибки за месяц</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="month-form" autocomplete="off" novalidate>
        <div class="field"><label for="m-service">Сервис (качество без ошибок), % <span>из отчёта</span></label>
          <input class="input big num" id="m-service" inputmode="decimal" placeholder="99,95" value="${v(md.service)}"></div>
        <div class="note" id="m-zone"></div>
        <div class="field"><label for="m-penalty">Штраф за ошибки (сервис) за месяц, ₽ <span>0 — нет штрафа</span></label>
          <input class="input num" id="m-penalty" inputmode="decimal" placeholder="0" value="${v(md.penalty)}"></div>
        <p class="hint" style="margin:-4px 0 14px">Зоны: зелёная от ${N(b.greenThreshold, 2)}% (премия ${M(b.greenAmount)}), жёлтая от ${N(b.yellowThreshold, 2)}% (${M(b.yellowAmount)}), ниже — красная (${M(b.redAmount)}). Суммы меняются в настройках.</p>
        <p class="error" id="m-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const upd = () => {
      const raw = $('#m-service').value.trim(), n = Number(raw.replace(',', '.'));
      const el = $('#m-zone');
      if (!raw || !Number.isFinite(n)) { el.className = 'note'; el.textContent = ''; return; }
      const z = C.serviceZone(n, b);
      el.className = 'note';
      el.innerHTML = `<span class="zone ${ZONES[z][1]}">${ZONES[z][0]} зона</span> премия за сервис ${M(b[z + 'Amount'])}`;
    };
    $('#month-form').addEventListener('input', upd); upd();
    sh.onclick = (e) => { if (e.target.closest('[data-close]')) closeModal(); };
    $('#month-form').onsubmit = (e) => {
      e.preventDefault();
      const r = C.setMonthData(state, m, { service: $('#m-service').value, penalty: $('#m-penalty').value }, y);
      if (!r.ok) { $('#m-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast('Сохранено'); }
    };
    openModal(sh, $('#backdrop'));
  }
  function rowHtml(d) {
    const e = state.entries[d.key], p = C.parseKey(d.key);
    return `<button class="list-row" data-act="open-day" data-key="${d.key}">
      <div class="date-badge num">${p.d}<small>${C.WEEKDAYS[C.weekdayMon(d.key)]}</small></div>
      <div class="grow"><div>${N(e.lines)} линий${e.prod !== null && e.prod !== undefined ? ` · ${N(e.prod, 2)}%` : ''}${e.hours ? ` · ${N(e.hours, 2)} ч` : ''}</div><div>${e.actual !== null ? `факт · расчёт ${M(C.estimated(e))}` : `${N(e.lines)} × ${M(e.rate)}`}${e.comment ? ' · ' + esc(e.comment) : ''}</div></div>
      <div class="amount num">${M(C.total(e))}</div></button>`;
  }
  const plural = (n, a, b, c) => { n = Math.abs(n) % 100; const n1 = n % 10; return n > 10 && n < 20 ? c : n1 > 1 && n1 < 5 ? b : n1 === 1 ? a : c; };

  // ---------- Календарь ----------
  function renderCal(anim) {
    const idx = ui.calMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.summarize(state.entries, C.monthKeys(m, y));
    const ex = C.monthExtras(state, m, s, y);
    $('#view-cal').innerHTML = `
      ${monthSwitch(idx, 'cal')}
      <div class="cal" id="cal-swipe">
        <div class="cal-head">${C.WEEKDAYS.map((w) => `<div>${w}</div>`).join('')}</div>
        <div class="cal-grid ${anim ? 'anim-' + anim : ''}">
          ${C.calendarGrid(m, y).flat().map((k) => {
            if (!k) return '<div class="day empty"></div>';
            const info = C.dayInfo(k), e = state.entries[k];
            const cls = ['day', info.off ? 'off' : '', k === today ? 'today' : '', e ? 'has' : '', e && e.actual !== null ? 'actual' : ''].join(' ');
            return `<button class="${cls}" data-act="open-day" data-key="${k}" aria-label="${C.fmtDateLong(k)}${info.holiday ? ', ' + info.label : ''}">
              <span class="num">${C.parseKey(k).d}</span>
              ${e ? `<span class="d-lines num">${e.lines ? N(e.lines) : '₽'}</span><span class="d-money num">${C.fmtMoneyShort(C.total(e))}</span>` : ''}
            </button>`;
          }).join('')}
        </div>
        <div class="legend">
          <span><i style="background:var(--accent-soft);border:1px solid var(--accent)"></i>Смена внесена</span>
          <span><i style="background:var(--weekend)"></i>Выходной (сб, вс)</span>
          <span><i style="background:var(--good);border-radius:50%;width:8px;height:8px"></i>Указан факт</span>
        </div>
      </div>
      <div class="cal-summary">
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Итого</div><div class="t-value num">${C.fmtMoneyShort(s.total + ex.net)}&nbsp;₽</div></div>
      </div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}" style="margin-top:12px">Сервис и штраф за ${C.MONTHS[m].toLowerCase()}${ex.penalty ? ` · −${M(ex.penalty)}` : ''}</button>
      <p class="hint" style="text-align:center">Будних дней в месяце: ${C.workdaysInMonth(m, y)}. Выходные — суббота и воскресенье. Листайте календарь свайпом.</p>`;
    bindSwipe();
    updateChip();
  }
  function bindSwipe() {
    const el = $('#cal-swipe');
    let x0 = null, y0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dy) < 50) shiftCal(dx < 0 ? 1 : -1);
    }, { passive: true });
  }
  function shiftCal(d) {
    const i = ui.calMonth + d;
    if (i < 0 || i >= C.MONTH_COUNT) return;
    ui.calMonth = i; renderCal(d > 0 ? 'left' : 'right');
  }

  // ---------- Форма дня ----------
  function openDay(k) {
    if (!C.isValidKey(k) || !C.inYear(k)) return;
    const sh = $('#sheet');
    const already = modalStack.length && modalStack[modalStack.length - 1].el === sh;
    fillDaySheet(k);
    if (!already) {
      openModal(sh, $('#backdrop'));
      if (!state.entries[k]) setTimeout(() => { const i = $('#f-lines'); if (i) i.focus(); }, 320);
    }
  }
  function fillDaySheet(k) {
    const sh = $('#sheet');
    const e = state.entries[k];
    const info = C.dayInfo(k);
    const curRate = C.rateFor(state.settings.rateHistory, k);
    const rate = e ? e.rate : curRate;
    const v = (x) => (x === null || x === undefined ? '' : String(x).replace('.', ','));
    const prevK = C.addDays(k, -1), nextK = C.addDays(k, 1);
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head">
        <button class="icon-btn" data-day="${prevK}" ${C.inYear(prevK) ? '' : 'disabled style="opacity:.3"'} aria-label="Предыдущий день">‹</button>
        <div class="grow"><div class="sheet-title">${C.fmtDateLong(k)}</div>
          <div class="sheet-sub ${info.off ? 'holiday' : ''}">${C.WEEKDAYS_FULL[C.weekdayMon(k)]} · ${esc(info.label)}</div></div>
        <button class="icon-btn" data-day="${nextK}" ${C.inYear(nextK) ? '' : 'disabled style="opacity:.3"'} aria-label="Следующий день">›</button>
      </div>
      <form id="day-form" autocomplete="off" novalidate>
        <div class="field"><label for="f-lines">Количество собранных линий</label>
          <input class="input big num" id="f-lines" inputmode="numeric" pattern="[0-9]*" placeholder="0" value="${e ? v(e.lines || '') : ''}">
          <div class="quick">${[10, 50, 100].map((n) => `<button type="button" data-add="${n}">+${n}</button>`).join('')}<button type="button" data-add="0">Сброс</button></div>
        </div>
        <div class="field"><label for="f-prod">Производительность за день, % <span>из отчёта</span></label>
          <input class="input num" id="f-prod" inputmode="decimal" placeholder="Например, 124,5" value="${e ? v(e.prod) : ''}"></div>
        <div class="note" id="f-prodnote"></div>
        <div class="calc"><div><div class="formula num" id="f-formula"></div><div class="formula">расчётный заработок</div></div><div class="res num" id="f-est"></div></div>
        ${e && e.rate !== curRate ? `<label class="check"><input type="checkbox" id="f-rerate"><span>Запись сохранена по тарифу <b>${M(e.rate)}</b>. Пересчитать по тарифу на эту дату — <b>${M(curRate)}</b>?</span></label>` : ''}
        <div class="field"><label for="f-actual">Фактически заработано, ₽ <span>необязательно</span></label>
          <input class="input num" id="f-actual" inputmode="decimal" placeholder="Например, по расчётному листу" value="${e ? v(e.actual) : ''}"></div>
        <div class="note" id="f-diff"></div>
        <div class="field"><label for="f-hours">Отработано часов <span>необязательно</span></label>
          <input class="input num" id="f-hours" inputmode="decimal" placeholder="Например, 11" value="${e ? v(e.hours) : ''}"></div>
        <div class="note" id="f-perhour"></div>
        <div class="field"><label for="f-comment">Комментарий <span>необязательно</span></label>
          <textarea class="input" id="f-comment" maxlength="500" placeholder="Ночная смена, переработка…">${e ? esc(e.comment) : ''}</textarea></div>
        <p class="error" id="f-error"></p>
        <button class="btn btn-primary" type="submit">${e ? 'Сохранить изменения' : 'Сохранить смену'}</button>
        ${e ? '<button class="btn btn-danger" type="button" data-del>Удалить запись</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const f = $('#day-form');
    const rateNow = () => ($('#f-rerate') && $('#f-rerate').checked ? curRate : rate);
    const parse = (s) => { const n = Number(String(s).replace(',', '.').replace(/\s/g, '')); return s.trim() === '' || !Number.isFinite(n) ? null : n; };
    const update = () => {
      const lines = parse($('#f-lines').value), actual = parse($('#f-actual').value), hours = parse($('#f-hours').value);
      const r = rateNow(), est = C.round2((lines || 0) * r);
      $('#f-formula').textContent = `${N(lines || 0)} × ${M(r)}`;
      $('#f-est').textContent = M(est);
      const diff = $('#f-diff');
      if (actual !== null && lines) {
        const d = C.round2(actual - est);
        diff.className = 'note ' + (d >= 0 ? 'good' : 'bad');
        diff.textContent = d === 0 ? 'Факт совпадает с расчётом' : `Факт ${d > 0 ? 'больше' : 'меньше'} расчёта на ${M(Math.abs(d))}. В итог пойдёт фактическая сумма.`;
      } else { diff.className = 'note'; diff.textContent = actual !== null ? 'В итог пойдёт фактическая сумма.' : ''; }
      const prod = parse($('#f-prod').value), pn = $('#f-prodnote');
      const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
      if (prod !== null) { pn.className = 'note ' + (prod >= thr ? 'good' : 'bad'); pn.textContent = prod >= thr ? `Не ниже ${N(thr, 0)}% — уровень премии` : `Ниже ${N(thr, 0)}% на ${N(thr - prod, 2)}%`; }
      else { pn.className = 'note'; pn.textContent = ''; }
      const total = actual !== null ? actual : est;
      $('#f-perhour').textContent = hours ? `≈ ${N((lines || 0) / hours, 1)} линий/час · ${M(C.round2(total / hours))}/час` : '';
    };
    f.addEventListener('input', update);
    f.addEventListener('change', update);
    update();
    sh.onclick = async (ev) => {
      const t = ev.target;
      if (t.closest('[data-close]')) return closeModal();
      const dayBtn = t.closest('[data-day]');
      if (dayBtn && !dayBtn.disabled) return fillDaySheet(dayBtn.dataset.day);
      const add = t.closest('[data-add]');
      if (add) {
        const inp = $('#f-lines'), n = +add.dataset.add;
        inp.value = n ? String((parseInt(inp.value, 10) || 0) + n) : '';
        update(); return;
      }
      if (t.closest('[data-del]')) {
        if (await confirmDlg('Удалить запись?', `Смена за ${C.fmtDateLong(k)} будет удалена.`, 'Удалить', true)) {
          C.deleteEntry(state, k); save(); closeModal(); renderAll(); toast('Запись удалена');
        }
      }
    };
    f.onsubmit = (ev) => {
      ev.preventDefault();
      const res = C.saveEntry(state, k, { lines: $('#f-lines').value, actual: $('#f-actual').value, hours: $('#f-hours').value, prod: $('#f-prod').value, comment: $('#f-comment').value },
        { useCurrentRate: !!($('#f-rerate') && $('#f-rerate').checked) });
      if (!res.ok) { $('#f-error').textContent = res.error; return; }
      if (save()) { closeModal(); renderAll(); toast(`Сохранено: ${M(C.total(res.entry))}`); }
    };
  }

  // ---------- Графики (SVG без библиотек) ----------
  const W = 340, H = 170, PL = 34, PR = 6, PT = 10, PB = 22;
  function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
  function axes(max, fmtAxis) {
    let s = '';
    for (let i = 0; i <= 3; i++) {
      const y = PT + (H - PT - PB) * (1 - i / 3);
      s += `<line class="gridline" x1="${PL}" x2="${W - PR}" y1="${y}" y2="${y}"/><text x="${PL - 5}" y="${y + 3}" text-anchor="end">${fmtAxis((max * i) / 3)}</text>`;
    }
    return s;
  }
  function xLabels(labels, xs) {
    const step = Math.ceil(labels.filter(Boolean).length / 8);
    let c = 0;
    return labels.map((l, i) => (l && c++ % step === 0 ? `<text x="${xs(i)}" y="${H - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  }
  // Возвращает HTML карточки графика. items: [{label, tip, value}]
  let chartSeq = 0;
  function chartCard({ title, items, kind = 'bar', fmt = M, fmtAxis = C.fmtMoneyShort, avg = null, alt = false, summary }) {
    const id = 'ch' + ++chartSeq;
    const has = items.some((it) => it.value > 0);
    if (!has) return `<div class="card chart-card"><h2>${esc(title)}</h2><div class="empty-chart">Нет данных за выбранный период</div></div>`;
    const max = niceMax(Math.max(...items.map((i) => i.value), avg || 0));
    const iw = (W - PL - PR) / items.length;
    const xs = (i) => PL + iw * i + iw / 2;
    const ys = (v) => PT + (H - PT - PB) * (1 - v / max);
    let body = '';
    if (kind === 'bar') {
      const bw = Math.max(1.5, Math.min(26, iw * 0.68));
      body = items.map((it, i) => it.value > 0
        ? `<rect class="bar ${alt ? 'alt' : ''}" data-i="${i}" x="${xs(i) - bw / 2}" y="${ys(it.value)}" width="${bw}" height="${Math.max(0, H - PB - ys(it.value))}" rx="${Math.min(4, bw / 3)}" style="animation-delay:${Math.min(i * 12, 400)}ms"/>` : '').join('');
    } else {
      const pts = items.map((it, i) => [xs(i), ys(it.value)]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
      body = `<path class="area" d="${d}L${pts[pts.length - 1][0].toFixed(1)} ${H - PB}L${pts[0][0].toFixed(1)} ${H - PB}Z"/><path class="line" d="${d}"/>` +
        (items.length <= 40 ? items.map((it, i) => (it.value > 0 ? `<circle class="dot" data-i="${i}" cx="${xs(i)}" cy="${ys(it.value)}" r="3"/>` : '')).join('') : '');
    }
    const hits = items.map((_, i) => `<rect class="hit" data-i="${i}" x="${PL + iw * i}" y="${PT}" width="${iw}" height="${H - PT}"/>`).join('');
    const avgLine = avg ? `<line class="avg" x1="${PL}" x2="${W - PR}" y1="${ys(avg)}" y2="${ys(avg)}"/>` : '';
    chartData[id] = { items, fmt, summary };
    return `<div class="card chart-card"><h2>${esc(title)}</h2>
      <div class="readout" id="${id}-ro">${summary}</div>
      <svg class="chart" id="${id}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px">
        ${axes(max, fmtAxis)}${body}${avgLine}${xLabels(items.map((i) => i.label), xs)}${hits}</svg></div>`;
  }
  const chartData = {};
  document.addEventListener('click', (e) => {
    const hit = e.target.closest('svg.chart [data-i]');
    if (!hit) return;
    const svg = hit.closest('svg'), cd = chartData[svg.id], i = +hit.dataset.i, it = cd.items[i];
    svg.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel'));
    svg.querySelectorAll(`.bar[data-i="${i}"], .dot[data-i="${i}"]`).forEach((x) => x.classList.add('sel'));
    $('#' + svg.id + '-ro').innerHTML = `<b class="num">${cd.fmt(it.value)}</b><span>${esc(it.tip || it.label)}</span>`;
  });

  // ---------- Статистика ----------
  function periodKeys() {
    const st = ui.stats;
    if (st.mode === 'month') { const { y, m } = C.ymOf(st.month); return C.monthKeys(m, y); }
    if (st.mode === 'year') return C.yearKeys(st.year);
    return C.rangeKeys(st.from, st.to).filter((k) => C.inYear(k));
  }
  function periodTitle() {
    const st = ui.stats;
    if (st.mode === 'month') return monthName(st.month);
    if (st.mode === 'year') return `${st.year} год`;
    return `${C.fmtDateShort(st.from <= st.to ? st.from : st.to)} — ${C.fmtDateShort(st.from <= st.to ? st.to : st.from)}`;
  }
  function renderStats() {
    chartSeq = 0;
    const st = ui.stats, keys = periodKeys();
    const s = C.summarize(state.entries, keys);
    const wk = C.weekly(state.entries, keys);
    // Год для раздела «год целиком»: год выбранного месяца / выбранный год / год начала периода
    const statYear = st.mode === 'month' ? C.ymOf(st.month).y : st.mode === 'year' ? st.year : C.parseKey(st.from <= st.to ? st.from : st.to).y;
    const months = C.yearByMonths(state, statYear);
    const yearTotal = C.round2(months.reduce((a, x) => a + x.grand, 0));
    const yearBonuses = C.round2(months.reduce((a, x) => a + x.extras.bonuses, 0));
    const yearPenalty = C.round2(months.reduce((a, x) => a + x.extras.penalty, 0));
    const yearProd = (() => { const d = months.reduce((a, x) => a + x.prodDays, 0); return d ? months.reduce((a, x) => a + x.prodSum, 0) / d : null; })();
    // Премии и штраф — помесячные: учитываются в режимах «Месяц» и «Весь год»
    const pex = st.mode === 'month' ? months[C.ymOf(st.month).m].extras
      : st.mode === 'year' ? { bonuses: yearBonuses, penalty: yearPenalty, net: C.round2(yearBonuses - yearPenalty) } : null;
    const periodGrand = pex ? C.round2(s.total + pex.net) : s.total;
    const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
    const yearLines = months.reduce((a, x) => a + x.lines, 0);
    const yearShifts = months.reduce((a, x) => a + x.shifts, 0);
    const daily = keys.length <= 62;
    const dayItems = keys.map((k) => { const e = state.entries[k]; return { label: daily ? String(C.parseKey(k).d) : C.MONTHS_SHORT[C.parseKey(k).m], tip: `${C.fmtDateLong(k)}, ${C.WEEKDAYS_FULL[C.weekdayMon(k)].toLowerCase()}`, value: e ? C.total(e) : 0, lines: e ? e.lines : 0 }; });
    if (!daily) dayItems.forEach((it, i) => { if (C.parseKey(keys[i]).d !== 1) it.label = ''; });
    const opt = (v, cur, t) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${t}</option>`;
    const maxMonth = months.reduce((b, x, i) => (x.grand > months[b].grand ? i : b), 0);
    const prodItems = keys.filter((k) => state.entries[k] && state.entries[k].prod !== null && state.entries[k].prod !== undefined)
      .map((k) => ({ label: daily ? String(C.parseKey(k).d) : C.fmtDateShort(k), tip: C.fmtDateLong(k), value: state.entries[k].prod }));

    $('#view-stats').innerHTML = `
      <div class="seg" role="tablist">
        ${[['month', 'Месяц'], ['year', 'Весь год'], ['range', 'Период']].map(([v, t]) => `<button data-mode="${v}" class="${st.mode === v ? 'active' : ''}">${t}</button>`).join('')}
      </div>
      ${st.mode === 'month' ? `<div class="field"><select class="input" id="st-month">${C.YEARS.map((y) => `<optgroup label="${y}">${C.MONTHS.map((n, m) => opt(C.indexOf(y, m), st.month, `${n} ${y}`)).join('')}</optgroup>`).join('')}</select></div>` : ''}
      ${st.mode === 'year' ? `<div class="seg">${C.YEARS.map((y) => `<button data-year="${y}" class="${y === st.year ? 'active' : ''}">${y}</button>`).join('')}</div>` : ''}
      ${st.mode === 'range' ? `<div class="period-inputs">
          <div><label for="st-from">С</label><input class="input" type="date" id="st-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.from}"></div>
          <div><label for="st-to">По</label><input class="input" type="date" id="st-to" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.to}"></div></div>` : ''}

      <div class="card"><h2>${esc(periodTitle())}</h2>
        <div class="year-total num">${M(periodGrand)}</div>
        ${pex && (pex.bonuses || pex.penalty) ? `<p class="hint" style="margin-top:2px">Смены ${M(s.total)}${pex.bonuses ? ` + премии ${M(pex.bonuses)}` : ''}${pex.penalty ? ` − штраф ${M(pex.penalty)}` : ''}</p>` : ''}
        ${st.mode === 'range' ? '<p class="hint" style="margin-top:2px">За произвольный период — только смены. Премии и штраф помесячные, смотрите их в режимах «Месяц» и «Весь год».</p>' : ''}
        <p class="hint" style="margin-top:2px">Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт ${M(s.actual)} (${s.actualCount} ${plural(s.actualCount, 'смена', 'смены', 'смен')})` : ''}${s.diffCount ? ` · разница факт−расчёт ${s.diff >= 0 ? '+' : '−'}${M(Math.abs(s.diff))}` : ''}</p>
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за неделю</div><div class="t-value num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</div><div class="t-sub">${wk.workedWeeks ? `по ${wk.workedWeeks} ${plural(wk.workedWeeks, 'неделе', 'неделям', 'неделям')} со сменами` : ''}</div></div>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${s.prodAvg === null ? '' : s.prodAvg >= thr ? 'up' : 'down'}">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</div><div class="t-sub">${s.prodDays ? `по ${s.prodDays} ${plural(s.prodDays, 'смене', 'сменам', 'сменам')}` : 'не указана'}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div></div>
        <div class="tile"><div class="t-label">Лучший день</div><div class="t-value num">${s.best ? C.fmtDateShort(s.best.key) : '—'}</div><div class="t-sub num">${s.best ? `${N(s.best.lines)} линий` : ''}</div></div>
        ${s.hours ? `<div class="tile wide"><div class="t-label">Выработка в час (по сменам с указанными часами)</div><div class="t-value num">${N(s.linesPerHour, 1)} линий/ч · ${M(s.earnPerHour)}/ч</div><div class="t-sub num">${N(s.hours, 1)} ч всего</div></div>` : ''}
      </div>

      ${chartCard({ title: 'Ежедневный заработок', items: dayItems, kind: daily ? 'bar' : 'line', avg: s.shifts ? s.avgPerShift : null,
        summary: `<b class="num">${M(s.total)}</b><span>${daily ? 'пунктир — среднее за смену · нажмите на столбец' : 'нажмите на график'}</span>` })}
      ${chartCard({ title: 'Собранные линии по дням', items: dayItems.map((d) => ({ ...d, value: d.lines })), kind: 'line', fmt: (v) => N(v) + ' линий', fmtAxis: (v) => N(v),
        summary: `<b class="num">${N(s.lines)}</b><span>линий за период</span>` })}
      ${chartCard({ title: 'Производительность по дням', items: prodItems, kind: prodItems.length > 40 ? 'line' : 'bar', fmt: (v) => N(v, 2) + '%', fmtAxis: (v) => N(v) + '%', avg: thr, alt: true,
        summary: `<b class="num">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</b><span>средняя · пунктир — ${N(thr, 0)}% для премии</span>` })}
      ${wk.weeks.length > 1 ? chartCard({ title: 'Заработок по неделям', items: wk.weeks.map((w) => ({ label: C.fmtDateShort(w.monday).split(' ')[0], tip: `Неделя ${C.fmtDateShort(w.monday)} — ${C.fmtDateShort(w.sunday)}, ${w.shifts} ${plural(w.shifts, 'смена', 'смены', 'смен')}`, value: w.total })),
        avg: wk.avgWeekly || null, alt: true, summary: `<b class="num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</b><span>в среднем за неделю</span>` }) : ''}

      <h2 style="margin:22px 4px 10px;font-size:20px">${statYear} год целиком</h2>
      <div class="card"><div class="muted" style="font-size:14px">Общая сумма заработка за ${statYear} год</div>
        <div class="year-total num">${M(yearTotal)}</div>
        ${yearBonuses || yearPenalty ? `<p class="hint" style="margin-top:2px">включая премии ${M(yearBonuses)}${yearPenalty ? ` и штрафы −${M(yearPenalty)}` : ''}</p>` : ''}
        <p class="hint" style="margin-top:2px">${N(yearLines)} линий · ${yearShifts} ${plural(yearShifts, 'смена', 'смены', 'смен')}${yearProd !== null ? ` · средняя производительность ${N(yearProd, 2)}%` : ''}</p></div>
      ${chartCard({ title: 'Заработок по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.grand })),
        summary: yearShifts ? `<b class="num">${M(months[maxMonth].grand)}</b><span>лучший месяц — ${C.MONTHS[maxMonth].toLowerCase()}</span>` : '' })}
      ${chartCard({ title: 'Линии по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.lines })), alt: true, fmt: (v) => N(v) + ' линий', fmtAxis: (v) => C.fmtMoneyShort(v),
        summary: `<b class="num">${N(yearLines)}</b><span>линий за год</span>` })}
      <div class="card"><h2>Сравнение месяцев</h2>
        <table class="table num"><thead><tr><th>Месяц</th><th>Смен</th><th>Произв.</th><th>Итого</th><th>к пред.</th></tr></thead><tbody>
        ${months.map((x, i) => `<tr class="${x.shifts ? '' : 'zero'}"><td>${C.MONTHS[i]}</td><td>${x.shifts || '—'}</td><td class="${x.prodAvg === null ? '' : x.extras.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</td><td>${x.shifts || x.grand ? M(x.grand) : '—'}</td>
          <td class="${x.change > 0 ? 'up' : x.change < 0 ? 'down' : ''}">${x.change === null || !x.shifts ? '—' : (x.change > 0 ? '+' : '') + N(x.change * 100, 0) + '%'}</td></tr>`).join('')}
        </tbody><tfoot><tr><td>Итого</td><td>${yearShifts}</td><td>${yearProd === null ? '—' : N(yearProd, 1) + '%'}</td><td>${M(yearTotal)}</td><td></td></tr></tfoot></table><p class="hint">«Итого» — смены + премии − штраф.</p></div>`;

    $('#view-stats').onclick = (e) => {
      const b = e.target.closest('[data-mode]'); if (b) { st.mode = b.dataset.mode; return renderStats(); }
      const yb = e.target.closest('[data-year]'); if (yb) { st.year = +yb.dataset.year; renderStats(); }
    };
    const sm = $('#st-month'); if (sm) sm.onchange = () => { st.month = +sm.value; renderStats(); };
    const f = $('#st-from'), t = $('#st-to');
    if (f) {
      const upd = () => { if (C.isValidKey(f.value) && C.isValidKey(t.value)) { st.from = f.value; st.to = t.value; renderStats(); } };
      f.onchange = upd; t.onchange = upd;
    }
    updateChip();
  }

  // ---------- Настройки ----------
  function renderSettings() {
    const set = state.settings, today = todayKey();
    const refKey = C.inYear(today) ? today : C.FIRST_DAY;
    const count = Object.keys(state.entries).length;
    const hist = [...set.rateHistory].sort((a, b) => (a.from < b.from ? 1 : -1));
    $('#view-settings').innerHTML = `
      <div class="card"><h2>Стоимость одной линии</h2>
        <div class="rate-now"><b class="num">${M(C.rateFor(set.rateHistory, refKey))}</b><span class="muted">${C.inYear(today) ? 'действует сегодня' : `на ${C.fmtDateLong(refKey)}`}</span></div>
        <div class="inline-form">
          <div><label for="s-rate">Новая стоимость, ₽</label><input class="input num" id="s-rate" inputmode="decimal" placeholder="5"></div>
          <div><label for="s-from">Действует с</label><input class="input" type="date" id="s-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${refKey}"></div>
        </div>
        <button class="btn btn-primary" data-act="set-rate">Применить тариф</button>
        <p class="hint">Новые записи с этой даты считаются по новой стоимости. Уже сохранённые смены не пересчитываются — у каждой хранится свой тариф.</p>
        <div style="margin-top:12px">${hist.map((h) => `<div class="hist-row num"><span>с ${C.fmtDateLong(h.from)} — <b>${M(h.rate)}</b></span>${hist.length > 1 ? `<button data-act="del-rate" data-from="${h.from}">Удалить</button>` : ''}</div>`).join('')}</div>
      </div>
      <div class="card"><h2>Цели на месяц</h2>
        <div class="field"><label for="s-target">Целевая зарплата за месяц, ₽ <span>0 — без цели</span></label><input class="input num" id="s-target" inputmode="decimal" value="${set.target || ''}" placeholder="Например, 60000"></div>
        <div class="field"><label for="s-planned">Планируемое количество смен в месяц <span>0 — по календарю</span></label><input class="input num" id="s-planned" inputmode="numeric" value="${set.plannedShifts || ''}" placeholder="Например, 15"></div>
        <button class="btn btn-primary" data-act="save-goals">Сохранить цели</button>
        <p class="hint">Прогноз = уже заработано + средний заработок за смену × оставшиеся смены. Без плана оставшиеся смены — это будние дни (пн–пт) до конца месяца.</p>
      </div>
      <div class="card"><h2>Премии</h2>
        ${(() => { const b = { ...C.DEFAULT_BONUS, ...set.bonus }; const f = (id, label, val) => `<div><label for="${id}">${label}</label><input class="input num" id="${id}" inputmode="decimal" value="${String(val).replace('.', ',')}"></div>`;
          return `<p class="hint" style="margin:0 0 8px">За производительность — по средней за месяц</p>
          <div class="inline-form">${f('b-pthr', 'Порог, %', b.prodThreshold)}${f('b-pamt', 'Премия, ₽', b.prodAmount)}</div>
          <p class="hint" style="margin:6px 0 8px">За сервис (работа без ошибок) — по зонам</p>
          <div class="inline-form">${f('b-gthr', 'Зелёная от, %', b.greenThreshold)}${f('b-gamt', 'Премия, ₽', b.greenAmount)}</div>
          <div class="inline-form">${f('b-ythr', 'Жёлтая от, %', b.yellowThreshold)}${f('b-yamt', 'Премия, ₽', b.yellowAmount)}</div>
          <div class="inline-form"><div><label>Красная</label><div class="input num" style="color:var(--muted);font-size:15px;display:flex;align-items:center">ниже жёлтой</div></div>${f('b-ramt', 'Премия, ₽', b.redAmount)}</div>`; })()}
        <button class="btn btn-primary" data-act="save-bonus">Сохранить премии</button>
        <p class="hint">Сервис и штраф за ошибки вносятся на главном экране для каждого месяца. Если узнаете сумму премии за жёлтую зону, укажите её здесь.</p>
      </div>
      <div class="card"><h2>Оформление</h2>
        <div class="seg" id="s-theme">${[['system', 'Как в системе'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, t]) => `<button data-theme="${v}" class="${set.theme === v ? 'active' : ''}">${t}</button>`).join('')}</div>
        <div class="muted" style="font-size:14px;margin:6px 0 10px">Цветовая гамма — меняется во всём приложении</div>
        <div class="palettes" id="s-palettes">${C.PALETTES.map((p) => `<button data-pal="${p.id}" class="${set.palette && set.palette.id === p.id ? 'active' : ''}" aria-label="${p.name}">
          <span class="sw" style="background:linear-gradient(135deg, ${p.accent} 0 58%, ${p.accent2} 58% 100%)"></span><small>${p.name}</small></button>`).join('')}</div>
        <div class="inline-form" style="margin-top:12px">
          <div><label for="s-acc">Свой основной цвет</label><input class="input color" type="color" id="s-acc" value="${(set.palette || C.PALETTES[0]).accent}"></div>
          <div><label for="s-acc2">Цвет графиков</label><input class="input color" type="color" id="s-acc2" value="${(set.palette || C.PALETTES[0]).accent2}"></div>
        </div>
        <p class="hint">Основной цвет — кнопки, календарь, главная карточка, вкладки. Цвет графиков — линии и вторые столбцы в статистике.</p>
      </div>
      <div class="card"><h2>Резервная копия <small>${count} ${plural(count, 'запись', 'записи', 'записей')}</small></h2>
        <button class="btn btn-primary" data-act="export">Сохранить копию в файл</button>
        <button class="btn btn-secondary" data-act="import">Восстановить из файла</button>
        <div class="btn-row" style="margin-top:10px"><button class="btn btn-secondary" data-act="export-text">Копировать текстом</button><button class="btn btn-secondary" data-act="import-text">Вставить текст</button></div>
        <button class="btn btn-secondary" data-act="csv">Таблица для Excel (CSV)</button>
        <p class="hint">${meta.lastBackup ? `Последняя копия: ${new Date(meta.lastBackup).toLocaleString('ru-RU')}.` : 'Копия ещё не создавалась.'} Данные хранятся только на этом телефоне — сохраняйте копию раз в неделю (например, в Telegram «Избранное» или на Google Диск).</p>
        <input type="file" id="s-file" accept=".json,application/json,text/plain" hidden>
      </div>
      <div class="card"><h2>Данные</h2><button class="btn btn-danger" data-act="wipe">Удалить все записи</button></div>
      <div class="about">Калькулятор зарплаты комплектовщика · версия 1.2<br>Годы ${C.YEARS.join(', ')} · выходные — суббота и воскресенье<br>Работает без интернета · данные хранятся на устройстве</div>`;
  }

  async function settingsAction(act, el) {
    const set = state.settings;
    if (act === 'set-rate') {
      const r = Number(String($('#s-rate').value).replace(',', '.'));
      const from = $('#s-from').value;
      try {
        if (!C.inYear(from)) throw new Error(`Укажите дату с ${C.YEARS[0]} по ${C.YEARS[C.YEARS.length - 1]} год`);
        C.setRate(state, from, r); save(); renderAll(); toast(`Тариф ${M(r)} с ${C.fmtDateLong(from)}`);
      } catch (e) { toast(e.message || 'Введите стоимость больше нуля'); }
    } else if (act === 'del-rate') {
      if (await confirmDlg('Удалить тариф?', 'Сохранённые смены не изменятся.', 'Удалить', true)) {
        try { C.removeRate(state, el.dataset.from); save(); renderAll(); } catch (e) { toast(e.message); }
      }
    } else if (act === 'save-bonus') {
      const g = (id) => Number(String($('#' + id).value).replace(',', '.').replace(/\s/g, ''));
      const nb = { prodThreshold: g('b-pthr'), prodAmount: g('b-pamt'), greenThreshold: g('b-gthr'), greenAmount: g('b-gamt'), yellowThreshold: g('b-ythr'), yellowAmount: g('b-yamt'), redAmount: g('b-ramt') };
      if (Object.values(nb).some((v) => !Number.isFinite(v) || v < 0)) return toast('Проверьте значения: числа не меньше 0');
      if (nb.greenThreshold > 100 || nb.yellowThreshold > nb.greenThreshold) return toast('Порог жёлтой зоны должен быть не выше зелёной, а зелёной — не выше 100%');
      set.bonus = nb; save(); renderAll(); toast('Премии сохранены');
    } else if (act === 'save-goals') {
      const t = Number(String($('#s-target').value || 0).replace(',', '.').replace(/\s/g, ''));
      const p = Number($('#s-planned').value || 0);
      if (!(t >= 0) || !(p >= 0) || !Number.isInteger(p) || p > 31) return toast('Проверьте значения: смен от 0 до 31');
      set.target = C.round2(t); set.plannedShifts = p; save(); renderAll(); toast('Цели сохранены');
    } else if (act === 'export') {
      await saveFile(`zarplata-backup-${todayKey()}.json`, C.exportData(state), 'application/json');
      meta.lastBackup = Date.now(); saveMeta(); renderSettings();
    } else if (act === 'csv') {
      await saveFile(`zarplata-${todayKey()}.csv`, C.toCSV(state), 'text/csv');
    } else if (act === 'import') {
      const inp = $('#s-file'); inp.value = '';
      inp.onchange = () => { const file = inp.files[0]; if (!file) return; const rd = new FileReader(); rd.onload = () => importText(String(rd.result)); rd.readAsText(file); };
      inp.click();
    } else if (act === 'export-text') {
      const txt = C.exportData(state);
      let copied = false;
      try { await navigator.clipboard.writeText(txt); copied = true; } catch {}
      if (copied) { meta.lastBackup = Date.now(); saveMeta(); renderSettings(); toast('Копия скопирована — вставьте её в заметки или мессенджер'); }
      else dialog({ title: 'Резервная копия', text: 'Выделите весь текст и скопируйте:', html: `<textarea class="input" readonly>${esc(txt)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    } else if (act === 'import-text') {
      const txt = await dialog({ title: 'Вставьте резервную копию', html: '<textarea class="input" id="imp-text" placeholder="{ ... }"></textarea>',
        buttons: [{ text: 'Восстановить', cls: 'btn-primary', read: (d) => $('#imp-text', d).value }, { text: 'Отмена', value: null }] });
      if (txt) importText(txt);
    } else if (act === 'wipe') {
      if (await confirmDlg('Удалить все записи?', 'Все смены будут удалены без возможности восстановления. Сначала сохраните резервную копию.', 'Удалить всё', true)
        && await confirmDlg('Точно удалить?', `${Object.keys(state.entries).length} записей будет удалено.`, 'Да, удалить', true)) {
        state.entries = {}; save(); renderAll(); toast('Все записи удалены');
      }
    }
  }
  async function importText(txt) {
    let parsed;
    try { parsed = C.normalizeState(JSON.parse(txt)); } catch (e) { return toast('Не удалось прочитать копию: ' + (e.message || 'неверный формат')); }
    const n = Object.keys(parsed.state.entries).length;
    const choice = await dialog({ title: 'Восстановление', text: `В копии ${n} ${plural(n, 'запись', 'записи', 'записей')}${parsed.skipped ? `, пропущено повреждённых: ${parsed.skipped}` : ''}.\nЗаменить текущие данные или объединить?`,
      buttons: [{ text: 'Заменить всё', cls: 'btn-primary', value: 'replace' }, { text: 'Объединить', value: 'merge' }, { text: 'Отмена', value: null }] });
    if (!choice) return;
    state = choice === 'replace' ? parsed.state : C.mergeStates(state, parsed.state);
    save(); applyTheme(); renderAll(); toast('Данные восстановлены');
  }
  async function saveFile(name, text, mime) {
    const cap = window.Capacitor;
    if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
      const P = cap.Plugins || {};
      if (P.Filesystem && P.Share) {
        try {
          const r = await P.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
          await P.Share.share({ title: name, files: [r.uri], url: r.uri, dialogTitle: 'Сохранить или отправить копию' });
          return;
        } catch (e) { if (String(e && e.message).match(/cancel/i)) return; console.warn(e); }
      }
      return dialog({ title: name, text: 'Скопируйте текст и сохраните его в надёжном месте:', html: `<textarea class="input" readonly>${esc(text)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    }
    const file = new File([text], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android/i.test(navigator.userAgent)) {
      try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Файл сохранён в «Загрузки»');
  }

  // ---------- Навигация ----------
  const TITLES = { home: 'Главная', cal: 'Календарь', stats: 'Статистика', settings: 'Настройки' };
  function setTab(tab) {
    ui.tab = tab;
    document.querySelectorAll('.tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + tab));
    $('#title').textContent = TITLES[tab];
    renderTab(tab);
    updateChip();
    window.scrollTo({ top: 0 });
  }
  function renderTab(tab) { ({ home: renderHome, cal: renderCal, stats: renderStats, settings: renderSettings })[tab](); }
  function renderAll() { renderTab(ui.tab); updateChip(); }
  function updateChip() {
    const chip = $('.year-chip');
    const y = ui.tab === 'home' ? C.ymOf(ui.homeMonth).y : ui.tab === 'cal' ? C.ymOf(ui.calMonth).y
      : ui.tab === 'stats' ? (ui.stats.mode === 'month' ? C.ymOf(ui.stats.month).y : ui.stats.mode === 'year' ? ui.stats.year : null) : null;
    chip.textContent = y || `${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]}`;
  }

  document.addEventListener('click', async (e) => {
    const tabBtn = e.target.closest('.tabbar button');
    if (tabBtn) return setTab(tabBtn.dataset.tab);
    const el = e.target.closest('[data-act]');
    if (!el || el.closest('#sheet') || el.disabled) return;
    const act = el.dataset.act;
    if (act === 'open-day') return el.dataset.key && openDay(el.dataset.key);
    if (act === 'open-today') return openDay(todayKey());
    if (act === 'month-extras') return openMonthSheet(+el.dataset.m);
    if (act === 'go-cal') { ui.calMonth = ui.homeMonth; return setTab('cal'); }
    if (act === 'home-prev' || act === 'home-next') { ui.homeMonth += act.endsWith('next') ? 1 : -1; ui.homeMonth = Math.max(0, Math.min(C.MONTH_COUNT - 1, ui.homeMonth)); return renderHome(); }
    if (act === 'cal-prev' || act === 'cal-next') return shiftCal(act.endsWith('next') ? 1 : -1);
    if (act === 'home-pick' || act === 'cal-pick') {
      const cur = act === 'home-pick' ? ui.homeMonth : ui.calMonth;
      const m = await pickMonth(cur);
      if (m === null) return;
      if (act === 'home-pick') { ui.homeMonth = m; renderHome(); } else { ui.calMonth = m; renderCal(m > cur ? 'left' : 'right'); }
      return;
    }
    if (el.closest('#view-settings')) return settingsAction(act, el);
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-theme [data-theme]');
    if (!b) return;
    state.settings.theme = b.dataset.theme; save(); applyTheme(); renderSettings();
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-palettes [data-pal]');
    if (!b) return;
    const p = C.PALETTES.find((x) => x.id === b.dataset.pal);
    state.settings.palette = { id: p.id, accent: p.accent, accent2: p.accent2 };
    save(); applyTheme(); renderSettings(); toast(`Гамма «${p.name}»`);
  });
  const customColor = (e, commit) => {
    if (!e.target.matches('#s-acc, #s-acc2')) return;
    const pal = { ...(state.settings.palette || C.PALETTES[0]), id: 'custom' };
    pal[e.target.id === 's-acc' ? 'accent' : 'accent2'] = e.target.value;
    state.settings.palette = pal; applyTheme();
    if (commit) { save(); document.querySelectorAll('#s-palettes [data-pal]').forEach((x) => x.classList.remove('active')); }
  };
  document.addEventListener('input', (e) => customColor(e, false));
  document.addEventListener('change', (e) => customColor(e, true));
  $('#backdrop').addEventListener('click', closeModal);
  $('#dlg-backdrop').addEventListener('click', closeModal);
  // Свайп вниз по шапке листа закрывает его
  (() => {
    const sh = $('#sheet'); let y0 = null;
    sh.addEventListener('touchstart', (e) => { y0 = sh.scrollTop <= 0 && e.target.closest('.grabber, .sheet-head') ? e.touches[0].clientY : null; }, { passive: true });
    sh.addEventListener('touchend', (e) => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 70) closeModal(); y0 = null; }, { passive: true });
  })();

  // ---------- Запуск ----------
  function init() {
    document.querySelectorAll('.tabbar button').forEach((b) => b.insertAdjacentHTML('afterbegin', icon(b.dataset.icon)));
    applyTheme();
    setTab('home');
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const cap = window.Capacitor;
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !(cap && cap.isNativePlatform && cap.isNativePlatform())) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
    // Обновляем «сегодня» при возврате в приложение (например, на следующий день)
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !modalStack.length) renderAll(); });
    window.__app = { get state() { return state; }, openDay, setTab, ui };
  }
  init();
})();
