# Генерирует иконки приложения (PWA + Android mipmap)
from PIL import Image, ImageDraw
import os, sys
root = os.path.join(os.path.dirname(__file__), '..')
def draw(size, maskable=False, round_=False):
    S = size * 4
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    bg = (232, 89, 12, 255)
    if maskable: d.rectangle([0, 0, S, S], fill=bg)
    elif round_: d.ellipse([0, 0, S, S], fill=bg)
    else: d.rounded_rectangle([0, 0, S, S], radius=int(S * .22), fill=bg)
    k = 0.62 if maskable else 0.78
    o = S * (1 - k) / 2; u = S * k
    w = (255, 255, 255, 255)
    # коробка (склад) + столбики роста
    bx0, by0, bx1, by1 = o + u*.10, o + u*.38, o + u*.90, o + u*.92
    d.rounded_rectangle([bx0, by0, bx1, by1], radius=int(u*.06), outline=w, width=int(u*.075))
    d.line([bx0, by0 + u*.17, bx1, by0 + u*.17], fill=w, width=int(u*.06))
    bw = u * .12
    for i, h in enumerate([.12, .22, .34]):
        x = o + u*(.26 + i*.18)
        d.rounded_rectangle([x, by1 - u*.08 - u*h, x + bw, by1 - u*.08], radius=int(bw*.3), fill=w)
    # стрелка вверх
    d.polygon([(o+u*.50, o+u*.04), (o+u*.68, o+u*.24), (o+u*.32, o+u*.24)], fill=w)
    d.rectangle([o+u*.45, o+u*.22, o+u*.55, o+u*.34], fill=w)
    return im.resize((size, size), Image.LANCZOS)
out = os.path.join(root, 'www', 'icons'); os.makedirs(out, exist_ok=True)
draw(192).save(os.path.join(out, 'icon-192.png'))
draw(512).save(os.path.join(out, 'icon-512.png'))
draw(512, maskable=True).save(os.path.join(out, 'icon-maskable-512.png'))
res = os.path.join(root, 'android-res')
for name, px in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    p = os.path.join(res, f'mipmap-{name}'); os.makedirs(p, exist_ok=True)
    draw(px).save(os.path.join(p, 'ic_launcher.png'))
    draw(px, round_=True).save(os.path.join(p, 'ic_launcher_round.png'))
print('icons ok')
