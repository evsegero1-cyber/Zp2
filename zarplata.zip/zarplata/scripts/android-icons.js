// Копирует иконки приложения в Android-проект (после `npx cap add android`)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
if (!fs.existsSync(res)) { console.error('Нет папки android — сначала выполните npx cap add android'); process.exit(1); }
for (const dir of fs.readdirSync(path.join(root, 'android-res')).filter((d) => d.startsWith('mipmap-'))) {
  for (const f of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const dst = path.join(res, dir);
    fs.mkdirSync(dst, { recursive: true });
    fs.copyFileSync(path.join(root, 'android-res', dir, f), path.join(dst, f));
  }
  const fg = path.join(res, dir, 'ic_launcher_foreground.png');
  if (fs.existsSync(fg)) fs.unlinkSync(fg);
}
// Заставка: нейтральный фон вместо логотипа Capacitor
for (const dir of fs.readdirSync(res).filter((d) => d.startsWith('drawable'))) {
  const f = path.join(res, dir, 'splash.png');
  if (fs.existsSync(f)) fs.copyFileSync(path.join(root, 'android-res', 'splash.png'), f);
}
// Адаптивные иконки по умолчанию (логотип Capacitor) убираем, чтобы использовалась наша
const anydpi = path.join(res, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpi)) fs.rmSync(anydpi, { recursive: true, force: true });
// Цвет статус-бара и фон заставки
const colors = path.join(res, 'values', 'colors.xml');
if (fs.existsSync(colors)) {
  let x = fs.readFileSync(colors, 'utf8');
  x = x.replace(/(name="colorPrimary">)[^<]*/, '$1#E8590C').replace(/(name="colorPrimaryDark">)[^<]*/, '$1#C24A0A');
  fs.writeFileSync(colors, x);
}
console.log('Иконки Android обновлены');
