const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');

test('календарь 2027: 365 дней, 247 рабочих, неделя с понедельника', () => {
  const all = C.yearKeys();
  assert.equal(all.length, 365);
  assert.equal(all.filter((k) => !C.dayInfo(k).off).length, 247);
  assert.equal(C.weekdayMon('2027-01-01'), 4); // пятница
  assert.equal(C.weekdayMon('2027-03-01'), 0); // понедельник
  const g = C.calendarGrid(0);
  assert.equal(g[0].filter((x) => x === null).length, 4);
  assert.equal(g.flat().filter(Boolean).length, 31);
  assert.ok(g.every((w) => w.length === 7));
  assert.equal(C.calendarGrid(1).flat().filter(Boolean).length, 28);
});

test('праздники и переносы', () => {
  assert.equal(C.workdaysInMonth(0), 15); // январь
  assert.equal(C.dayInfo('2027-02-20').off, false); // рабочая суббота
  assert.equal(C.dayInfo('2027-02-22').off, true);
  assert.equal(C.dayInfo('2027-11-05').off, true);
  assert.equal(C.dayInfo('2027-12-31').off, true);
  assert.equal(C.dayInfo('2027-01-11').off, false);
  assert.equal(C.dayInfo('2027-03-13').weekend, true);
});

test('расчёт: линии × тариф, факт отдельно', () => {
  const st = C.defaultState();
  assert.ok(C.saveEntry(st, '2027-03-01', { lines: '250' }).ok);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1250);
  C.saveEntry(st, '2027-03-02', { lines: 300, actual: '1600,50' });
  const e = st.entries['2027-03-02'];
  assert.equal(C.estimated(e), 1500);
  assert.equal(C.total(e), 1600.5);
  const s = C.summarize(st.entries, C.monthKeys(2));
  assert.equal(s.shifts, 2);
  assert.equal(s.lines, 550);
  assert.equal(s.estimated, 2750);
  assert.equal(s.actual, 1600.5);
  assert.equal(s.total, 2850.5);
  assert.equal(s.diff, 100.5);
  assert.equal(s.avgLines, 275);
  assert.equal(s.avgPerShift, 1425.25);
  assert.equal(s.best.key, '2027-03-02');
});

test('валидация', () => {
  const st = C.defaultState();
  assert.equal(C.saveEntry(st, '2027-03-01', {}).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: -1 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 2.5 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 'abc' }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 10, hours: 30 }).ok, false);
  assert.ok(C.saveEntry(st, '2027-03-01', { actual: 2000 }).ok); // только факт
  assert.equal(C.total(st.entries['2027-03-01']), 2000);
  assert.equal(C.saveEntry(st, '2027-02-30', { lines: 1 }).ok, false);
});

test('смена тарифа не пересчитывает старые записи', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 });
  C.setRate(st, '2027-04-01', 6);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-03-31'), 5);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-04-01'), 6);
  assert.equal(C.estimated(st.entries['2027-03-01']), 500);
  C.saveEntry(st, '2027-04-02', { lines: 100 });
  assert.equal(C.estimated(st.entries['2027-04-02']), 600);
  // редактирование старой записи сохраняет её тариф
  C.saveEntry(st, '2027-03-01', { lines: 200 });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000);
  // запись задним числом в марте берёт мартовский тариф
  C.setRate(st, '2027-01-01', 5.5);
  C.saveEntry(st, '2027-03-05', { lines: 3 });
  assert.equal(C.estimated(st.entries['2027-03-05']), 16.5);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000); // старая не изменилась
  // явный пересчёт по тарифу даты
  C.saveEntry(st, '2027-03-01', { lines: 200 }, { useCurrentRate: true });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1100);
  assert.throws(() => C.setRate(st, '2027-05-01', 0));
});

test('дробный тариф без ошибок округления', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-01-01', 5.1);
  for (let d = 1; d <= 10; d++) C.saveEntry(st, C.key(2027, 2, d), { lines: 3 });
  assert.equal(C.summarize(st.entries, C.monthKeys(2)).estimated, 153);
});

test('прогноз месяца', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 }); // 1000
  C.saveEntry(st, '2027-03-02', { lines: 400 }); // 2000
  // сегодня 2 марта: рабочих дней в марте 22, после 2 марта без записей — 20
  let s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(C.workdaysInMonth(2), 22);
  assert.equal(s.remainingShifts, 20);
  assert.equal(s.projected, 3000 + 1500 * 20);
  // план 15 смен
  st.settings.plannedShifts = 15;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.remainingShifts, 13);
  assert.equal(s.projected, 3000 + 1500 * 13);
  // месяц прошёл — прогноз = факт
  s = C.monthSummary(st, 2, '2027-04-10');
  assert.equal(s.projected, 3000);
  // цель
  st.settings.target = 30000;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.targetProgress, 0.1);
  assert.equal(s.needPerShift, C.round2(27000 / 13));
  // будущий месяц без данных — по средней года
  s = C.monthSummary(st, 4, '2026-11-08');
  assert.equal(s.projectionBasis, 'year');
  assert.equal(s.projected, 1500 * 15);
  // пустой год — прогноз неизвестен
  assert.equal(C.monthSummary(C.defaultState(), 0, '2026-11-08').projected, null);
});

test('недели и месяцы', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 }); // неделя 1 марта
  C.saveEntry(st, '2027-03-03', { lines: 100 });
  C.saveEntry(st, '2027-03-10', { lines: 200 }); // неделя 8 марта
  const w = C.weekly(st.entries, C.monthKeys(2));
  assert.equal(w.workedWeeks, 2);
  assert.equal(w.avgWeekly, 1000);
  assert.equal(w.weeks[0].monday, '2027-03-01');
  C.saveEntry(st, '2027-04-01', { lines: 300 });
  const ym = C.yearByMonths(st);
  assert.equal(ym[2].total, 2000);
  assert.equal(ym[3].total, 1500);
  assert.equal(ym[3].change, -0.25);
  assert.equal(ym[0].change, null);
  assert.equal(C.rangeKeys('2027-03-05', '2027-03-01').length, 5);
});

test('резервная копия: экспорт → импорт, слияние, CSV', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-06-01', 7);
  C.saveEntry(st, '2027-03-01', { lines: 100, actual: 600, hours: 8, comment: 'ночь; "склад"' });
  st.settings.target = 50000;
  const back = C.normalizeState(JSON.parse(C.exportData(st)));
  assert.equal(back.skipped, 0);
  assert.deepEqual(back.state.settings.rateHistory, st.settings.rateHistory);
  assert.equal(back.state.settings.target, 50000);
  assert.equal(back.state.entries['2027-03-01'].actual, 600);
  assert.equal(back.state.entries['2027-03-01'].rate, 5);
  assert.throws(() => C.normalizeState(null));
  assert.throws(() => C.normalizeState({ foo: 1 }));
  const other = C.defaultState();
  C.saveEntry(other, '2027-03-02', { lines: 5 });
  const merged = C.mergeStates(other, back.state);
  assert.equal(Object.keys(merged.entries).length, 2);
  const csv = C.toCSV(st);
  assert.ok(csv.includes('"ночь; ""склад"""'));
  assert.ok(csv.split('\r\n').length === 2);
});

test('форматирование', () => {
  assert.equal(C.fmtMoney(1250), '1 250 ₽');
  assert.equal(C.fmtMoney(1600.5), '1 600,5 ₽');
  assert.equal(C.fmtMoneyShort(1250), '1,3к');
  assert.equal(C.fmtMoneyShort(450), '450');
  assert.equal(C.fmtDateLong('2027-03-08'), '8 марта 2027');
});
