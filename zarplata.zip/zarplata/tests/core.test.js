const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');

test('календарь 2027: 365 дней, 247 рабочих, неделя с понедельника', () => {
  const all = C.yearKeys();
  assert.equal(all.length, 365);
  assert.equal(all.filter((k) => !C.dayInfo(k).off).length, 261); // все будни рабочие
  assert.equal(C.weekdayMon('2027-01-01'), 4); // пятница
  assert.equal(C.weekdayMon('2027-03-01'), 0); // понедельник
  const g = C.calendarGrid(0);
  assert.equal(g[0].filter((x) => x === null).length, 4);
  assert.equal(g.flat().filter(Boolean).length, 31);
  assert.ok(g.every((w) => w.length === 7));
  assert.equal(C.calendarGrid(1).flat().filter(Boolean).length, 28);
});

test('выходные только сб и вс, праздники рабочие (сделка / ИП)', () => {
  assert.equal(C.workdaysInMonth(0), 21);                 // январь 2027
  assert.equal(C.dayInfo('2027-01-01').off, false);      // 1 января — пятница, рабочий
  assert.equal(C.dayInfo('2027-03-08').off, false);
  assert.equal(C.dayInfo('2027-02-20').off, true);       // суббота — выходной
  assert.equal(C.dayInfo('2027-03-14').off, true);       // воскресенье
  assert.equal(C.workdaysInMonth(2), 23);
});

test('три года: 2026, 2027, 2028', () => {
  assert.deepEqual(C.YEARS, [2026, 2027, 2028]);
  assert.equal(C.yearKeys(2026).length, 365);
  assert.equal(C.yearKeys(2028).length, 366);            // високосный
  assert.equal(C.calendarGrid(1, 2028).flat().filter(Boolean).length, 29);
  assert.ok(C.inYear('2026-11-09') && C.inYear('2028-12-31') && !C.inYear('2029-01-01') && !C.inYear('2025-12-31'));
  assert.ok(C.inYear('2026-11-09', 2026) && !C.inYear('2026-11-09', 2027));
  assert.deepEqual(C.ymOf(0), { y: 2026, m: 0 });
  assert.deepEqual(C.ymOf(35), { y: 2028, m: 11 });
  assert.equal(C.indexOf(2027, 0), 12);
  const st = C.defaultState();
  assert.equal(C.rateFor(st.settings.rateHistory, '2026-05-01'), 5);
  C.saveEntry(st, '2026-12-01', { lines: 100, prod: 130 });
  C.saveEntry(st, '2028-02-29', { lines: 50 });
  C.setMonthData(st, 11, { service: 99.99, penalty: 100 }, 2026);
  const dec = C.monthSummary(st, 11, '2027-01-05', 2026);
  assert.equal(dec.grand, 500 + 15000 + 15000 - 100);
  assert.equal(C.monthSummary(st, 11, '2027-01-05').grand, 0); // декабрь 2027 — отдельно
  assert.equal(C.yearByMonths(st, 2028)[1].total, 250);
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.months['2026-12'].penalty, 100);
  assert.equal(back.entries['2028-02-29'].lines, 50);
});

test('цветовая гамма сохраняется в копии', () => {
  const st = C.defaultState();
  assert.equal(st.settings.palette.accent, '#e8590c');
  st.settings.palette = { id: 'custom', accent: '#123456', accent2: '#abcdef' };
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.settings.palette.accent, '#123456');
  const bad = C.normalizeState({ settings: { palette: { accent: 'red', accent2: '#000000' } }, entries: {} }).state;
  assert.equal(bad.settings.palette.accent, '#e8590c');
  assert.equal(C.PALETTES.length, 8);
});

test('расчёт: линии × тариф, факт отдельно', () => {
  const st = C.defaultState();
  assert.ok(C.saveEntry(st, '2027-03-01', { lines: '250' }).ok);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1250);
  C.saveEntry(st, '2027-03-02', { lines: 300, actual: '1600,50' });
  const e = st.entries['2027-03-02'];
  assert.equal(C.estimated(e), 1500);
  assert.equal(C.total(e), 1600.5);
  const s = C.summarize(st.entries, C.monthKeys(2));
  assert.equal(s.shifts, 2);
  assert.equal(s.lines, 550);
  assert.equal(s.estimated, 2750);
  assert.equal(s.actual, 1600.5);
  assert.equal(s.total, 2850.5);
  assert.equal(s.diff, 100.5);
  assert.equal(s.avgLines, 275);
  assert.equal(s.avgPerShift, 1425.25);
  assert.equal(s.best.key, '2027-03-02');
});

test('валидация', () => {
  const st = C.defaultState();
  assert.equal(C.saveEntry(st, '2027-03-01', {}).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: -1 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 2.5 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 'abc' }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-01', { lines: 10, hours: 30 }).ok, false);
  assert.ok(C.saveEntry(st, '2027-03-01', { actual: 2000 }).ok); // только факт
  assert.equal(C.total(st.entries['2027-03-01']), 2000);
  assert.equal(C.saveEntry(st, '2027-02-30', { lines: 1 }).ok, false);
});

test('смена тарифа не пересчитывает старые записи', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 });
  C.setRate(st, '2027-04-01', 6);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-03-31'), 5);
  assert.equal(C.rateFor(st.settings.rateHistory, '2027-04-01'), 6);
  assert.equal(C.estimated(st.entries['2027-03-01']), 500);
  C.saveEntry(st, '2027-04-02', { lines: 100 });
  assert.equal(C.estimated(st.entries['2027-04-02']), 600);
  // редактирование старой записи сохраняет её тариф
  C.saveEntry(st, '2027-03-01', { lines: 200 });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000);
  // запись задним числом в марте берёт мартовский тариф
  C.setRate(st, '2027-01-01', 5.5);
  C.saveEntry(st, '2027-03-05', { lines: 3 });
  assert.equal(C.estimated(st.entries['2027-03-05']), 16.5);
  assert.equal(C.estimated(st.entries['2027-03-01']), 1000); // старая не изменилась
  // явный пересчёт по тарифу даты
  C.saveEntry(st, '2027-03-01', { lines: 200 }, { useCurrentRate: true });
  assert.equal(C.estimated(st.entries['2027-03-01']), 1100);
  assert.throws(() => C.setRate(st, '2027-05-01', 0));
});

test('дробный тариф без ошибок округления', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-01-01', 5.1);
  for (let d = 1; d <= 10; d++) C.saveEntry(st, C.key(2027, 2, d), { lines: 3 });
  assert.equal(C.summarize(st.entries, C.monthKeys(2)).estimated, 153);
});

test('прогноз месяца', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 }); // 1000
  C.saveEntry(st, '2027-03-02', { lines: 400 }); // 2000
  // сегодня 2 марта: будних дней в марте 23, после 2 марта без записей — 21
  let s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.remainingShifts, 21);
  assert.equal(s.projected, 3000 + 1500 * 21);
  // план 15 смен
  st.settings.plannedShifts = 15;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.remainingShifts, 13);
  assert.equal(s.projected, 3000 + 1500 * 13);
  // месяц прошёл — прогноз = факт
  s = C.monthSummary(st, 2, '2027-04-10');
  assert.equal(s.projected, 3000);
  // цель
  st.settings.target = 30000;
  s = C.monthSummary(st, 2, '2027-03-02');
  assert.equal(s.targetProgress, 0.1);
  assert.equal(s.needPerShift, C.round2(27000 / 13));
  // будущий месяц без данных — по средней года
  s = C.monthSummary(st, 4, '2026-11-08');
  assert.equal(s.projectionBasis, 'year');
  assert.equal(s.projected, 1500 * 15); // план 15 смен
  // пустой год — прогноз неизвестен
  assert.equal(C.monthSummary(C.defaultState(), 0, '2026-11-08').projected, null);
});

test('недели и месяцы', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 100 }); // неделя 1 марта
  C.saveEntry(st, '2027-03-03', { lines: 100 });
  C.saveEntry(st, '2027-03-10', { lines: 200 }); // неделя 8 марта
  const w = C.weekly(st.entries, C.monthKeys(2));
  assert.equal(w.workedWeeks, 2);
  assert.equal(w.avgWeekly, 1000);
  assert.equal(w.weeks[0].monday, '2027-03-01');
  C.saveEntry(st, '2027-04-01', { lines: 300 });
  const ym = C.yearByMonths(st);
  assert.equal(ym[2].total, 2000);
  assert.equal(ym[3].total, 1500);
  assert.equal(ym[3].change, -0.25);
  assert.equal(ym[0].change, null);
  assert.equal(C.rangeKeys('2027-03-05', '2027-03-01').length, 5);
});

test('резервная копия: экспорт → импорт, слияние, CSV', () => {
  const st = C.defaultState();
  C.setRate(st, '2027-06-01', 7);
  C.saveEntry(st, '2027-03-01', { lines: 100, actual: 600, hours: 8, comment: 'ночь; "склад"' });
  st.settings.target = 50000;
  const back = C.normalizeState(JSON.parse(C.exportData(st)));
  assert.equal(back.skipped, 0);
  assert.deepEqual(back.state.settings.rateHistory, st.settings.rateHistory);
  assert.equal(back.state.settings.target, 50000);
  assert.equal(back.state.entries['2027-03-01'].actual, 600);
  assert.equal(back.state.entries['2027-03-01'].rate, 5);
  assert.throws(() => C.normalizeState(null));
  assert.throws(() => C.normalizeState({ foo: 1 }));
  const other = C.defaultState();
  C.saveEntry(other, '2027-03-02', { lines: 5 });
  const merged = C.mergeStates(other, back.state);
  assert.equal(Object.keys(merged.entries).length, 2);
  const csv = C.toCSV(st);
  assert.ok(csv.includes('"ночь; ""склад"""'));
  assert.ok(csv.split('\r\n').length === 2);
});

test('форматирование (неразрывные пробелы, чтобы суммы не переносились)', () => {
  assert.equal(C.fmtMoney(1250), '1\u00a0250\u00a0₽');
    assert.equal(C.fmtMoney(1600.5), '1\u00a0600,5\u00a0₽');
  assert.equal(C.fmtMoneyShort(1250), '1,3к');
  assert.equal(C.fmtMoneyShort(450), '450');
  assert.equal(C.fmtDateLong('2027-03-08'), '8 марта 2027');
});

test('производительность: за день и средняя за месяц', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: '115,5' });
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 130 });
  C.saveEntry(st, '2027-03-03', { lines: 200 }); // без производительности — не влияет на среднюю
  const s = C.summarize(st.entries, C.monthKeys(2));
  assert.equal(s.prodDays, 2);
  assert.equal(s.prodAvg, 122.75);
  assert.equal(C.saveEntry(st, '2027-03-04', { lines: 1, prod: -5 }).ok, false);
  assert.equal(C.saveEntry(st, '2027-03-04', { lines: 1, prod: 'x' }).ok, false);
});

test('премия за производительность: средняя ≥ 120% → 15 000 ₽', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 110 });
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 130 }); // средняя ровно 120
  let s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.prodOk, true);
  assert.equal(s.extras.prodBonus, 15000);
  assert.equal(s.grand, 2000 + 15000);
  C.saveEntry(st, '2027-03-02', { lines: 200, prod: 129.98 }); // 119,99 — премии нет
  s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.prodBonus, 0);
  assert.equal(s.grand, 2000);
});

test('сервис по зонам и штраф за месяц', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200 });
  const z = (v) => C.serviceZone(v, C.DEFAULT_BONUS);
  assert.equal(z(99.95), 'green');
  assert.equal(z(100), 'green');
  assert.equal(z(99.949), 'yellow');
  assert.equal(z(99.9), 'yellow');
  assert.equal(z(99.89), 'red');
  assert.equal(z(null), null);
  assert.ok(C.setMonthData(st, 2, { service: '99,97', penalty: '1500' }).ok);
  let s = C.monthSummary(st, 2, '2027-04-01');
  assert.equal(s.extras.zone, 'green');
  assert.equal(s.extras.serviceBonus, 15000);
  assert.equal(s.extras.penalty, 1500);
  assert.equal(s.grand, 1000 + 15000 - 1500);
  // жёлтая зона — сумма из настроек (по умолчанию 0)
  C.setMonthData(st, 2, { service: 99.92, penalty: 0 });
  assert.equal(C.monthSummary(st, 2, '2027-04-01').grand, 1000);
  st.settings.bonus.yellowAmount = 7000;
  assert.equal(C.monthSummary(st, 2, '2027-04-01').grand, 8000);
  assert.equal(C.setMonthData(st, 2, { service: 101 }).ok, false);
  assert.equal(C.setMonthData(st, 2, { penalty: -1 }).ok, false);
  // пустые значения удаляют данные месяца
  C.setMonthData(st, 2, { service: '', penalty: '' });
  assert.equal(st.months['2027-03'], undefined);
});

test('прогноз и годовая статистика учитывают премии и штраф', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 125 }); // 1000
  C.setMonthData(st, 2, { service: 99.96, penalty: 500 });
  const s = C.monthSummary(st, 2, '2027-03-01');
  // смены: 1000 + 1000 × 22 оставшихся будних дня; + 15000 + 15000 − 500
  assert.equal(s.remainingShifts, 22);
  assert.equal(s.projected, 23000 + 29500);
  const ym = C.yearByMonths(st);
  assert.equal(ym[2].grand, 30500);
  // нужная производительность до премии
  C.saveEntry(st, '2027-03-01', { lines: 200, prod: 100 });
  const s2 = C.monthSummary(st, 2, '2027-03-01');
  assert.equal(s2.needProd, C.round2((120 * 23 - 100) / 22));
});

test('резервная копия сохраняет премии, сервис, штраф и производительность', () => {
  const st = C.defaultState();
  C.saveEntry(st, '2027-05-04', { lines: 10, prod: 121 });
  C.setMonthData(st, 4, { service: 99.95, penalty: 300 });
  st.settings.bonus.yellowAmount = 5000;
  const back = C.normalizeState(JSON.parse(C.exportData(st))).state;
  assert.equal(back.entries['2027-05-04'].prod, 121);
  assert.equal(back.months['2027-05'].service, 99.95);
  assert.equal(back.months['2027-05'].penalty, 300);
  assert.equal(back.settings.bonus.yellowAmount, 5000);
  // старые копии без новых полей читаются
  const old = C.normalizeState({ settings: {}, entries: { '2027-01-11': { lines: 5, rate: 5 } } }).state;
  assert.equal(old.entries['2027-01-11'].prod, null);
  assert.deepEqual(old.months, {});
  const merged = C.mergeStates(C.defaultState(), back);
  assert.equal(merged.months['2027-05'].penalty, 300);
});
