// Данные из отчёта, которые администратор отправил сборщику: imports/{uid}/days/{день} = {lines?, prod?, actual?, source, at, applied}.
// Приложение сборщика само вносит их в свою смену (дальше — обычная синхронизация и рейтинг) и отмечает applied.
// Так администратор не пишет в чужие личные данные напрямую, а сборщик может отключить приём в профиле.
import { collection, doc, query, where, onSnapshot, updateDoc, serverTimestamp } from 'firebase/firestore';

export const IMPORT_FIELDS = ['lines', 'prod', 'actual'];

export function createImports(ctx) {
  const { db, emit } = ctx;
  let app = null, uid = null, unsub = null, pending = [];
  const api = {
    pending: [],                       // пришло, но не применено (приём выключен) — [{day, lines, prod, actual}]
    attach(a) { app = a; flush(); },
    // Применить отложенные (когда сборщик снова включил приём)
    applyPending() { flush(true); },
  };
  function flush(force) {
    if (!app || !uid) return;
    const accept = app.acceptImports ? app.acceptImports() : true;
    api.pending = pending.slice();
    if (!accept && !force) { emit('imports', { pending: api.pending.length }); return; }
    const done = [];
    for (const it of pending) {
      try { if (app.applyImport(it.day, it)) done.push(it); } catch (e) { console.warn('Импорт отчёта', e); }
    }
    if (done.length) emit('imports', { applied: done });
    for (const it of done) updateDoc(doc(db, 'imports', uid, 'days', it.day), { applied: true, appliedAt: serverTimestamp() }).catch(() => {});
    pending = pending.filter((x) => !done.includes(x));
    api.pending = pending.slice();
  }
  api.start = (u) => {
    if (unsub) { unsub(); unsub = null; }
    uid = u; pending = []; api.pending = [];
    if (!u) return;
    unsub = onSnapshot(query(collection(db, 'imports', u, 'days'), where('applied', '==', false)), (q) => {
      // только подтверждённые сервером (не своё эхо)
      if (q.metadata.hasPendingWrites) return;
      pending = q.docs.map((d) => {
        const x = d.data(), it = { day: d.id, source: x.source || '' };
        for (const f of IMPORT_FIELDS) if (typeof x[f] === 'number') it[f] = x[f];
        return it;
      });
      flush();
    }, () => {});
  };
  return api;
}
