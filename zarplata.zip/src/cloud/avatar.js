// Аватары без Cloud Storage (на бесплатном тарифе его нет): картинка хранится прямо в профиле текстом (data:URL).
// Готовые аватары — эмодзи на цветном круге: {kind:'preset', v:'🐱|#E8590C'}.

export const PRESETS = [
  ['🐱', '#E8590C'], ['🐶', '#2F6FDB'], ['🦊', '#D9480F'], ['🐻', '#8B5E3C'], ['🐼', '#2B8A3E'], ['🐯', '#E67700'],
  ['🦁', '#C79100'], ['🐸', '#37B24D'], ['🐧', '#1C7ED6'], ['🦉', '#7048E8'], ['🐺', '#495057'], ['🐰', '#D6336C'],
  ['🚀', '#5F3DC4'], ['📦', '#B35C1E'], ['⚡', '#F08C00'], ['🔥', '#C92A2A'], ['⭐', '#3B5BDB'], ['💪', '#0C8599'],
];
export const presetAvatar = (i) => ({ kind: 'preset', v: PRESETS[i][0] + '|' + PRESETS[i][1] });
export const defaultAvatar = (seed = '') => {
  let h = 0; for (const ch of String(seed)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return presetAvatar(h % PRESETS.length);
};

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Не удалось открыть фото. Попробуйте другое (JPG или PNG).')); };
    img.src = url;
  });
}
// Квадрат по центру → size×size JPEG, уменьшая качество/размер, пока не влезет в maxChars
function encode(img, size, maxChars) {
  const s = Math.min(img.naturalWidth || img.width, img.naturalHeight || img.height);
  const sx = ((img.naturalWidth || img.width) - s) / 2, sy = ((img.naturalHeight || img.height) - s) / 2;
  for (let px = size; px >= 48; px = Math.round(px * 0.8)) {
    const c = document.createElement('canvas'); c.width = c.height = px;
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, px, px);
    g.imageSmoothingQuality = 'high'; g.drawImage(img, sx, sy, s, s, 0, 0, px, px);
    for (let q = 0.86; q >= 0.4; q -= 0.12) { const url = c.toDataURL('image/jpeg', q); if (url.length <= maxChars) return url; }
  }
  throw new Error('Фото слишком большое');
}
// Фото профиля (~256 px, ≤ 55 000 символов) — правило базы допускает до 60 000
export async function photoAvatar(file) {
  if (!file || !/^image\//.test(file.type || 'image/')) throw new Error('Выберите изображение');
  const img = await loadImage(file);
  return { kind: 'photo', v: encode(img, 256, 55000) };
}
// Маленькая копия для рейтинга (≤ 11 000 символов) — чтобы таблица лидеров грузилась быстро
export async function smallAvatar(av) {
  if (!av || av.kind !== 'photo') return av;
  if (av.v.length <= 11000) return av;
  const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = av.v; });
  return { kind: 'photo', v: encode(img, 72, 11000) };
}
