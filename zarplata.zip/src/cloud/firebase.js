// Подключение к Firebase. Конфиг подставляется при сборке из переменных окружения (scripts/build.js → esbuild define).
// В репозитории ключей нет: локально — файл .env, в GitHub — Secrets.
import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, browserPopupRedirectResolver, connectAuthEmulator } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, memoryLocalCache, connectFirestoreEmulator } from 'firebase/firestore';

/* global __FIREBASE_CONFIG__, __FIREBASE_EMULATORS__ */
export const config = __FIREBASE_CONFIG__;
export const emulators = __FIREBASE_EMULATORS__;
export { browserPopupRedirectResolver };

let app = null, auth = null, db = null;

export function init() {
  if (app) return { app, auth, db };
  app = initializeApp(config);
  // Вход сохраняется между запусками (Safari/PWA/WebView). Если IndexedDB недоступен (приватный режим) — localStorage.
  // Окно входа Google (popupRedirectResolver) здесь НЕ подключаем: оно грузит страницу с сервера при каждом запуске,
  // и без сети вход (а с ним и база) ждали его десятки секунд. Подключается только при входе через Google.
  try {
    auth = initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence] });
  } catch (e) { auth = getAuth(app); }
  auth.languageCode = 'ru';
  // Локальный кэш Firestore: приложение работает офлайн, изменения уходят при появлении сети
  let cache;
  try { cache = persistentLocalCache({ tabManager: persistentMultipleTabManager() }); } catch (e) { cache = memoryLocalCache(); }
  db = initializeFirestore(app, { localCache: cache, ignoreUndefinedProperties: true });
  if (emulators) {
    const host = typeof emulators === 'string' ? emulators : '127.0.0.1';
    connectAuthEmulator(auth, `http://${host}:9099`, { disableWarnings: true });
    connectFirestoreEmulator(db, host, 8080);
  }
  return { app, auth, db };
}
