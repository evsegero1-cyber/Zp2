// Логика синхронизации без Firebase — чистые функции, покрыты тестами (tests/sync.test.mjs).
//
// Модель: у устройства есть «база» — то, что, по его сведениям, сейчас лежит в облаке.
//  * локальная правка = отличие локального состояния от базы → уходит в облако;
//  * облачная правка  = отличие облака от базы → применяется на устройстве;
//  * если день изменён и там и там — побеждает более свежая запись (updatedAt).
// Так офлайн-правки не теряются, а удаление на одном устройстве удаляет день и на другом.

export const DOC_KEYS = ['settings', 'months', 'marks', 'payouts'];

// Сравнение без учёта порядка ключей
export function stable(v) {
  if (v === undefined) return 'u';
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  return '{' + Object.keys(v).filter((k) => v[k] !== undefined).sort().map((k) => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
}
export const same = (a, b) => stable(a) === stable(b);
const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));

// Состояние приложения → документ пользователя + записи по дням
export function splitState(state) {
  const doc = {};
  for (const k of DOC_KEYS) doc[k] = clone(state[k] || {});
  return { doc, entries: clone(state.entries || {}) };
}
export function joinState(local, part) {
  const out = clone(local);
  for (const k of DOC_KEYS) out[k] = clone(part.doc[k] || (k === 'settings' ? local.settings : {}));
  out.entries = clone(part.entries || {});
  return out;
}

// Есть ли на устройстве что-то своё (иначе при входе просто берём облако)
export function hasLocalData(state, defaults) {
  if (Object.keys(state.entries || {}).length) return true;
  if (Object.keys(state.marks || {}).length || Object.keys(state.payouts || {}).length) return true;
  if (Object.keys(state.months || {}).length) return true;
  return defaults ? !same(state.settings, defaults.settings) : false;
}
export const isEmptyCloud = (cloud) => !cloud.doc && !Object.keys(cloud.entries || {}).length;

// Что отправить в облако: дни, которые отличаются от базы, удалённые дни и документ (если изменился)
export function diffLocal(local, base) {
  const upserts = {}, deletes = [];
  const be = (base && base.entries) || {};
  for (const [k, e] of Object.entries(local.entries)) if (!same(e, be[k])) upserts[k] = e;
  for (const k of Object.keys(be)) if (!(k in local.entries)) deletes.push(k);
  const doc = !base || !base.doc || !same(local.doc, pickDoc(base.doc)) ? local.doc : null;
  return { upserts, deletes, doc, count: Object.keys(upserts).length + deletes.length + (doc ? 1 : 0) };
}
const pickDoc = (d) => { const o = {}; for (const k of DOC_KEYS) o[k] = d[k] || {}; return o; };

// Применить снимок облака. remote = {doc: {...} | null, docUpdatedAt, entries: {k: entry}}
// localDocUpdatedAt — когда документ последний раз менялся на устройстве (для спора «кто свежее»).
export function applyRemote(local, base, remote, localDocUpdatedAt = 0) {
  const be = (base && base.entries) || {}, re = remote.entries || {}, le = local.entries;
  const entries = {};
  let changed = false;
  const keys = new Set([...Object.keys(le), ...Object.keys(be), ...Object.keys(re)]);
  for (const k of keys) {
    const l = le[k], b = be[k], r = re[k];
    let v;
    if (same(l, b)) v = r;                      // на устройстве не трогали — берём облако
    else if (same(r, b)) v = l;                 // в облаке не трогали — оставляем своё
    else if (l && r) v = (r.updatedAt || 0) > (l.updatedAt || 0) ? r : l; // изменили оба — свежее
    else v = l || r;                            // удалили с одной стороны, изменили с другой — изменение важнее
    if (v !== undefined) entries[k] = v;
    if (!same(v, l)) changed = true;
  }
  let doc = local.doc;
  if (remote.doc) {
    const rd = pickDoc(remote.doc), bd = base && base.doc ? pickDoc(base.doc) : null;
    if (bd && same(local.doc, bd)) doc = rd;
    else if (bd && same(rd, bd)) doc = local.doc;
    else if (!same(rd, local.doc)) doc = (remote.docUpdatedAt || 0) > (localDocUpdatedAt || 0) ? rd : local.doc;
    if (!same(doc, local.doc)) changed = true;
  }
  return { part: { doc: clone(doc), entries: clone(entries) }, base: { doc: remote.doc ? pickDoc(remote.doc) : null, entries: clone(re) }, changed };
}
