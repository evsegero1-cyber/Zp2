// Публичная статистика сборщика: чистые функции без Firebase.
// Пересчёт делается «по одному дню» — ровно так, как это проверяют правила firestore.rules (ARCHITECTURE.md §4).

export const MAX_DAY_LINES = 5000;      // больше за смену не публикуется (защита от опечаток)
export const MAX_RATE = 50;             // ₽ за линию — верхняя граница для проверки заработка

const r2 = (v) => Math.round(v * 100) / 100;
const worked = (l) => (l > 0 ? 1 : 0);
const avgOf = (lines, days) => (days > 0 ? lines / days : 0);
const pad = (n) => String(n).padStart(2, '0');

// Понедельник недели дня 'YYYY-MM-DD' (в UTC — так же считает timestamp.dayOfWeek() в правилах)
export function mondayOf(day) {
  const [y, m, d] = day.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d));
  const dow = (t.getUTCDay() + 6) % 7; // 0 = понедельник
  t.setUTCDate(t.getUTCDate() - dow);
  return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`;
}

export function emptyStats(profile, showEarn = false) {
  return {
    visible: false, showEarn: !!showEarn,
    nick: profile.nick, name: profile.name, avatar: profile.avatar,
    lastDay: '', lastWeek: '',
    totals: { lines: 0, days: 0, earn: 0, best: 0, avg: 0 },
    day: { key: '', lines: 0, earn: 0 },
    week: { key: '', lines: 0, days: 0, earn: 0, avg: 0 },
    month: { key: '', lines: 0, days: 0, earn: 0, avg: 0 },
  };
}

// Что публикуется о дне: только линии и оценка «линии × ставка» (без фактических сумм, премий, конверта)
export function publicDay(entry, showEarn) {
  const lines = Math.round(Number(entry && entry.lines) || 0);
  if (!(lines > 0) || lines > MAX_DAY_LINES) return null;
  const rate = Math.min(MAX_RATE, Math.max(0, Number(entry.rate) || 0));
  return { lines, earn: showEarn ? r2(lines * rate) : 0 };
}

function bucket(o, key, nl, ol, en, eo, withDays) {
  if (key === o.key) {
    const b = { key, lines: o.lines + nl - ol, earn: Math.max(0, r2(o.earn + en - eo)) };
    if (withDays) { b.days = o.days + worked(nl) - worked(ol); b.avg = avgOf(b.lines, b.days); }
    return b;
  }
  if (key > o.key) {
    const b = { key, lines: nl, earn: r2(en) };
    if (withDays) { b.days = worked(nl); b.avg = avgOf(b.lines, b.days); }
    return b;
  }
  return { ...o };
}

// Новая статистика после изменения одного дня.
// next/prev — публичные данные дня после и до ({lines, earn} или null); best — личный рекорд по всем дням (считает клиент).
export function applyDay(stats, day, next, prev, best) {
  const nl = next ? next.lines : 0, ol = prev ? prev.lines : 0;
  const en = next && stats.showEarn ? next.earn : 0, eo = prev && stats.showEarn ? prev.earn : 0;
  const t = stats.totals;
  const totals = {
    lines: t.lines + nl - ol,
    days: t.days + worked(nl) - worked(ol),
    earn: stats.showEarn ? Math.max(0, r2(t.earn + en - eo)) : 0,
    best: 0, avg: 0,
  };
  totals.avg = avgOf(totals.lines, totals.days);
  totals.best = Math.min(totals.lines, Math.max(nl, best != null ? best : t.best));
  const week = mondayOf(day);
  return {
    ...stats,
    lastDay: day, lastWeek: week, totals,
    day: day >= stats.day.key ? { key: day, lines: nl, earn: r2(en) } : { ...stats.day },
    week: bucket(stats.week, week, nl, ol, en, eo, true),
    month: bucket(stats.month, day.slice(0, 7), nl, ol, en, eo, true),
  };
}

// Сравнение локальных записей с опубликованными днями: какие дни нужно записать/удалить
export function diffDays(entries, published, showEarn) {
  const ops = [];
  const keys = new Set([...Object.keys(entries || {}), ...Object.keys(published || {})]);
  for (const k of [...keys].sort()) {
    const want = publicDay(entries[k], showEarn), have = published[k] || null;
    if (!want && !have) continue;
    if (want && have && want.lines === have.lines && want.earn === have.earn) continue;
    ops.push({ day: k, next: want, prev: have });
  }
  return ops;
}

// Личный рекорд среди публикуемых дней
export function bestOf(entries) {
  let b = 0;
  for (const k in entries || {}) { const p = publicDay(entries[k], false); if (p && p.lines > b) b = p.lines; }
  return b;
}
