// Синхронизация данных калькулятора с облаком (users/{uid} + users/{uid}/entries/{день}).
// Логика слияния — в sync-core.js (покрыта тестами), здесь только работа с Firestore.
import { doc, collection, onSnapshot, writeBatch, waitForPendingWrites, serverTimestamp } from 'firebase/firestore';
import { splitState, joinState, diffLocal, applyRemote, hasLocalData, isEmptyCloud, same } from './sync-core.js';

const BASE_KEY = 'zarplata2027:sync';      // база: что, по сведениям устройства, лежит в облаке (+ uid)
const BACKUP_KEY = 'zarplata2027:backup-before-sync';

const readJSON = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const writeJSON = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } };

export function createSync(ctx) {
  const { db, emit } = ctx;
  let app = null;              // адаптер приложения: get(), set(state), defaults(), merge(a,b), exportData(state)
  let uid = null, unsubs = [], remote = { doc: null, docUpdatedAt: 0, entries: {} };
  let gotDoc = false, gotEntries = false, mode = 'off', timer = 0, pushing = false, again = false;
  let saved = readJSON(BASE_KEY) || {};

  const api = {
    status: 'off',             // off | loading | needs-choice | syncing | synced | offline | error
    lastSynced: saved.at || null,
    pendingChoice: null,       // {localDays, cloudDays} — нужно спросить пользователя, как объединить
    attach(adapter) { app = adapter; if (uid && mode === 'waiting') start(uid); },
    changed() { if (mode === 'live') { clearTimeout(timer); timer = setTimeout(push, 700); } },
    resolveChoice,
    backup: () => readJSON(BACKUP_KEY),
    forget() { saved = {}; localStorage.removeItem(BASE_KEY); },
    // Состояние смены за день в облаке: 'ok' — сервер подтвердил ровно эту версию; 'pending' — отправляется;
    // 'offline' — ждёт сети; null — без аккаунта или облако ещё не загружено
    dayState(day, entry) {
      if (!uid || !entry || saved.uid !== uid || !saved.base) return null;
      if (same(entry, (saved.base.entries || {})[day])) return 'ok';
      return navigator.onLine && mode === 'live' && api.status !== 'error' ? 'pending' : 'offline';
    },
  };
  const setStatus = (s, extra) => { api.status = s; emit('sync', { status: s, lastSynced: api.lastSynced, ...extra }); };
  const persistBase = (base) => { saved = { uid, at: Date.now(), docTime: saved.docTime || 0, base }; api.lastSynced = saved.at; writeJSON(BASE_KEY, saved); };

  function stop() {
    unsubs.forEach((u) => u()); unsubs = []; clearTimeout(timer);
    uid = null; mode = 'off'; gotDoc = gotEntries = false; remote = { doc: null, docUpdatedAt: 0, entries: {} };
    api.pendingChoice = null; setStatus('off');
  }
  function start(u) {
    if (uid === u && mode !== 'off' && mode !== 'waiting') return;
    uid = u;
    if (!app) { mode = 'waiting'; return; }   // приложение ещё не подключилось — начнём после attach()
    // Уже синхронизировались на этом устройстве — работаем сразу, даже без сети: правки ставятся в очередь
    // Firestore (она переживает перезапуск) и уйдут при появлении интернета. Облачные правки применим, когда ответит сервер.
    if (saved.uid === uid && saved.base) { mode = 'live'; setStatus(navigator.onLine ? 'loading' : 'offline'); setTimeout(push, 300); }
    else { mode = 'loading'; setStatus(navigator.onLine ? 'loading' : 'offline'); }
    const userRef = doc(db, 'users', uid);
    unsubs.push(onSnapshot(userRef, { includeMetadataChanges: true }, (s) => {
      if (s.metadata.hasPendingWrites) return;
      const d = s.exists() ? s.data() : null;
      remote.doc = d ? { settings: d.settings || {}, months: d.months || {}, marks: d.marks || {}, payouts: d.payouts || {} } : null;
      remote.docUpdatedAt = d ? d.clientUpdatedAt || 0 : 0;
      gotDoc = gotDoc || !s.metadata.fromCache;
      onRemote(s.metadata.fromCache);
    }, onError));
    unsubs.push(onSnapshot(collection(db, 'users', uid, 'entries'), { includeMetadataChanges: true }, (q) => {
      if (q.metadata.hasPendingWrites) return;
      const ent = {}; q.forEach((d) => { ent[d.id] = d.data(); });
      remote.entries = ent;
      gotEntries = gotEntries || !q.metadata.fromCache;
      onRemote(q.metadata.fromCache);
    }, onError));
  }
  function onError(e) { console.error('sync', e); setStatus('error', { message: e.code === 'permission-denied' ? 'Нет доступа к данным' : 'Ошибка синхронизации' }); }

  function onRemote(fromCache) {
    // Применяем только подтверждённые сервером снимки: данные из локального кэша могут быть неполными
    // (например, после очистки кэша браузера), и «пустой» кэш нельзя принимать за удаление всех смен.
    if (fromCache) { if (!navigator.onLine && mode !== 'choice' && !pushing) setStatus('offline'); return; }
    if (!gotDoc || !gotEntries) return;   // ждём ответа по обоим запросам (документ и смены)
    if (mode === 'loading') {
      {
        const local = app.get();
        const localHas = hasLocalData(local, app.defaults());
        if (isEmptyCloud(remote)) { mode = 'live'; saved = { uid, docTime: 0, base: { doc: null, entries: {} } }; }
        else if (!localHas) { mode = 'live'; saved = { uid, docTime: 0, base: { doc: null, entries: {} } }; }
        else {
          mode = 'choice';
          api.pendingChoice = { localDays: Object.keys(local.entries).length, cloudDays: Object.keys(remote.entries).length };
          setStatus('needs-choice', api.pendingChoice);
          return;
        }
      }
    }
    if (mode !== 'live') return;
    const local = app.get();
    const r = applyRemote(splitState(local), saved.base, remote, saved.docTime || 0);
    if (r.changed) app.set(joinState(local, r.part), 'remote');
    persistBase(r.base);
    push();
  }

  // Первый вход с данными и там и там: merge — объединить, cloud — взять облако, local — взять с устройства
  async function resolveChoice(choice) {
    if (mode !== 'choice') return;
    const local = app.get();
    writeJSON(BACKUP_KEY, { at: Date.now(), data: app.exportData(local) });   // копия до любых изменений
    const cloudState = joinState(local, { doc: remote.doc || splitState(local).doc, entries: remote.entries });
    let next = local;
    if (choice === 'cloud') next = cloudState;
    else if (choice === 'merge') next = app.merge(local, cloudState);
    saved = { uid, docTime: Date.now(), base: { doc: remote.doc, entries: JSON.parse(JSON.stringify(remote.entries)) } };
    persistBase(saved.base);
    api.pendingChoice = null; mode = 'live';
    if (next !== local) app.set(next, 'choice');
    await push();
  }

  async function push() {
    if (mode !== 'live' || !app) return;
    if (pushing) { again = true; return; }
    const part = splitState(app.get());
    const d = diffLocal(part, saved.base);
    if (!d.count) { setStatus(navigator.onLine ? 'synced' : 'offline'); return; }
    pushing = true; setStatus('syncing');
    try {
      const ops = [];
      for (const [k, e] of Object.entries(d.upserts)) ops.push((b) => b.set(doc(db, 'users', uid, 'entries', k), e));
      for (const k of d.deletes) ops.push((b) => b.delete(doc(db, 'users', uid, 'entries', k)));
      if (d.doc) {
        const now = Date.now();
        ops.push((b) => b.set(doc(db, 'users', uid), { ...d.doc, clientUpdatedAt: now, updatedAt: serverTimestamp() }));
        saved.docTime = now;
      }
      // Пакеты до 450 операций. Офлайн запись сразу попадает в очередь Firestore (переживает перезапуск) и уйдёт при появлении сети.
      const commits = [];
      for (let i = 0; i < ops.length; i += 450) { const b = writeBatch(db); ops.slice(i, i + 450).forEach((f) => f(b)); commits.push(b.commit()); }
      if (!navigator.onLine) setStatus('offline');
      await Promise.all(commits);       // офлайн ждёт, пока сервер не подтвердит
      await waitForPendingWrites(db);
      // База обновляется только после подтверждения сервера: если запись потеряется, правки отправятся снова
      // (повторная отправка безопасна — это те же значения), а не будут считаться «уже в облаке».
      const base = { doc: d.doc || (saved.base && saved.base.doc), entries: { ...((saved.base && saved.base.entries) || {}) } };
      Object.assign(base.entries, JSON.parse(JSON.stringify(d.upserts))); d.deletes.forEach((k) => delete base.entries[k]);
      persistBase(base);
      setStatus('synced');
    } catch (e) { onError(e); }
    finally { pushing = false; if (again) { again = false; push(); } }
  }
  // Сеть вернулась — дослать правки; приложение снова на экране — проверить, всё ли ушло
  window.addEventListener('online', () => { if (mode === 'live') { setStatus(pushing ? 'syncing' : 'loading'); api.changed(); } });
  window.addEventListener('offline', () => { if (mode === 'live' || mode === 'loading') setStatus('offline'); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && mode === 'live') api.changed(); });

  api.start = start; api.stop = stop;
  return api;
}
