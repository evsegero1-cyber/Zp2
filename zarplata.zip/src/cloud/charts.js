// Графики сравнения сборщиков (Chart.js). Отдельный файл www/charts.js — грузится только при открытии «Сравнения».
import Chart from 'chart.js/auto';
window.Chart = Chart;
document.dispatchEvent(new CustomEvent('charts:ready'));
