// «Сборщики»: публикация своей статистики (по согласию), рейтинг, список и поиск, публичные профили, данные для сравнения.
// Публичные данные — только линии и (отдельно разрешаемая) оценка «линии × ставка». Каждый день публикуется
// транзакцией вместе с пересчётом итогов; правила базы проверяют, что итоги равны сумме дней.
import {
  doc, collection, query, where, orderBy, limit, startAt, endAt, getDoc, getDocs, onSnapshot, runTransaction,
  writeBatch, setDoc, updateDoc, serverTimestamp, documentId,
} from 'firebase/firestore';
import { emptyStats, publicDay, applyDay, diffDays, bestOf, mondayOf } from './stats.js';
import { smallAvatar } from './avatar.js';
import { same } from './sync-core.js';

const pad = (n) => String(n).padStart(2, '0');
export const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const periodKey = (period, today = dayKey()) =>
  period === 'day' ? today : period === 'week' ? mondayOf(today) : period === 'month' ? today.slice(0, 7) : null;

export function createSocial(ctx) {
  const { db, emit } = ctx;
  let app = null, uid = null, statsUnsub = null, published = null, running = false, again = false, timer = 0;

  const api = {
    my: null,               // моя publicStats (null — не опубликовано)
    myLoaded: false,
    progress: null,         // {done, total} — идёт публикация
    attach(a) { app = a; },
    // ---------- Публикация ----------
    // visible: показывать статистику; showEarn: показывать заработок
    async setVisibility({ visible, showEarn }) {
      const prof = ctx.account.profile;
      if (!uid || !prof) throw Object.assign(new Error('Сначала заполните профиль'), { code: 'no-profile' });
      if (!visible) return unpublish();
      if (!api.my) {
        const st = { ...emptyStats({ nick: prof.nick, name: prof.name, avatar: await smallAvatar(prof.avatar) }, !!showEarn), visible: true };
        await setDoc(doc(db, 'publicStats', uid), { ...st, updatedAt: serverTimestamp() });
        published = {};
      } else if (!!showEarn !== !!api.my.showEarn || !api.my.visible) {
        // смена «показывать заработок»: флаг и (если скрываем) обнуление сумм; дни перепишутся при сверке
        const patch = { showEarn: !!showEarn, visible: true, updatedAt: serverTimestamp() };
        if (!showEarn) for (const k of ['totals', 'day', 'week', 'month']) patch[k + '.earn'] = 0;
        await updateDoc(doc(db, 'publicStats', uid), patch);
      }
      return api.reconcile(true);
    },
    // Сверить опубликованные дни с записями на устройстве и дослать разницу (по одному дню в транзакции)
    async reconcile(force) {
      if (!uid || !app || !(api.my && api.my.visible) && !force) return;
      if (running) { again = true; return; }
      running = true;
      try {
        if (!published || force) published = await loadMyDays();
        const st = (await getDoc(doc(db, 'publicStats', uid))).data();
        if (!st || !st.visible) return;
        const limitDay = dayKey(new Date(Date.now() + 864e5)); // будущие смены не публикуются
        const entries = {}; const all = app.get().entries;
        for (const k in all) if (k <= limitDay) entries[k] = all[k];
        const ops = diffDays(entries, published, st.showEarn);
        const best = bestOf(entries);
        api.progress = ops.length > 3 ? { done: 0, total: ops.length } : null;
        for (let i = 0; i < ops.length; i++) {
          await publishDay(ops[i].day, ops[i].next, best);
          if (api.progress) { api.progress.done = i + 1; emit('social', { progress: api.progress }); }
        }
      } catch (e) { console.error('Публикация статистики', e); published = null; emit('error', { message: 'Не удалось обновить статистику в рейтинге — повторю позже' }); }
      finally {
        running = false; api.progress = null; emit('social', { progress: null });
        if (again) { again = false; api.reconcile(); }
      }
    },
    changed() { clearTimeout(timer); timer = setTimeout(() => api.reconcile(), 2500); },
    // Профиль изменился — обновить копию ника/имени/аватара в рейтинге
    async profileChanged() {
      const prof = ctx.account.profile;
      if (!uid || !api.my || !prof) return;
      await updateDoc(doc(db, 'publicStats', uid), { nick: prof.nick, name: prof.name, avatar: await smallAvatar(prof.avatar), updatedAt: serverTimestamp() });
    },

    // ---------- Чтение ----------
    // Рейтинг: period = day|week|month|all, metric = lines|earn|avg|days. Обновляется сам (onSnapshot).
    watchLeaderboard({ period, metric }, cb) {
      const cons = [where('visible', '==', true)];
      if (metric === 'earn') cons.push(where('showEarn', '==', true));
      const key = periodKey(period);
      if (key) cons.push(where(period + '.key', '==', key));
      const field = (period === 'all' ? 'totals' : period) + '.' + metric;
      const q = query(collection(db, 'publicStats'), ...cons, orderBy(field, 'desc'), limit(50));
      return onSnapshot(q, (s) => cb(null, s.docs.map((d) => ({ uid: d.id, ...d.data() })).filter((x) => (period === 'all' ? x.totals : x[period])[metric] > 0)),
        (e) => cb(e));
    },
    async listProfiles(q = '') {
      q = String(q).trim().toLowerCase().replace(/^@/, '');
      const c = collection(db, 'publicProfiles');
      const qq = q ? query(c, orderBy('nick'), startAt(q), endAt(q + ''), limit(40)) : query(c, orderBy('nick'), limit(60));
      return (await getDocs(qq)).docs.map((d) => ({ uid: d.id, ...d.data() }));
    },
    async getPublic(id) {
      const p = await getDoc(doc(db, 'publicProfiles', id));
      let stats = null;
      try { const s = await getDoc(doc(db, 'publicStats', id)); stats = s.exists() ? s.data() : null; } catch { stats = null; } // скрыта
      return { profile: p.exists() ? { uid: id, ...p.data() } : null, stats };
    },
    // Опубликованные дни сборщика за период [from, to] (ключи 'YYYY-MM-DD')
    async days(id, from, to) {
      const q = query(collection(db, 'publicDays', id, 'days'), where(documentId(), '>=', from), where(documentId(), '<=', to));
      const out = {}; (await getDocs(q)).forEach((d) => { out[d.id] = d.data(); });
      return out;
    },
  };

  async function loadMyDays() {
    const out = {}; (await getDocs(collection(db, 'publicDays', uid, 'days'))).forEach((d) => { out[d.id] = d.data(); });
    return out;
  }
  async function publishDay(day, next, best) {
    const sRef = doc(db, 'publicStats', uid), dRef = doc(db, 'publicDays', uid, 'days', day);
    let result = null;
    await runTransaction(db, async (tx) => {
      const s = await tx.get(sRef), d = await tx.get(dRef);
      if (!s.exists()) throw new Error('Статистика не опубликована');
      const st = s.data(), prev = d.exists() ? d.data() : null;
      const nxt = next ? { lines: next.lines, earn: st.showEarn ? next.earn : 0 } : null;
      result = nxt;
      if (same(prev, nxt)) return;
      const n = applyDay(st, day, nxt, prev, best);
      tx.set(sRef, { ...n, updatedAt: serverTimestamp() });
      if (nxt) tx.set(dRef, nxt); else tx.delete(dRef);
    });
    if (result) published[day] = result; else delete published[day];
  }
  async function unpublish() {
    const days = await getDocs(collection(db, 'publicDays', uid, 'days'));
    const refs = [doc(db, 'publicStats', uid), ...days.docs.map((d) => d.ref)]; // сначала итоги — потом правила разрешат удалить дни
    for (let i = 0; i < refs.length; i += 450) { const b = writeBatch(db); refs.slice(i, i + 450).forEach((r) => b.delete(r)); await b.commit(); }
    published = null;
  }

  api.start = (u) => {
    if (statsUnsub) statsUnsub();
    uid = u; published = null; api.my = null; api.myLoaded = false;
    if (!u) { statsUnsub = null; emit('social', {}); return; }
    statsUnsub = onSnapshot(doc(db, 'publicStats', u), (s) => {
      const wasVisible = api.my && api.my.visible;
      api.my = s.exists() ? s.data() : null; api.myLoaded = true;
      emit('social', { my: api.my });
      if (api.my && api.my.visible && !wasVisible) api.changed(); // при запуске сверить дни
    }, () => { api.myLoaded = true; emit('social', { my: null }); });
  };
  return api;
}
