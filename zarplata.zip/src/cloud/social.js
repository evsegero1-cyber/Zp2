// «Сборщики»: публикация своей статистики (по согласию), рейтинг, список и поиск, публичные профили, данные для сравнения.
// Публичные данные — только линии и (отдельно разрешаемая) оценка «линии × ставка». Каждый день публикуется
// транзакцией вместе с пересчётом итогов; правила базы проверяют, что итоги равны сумме дней.
import {
  doc, collection, query, where, orderBy, limit, startAt, endAt, getDoc, getDocs, onSnapshot, runTransaction,
  writeBatch, setDoc, updateDoc, serverTimestamp, documentId,
} from 'firebase/firestore';
import { emptyStats, publicDay, applyDay, diffDays, bestOf, mondayOf } from './stats.js';
import { smallAvatar } from './avatar.js';
import { same } from './sync-core.js';

const pad = (n) => String(n).padStart(2, '0');
export const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const periodKey = (period, today = dayKey()) =>
  period === 'day' ? today : period === 'week' ? mondayOf(today) : period === 'month' ? today.slice(0, 7) : null;

// Значки, по которым видно заработок: публикуются, только если сборщик разрешил показывать заработок
export const MONEY_BADGES = ['m50', 'm100', 'm250', 'm500', 'm1m', 'day3k', 'day5k', 'mon100k'];
let waitOnline = false;
window.addEventListener('online', () => { if (waitOnline) { waitOnline = false; setTimeout(() => window.Cloud && window.Cloud.social && window.Cloud.social.reconcile(), 3000); } });

const addDay = (k, n) => { const [y, m, d] = k.split('-').map(Number); const t = new Date(Date.UTC(y, m - 1, d + n)); return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`; };
const weekCache = {};
export function createSocial(ctx) {
  const { db, emit } = ctx;
  let aliasUnsub = null;
  let app = null, uid = null, statsUnsub = null, published = null, running = false, again = false, timer = 0;

  const api = {
    my: null,               // моя publicStats (null — не опубликовано)
    // Подмены имён от администратора: {uid: {alias, allow[]}}. Копия на телефоне — чтобы офлайн не мелькало настоящее имя
    aliases: (() => { try { return JSON.parse(localStorage.getItem('zarplata2027:aliases')) || {}; } catch { return {}; } })(),
    myLoaded: false,
    progress: null,         // {done, total} — идёт публикация
    attach(a) { app = a; },
    // ---------- Публикация ----------
    // visible: показывать статистику; showEarn: показывать заработок
    async setVisibility({ visible, showEarn }) {
      const prof = ctx.account.profile;
      if (!uid || !prof) throw Object.assign(new Error('Сначала заполните профиль'), { code: 'no-profile' });
      if (!visible) return unpublish();
      if (!api.my) {
        const st = { ...emptyStats({ nick: prof.nick, name: prof.name, avatar: await smallAvatar(prof.avatar) }, !!showEarn), visible: true };
        if (prof.fx) st.fx = prof.fx; if (typeof prof.status === 'string') st.status = prof.status;
        await setDoc(doc(db, 'publicStats', uid), { ...st, updatedAt: serverTimestamp() });
        published = {};
      } else if (!!showEarn !== !!api.my.showEarn || !api.my.visible) {
        // смена «показывать заработок»: флаг и (если скрываем) обнуление сумм; дни перепишутся при сверке
        const patch = { showEarn: !!showEarn, visible: true, updatedAt: serverTimestamp() };
        if (!showEarn) { for (const k of ['totals', 'day', 'week', 'month']) patch[k + '.earn'] = 0; if (api.my.badges) patch.badges = api.my.badges.filter((x) => !MONEY_BADGES.includes(x)); }
        await updateDoc(doc(db, 'publicStats', uid), patch);
      }
      return api.reconcile(true);
    },
    // Сверить опубликованные дни с записями на устройстве и дослать разницу (по одному дню в транзакции)
    async reconcile(force) {
      if (!uid || !app || !(api.my && api.my.visible) && !force) return;
      // без сети транзакции не проходят — досчитаем, когда появится интернет
      if (!navigator.onLine) { waitOnline = true; return; }
      if (running) { again = true; return; }
      running = true;
      try {
        if (!published || force) published = await loadMyDays();
        const st = (await getDoc(doc(db, 'publicStats', uid))).data();
        if (!st || !st.visible) return;
        const limitDay = dayKey(new Date(Date.now() + 864e5)); // будущие смены не публикуются
        const entries = {}; const all = app.get().entries;
        for (const k in all) if (k <= limitDay) entries[k] = all[k];
        const ops = diffDays(entries, published, st.showEarn);
        const best = bestOf(entries);
        api.progress = ops.length > 3 ? { done: 0, total: ops.length } : null;
        for (let i = 0; i < ops.length; i++) {
          await publishDay(ops[i].day, ops[i].next, best);
          if (api.progress) { api.progress.done = i + 1; emit('social', { progress: api.progress }); }
        }
      } catch (e) {
        published = null;
        // Статистику скрыли (например, с другого устройства) — просто прекращаем, это не ошибка
        if (e.code === 'unavailable' || !navigator.onLine) { waitOnline = true; }
        else if (e.code !== 'not-published') { console.warn('Публикация статистики', e); emit('error', { message: 'Не удалось обновить статистику в рейтинге — повторю позже' + (e.code ? ` (${e.code})` : '') }); setTimeout(() => api.reconcile(), 60e3); }
      }
      finally {
        running = false; api.progress = null; emit('social', { progress: null });
        if (again) { again = false; api.reconcile(); }
      }
    },
    changed() { clearTimeout(timer); timer = setTimeout(() => api.reconcile(), 2500); },
    // Значки достижений в рейтинге и профиле (денежные — только если показывается заработок)
    async setBadges(ids) {
      if (!uid || !api.my || !api.my.visible) return;
      const list = [...new Set(ids)].filter((x) => typeof x === 'string' && /^[a-z0-9]{1,8}$/.test(x)).filter((x) => api.my.showEarn || !MONEY_BADGES.includes(x)).slice(0, 80);
      const cur = Array.isArray(api.my.badges) ? api.my.badges : [];
      if (cur.length === list.length && cur.every((x, i) => x === list[i])) return;
      await updateDoc(doc(db, 'publicStats', uid), { badges: list, updatedAt: serverTimestamp() });
    },
    // Профиль изменился — обновить копию ника/имени/аватара в рейтинге
    async profileChanged(fresh) {
      const prof = fresh || ctx.account.profile;
      if (!uid || !api.my || !prof) return;
      const look = {}; if (prof.fx) look.fx = prof.fx; if (typeof prof.status === 'string') look.status = prof.status;
      await updateDoc(doc(db, 'publicStats', uid), { nick: prof.nick, name: prof.name, avatar: await smallAvatar(prof.avatar), ...look, updatedAt: serverTimestamp() });
    },

    // ---------- Чтение ----------
    // Рейтинг: period = day|week|month|all, metric = lines|earn|avg|days. Обновляется сам (onSnapshot).
    watchLeaderboard({ period, metric }, cb) {
      const cons = [where('visible', '==', true)];
      if (metric === 'earn') cons.push(where('showEarn', '==', true));
      const key = periodKey(period);
      if (key) cons.push(where(period + '.key', '==', key));
      const field = (period === 'all' ? 'totals' : period) + '.' + metric;
      const q = query(collection(db, 'publicStats'), ...cons, orderBy(field, 'desc'), limit(50));
      return onSnapshot(q, (s) => cb(null, s.docs.map((d) => ({ uid: d.id, ...d.data() })).filter((x) => (period === 'all' ? x.totals : x[period])[metric] > 0)),
        (e) => cb(e));
    },
    // Рейтинг за прошедшую неделю (monday = 'YYYY-MM-DD'): считается по опубликованным дням.
    // В publicStats хранится только текущая неделя, поэтому прошлые собираем из publicDays. Кэш на 5 минут.
    async weekBoard(monday) {
      const c = weekCache[monday];
      if (c && Date.now() - c.at < 300000) return c.rows;
      const sun = addDay(monday, 6);
      const list = (await getDocs(query(collection(db, 'publicStats'), where('visible', '==', true), limit(300)))).docs.map((d) => ({ uid: d.id, ...d.data() }));
      const rows = (await Promise.all(list.map(async (x) => {
        if (x.lastDay && x.lastDay < monday) return null; // с тех пор ничего не публиковал
        const days = await api.days(x.uid, monday, sun).catch(() => ({}));
        let lines = 0, n = 0, earn = 0, kg = 0;
        for (const k in days) { const d = days[k]; if (d.lines > 0) { lines += d.lines; n++; earn += Number(d.earn) || 0; kg += Number(d.kg) || 0; } }
        if (!lines) return null;
        return { ...x, week: { key: monday, lines, days: n, earn: x.showEarn ? Math.round(earn * 100) / 100 : 0, avg: lines / n }, _days: days, _kg: kg };
      }))).filter(Boolean);
      weekCache[monday] = { at: Date.now(), rows };
      return rows;
    },
    async listProfiles(q = '') {
      q = String(q).trim().toLowerCase().replace(/^@/, '');
      const c = collection(db, 'publicProfiles');
      const qq = q ? query(c, orderBy('nick'), startAt(q), endAt(q + ''), limit(40)) : query(c, orderBy('nick'), limit(60));
      return (await getDocs(qq)).docs.map((d) => ({ uid: d.id, ...d.data() }));
    },
    async getPublic(id) {
      const p = await getDoc(doc(db, 'publicProfiles', id));
      let stats = null;
      try { const s = await getDoc(doc(db, 'publicStats', id)); stats = s.exists() ? s.data() : null; } catch { stats = null; } // скрыта
      return { profile: p.exists() ? { uid: id, ...p.data() } : null, stats };
    },
    // Опубликованные дни сборщика за период [from, to] (ключи 'YYYY-MM-DD')
    async days(id, from, to) {
      const q = query(collection(db, 'publicDays', id, 'days'), where(documentId(), '>=', from), where(documentId(), '<=', to));
      const out = {}; (await getDocs(q)).forEach((d) => { out[d.id] = d.data(); });
      return out;
    },
  };

  async function loadMyDays() {
    const out = {}; (await getDocs(collection(db, 'publicDays', uid, 'days'))).forEach((d) => { out[d.id] = d.data(); });
    return out;
  }
  // who — чей день (по умолчанию свой; администратор — за сборщика после правки его календаря)
  async function publishDay(day, next, best, who = uid) {
    const sRef = doc(db, 'publicStats', who), dRef = doc(db, 'publicDays', who, 'days', day);
    let result = null;
    await runTransaction(db, async (tx) => {
      const s = await tx.get(sRef), d = await tx.get(dRef);
      if (!s.exists() || !s.data().visible) throw Object.assign(new Error('Статистика скрыта'), { code: 'not-published' });
      const st = s.data(), prev = d.exists() ? d.data() : null;
      const nxt = next ? { lines: next.lines, earn: st.showEarn ? next.earn : 0, ...(next.kg ? { kg: next.kg } : {}) } : null;
      result = nxt;
      if (same(prev, nxt)) return;
      const n = applyDay(st, day, nxt, prev, best);
      tx.set(sRef, { ...n, updatedAt: serverTimestamp() });
      if (nxt) tx.set(dRef, nxt); else tx.delete(dRef);
    });
    if (who !== uid || !published) return;
    if (result) published[day] = result; else delete published[day];
  }
  // Администратор: сверить опубликованные дни сборщика с его сменами и дописать недостающее (например, вес,
  // внесённый до того, как он стал попадать в рейтинг). Возвращает число исправленных дней.
  api.adminReconcile = async (who, entries) => {
    const s = await getDoc(doc(db, 'publicStats', who));
    if (!s.exists() || !s.data().visible) return 0;
    const pub = {}; (await getDocs(collection(db, 'publicDays', who, 'days'))).forEach((d) => { pub[d.id] = d.data(); });
    const ops = diffDays(entries, pub, s.data().showEarn), best = bestOf(entries);
    for (const op of ops) await publishDay(op.day, op.next, best, who);
    return ops.length;
  };
  // Администратор поправил смену сборщика → сразу пересчитать его рейтинг (если он участвует).
  // entries — все смены сборщика (для личного рекорда). Возвращает false, если статистика скрыта.
  api.adminPublish = async (who, day, entry, entries) => {
    const s = await getDoc(doc(db, 'publicStats', who));
    if (!s.exists() || !s.data().visible) return false;
    const rest = { ...entries }; if (entry) rest[day] = entry; else delete rest[day];
    try { await publishDay(day, entry ? publicDay(entry, s.data().showEarn) : null, bestOf(rest), who); }
    catch (e) { if (e && e.code === 'not-published') return false; throw e; }
    return true;
  };
  async function unpublish() {
    const days = await getDocs(collection(db, 'publicDays', uid, 'days'));
    const refs = [doc(db, 'publicStats', uid), ...days.docs.map((d) => d.ref)]; // сначала итоги — потом правила разрешат удалить дни
    for (let i = 0; i < refs.length; i += 450) { const b = writeBatch(db); refs.slice(i, i + 450).forEach((r) => b.delete(r)); await b.commit(); }
    published = null;
  }

  api.start = (u) => {
    if (statsUnsub) statsUnsub();
    uid = u; published = null; api.my = null; api.myLoaded = false;
    if (aliasUnsub) { aliasUnsub(); aliasUnsub = null; }
    if (!u) { statsUnsub = null; emit('social', {}); return; }
    aliasUnsub = onSnapshot(collection(db, 'nameAlias'), (s) => {
      const m = {}; s.forEach((d) => { const x = d.data(); if (x && x.alias) m[d.id] = { alias: x.alias, allow: Array.isArray(x.allow) ? x.allow : [] }; });
      api.aliases = m; try { localStorage.setItem('zarplata2027:aliases', JSON.stringify(m)); } catch {}
      emit('social', { aliases: m });
    }, () => {});
    statsUnsub = onSnapshot(doc(db, 'publicStats', u), (s) => {
      const wasVisible = api.my && api.my.visible;
      api.my = s.exists() ? s.data() : null; api.myLoaded = true;
      emit('social', { my: api.my });
      if (api.my && api.my.visible && !wasVisible) {
        api.changed(); // при запуске сверить дни
        // старая мелкая копия фото (72 px) — пересоздать покрупнее
        const prof = ctx.account.profile, av = api.my.avatar;
        if (prof && prof.avatar && prof.avatar.kind === 'photo' && av && av.kind === 'photo' && av.v.length < 12000 && prof.avatar.v.length > av.v.length * 1.5) api.profileChanged().catch(() => {});
      }
    }, () => { api.myLoaded = true; emit('social', { my: null }); });
  };
  return api;
}
