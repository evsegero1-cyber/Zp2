// Общий чат сборщиков: сообщения в реальном времени, фото (сжатые в текст base64 — без Cloud Storage),
// реакции, ответы, правка и удаление своих сообщений, «прочитано», «печатает…», непрочитанные.
// Данные: chats/general/messages/{id}, chats/general/members/{uid} (lastRead, lastSeen, typingUntil).
import {
  collection, doc, query, orderBy, limit, onSnapshot, addDoc, updateDoc, setDoc, deleteDoc, serverTimestamp,
  Timestamp, deleteField, getDocs, writeBatch,
} from 'firebase/firestore';

export const CHAT = 'general';
export const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥', '👏', '🤝'];
export const MAX_TEXT = 2000;
const PAGE = 60;

export function createChat(ctx) {
  const { db, emit } = ctx;
  const msgsCol = collection(db, 'chats', CHAT, 'messages');
  const memRef = (uid) => doc(db, 'chats', CHAT, 'members', uid);
  let uid = null, unsubs = [], pageSize = PAGE, readTimer = 0, typingAt = 0, seenTimer = 0;

  const api = {
    messages: [],          // по возрастанию времени: {id, uid, name, nick, text, image, replyTo, createdAt(ms), editedAt, deleted, reactions, pending}
    members: {},           // uid → {lastRead(ms), lastSeen(ms), typingUntil(ms)}
    hasMore: false,
    error: null,
    active: false,         // открыт ли экран чата (тогда отмечаем прочитанным)
    get unread() {
      const me = api.members[uid], last = me ? me.lastRead || 0 : 0;
      return api.messages.filter((m) => m.uid !== uid && !m.deleted && m.createdAt > last).length;
    },
    // Прочитано ли моё сообщение хоть кем-то из остальных
    readBy(m) {
      return Object.entries(api.members).filter(([id, x]) => id !== m.uid && (x.lastRead || 0) >= m.createdAt).map(([id]) => id);
    },
    typing() {
      const now = Date.now();
      return Object.entries(api.members).filter(([id, x]) => id !== uid && (x.typingUntil || 0) > now).map(([id]) => id);
    },
    online(id) { const x = api.members[id]; return !!x && now() - (x.lastSeen || 0) < 3 * 60e3; },

    async send({ text = '', image = null, replyTo = null, name, nick }) {
      text = String(text).trim().slice(0, MAX_TEXT);
      if (!text && !image) return;
      const data = { uid, name, nick, text, createdAt: serverTimestamp(), reactions: {}, deleted: false };
      if (image) data.image = image;
      if (replyTo) data.replyTo = { id: replyTo.id, name: String(replyTo.name || '').slice(0, 40), text: String(replyTo.text || (replyTo.image ? '📷 Фото' : '')).slice(0, 200) };
      setDoc(memRef(uid), { typingUntil: Timestamp.fromMillis(0) }, { merge: true }).catch(() => {});
      typingAt = 0;
      return addDoc(msgsCol, data);
    },
    edit: (id, text) => updateDoc(doc(msgsCol, id), { text: String(text).trim().slice(0, MAX_TEXT), editedAt: serverTimestamp() }),
    // Удалить у всех (своё — любой, чужое — только администратор): текст и фото стираются, остаётся «Сообщение удалено»
    remove: (id) => updateDoc(doc(msgsCol, id), { deleted: true, text: '', image: deleteField(), replyTo: deleteField(), editedAt: serverTimestamp() }),
    react(id, emoji) {
      const m = api.messages.find((x) => x.id === id); if (!m) return;
      const mine = m.reactions && m.reactions[uid];
      return updateDoc(doc(msgsCol, id), { ['reactions.' + uid]: !emoji || mine === emoji ? deleteField() : emoji });
    },
    // Отметить прочитанным (с задержкой, чтобы не писать в базу на каждое сообщение)
    markRead() {
      if (!uid || !api.active || document.hidden) return;
      const last = api.messages.length ? api.messages[api.messages.length - 1].createdAt : 0;
      const me = api.members[uid];
      if (!last || (me && (me.lastRead || 0) >= last)) return;
      clearTimeout(readTimer);
      readTimer = setTimeout(() => {
        // Чат могли закрыть за эти полсекунды — тогда ничего не отмечаем. Отметка = время последнего ПОКАЗАННОГО
        // сообщения, а не «сейчас»: иначе пришедшее в этот момент сообщение посчиталось бы прочитанным.
        if (!uid || !api.active || document.hidden || !api.messages.length) return;
        const seenUpTo = api.messages[api.messages.length - 1].createdAt;
        const mine = api.members[uid];
        if (mine && (mine.lastRead || 0) >= seenUpTo) return;
        setDoc(memRef(uid), { lastRead: Timestamp.fromMillis(seenUpTo), lastSeen: serverTimestamp() }, { merge: true }).catch(() => {});
      }, 600);
    },
    // «печатает…» — не чаще раза в 3 секунды
    typingNow() {
      if (!uid || Date.now() - typingAt < 3000) return;
      typingAt = Date.now();
      setDoc(memRef(uid), { typingUntil: Timestamp.fromMillis(Date.now() + 6000) }, { merge: true }).catch(() => {});
    },
    loadMore() { pageSize += PAGE; listen(); },
    // Администратор: полная очистка чата
    async clearAll() {
      const all = await getDocs(msgsCol);
      for (let i = 0; i < all.docs.length; i += 450) { const b = writeBatch(db); all.docs.slice(i, i + 450).forEach((d) => b.delete(d.ref)); await b.commit(); }
    },
    hardDelete: (id) => deleteDoc(doc(msgsCol, id)),
  };
  const now = () => Date.now();
  const ms = (t) => (t && t.toMillis ? t.toMillis() : 0);

  function listen() {
    if (unsubs[0]) unsubs[0]();
    unsubs[0] = onSnapshot(query(msgsCol, orderBy('createdAt', 'desc'), limit(pageSize)), { includeMetadataChanges: true }, (q) => {
      api.error = null;
      api.hasMore = q.size >= pageSize;
      api.messages = q.docs.map((d) => {
        const x = d.data({ serverTimestamps: 'estimate' });
        return { id: d.id, uid: x.uid, name: x.name, nick: x.nick, text: x.text || '', image: x.image || null, replyTo: x.replyTo || null,
          createdAt: ms(x.createdAt) || now(), editedAt: ms(x.editedAt), deleted: !!x.deleted, reactions: x.reactions || {}, pending: d.metadata.hasPendingWrites };
      }).reverse();
      emit('chat', { kind: 'messages' });
      api.markRead();
    }, (e) => { api.error = e.code === 'permission-denied' ? 'Доступ к чату закрыт' : 'Не удалось загрузить чат'; emit('chat', { kind: 'error' }); });
  }
  function seen() { if (uid && !document.hidden) setDoc(memRef(uid), { lastSeen: serverTimestamp() }, { merge: true }).catch(() => {}); }

  api.start = (u) => {
    api.stop();
    if (!u) return;
    uid = u; pageSize = PAGE;
    listen();
    unsubs[1] = onSnapshot(collection(db, 'chats', CHAT, 'members'), (q) => {
      const m = {}; q.forEach((d) => { const x = d.data({ serverTimestamps: 'estimate' }); m[d.id] = { lastRead: ms(x.lastRead), lastSeen: ms(x.lastSeen), typingUntil: ms(x.typingUntil) }; });
      api.members = m; emit('chat', { kind: 'members' });
    }, () => {});
    // Блокировка администратором: уже открытое соединение не перепроверяет права, поэтому следим сами
    unsubs[2] = onSnapshot(doc(db, 'banned', u), (b) => {
      if (b.exists()) {
        if (unsubs[0]) { unsubs[0](); unsubs[0] = null; }
        api.messages = []; api.banned = true;
        const r = b.data().reason;
        api.error = 'Доступ к чату закрыт администратором' + (r ? ': ' + r : '');
        emit('chat', { kind: 'error' });
      } else if (api.banned) { api.banned = false; api.error = null; listen(); }
    }, () => {});
    seen(); seenTimer = setInterval(seen, 2 * 60e3);
  };
  api.stop = () => {
    unsubs.forEach((f) => f && f()); unsubs = []; clearInterval(seenTimer); clearTimeout(readTimer);
    uid = null; api.messages = []; api.members = {}; api.error = null; api.banned = false;
  };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { seen(); api.markRead(); } });
  return api;
}

// Фото для чата: длинная сторона до 1280 px, JPEG — до ~280 000 символов текста (правило базы допускает 350 000)
export async function chatPhoto(file) {
  if (!file || !/^image\//.test(file.type || 'image/')) throw new Error('Выберите изображение');
  const img = await new Promise((res, rej) => {
    const url = URL.createObjectURL(file), i = new Image();
    i.onload = () => { URL.revokeObjectURL(url); res(i); };
    i.onerror = () => { URL.revokeObjectURL(url); rej(new Error('Не удалось открыть фото (нужен JPG или PNG)')); };
    i.src = url;
  });
  const W = img.naturalWidth, H = img.naturalHeight;
  for (let side = 1280; side >= 480; side = Math.round(side * 0.8)) {
    const k = Math.min(1, side / Math.max(W, H)), w = Math.round(W * k), h = Math.round(H * k);
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.imageSmoothingQuality = 'high'; g.drawImage(img, 0, 0, w, h);
    for (let q = 0.8; q >= 0.45; q -= 0.1) { const url = c.toDataURL('image/jpeg', q); if (url.length <= 280000) return url; }
  }
  throw new Error('Фото слишком большое');
}
