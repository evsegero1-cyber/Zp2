// Аккаунт: регистрация, вход, профиль (ник, имя, аватар), удаление аккаунта со всеми данными.
import {
  onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut as fbSignOut,
  sendPasswordResetEmail, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult,
  EmailAuthProvider, reauthenticateWithCredential, reauthenticateWithPopup, deleteUser,
} from 'firebase/auth';
import {
  doc, getDoc, onSnapshot, runTransaction, serverTimestamp, updateDoc, collection, getDocs, writeBatch,
} from 'firebase/firestore';

export const NICK_RE = /^[a-z0-9_.]{3,20}$/;
export const normNick = (s) => String(s || '').trim().toLowerCase().replace(/^@/, '');

// Понятные сообщения вместо кодов Firebase
const MESSAGES = {
  'auth/email-already-in-use': 'Эта почта уже зарегистрирована — войдите или восстановите пароль.',
  'auth/invalid-email': 'Неверный адрес почты.',
  'auth/weak-password': 'Слишком простой пароль: нужно не меньше 6 символов.',
  'auth/missing-password': 'Введите пароль.',
  'auth/invalid-credential': 'Неверная почта или пароль.',
  'auth/wrong-password': 'Неверный пароль.',
  'auth/user-not-found': 'Аккаунт с такой почтой не найден.',
  'auth/too-many-requests': 'Слишком много попыток. Подождите несколько минут.',
  'auth/network-request-failed': 'Нет связи с сервером. Проверьте интернет.',
  'auth/popup-closed-by-user': 'Окно входа закрыто.',
  'auth/cancelled-popup-request': 'Окно входа закрыто.',
  'auth/popup-blocked': 'Браузер заблокировал окно входа. Разрешите всплывающие окна или попробуйте ещё раз.',
  'auth/requires-recent-login': 'Для этого действия войдите заново.',
  'auth/user-disabled': 'Аккаунт отключён.',
  'auth/operation-not-allowed': 'Этот способ входа не включён в настройках Firebase.',
  'auth/unauthorized-domain': 'Этот адрес сайта не разрешён для входа (Firebase → Authentication → Settings → Authorized domains).',
  'permission-denied': 'Нет доступа (правила базы).',
  'unavailable': 'Нет связи с сервером. Проверьте интернет.',
  'nick-taken': 'Этот ник уже занят — выберите другой.',
  'nick-bad': 'Ник: 3–20 символов, латинские буквы, цифры, точка и подчёркивание.',
  'name-bad': 'Имя: от 1 до 40 символов.',
};
export function errText(e) {
  const code = (e && (e.code || e.message)) || '';
  return MESSAGES[code] || MESSAGES[String(code).replace(/^firestore\//, '')] || (e && e.message) || 'Что-то пошло не так';
}
const fail = (code) => { const e = new Error(code); e.code = code; throw e; };

export function createAccount(ctx) {
  const { auth, db, emit } = ctx;
  const isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  let profileUnsub = null;

  const api = {
    user: null,
    profile: null,           // publicProfiles/{uid} (null — ещё не создан: нужно выбрать ник)
    profileLoaded: false,
    // Google: в браузере и на iPhone — да; в APK нужен отдельный нативный плагин (будет позже)
    canGoogle: !isNative,

    async signUp({ email, password, nick, name, avatar }) {
      nick = normNick(nick);
      if (!NICK_RE.test(nick)) fail('nick-bad');
      if (!name || name.trim().length > 40) fail('name-bad');
      const cred = await createUserWithEmailAndPassword(auth, String(email).trim(), password);
      try { await api.createProfile({ nick, name, avatar }, cred.user); }
      catch (e) { e.afterSignup = true; throw e; } // аккаунт создан, ник занят — выберем другой на экране профиля
      return cred.user;
    },
    signIn: ({ email, password }) => signInWithEmailAndPassword(auth, String(email).trim(), password).then((c) => c.user),
    async signInGoogle() {
      const p = new GoogleAuthProvider(); p.setCustomParameters({ prompt: 'select_account' });
      try { return (await signInWithPopup(auth, p)).user; }
      catch (e) {
        if (e && (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment')) { await signInWithRedirect(auth, p); return null; }
        throw e;
      }
    },
    resetPassword: (email) => sendPasswordResetEmail(auth, String(email).trim()),
    signOut: () => fbSignOut(auth),

    async isNickFree(nick) {
      nick = normNick(nick);
      if (!NICK_RE.test(nick)) return false;
      const s = await getDoc(doc(db, 'usernames', nick));
      return !s.exists() || (api.user && s.data().uid === api.user.uid);
    },
    // Профиль + ник одной транзакцией: ник уникален (проверяют и транзакция, и правила базы)
    async createProfile({ nick, name, avatar }, user = api.user) {
      nick = normNick(nick); name = String(name || '').trim();
      if (!NICK_RE.test(nick)) fail('nick-bad');
      if (!name || name.length > 40) fail('name-bad');
      await runTransaction(db, async (tx) => {
        const u = await tx.get(doc(db, 'usernames', nick));
        if (u.exists() && u.data().uid !== user.uid) fail('nick-taken');
        tx.set(doc(db, 'publicProfiles', user.uid), { nick, name, avatar, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
        tx.set(doc(db, 'usernames', nick), { uid: user.uid });
      });
    },
    async updateProfile({ nick, name, avatar }) {
      const uid = api.user.uid, cur = api.profile;
      nick = normNick(nick ?? cur.nick); name = String(name ?? cur.name).trim();
      if (!NICK_RE.test(nick)) fail('nick-bad');
      if (!name || name.length > 40) fail('name-bad');
      const data = { name, avatar: avatar || cur.avatar, updatedAt: serverTimestamp() };
      if (nick === cur.nick) { await updateDoc(doc(db, 'publicProfiles', uid), data); }
      else {
        await runTransaction(db, async (tx) => {
          const u = await tx.get(doc(db, 'usernames', nick));
          if (u.exists() && u.data().uid !== uid) fail('nick-taken');
          tx.update(doc(db, 'publicProfiles', uid), { ...data, nick });
          tx.set(doc(db, 'usernames', nick), { uid });
          tx.delete(doc(db, 'usernames', cur.nick));
        });
      }
      // Копия ника/имени/аватара в рейтинге — новыми значениями (локальный снимок профиля обновится чуть позже)
      if (ctx.onProfileSaved) await ctx.onProfileSaved({ nick, name, avatar: data.avatar });
    },

    // Удаление аккаунта: повторный вход → все документы пользователя → сам аккаунт
    async deleteAccount(password) {
      const user = api.user, uid = user.uid;
      if (user.providerData.some((p) => p.providerId === 'password')) {
        await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password || ''));
      } else {
        await reauthenticateWithPopup(user, new GoogleAuthProvider());
      }
      if (ctx.beforeDelete) await ctx.beforeDelete();
      const refs = [];
      const days = await getDocs(collection(db, 'publicDays', uid, 'days')).catch(() => ({ docs: [] }));
      // Сначала статистика: без неё правила разрешают удалить опубликованные дни
      refs.push(doc(db, 'publicStats', uid), ...days.docs.map((d) => d.ref));
      const entries = await getDocs(collection(db, 'users', uid, 'entries'));
      refs.push(...entries.docs.map((d) => d.ref), doc(db, 'users', uid), doc(db, 'chats', 'general', 'members', uid));
      for (let i = 0; i < refs.length; i += 450) {
        const b = writeBatch(db); refs.slice(i, i + 450).forEach((r) => b.delete(r)); await b.commit();
      }
      if (api.profile) {
        const b = writeBatch(db);
        b.delete(doc(db, 'publicProfiles', uid)); b.delete(doc(db, 'usernames', api.profile.nick));
        await b.commit();
      }
      await deleteUser(user);
    },
  };

  getRedirectResult(auth).catch((e) => emit('error', { message: errText(e) }));

  onAuthStateChanged(auth, (user) => {
    if (profileUnsub) { profileUnsub(); profileUnsub = null; }
    api.user = user; api.profile = null; api.profileLoaded = false;
    emit('auth', { user });
    if (!user) return;
    profileUnsub = onSnapshot(doc(db, 'publicProfiles', user.uid), (s) => {
      api.profile = s.exists() ? { uid: user.uid, ...s.data() } : null;
      api.profileLoaded = !s.metadata.fromCache || s.exists();
      emit('profile', { profile: api.profile, loaded: api.profileLoaded });
    }, (e) => emit('error', { message: errText(e) }));
  });
  return api;
}
