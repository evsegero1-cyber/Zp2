// Администратор приложения. Права проверяют правила базы (firestore.rules → isAdmin):
// вход с почтой ADMIN_EMAIL и подтверждённым адресом. Здесь — только удобный доступ к действиям.
import {
  collection, doc, getDocs, query, where, setDoc, deleteDoc, writeBatch, serverTimestamp, Timestamp,
} from 'firebase/firestore';
import { sendEmailVerification } from 'firebase/auth';
import { CHAT } from './chat.js';

export const ADMIN_EMAIL = 'evsegero.one@gmail.com';

export function createAdmin(ctx) {
  const { db, auth } = ctx;
  const api = {
    // Почта совпадает — показываем панель; права в базе появятся, когда адрес подтверждён
    isAdminEmail: () => !!(auth.currentUser && (auth.currentUser.email || '').toLowerCase() === ADMIN_EMAIL),
    isAdmin: () => api.isAdminEmail() && !!auth.currentUser.emailVerified,
    sendVerification: () => sendEmailVerification(auth.currentUser),
    // Подтвердил почту по ссылке → обновить данные входа, чтобы база увидела подтверждение
    async refreshVerification() { await auth.currentUser.reload(); await auth.currentUser.getIdToken(true); return auth.currentUser.emailVerified; },

    // Все сборщики: профиль + публичная статистика (видна администратору и скрытая) + блокировка + когда был в приложении
    async users() {
      const [profiles, stats, banned, members] = await Promise.all([
        getDocs(collection(db, 'publicProfiles')), getDocs(collection(db, 'publicStats')),
        getDocs(collection(db, 'banned')), getDocs(collection(db, 'chats', CHAT, 'members')),
      ]);
      const st = {}, bn = {}, mm = {};
      stats.forEach((d) => { st[d.id] = d.data(); });
      banned.forEach((d) => { bn[d.id] = d.data(); });
      members.forEach((d) => { mm[d.id] = d.data(); });
      return profiles.docs.map((d) => {
        const p = d.data(), m = mm[d.id] || {};
        return { uid: d.id, ...p, stats: st[d.id] || null, banned: bn[d.id] || null,
          lastSeen: m.lastSeen && m.lastSeen.toMillis ? m.lastSeen.toMillis() : 0 };
      }).sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
    },
    async summary() {
      const day = Timestamp.fromMillis(Date.now() - 864e5);
      const msgs = await getDocs(query(collection(db, 'chats', CHAT, 'messages'), where('createdAt', '>=', day)));
      return { messages24h: msgs.size };
    },
    // Убрать из рейтинга: удалить опубликованную статистику и дни (сборщик может опубликовать заново, если не заблокирован)
    async hideStats(uid) {
      const days = await getDocs(collection(db, 'publicDays', uid, 'days'));
      const refs = [doc(db, 'publicStats', uid), ...days.docs.map((d) => d.ref)];
      for (let i = 0; i < refs.length; i += 450) { const b = writeBatch(db); refs.slice(i, i + 450).forEach((r) => b.delete(r)); await b.commit(); }
    },
    // Блокировка: нет доступа к чату и рейтингу (статистика удаляется), свои смены и калькулятор остаются
    async ban(uid, nick, reason) {
      await setDoc(doc(db, 'banned', uid), { at: serverTimestamp(), reason: String(reason || '').slice(0, 200), nick: String(nick || '') });
      await api.hideStats(uid);
    },
    unban: (uid) => deleteDoc(doc(db, 'banned', uid)),
  };
  return api;
}
