// Администратор приложения. Права проверяют правила базы (firestore.rules → isAdmin):
// вход с почтой ADMIN_EMAIL и подтверждённым адресом. Здесь — только удобный доступ к действиям.
import {
  collection, doc, getDocs, query, where, setDoc, deleteDoc, writeBatch, serverTimestamp, Timestamp, getDoc,
} from 'firebase/firestore';
import { sendEmailVerification } from 'firebase/auth';
import { CHAT } from './chat.js';

export const ADMIN_EMAIL = 'evsegero.one@gmail.com';

export function createAdmin(ctx) {
  const { db, auth } = ctx;
  const api = {
    // Почта совпадает — показываем панель; права в базе появятся, когда адрес подтверждён
    isAdminEmail: () => !!(auth.currentUser && (auth.currentUser.email || '').toLowerCase() === ADMIN_EMAIL),
    isAdmin: () => api.isAdminEmail() && !!auth.currentUser.emailVerified,
    sendVerification: () => sendEmailVerification(auth.currentUser),
    // Подтвердил почту по ссылке → обновить данные входа, чтобы база увидела подтверждение
    async refreshVerification() { await auth.currentUser.reload(); await auth.currentUser.getIdToken(true); return auth.currentUser.emailVerified; },

    // Все сборщики: профиль + публичная статистика (видна администратору и скрытая) + блокировка + когда был в приложении
    async users() {
      const [profiles, stats, banned, members, access, notes] = await Promise.all([
        getDocs(collection(db, 'publicProfiles')), getDocs(collection(db, 'publicStats')),
        getDocs(collection(db, 'banned')), getDocs(collection(db, 'chats', CHAT, 'members')),
        getDocs(collection(db, 'chatAccess')), getDocs(collection(db, 'adminNotes')),
      ]);
      const st = {}, bn = {}, mm = {}, ac = {}, nt = {};
      stats.forEach((d) => { st[d.id] = d.data(); });
      banned.forEach((d) => { bn[d.id] = d.data(); });
      members.forEach((d) => { mm[d.id] = d.data(); });
      access.forEach((d) => { ac[d.id] = true; });
      notes.forEach((d) => { nt[d.id] = d.data(); });
      return profiles.docs.map((d) => {
        const p = d.data(), m = mm[d.id] || {};
        return { uid: d.id, ...p, stats: st[d.id] || null, banned: bn[d.id] || null, chatAccess: !!ac[d.id],
          note: nt[d.id] || null, lastSeen: m.lastSeen && m.lastSeen.toMillis ? m.lastSeen.toMillis() : 0 };
      }).sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
    },
    // Доступ к чату (новые сборщики ждут одобрения)
    grantChat: (uid) => setDoc(doc(db, 'chatAccess', uid), { at: serverTimestamp() }),
    revokeChat: (uid) => deleteDoc(doc(db, 'chatAccess', uid)),
    // Заметки администратора о сборщике — видны только администратору: ФИО как в отчёте и что вносить из отчёта
    setNote: (uid, { fio, fields }) => setDoc(doc(db, 'adminNotes', uid), {
      fio: String(fio || '').trim().replace(/\s+/g, ' ').slice(0, 80),
      fields: { lines: fields.lines !== false, prod: fields.prod !== false, actual: fields.actual === true },
      updatedAt: serverTimestamp(),
    }),
    // Отправить сборщику данные из отчёта за день (его приложение внесёт их само)
    sendImport(uid, day, vals, source) {
      const data = { source: String(source || '').slice(0, 60), at: serverTimestamp(), applied: false };
      for (const k of ['lines', 'prod', 'actual']) if (typeof vals[k] === 'number' && Number.isFinite(vals[k])) data[k] = vals[k];
      return setDoc(doc(db, 'imports', uid, 'days', day), data);
    },
    // Что уже отправлено за день: uid → {applied, lines, …}
    async importsFor(day, uids) {
      const out = {};
      await Promise.all(uids.map(async (u) => { const d = await getDoc(doc(db, 'imports', u, 'days', day)).catch(() => null); if (d && d.exists()) out[u] = d.data(); }));
      return out;
    },
    async summary() {
      const day = Timestamp.fromMillis(Date.now() - 864e5);
      const msgs = await getDocs(query(collection(db, 'chats', CHAT, 'messages'), where('createdAt', '>=', day)));
      return { messages24h: msgs.size };
    },
    // Убрать из рейтинга: удалить опубликованную статистику и дни (сборщик может опубликовать заново, если не заблокирован)
    async hideStats(uid) {
      const days = await getDocs(collection(db, 'publicDays', uid, 'days'));
      const refs = [doc(db, 'publicStats', uid), ...days.docs.map((d) => d.ref)];
      for (let i = 0; i < refs.length; i += 450) { const b = writeBatch(db); refs.slice(i, i + 450).forEach((r) => b.delete(r)); await b.commit(); }
    },
    // Блокировка: нет доступа к чату и рейтингу (статистика удаляется), свои смены и калькулятор остаются
    async ban(uid, nick, reason) {
      await setDoc(doc(db, 'banned', uid), { at: serverTimestamp(), reason: String(reason || '').slice(0, 200), nick: String(nick || '') });
      await api.hideStats(uid);
    },
    unban: (uid) => deleteDoc(doc(db, 'banned', uid)),
  };
  return api;
}
