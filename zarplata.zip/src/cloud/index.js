// Точка входа облачного слоя. Собирается в www/cloud.js и подключается к приложению через window.Cloud.
// Калькулятор от этого слоя не зависит: без ключей или без сети он работает как раньше.
import { init, config, emulators } from './firebase.js';
import { createAccount, errText, NICK_RE, normNick } from './account.js';
import { createSync } from './sync.js';
import { createSocial, periodKey, dayKey } from './social.js';
import { mondayOf } from './stats.js';
import { PRESETS, presetAvatar, defaultAvatar, photoAvatar } from './avatar.js';

const listeners = new Set();
const Cloud = {
  configured: true,
  projectId: config.projectId,
  emulators: !!emulators,
  ready: false,
  error: null,
  // Подписка на события: auth, profile, sync, error
  on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  emit(type, detail) {
    for (const fn of listeners) { try { fn(type, detail); } catch (e) { console.error(e); } }
    document.dispatchEvent(new CustomEvent('cloud:' + type, { detail }));
  },
  errText, NICK_RE, normNick,
  avatars: { PRESETS, presetAvatar, defaultAvatar, photoAvatar },
};

try {
  const { auth, db } = init();
  const ctx = { auth, db, emit: (t, d) => Cloud.emit(t, d) };
  const account = createAccount(ctx);
  ctx.account = account;
  const sync = createSync(ctx);
  const social = createSocial(ctx);
  ctx.onProfileSaved = () => social.profileChanged();
  Object.assign(Cloud, { auth, db, account, sync, social, ready: true, util: { periodKey, dayKey, mondayOf } });
  // Вход/выход → запуск/остановка синхронизации и публичной статистики
  Cloud.on((type, d) => {
    if (type === 'auth') { if (d.user) sync.start(d.user.uid); else sync.stop(); social.start(d.user ? d.user.uid : null); }
    if (type === 'sync' && d.status === 'synced') social.changed(); // смены в облаке → обновить рейтинг
  });
  // Приложение подключается, передавая доступ к своему состоянию
  Cloud.attach = (adapter) => { sync.attach(adapter); social.attach(adapter); };
} catch (e) {
  console.error('Firebase не запустился', e);
  Cloud.error = String((e && e.message) || e);
}

window.Cloud = Cloud;
Cloud.emit('ready', { ok: Cloud.ready, error: Cloud.error });
