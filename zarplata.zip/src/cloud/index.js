// Точка входа облачного слоя. Собирается в www/cloud.js и подключается к приложению через window.Cloud.
// Калькулятор от этого слоя не зависит: без ключей или без сети он работает как раньше.
import { init, config, emulators } from './firebase.js';

const listeners = new Set();
const Cloud = {
  configured: true,
  projectId: config.projectId,
  emulators: !!emulators,
  ready: false,
  error: null,
  // Подписка на события облака (вход/выход, изменения с других устройств — появятся на этапе 4)
  on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  emit(type, detail) { for (const fn of listeners) { try { fn(type, detail); } catch (e) { console.error(e); } } document.dispatchEvent(new CustomEvent('cloud:' + type, { detail })); },
};

try {
  const { auth, db } = init();
  Cloud.auth = auth; Cloud.db = db; Cloud.ready = true;
} catch (e) {
  console.error('Firebase не запустился', e);
  Cloud.error = String(e && e.message || e);
}

window.Cloud = Cloud;
Cloud.emit('ready', { ok: Cloud.ready, error: Cloud.error });
