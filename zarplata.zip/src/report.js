// Чтение отчёта производительности (Excel-файл или фото таблицы) и сопоставление строк с аккаунтами.
// Работает на устройстве администратора; в базу уходят только числа по выбранным аккаунтам.
// Источники: таблица ячеек (Excel/CSV) — точно; слова с координатами из распознавания фото — с проверкой человеком.
(function (root) {
  'use strict';

  const low = (s) => String(s == null ? '' : s).toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();

  // «1 389,22 ₽», «145,54%», «0,00», «2 942» → число; не число → null
  function parseNum(v) {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    let s = String(v == null ? '' : v).replace(/[   ]/g, '').replace(/₽|руб\.?|р\.?$|p$/gi, '');
    const pct = /%$/.test(s); s = s.replace(/%$/, '');
    if (!/^-?\d+(?:[.,]\d+)?$/.test(s)) return null;
    const n = Number(s.replace(',', '.'));
    return Number.isFinite(n) ? (pct ? n : n) : null;
  }

  // Дата «30.10.2026» → '2026-10-30'
  function parseDate(s) {
    if (s instanceof Date && !isNaN(s)) return s.getFullYear() + '-' + String(s.getMonth() + 1).padStart(2, '0') + '-' + String(s.getDate()).padStart(2, '0');
    const m = String(s || '').match(/(\d{1,2})[./](\d{1,2})[./](\d{4}|\d{2})(?!\d)/);
    if (!m) return null;
    const y = m[3].length === 2 ? '20' + m[3] : m[3], mo = +m[2], d = +m[1];
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
    return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }

  function lev(a, b) {
    const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  const sim = (a, b) => (a || b ? 1 - lev(a, b) / Math.max(a.length, b.length) : 1);
  // Похоже ли слово на образец (с ошибками распознавания): «пимий» ≈ «линий», «колвечество» ≈ «количество»
  const like = (word, target, th = 0.6) => {
    const w = low(word).replace(/[^а-яa-z%]/g, '');
    if (w.length < 2) return false;
    if (w === target || w.startsWith(target)) return true;
    return sim(w.slice(0, target.length + 1), target) >= th || sim(w, target) >= th;
  };
  const hasLike = (text, target, th) => low(text).split(/[\s\-_/.,]+/).some((w) => like(w, target, th));

  // ---------- Какие колонки нужны: по тексту заголовка ----------
  const COLS = {
    name: (h) => hasLike(h, 'фио', 0.67) || hasLike(h, 'комплектовщик') || hasLike(h, 'сотрудник') || hasLike(h, 'работник'),
    lines: (h) => (hasLike(h, 'линий') || hasLike(h, 'линии') || hasLike(h, 'строк')) && !hasLike(h, 'час', 0.67) && !hasLike(h, 'вес', 0.67)
      && !/л\/ч|скорост/.test(low(h)),
    prod: (h) => hasLike(h, 'производительность', 0.65) || /^%\s*произв/.test(low(h)),
    actual: (h) => hasLike(h, 'итого', 0.6) && !hasLike(h, 'час', 0.67),
    date: (h) => /^дата(?![а-я])/.test(low(h)),
  };
  // Колонка «Итого» лучше «Начислено»; среди нескольких подходящих — с «заработано»
  function pickColumns(headers) {
    const res = {};
    headers.forEach((h, i) => {
      for (const k of Object.keys(COLS)) {
        if (!COLS[k](h)) continue;
        if (k === 'name' && res.name !== undefined) continue;
        if (k === 'lines' && res.lines !== undefined && !hasLike(h, 'количество')) continue;
        if (k === 'actual' && res.actual !== undefined && !hasLike(h, 'заработано')) continue;
        if (k === 'prod' && res.prod !== undefined) continue;
        res[k] = i; break;
      }
    });
    return res;
  }

  const looksName = (s) => /[а-яА-ЯёЁ]{2,}/.test(String(s || '')) && !/итог|всего/i.test(String(s));
  // Производительность: 1,4554 (доля из Excel) → 145,54
  const prodVal = (v) => { const n = parseNum(v); if (n === null) return null; const pct = typeof v === 'string' && /%/.test(v); return Math.round((!pct && n > 0 && n <= 5 ? n * 100 : n) * 100) / 100; };
  const intVal = (v) => { const n = parseNum(v); return n === null ? null : Math.round(n); };
  const moneyVal = (v) => { const n = parseNum(v); return n === null ? null : Math.round(n * 100) / 100; };

  // Дата отчёта из текста вокруг таблицы: «Дата 30.10.2026», «Производительность отбора с 29.10.2026 20:00 по 30.10.2026»
  function sheetDate(cells) {
    for (let r = 0; r < cells.length; r++) {
      const row = cells[r];
      for (let c = 0; c < row.length; c++) {
        const t = low(row[c]);
        if (/^дата(?![а-я])/.test(t) && !parseDate(t)) {
          for (let k = c + 1; k < row.length; k++) { const d = parseDate(row[k]); if (d) return { date: d, how: 'дата отчёта' }; }
        }
        const m = t.match(/(?:^|[^а-я])с\s+(\d{1,2}\.\d{1,2}\.\d{2,4})\s+(\d{1,2}):\d{2}/);
        if (m) {
          // Ночная смена записывается на дату начала: «с 29.10 20:00» → 29.10
          return { date: parseDate(m[1]), how: 'начало смены' };
        }
      }
    }
    return { date: null, how: '' };
  }

  // ---------- Таблица ячеек (Excel/CSV): листы → таблицы со строками ----------
  function fromGrid(cells, sheet = '') {
    cells = cells.map((r) => (r || []).map((x) => (x instanceof Date ? x : x == null ? '' : x)));
    let hr = -1, cols = null;
    for (let r = 0; r < Math.min(cells.length, 60) && hr < 0; r++) {
      const head = cells[r].map((x) => String(x));
      // заголовок бывает в две строки — склеиваем со следующей
      const two = head.map((h, i) => h + ' ' + String((cells[r + 1] || [])[i] || ''));
      for (const variant of [head, two]) {
        const pc = pickColumns(variant);
        if (pc.name !== undefined && pc.lines !== undefined) { hr = r + (variant === two && pickColumns(head).lines === undefined ? 1 : 0); cols = pc; break; }
      }
    }
    if (hr < 0) return null;
    const { date: date0, how } = sheetDate(cells.slice(0, hr));
    const rows = [];
    for (let r = hr + 1; r < cells.length; r++) {
      const row = cells[r], nm = String(row[cols.name] || '').trim();
      if (!nm) { if (rows.length && !row.some((x) => String(x).trim())) break; continue; }
      if (/итог|всего/i.test(nm)) break;
      if (!looksName(nm)) continue;
      const it = { name: nm.replace(/\s+/g, ' '), lines: intVal(row[cols.lines]),
        prod: cols.prod !== undefined ? prodVal(row[cols.prod]) : null,
        actual: cols.actual !== undefined ? moneyVal(row[cols.actual]) : null,
        date: cols.date !== undefined ? parseDate(row[cols.date]) || date0 : date0 };
      if (it.lines === null && it.actual === null) continue;
      rows.push(it);
    }
    return { sheet, date: date0, dateHow: how, cols: Object.keys(cols), rows, exact: true };
  }

  // ---------- Фото: строки распознанного текста со словами и координатами ----------
  // lines: [{words:[{t, x0,y0,x1,y1}], y0, y1}] (как отдаёт распознавание). Возвращает таблицу как fromGrid, но exact=false.
  function fromWords(lines, opts = {}) {
    lines = lines.filter((l) => l.words && l.words.length).map((l) => ({ ...l, text: l.words.map((w) => w.t).join(' ') }));
    const isNumTok = (t) => /^[\d.,%₽|_\-—'"”:;\[\]()]+$/.test(t) && /\d/.test(t);
    const h = Math.max(8, median(lines.map((l) => l.y1 - l.y0)));
    const HEAD = ['фио', 'комплектовщик', 'количество', 'линий', 'отобрано', 'производительность', 'итого', 'время', 'начислено'];
    const headScore = (l) => l.words.filter((w) => HEAD.some((t) => like(w.t, t, 0.7))).length;
    const surnameLike = (l) => l.words.some((w) => /^[А-ЯЁ][а-яё]{3,}/.test(w.t.replace(/^[^А-ЯЁа-яё]+/, '')));
    // первая строка данных — после строки заголовков: слева фамилия, дальше не меньше двух чисел
    let hi = -1, hs = 1;
    lines.forEach((l, i) => { const sc = headScore(l); if (sc > hs) { hs = sc; hi = i; } });
    if (hi < 0) return null;
    // заголовок в две строки: верхняя половина могла набрать меньше слов
    if (hi > 0 && headScore(lines[hi - 1]) >= 2 && lines[hi - 1].y1 > lines[hi].y0 - 2 * h) hi--;
    const dataStart = lines.findIndex((l, i) => i > hi && surnameLike(l) && l.words.filter((w) => isNumTok(w.t)).length >= 2);
    if (dataStart < 0) return null;
    // заголовки колонок: слова строк заголовка (до 4 строк над первой строкой данных)
    const headWords = [];
    for (let i = Math.max(0, hi - 1); i < dataStart; i++) {
      if (lines[i].y0 < lines[hi].y0 - 1.5 * h) continue;
      for (const w of lines[i].words) if (/[а-яёa-z%]{2,}/i.test(w.t)) headWords.push(w);
    }
    // склеиваем слова, стоящие друг над другом (перекрываются по горизонтали), в колонки
    headWords.sort((a, b) => a.x0 - b.x0);
    const clusters = [];
    for (const w of headWords) {
      // та же колонка: слово под/над другим (перекрытие по горизонтали) или рядом в той же строке (маленький пробел)
      const c = clusters.find((k) => (Math.min(k.x1, w.x1) - Math.max(k.x0, w.x0) > -0.15 * h && k.words.every((o) => Math.abs(w.y0 - o.y0) > 0.5 * h))
        || k.words.some((o) => Math.abs(w.y0 - o.y0) <= 0.5 * h && w.x0 - o.x1 >= -2 && w.x0 - o.x1 < 0.45 * h));
      if (c) { c.x0 = Math.min(c.x0, w.x0); c.x1 = Math.max(c.x1, w.x1); c.words.push(w); }
      else clusters.push({ x0: w.x0, x1: w.x1, y: w.y0, words: [w] });
    }
    clusters.forEach((c) => { c.text = c.words.sort((a, b) => a.y0 - b.y0 || a.x0 - b.x0).map((w) => w.t).join(' '); c.cx = (c.x0 + c.x1) / 2; });
    clusters.sort((a, b) => a.cx - b.cx);
    if (opts.debug) console.log(clusters.map((c) => Math.round(c.x0) + "-" + Math.round(c.x1) + ":" + c.text).join("  |  "));
    const pc = pickColumns(clusters.map((c) => c.text));
    const anchor = clusters.findIndex((c) => hasLike(c.text, 'план', 0.75) || hasLike(c.text, 'наборов', 0.7));
    const { date } = sheetDate([[lines.slice(0, dataStart).map((l) => l.text).join(' ')], ...lines.slice(0, dataStart).map((l) => l.words.map((w) => w.t))]);
    const isStop = (l) => l.words.some((w) => like(w.t, 'итого', 0.75) || like(w.t, 'всего', 0.75) || like(w.t, 'общий', 0.75));
    // 1) строки: имя + числа (части «1 389,22» склеены)
    const data = [];
    for (let i = dataStart; i < lines.length; i++) {
      const l = lines[i];
      if (isStop(l)) break;
      const ws = l.words.slice().sort((a, b) => a.x0 - b.x0);
      const s0 = ws.findIndex((w) => { const t = w.t.replace(/^[^А-ЯЁа-яё]+/, ''); return /^[А-ЯЁ][а-яё]{2,}/.test(t) || /^[а-яё]{4,}/.test(t); });
      if (s0 < 0) continue;
      let e = s0;
      // «Иванов (1) Д.В.» — номер однофамильца не обрывает имя
      while (e + 1 < ws.length && (!/\d/.test(ws[e + 1].t) || /^\(\d\)$/.test(ws[e + 1].t)) && ws[e + 1].x0 - ws[e].x1 < 2.5 * h) e++;
      let name = ws.slice(s0, e + 1).map((w) => w.t).join(' ').replace(/[^А-ЯЁа-яё. \-]/g, ' ').replace(/\s+/g, ' ').trim();
      name = name.charAt(0).toUpperCase() + name.slice(1);
      if (!looksName(name)) continue;
      const toks = [];
      for (const w of ws.slice(e + 1)) {
        const t = w.t.replace(/[^\d.,%]/g, '');
        if (!/\d/.test(t)) continue;
        const prev = toks[toks.length - 1];
        if (prev && /^\d{1,3}$/.test(prev.t) && /^\d{3}(?:[.,]\d+)?%?$/.test(t) && w.x0 - prev.x1 < 0.6 * h) { prev.t += t; prev.x1 = w.x1; }
        else toks.push({ t, x0: w.x0, x1: w.x1 });
      }
      toks.forEach((k) => { k.cx = (k.x0 + k.x1) / 2; });
      if (toks.length) data.push({ name, toks, box: { y0: Math.min(...l.words.map((w) => w.y0)), y1: Math.max(...l.words.map((w) => w.y1)), x0: ws[s0].x0, x1: toks[toks.length - 1].x1 } });
    }
    if (!data.length) return null;
    // 2) колонки чисел: центры, стоящие друг под другом во многих строках
    const xs = data.flatMap((r) => r.toks.map((k) => k.cx)).sort((a, b) => a - b);
    const dcols = [];
    for (const x of xs) { const c = dcols[dcols.length - 1]; if (c && x - c.last < 1.1 * h) { c.sum += x; c.n++; c.last = x; } else dcols.push({ sum: x, n: 1, last: x }); }
    const cols = dcols.filter((c) => c.n >= Math.max(2, data.length * 0.25)).map((c) => c.sum / c.n);
    const near = (x) => { let bi = -1, bd = Infinity; cols.forEach((c, i) => { const d = Math.abs(c - x); if (d < bd) { bd = d; bi = i; } }); return bi; };
    const at = (r, ci) => { const ts = r.toks.filter((k) => near(k.cx) === ci); return ts.length ? ts.map((k) => k.t).join(' ') : null; };
    // 3) какие колонки нужны
    const pct = cols.map((_, ci) => data.filter((r) => /%/.test(at(r, ci) || '')).length);
    let prodCol = -1;
    if (pc.prod !== undefined) prodCol = near(clusters[pc.prod].cx);
    if (prodCol < 0 || pct[prodCol] < data.length * 0.4) prodCol = pct.findIndex((n) => n >= data.length * 0.4);
    let linesCol = -1;
    if (anchor >= 0) { const ai = near(clusters[anchor].cx); if (ai >= 0 && ai + 1 < cols.length) linesCol = ai + 1; }
    if (linesCol < 0 && pc.lines !== undefined) linesCol = near(clusters[pc.lines].cx);
    const actualCol = pc.actual !== undefined ? near(clusters[pc.actual].cx) : -1;
    if (linesCol < 0 && prodCol < 0) return null;
    if (opts.debug) console.log('cols', cols.map(Math.round), { prodCol, linesCol, actualCol });
    const rows = data.map((r) => {
      const L = linesCol >= 0 ? at(r, linesCol) : null, P = prodCol >= 0 ? at(r, prodCol) : null, A = actualCol >= 0 ? at(r, actualCol) : null;
      return { name: r.name, lines: L === null ? null : intVal(L.split(' ')[0]), prod: P === null ? null : prodVal(P.split(' ')[0].includes('%') ? P.split(' ')[0] : P.split(' ')[0] + '%'),
        actual: A === null ? null : moneyVal(A.split(' ')[0]), date, raw: { lines: L, prod: P, actual: A }, box: r.box };
    }).map(plausible);
    return { sheet: opts.sheet || 'фото', date, dateHow: date ? 'с фото' : '', cols: ['name', prodCol >= 0 && 'prod', linesCol >= 0 && 'lines', actualCol >= 0 && 'actual'].filter(Boolean), rows, exact: false };
  }
  // Проверка на правдоподобие (фото): «1 831,80 ₽» могло прочитаться как 1831800 — пробуем исправить, иначе пусто
  function plausible(r) {
    if (r.lines !== null && (r.lines < 1 || r.lines > 3000)) r.lines = null;
    if (r.prod !== null && (r.prod <= 0 || r.prod > 400)) r.prod = null;
    if (r.actual !== null && r.lines) {
      const ok = (v) => v >= r.lines * 1.5 && v <= r.lines * 20;
      if (!ok(r.actual)) {
        const d = String(r.raw.actual || '').replace(/\D/g, '');
        const fix = [d.slice(0, -1), d].map((x) => Number(x) / 100).find(ok);
        r.actual = fix !== undefined ? fix : null;
      }
    }
    return r;
  }
  function median(a) { const s = a.filter((x) => x > 0).sort((x, y) => x - y); return s.length ? s[s.length >> 1] : 0; }

  // ---------- Сопоставление ФИО ----------
  // «Евсюков Сергей Петрович» / «Евсюков С.П.» / «Евсюков СП» → {surname, initials:'сп'}
  function splitName(s) {
    const t = low(s).replace(/[^а-яa-z. \-]/g, ' ').replace(/\./g, '. ').split(/\s+/).map((x) => x.replace(/\.$/, '')).filter(Boolean);
    if (!t.length) return { surname: '', initials: '' };
    const surname = t[0];
    let initials = '';
    for (const x of t.slice(1)) initials += x.length <= 2 && t.length <= 3 && !/[аеиоуыэюя]{2}/.test(x) ? x : x[0];
    return { surname, initials: initials.slice(0, 2) };
  }
  // Насколько ФИО из профиля похоже на строку отчёта: 0…1. Перед фамилией с фото бывает мусор («Зач мо Прокопов ПС») —
  // пробуем начинать с каждого слова.
  function matchScore(fio, reportName) {
    const toks = String(reportName || '').split(/\s+/).filter(Boolean);
    let best = 0;
    for (let j = 0; j < toks.length; j++) {
      if (low(toks[j]).replace(/[^а-яa-z]/g, '').length < 3) continue;
      best = Math.max(best, score1(fio, toks.slice(j).join(' ')));
    }
    return best;
  }
  function score1(fio, reportName) {
    const a = splitName(fio), b = splitName(reportName);
    if (!a.surname || !b.surname) return 0;
    const s = sim(a.surname, b.surname);
    const fullIni = a.initials.length === 2 && b.initials.length === 2 && a.initials === b.initials;
    if (s < (fullIni ? 0.6 : 0.7)) return 0; // с совпавшими инициалами прощаем больше ошибок распознавания
    let ini = 0.5; // инициалов нет с одной из сторон — нейтрально, но фамилия тогда должна совпасть почти точно
    if (!(a.initials && b.initials) && s < 0.95) return 0;
    if (a.initials && b.initials) {
      if (a.initials[0] !== b.initials[0]) return s >= 0.99 ? 0.3 : 0; // однофамильцы с другим именем
      ini = a.initials[1] && b.initials[1] ? 0.75 + (a.initials[1] === b.initials[1] ? 0.25 : 0) : 1;
    }
    return Math.round((s * 0.7 + ini * 0.3) * 1000) / 1000;
  }
  // accounts: [{uid, fio}] → {matches: {uid: rowIndex}, scores: {uid: score}}; каждая строка — не больше одному аккаунту
  function matchAccounts(accounts, rows, min = 0.7) {
    const pairs = [];
    accounts.forEach((a) => { if (!a.fio) return; rows.forEach((r, i) => { const sc = matchScore(a.fio, r.name); if (sc >= min) pairs.push({ uid: a.uid, i, sc }); }); });
    pairs.sort((x, y) => y.sc - x.sc);
    const matches = {}, scores = {}, taken = new Set();
    for (const p of pairs) { if (p.uid in matches || taken.has(p.i)) continue; matches[p.uid] = p.i; scores[p.uid] = p.sc; taken.add(p.i); }
    return { matches, scores };
  }

  // Несколько таблиц (листы «Склад А», «Склад Б») → строки по людям и датам; один человек в двух складах — сумма
  function mergeTables(tables) {
    const map = new Map();
    for (const t of tables) for (const r of t.rows) {
      const key = low(r.name) + '|' + (r.date || '');
      const o = map.get(key);
      if (!o) { map.set(key, { ...r, sheets: [t.sheet] }); continue; }
      const l1 = o.lines || 0, l2 = r.lines || 0;
      if (o.prod !== null && r.prod !== null && l1 + l2) o.prod = Math.round(((o.prod * l1 + r.prod * l2) / (l1 + l2)) * 100) / 100;
      else if (o.prod === null) o.prod = r.prod;
      o.lines = o.lines === null && r.lines === null ? null : l1 + l2;
      o.actual = o.actual === null && r.actual === null ? null : Math.round(((o.actual || 0) + (r.actual || 0)) * 100) / 100;
      o.sheets.push(t.sheet);
    }
    return [...map.values()];
  }

  // Подготовка фото таблицы к распознаванию: чёрно-белое (светлый текст на тёмной шапке тоже) без линий сетки и пунктира.
  // g — яркость пикселей (0…255), W×H. Возвращает 0/255.
  function cleanTable(g, W, H) {
    // интегральное изображение для адаптивного порога
    const I = new Float64Array((W + 1) * (H + 1));
    for (let y = 0; y < H; y++) { let s = 0; for (let x = 0; x < W; x++) { s += g[y * W + x]; I[(y + 1) * (W + 1) + x + 1] = I[y * (W + 1) + x + 1] + s; } }
    const r = Math.max(8, Math.round(Math.min(W, H) / 60)), bin = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const x0 = Math.max(0, x - r), x1 = Math.min(W, x + r + 1), y0 = Math.max(0, y - r), y1 = Math.min(H, y + r + 1);
      const sum = I[y1 * (W + 1) + x1] - I[y0 * (W + 1) + x1] - I[y1 * (W + 1) + x0] + I[y0 * (W + 1) + x0];
      const mean = sum / ((x1 - x0) * (y1 - y0));
      const v = g[y * W + x];
      // тёмный фон (шапка таблицы) — текст светлый: инвертируем
      bin[y * W + x] = mean < 105 ? (v > mean * 1.25 + 12 ? 1 : 0) : (v < mean * 0.85 ? 1 : 0);
    }
    // Линии сетки: длинные тонкие отрезки; пунктир (разрывы до G px) тоже считается линией
    const L = Math.round(W / 25), LV = Math.round(H / 12), G = Math.max(3, Math.round(W / 700)), T = Math.max(3, Math.round(W / 900)), mask = new Uint8Array(W * H);
    const at = (x, y) => (x >= 0 && y >= 0 && x < W && y < H ? bin[y * W + x] : 0);
    function scan(n, m, get, put, minLen) {
      for (let a = 0; a < n; a++) {
        let start = -1, last = -1, cnt = 0, thick = 0;
        for (let b = 0; b <= m; b++) {
          const on = b < m && get(a, b);
          if (on) { if (start < 0 || b - last > G) { flush(); start = b; cnt = 0; thick = 0; } last = b; cnt++; if (get(a - T, b) || get(a + T, b)) thick++; }
        }
        flush();
        function flush() {
          if (start >= 0 && last - start + 1 >= minLen && thick < cnt * 0.35) for (let b = start; b <= last; b++) if (get(a, b)) put(a, b);
          start = -1;
        }
      }
    }
    scan(H, W, (y, x) => at(x, y), (y, x) => { mask[y * W + x] = 1; }, L);
    scan(W, H, (x, y) => at(x, y), (x, y) => { mask[y * W + x] = 1; }, LV);
    // расширить маску на 1 px
    const out = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) out[i] = bin[i] && !mask[i] && !(mask[i - 1] || mask[i + 1] || mask[i - W] || mask[i + W]) ? 0 : 255;
    return out;
  }

  const api = { cleanTable, parseNum, parseDate, pickColumns, fromGrid, fromWords, splitName, matchScore, matchAccounts, mergeTables, sim };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Report = api;
})(typeof window !== 'undefined' ? window : globalThis);
