/* Интерфейс приложения. Зависит от Core (core.js). */
(() => {
  'use strict';
  const C = Core;
  const STORE_KEY = 'zarplata2027:v1';
  const META_KEY = 'zarplata2027:meta';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const M = C.fmtMoney, N = C.fmtNum;

  // ---------- Хранилище ----------
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const obj = JSON.parse(raw), st = C.normalizeState(obj).state;
        // Старые данные: убираем удалённую игру и переносим выплаты на новую схему — сразу сохраняем
        if (obj.game || !obj.settings || obj.settings.payV !== C.PAY_V) { try { localStorage.setItem(STORE_KEY, JSON.stringify(st)); } catch (e) { /* сохранится при следующем изменении */ } }
        return st;
      }
    } catch (e) { console.warn('Не удалось прочитать данные', e); }
    return C.defaultState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); return true; }
    catch (e) { toast('Ошибка сохранения: память устройства недоступна'); return false; }
  }
  const meta = (() => { try { return JSON.parse(localStorage.getItem(META_KEY)) || {}; } catch { return {}; } })();
  const saveMeta = () => { try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch {} };

  let state = load();
  const todayKey = () => C.keyOfDate(new Date());
  // Сквозной номер месяца (0 = январь 2026 … 35 = декабрь 2028). Основной год — 2027:
  // если сегодня 2027 год, открываем текущий месяц, иначе январь 2027.
  // При запуске открывается текущий месяц и год (если вне 2026–2028 — ближайший край)
  const defaultMonth = () => {
    const t = todayKey();
    if (t < C.FIRST_DAY) return 0;
    if (t > C.LAST_DAY) return C.MONTH_COUNT - 1;
    const p = C.parseKey(t); return C.indexOf(p.y, p.m);
  };
  const monthName = (i) => { const { y, m } = C.ymOf(i); return `${C.MONTHS[m]} ${y}`; };
  const ui = {
    tab: 'home', homeMonth: defaultMonth(), calMonth: defaultMonth(),
    stats: { mode: 'month', month: defaultMonth(), year: C.ymOf(defaultMonth()).y, from: `${C.ymOf(defaultMonth()).y}-01-01`, to: `${C.ymOf(defaultMonth()).y}-12-31` },
    success: { scope: 'month' },
  };
  const prevHero = {};

  // ---------- Тема ----------
  const mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  // Цвета: смешивание hex и яркость — чтобы гамма читалась и в светлой, и в тёмной теме
  const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const rgbHex = (a) => '#' + a.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  const mixHex = (a, b, t) => { const x = hexRgb(a), y = hexRgb(b); return rgbHex(x.map((v, i) => v + (y[i] - v) * t)); };
  const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  function applyTheme() {
    const t = state.settings.theme === 'system' ? (mq && mq.matches ? 'dark' : 'light') : state.settings.theme;
    document.documentElement.dataset.theme = t;
    const pal = state.settings.palette || C.PALETTES[0], dark = t === 'dark';
    const acc = dark ? mixHex(pal.accent, '#ffffff', 0.18) : pal.accent;
    const acc2 = dark ? mixHex(pal.accent2, '#ffffff', 0.22) : pal.accent2;
    const rs = document.documentElement.style;
    rs.setProperty('--accent', acc);
    rs.setProperty('--chart', acc);
    rs.setProperty('--chart-2', acc2);
    rs.setProperty('--accent-ink', lum(acc) > 0.45 ? '#1a1a1a' : '#ffffff');
    rs.setProperty('--accent-soft', dark ? mixHex(acc, '#1d1d1c', 0.74) : mixHex(acc, '#ffffff', 0.85));
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = t === 'dark' ? '#121212' : '#f4f3ef';
  }
  if (mq) (mq.addEventListener ? mq.addEventListener('change', applyTheme) : mq.addListener(applyTheme));

  // ---------- Иконки ----------
  const ICONS = {
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
    stats: '<path d="M4 20V11M10 20V4M16 20v-7M22 20H2"/>',
    trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M17 5h3v2a4 4 0 0 1-4 4M7 5H4v2a4 4 0 0 0 4 4"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;

  // ---------- Нативные плагины (только в APK) ----------
  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const pluginCache = {};
  function nativePlugin(name) {
    const cap = window.Capacitor;
    if (!isNative() || !cap.registerPlugin || (cap.isPluginAvailable && !cap.isPluginAvailable(name))) return null;
    if (!pluginCache[name]) pluginCache[name] = (cap.Plugins && cap.Plugins[name]) || cap.registerPlugin(name);
    return pluginCache[name];
  }

  // ---------- Блокировка: PIN-код и отпечаток пальца ----------
  // Настройки блокировки хранятся только на этом устройстве (не попадают в резервную копию).
  const lockCfg = () => meta.lock || { enabled: false };
  async function hashPin(pin, salt) {
    const data = new TextEncoder().encode(salt + ':' + pin + ':zp');
    try { const h = await crypto.subtle.digest('SHA-256', data); return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, '0')).join(''); }
    catch { let h = 2166136261; for (const b of data) { h ^= b; h = Math.imul(h, 16777619) >>> 0; } return 'f' + h.toString(16); }
  }
  let authBusy = false, hiddenAt = null;
  async function bioAvailable() {
    const B = nativePlugin('NativeBiometric');
    if (!B) return false;
    try { const r = await B.isAvailable({ useFallback: false }); return !!(r && r.isAvailable); } catch { return false; }
  }
  async function bioVerify() {
    const B = nativePlugin('NativeBiometric');
    if (!B) return false;
    authBusy = true;
    try { await B.verifyIdentity({ title: 'Вход', subtitle: 'Калькулятор ЗП', reason: 'Подтвердите вход', negativeButtonText: 'PIN-код', maxAttempts: 3 }); return true; }
    catch { return false; }
    finally { setTimeout(() => { authBusy = false; hiddenAt = null; }, 800); }
  }
  // Цифровая клавиатура PIN. opts: { title, sub, onPin(pin) → true | 'текст ошибки', bio, forgot }
  function pinPad(el, opts) {
    let pin = '';
    el.innerHTML = `<div class="pin-box">
      <div class="pin-logo">🔒</div><div class="pin-title">${esc(opts.title)}</div><div class="pin-sub" id="pin-sub">${esc(opts.sub || '')}</div>
      <div class="pin-dots">${'<i></i>'.repeat(4)}</div>
      <div class="pin-keys">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button type="button" data-k="${n}">${n}</button>`).join('')}
        ${opts.bio ? '<button type="button" data-bio class="pin-fn">👆</button>' : '<span></span>'}<button type="button" data-k="0">0</button><button type="button" data-del class="pin-fn">⌫</button></div>
      ${opts.forgot ? '<button type="button" class="pin-link" data-forgot>Забыли PIN-код?</button>' : ''}
      ${opts.cancel ? '<button type="button" class="pin-link" data-cancel>Отмена</button>' : ''}</div>`;
    const dots = el.querySelectorAll('.pin-dots i');
    const draw = () => dots.forEach((d, i) => d.classList.toggle('on', i < pin.length));
    el.onclick = async (e) => {
      const k = e.target.closest('[data-k]');
      if (k && pin.length < 4) {
        pin += k.dataset.k; draw();
        if (pin.length === 4) {
          const r = await opts.onPin(pin);
          if (r !== true) {
            el.querySelector('.pin-dots').classList.add('shake');
            $('#pin-sub', el).textContent = r || 'Неверный PIN-код';
            setTimeout(() => { pin = ''; draw(); const d = el.querySelector('.pin-dots'); if (d) d.classList.remove('shake'); }, 450);
          }
        }
        return;
      }
      if (e.target.closest('[data-del]')) { pin = pin.slice(0, -1); draw(); return; }
      if (e.target.closest('[data-bio]') && opts.onBio) return opts.onBio();
      if (e.target.closest('[data-forgot]') && opts.forgot) return opts.forgot();
      if (e.target.closest('[data-cancel]') && opts.cancel) return opts.cancel();
    };
  }
  let lockShown = false;
  async function showLock() {
    const cfg = lockCfg();
    if (!cfg.enabled || !cfg.hash || lockShown) return;
    lockShown = true;
    const el = $('#lock');
    el.hidden = false; document.body.classList.add('locked');
    let fails = 0;
    const unlock = () => { el.hidden = true; lockShown = false; document.body.classList.remove('locked'); el.innerHTML = ''; renderAll(); };
    const tryBio = async () => { if (await bioVerify()) unlock(); };
    const useBio = cfg.bio && await bioAvailable();
    pinPad(el, {
      title: 'Введите PIN-код', sub: useBio ? 'или приложите палец' : '', bio: useBio, onBio: tryBio,
      onPin: async (pin) => {
        if (fails >= 5) return 'Слишком много попыток — подождите 30 секунд';
        if ((await hashPin(pin, cfg.salt)) === cfg.hash) { unlock(); return true; }
        fails++;
        if (fails >= 5) setTimeout(() => { fails = 0; const sub = $('#pin-sub'); if (sub) sub.textContent = 'Можно снова вводить PIN'; }, 30000);
        return `Неверный PIN-код${fails >= 3 && fails < 5 ? ` · осталось попыток: ${5 - fails}` : ''}`;
      },
      forgot: async () => {
        const ok = await confirmDlg('Сбросить PIN-код?', 'Чтобы защитить данные, сброс PIN удалит все записи на этом телефоне. Потом их можно восстановить из резервной копии.', 'Сбросить и удалить данные', true);
        if (!ok) return;
        state = C.defaultState(); save(); meta.lock = { enabled: false }; saveMeta(); applyTheme(); unlock(); toast('PIN сброшен, данные удалены');
      },
    });
    if (useBio) setTimeout(tryBio, 300);
  }
  // Включение PIN: ввод дважды
  function setupPin() {
    return new Promise((resolve) => {
      const sh = $('#sheet');
      let first = null;
      const step = () => pinPad(sh, {
        title: first ? 'Повторите PIN-код' : 'Придумайте PIN-код', sub: first ? '' : '4 цифры', cancel: () => closeModal(),
        onPin: async (pin) => {
          if (!first) { first = pin; setTimeout(step, 150); return true; }
          if (pin !== first) { first = null; setTimeout(step, 600); return 'Не совпадает — начните заново'; }
          const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
          meta.lock = { ...lockCfg(), enabled: true, salt, hash: await hashPin(pin, salt), after: lockCfg().after ?? 60 };
          saveMeta(); resolved = true; closeModal(); return true;
        },
      });
      let resolved = false;
      step();
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(resolved);
    });
  }
  document.addEventListener('visibilitychange', () => {
    if (authBusy) return;
    if (document.hidden) { hiddenAt = Date.now(); return; }
    const cfg = lockCfg();
    if (cfg.enabled && hiddenAt !== null && Date.now() - hiddenAt >= (cfg.after ?? 60) * 1000) showLock();
    hiddenAt = null;
  });

  // ---------- Модальные окна + кнопка «Назад» Android ----------
  const modalStack = [];
  function openModal(el, backdrop, onClose) {
    modalStack.push({ el, backdrop, onClose });
    backdrop.classList.add('show'); el.classList.add('show');
    try { history.pushState({ modal: modalStack.length }, ''); } catch {}
  }
  function hideTop() {
    const m = modalStack.pop();
    if (!m) return;
    m.el.classList.remove('show'); m.backdrop.classList.remove('show');
    if (m.onClose) m.onClose();
    if (document.activeElement && m.el.contains(document.activeElement)) document.activeElement.blur();
  }
  function closeModal() {
    if (!modalStack.length) return;
    if (history.state && history.state.modal) history.back(); else hideTop();
  }
  window.addEventListener('popstate', () => { if (modalStack.length) hideTop(); });

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }

  // Диалог с произвольными кнопками. buttons: [{text, cls, value}]
  function dialog({ title, text = '', buttons, html = '' }) {
    return new Promise((resolve) => {
      const d = $('#dialog');
      d.innerHTML = `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${html}` +
        buttons.map((b, i) => `<button class="btn ${b.cls || 'btn-secondary'}" data-i="${i}">${esc(b.text)}</button>`).join('');
      let result = null;
      d.onclick = (e) => {
        const b = e.target.closest('button[data-i]');
        if (!b) return;
        const btn = buttons[+b.dataset.i];
        result = btn.value;
        if (btn.read) result = btn.read(d);
        closeModal();
      };
      openModal(d, $('#dlg-backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(result);
    });
  }
  const confirmDlg = (title, text, okText = 'Да', danger = false) =>
    dialog({ title, text, buttons: [{ text: okText, cls: danger ? 'btn-danger' : 'btn-primary', value: true }, { text: 'Отмена', value: false }] });

  // ---------- Переключатель месяца ----------
  const monthSwitch = (i, id) => `
    <div class="month-switch">
      <button class="arrow" data-act="${id}-prev" ${i === 0 ? 'disabled' : ''} aria-label="Предыдущий месяц">‹</button>
      <button class="title" data-act="${id}-pick">${monthName(i)}</button>
      <button class="arrow" data-act="${id}-next" ${i === C.MONTH_COUNT - 1 ? 'disabled' : ''} aria-label="Следующий месяц">›</button>
    </div>`;

  function pickMonth(current) {
    return new Promise((resolve) => {
      const sh = $('#sheet');
      let year = C.ymOf(current).y;
      const draw = () => {
        const months = C.yearByMonths(state, year);
        sh.innerHTML = `<div class="grabber"></div>
          <div class="sheet-head"><div class="grow"><div class="sheet-title">Выберите месяц</div></div><button class="icon-btn" data-close>×</button></div>
          <div class="seg">${C.YEARS.map((y) => `<button data-y="${y}" class="${y === year ? 'active' : ''}">${y}${y === C.YEAR ? ' ★' : ''}</button>`).join('')}</div>
          <div class="month-picker">${C.MONTHS.map((n, m) => { const i = C.indexOf(year, m); return `<button data-m="${i}" class="${i === current ? 'current' : ''}"><b>${n}</b><small>${months[m].shifts || months[m].grand ? M(months[m].grand) : '—'}</small></button>`; }).join('')}</div>`;
      };
      draw();
      let chosen = null;
      sh.onclick = (e) => {
        if (e.target.closest('[data-close]')) return closeModal();
        const yb = e.target.closest('[data-y]');
        if (yb) { year = +yb.dataset.y; return draw(); }
        const b = e.target.closest('[data-m]');
        if (b) { chosen = +b.dataset.m; closeModal(); }
      };
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(chosen);
    });
  }

  // ---------- Анимация чисел ----------
  function countUp(el, to, fmt) {
    const id = el.id, from = prevHero[id] ?? 0;
    prevHero[id] = to;
    if (from === to || matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 500;
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(p < 1 ? Math.round(from + (to - from) * e) : to);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---------- Главная ----------
  function renderHome() {
    const idx = ui.homeMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.monthSummary(state, m, today, y);
    const x = s.extras, b = x.cfg;
    const tgt = s.target;
    const best = s.best ? `${C.fmtDateShort(s.best.key)}` : '—';
    const recent = s.days.slice().reverse().slice(0, 5);
    const canToday = C.inYear(today);
    const projHint = s.projected === null ? 'внесите первую смену'
      : s.projectionBasis === 'year' ? 'по средней за год'
      : s.remainingShifts ? `ещё ~${s.remainingShifts} ${plural(s.remainingShifts, 'смена', 'смены', 'смен')}` : 'месяц завершён';

    $('#view-home').innerHTML = `
      ${monthSwitch(idx, 'home')}
      <div class="hero">
        <div class="hero-head"><div class="label">${s.manual !== null ? `Получено за ${C.MONTHS[m].toLowerCase()} · факт` : `Заработок за ${C.MONTHS[m].toLowerCase()}`}</div>
          <button class="hero-edit" data-act="manual-total" data-m="${idx}">✎ ${s.manual !== null ? 'Изменить' : 'Ввести итог'}</button></div>
        <div class="big num" id="hero-total">${M(s.grand)}</div>
        ${s.manual !== null ? `<div class="manual-diff ${s.manualDiff > 0 ? 'plus' : s.manualDiff < 0 ? 'minus' : ''}">${s.manualDiff === 0 ? 'Совпадает с расчётом' : `На ${M(Math.abs(s.manualDiff))} ${s.manualDiff > 0 ? 'больше' : 'меньше'}, чем ожидалось`}</div>
          <div class="sub num">По календарю ожидалось ${M(s.calc)}${x.penalty ? ` (с учётом штрафа ${M(x.penalty)})` : ''}</div>`
        : `<div class="sub num">${x.penalty ? `Смены ${M(s.total)} − штраф ${M(x.penalty)}` : `Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт указан в ${s.actualCount} ${plural(s.actualCount, 'смене', 'сменах', 'сменах')}` : ''}`}</div>`}
        ${tgt ? `<div class="progress"><i style="width:${Math.min(100, s.targetProgress * 100).toFixed(1)}%"></i></div>
          <div class="progress-label num"><span>${Math.round(s.targetProgress * 100)}% от цели ${M(tgt)}</span><span>${s.grand >= tgt ? 'Цель достигнута 🎉' : s.needPerShift ? `нужно ≈${M(s.needPerShift)}/смену` : `осталось ${M(tgt - s.grand)}`}</span></div>` : ''}
        ${pendingBlock(s)}
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Отработано смен</div><div class="t-value num">${s.shifts}</div><div class="t-sub">из ${s.plannedTotal} ${s.plannedByUser ? 'по плану' : 'рабочих дней'}${marksText(s.marks) ? ` · ${marksText(s.marks)}` : ''}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div><div class="t-sub">в среднем</div></div>
        <div class="tile"><div class="t-label">Заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div><div class="t-sub">в среднем</div></div>
        <button class="tile clickable" data-act="open-day" data-key="${s.best ? s.best.key : ''}" ${s.best ? '' : 'disabled'} style="text-align:left">
          <div class="t-label">Самый продуктивный день</div><div class="t-value num">${best}</div>
          <div class="t-sub num">${s.best ? `${N(s.best.lines)} линий · ${M(s.best.total)}` : 'нет данных'}</div></button>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${x.prodAvg === null ? '' : x.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</div><div class="t-sub">${x.prodAvg === null ? 'не указана' : `по ${x.prodDays} ${plural(x.prodDays, 'смене', 'сменам', 'сменам')}`}</div></div>
        <div class="tile wide"><div class="t-label">Прогноз на месяц</div><div class="t-value num">${s.projected === null ? '—' : M(s.projected)}</div><div class="t-sub">${projHint}${s.projected !== null && (x.prodOk || s.needProd !== null) ? ` · <span class="pend-inline">${x.pending ? `+${M(x.pending)} премии ожидаются` : `до +${M(b.prodAmount)} премия при средней от ${N(b.prodThreshold, 0)}%`}</span>` : ''}</div></div>
      </div>
      ${payoutCard(idx)}
      ${bonusCard(s, idx)}
      ${s.shifts ? `<button class="wrap-btn" data-act="wrapped" data-y="${y}" data-mm="${m}"><span>🎬</span><div class="grow"><b>Итоги месяца · ${C.MONTHS[m].toLowerCase()}</b><small>истории о вашем месяце</small></div><i>›</i></button>` : ''}
      <button class="btn btn-primary" data-act="${canToday ? 'open-today' : 'go-cal'}">＋ ${canToday ? 'Записать сегодняшнюю смену' : 'Записать смену'}</button>
      ${recent.length ? `<div class="card" style="margin-top:14px"><h2>Смены за месяц <small>${s.shifts}</small></h2>
        ${recent.map(rowHtml).join('')}
        ${s.shifts > 5 ? `<button class="btn btn-secondary" data-act="go-cal" style="margin-top:6px">Все смены в календаре</button>` : ''}</div>`
      : `<p class="hint" style="text-align:center;margin-top:18px">${canToday ? '' : `Календарь рассчитан на ${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]} годы. `}Нажмите на любой день в календаре, чтобы внести смену.</p>`}`;
    countUp($('#hero-total'), Math.round(s.grand), (v) => (v === Math.round(s.grand) ? M(s.grand) : M(v)));
    updateChip();
  }
  // Отдельный блок «премия за производительность ожидается» — не входит в итог месяца
  // Премии за производительность и сервис — «ожидается», в итог не входят
  function pendingBlock(s) {
    const x = s.extras, b = x.cfg;
    const rows = [];
    if (x.prodAvg !== null) rows.push(x.prodOk
      ? `<div class="pend-row"><span>✓ Производительность ${N(x.prodAvg, 1)}%</span><b class="num">+${M(x.prodBonus)}</b></div>`
      : `<div class="pend-row dim"><span>🎯 Производительность ${N(x.prodAvg, 1)}% из ${N(b.prodThreshold, 0)}%</span><b class="num">+${M(b.prodAmount)}?</b></div>`);
    if (x.zone) rows.push(x.serviceBonus
      ? `<div class="pend-row"><span>✓ Сервис ${N(x.service, 2)}% · ${ZONES[x.zone][0].toLowerCase()}</span><b class="num">+${M(x.serviceBonus)}</b></div>`
      : `<div class="pend-row dim"><span>Сервис ${N(x.service, 2)}% · ${ZONES[x.zone][0].toLowerCase()} зона</span><b class="num">0 ₽</b></div>`);
    if (!rows.length) return '';
    return `<div class="pending ${x.pending ? 'ok' : ''}">
        <div class="pending-top"><span class="pending-tag">⏳ Премии — ожидаются</span>${x.pending ? `<b class="num">+${M(x.pending)}</b>` : ''}</div>
        ${rows.join('')}
        <div class="pending-sub num">${x.pending ? `не входят в итог${s.manual === null ? ` · вместе с ними: <b>${M(s.grandWithPending)}</b>` : ''}` : 'не входят в итог'}</div></div>`;
  }
  const marksText = (mk) => mk ? [['sick', 'больн.'], ['vacation', 'отпуск'], ['off', 'вых.'], ['work', 'раб. сб/вс']].filter(([k]) => mk[k]).map(([k, t]) => `${t} ${mk[k]}`).join(', ') : '';
  const ZONES = { green: ['Зелёная', 'zone-green'], yellow: ['Жёлтая', 'zone-yellow'], red: ['Красная', 'zone-red'] };
  // ---------- Выплаты: аванс, конверт, зарплата ----------
  const daysWord = (n) => (n === 0 ? 'сегодня' : n === 1 ? 'завтра' : n === -1 ? 'вчера' : n > 0 ? `через ${n} ${plural(n, 'день', 'дня', 'дней')}` : `${-n} ${plural(-n, 'день', 'дня', 'дней')} назад`);
  const dShort = (k) => `${C.WEEKDAYS[C.weekdayMon(k)].toLowerCase()} ${C.fmtDateShort(k)}`;
  function payoutCard(idx) {
    const { y, m } = C.ymOf(idx), today = todayKey();
    const list = C.payoutSchedule(state, m, y, today);
    const next = C.nextPayout(state, today);
    const got = C.payoutsTotal(state, m, y);
    const nextHtml = next ? `<div class="next-pay">
        <div class="np-icon">${next.icon}</div>
        <div class="grow"><div class="np-label">Ближайшая выплата</div><div class="np-title">${next.name} · ${next.dateTo ? `${C.fmtDateShort(next.date)}–${C.fmtDateShort(next.dateTo)}` : dShort(next.date)}</div></div>
        <div class="np-days num">${next.dateTo && next.daysLeft <= 0 ? 'ждём' : next.daysLeft <= 0 ? 'сегодня' : `<b>${next.daysLeft}</b><small>${plural(next.daysLeft, 'день', 'дня', 'дней')}</small>`}</div></div>` : '';
    return `<div class="card pay-card"><h2>Выплаты <small>${C.MONTHS[m].toLowerCase()}${got ? ` · получено ${M(got)}` : ''}</small></h2>
      ${nextHtml}
      ${list.map((p) => `<button class="pay-row ${p.status}" data-act="payout" data-m="${idx}" data-id="${p.id}">
        <span class="pay-ic">${p.icon}</span>
        <span class="grow"><b>${p.name} <span class="pay-for">${p.forMonth}</span></b><small>${p.dateTo ? `ориентировочно ${C.fmtDateShort(p.date)}–${C.fmtDateShort(p.dateTo)}` : dShort(p.date)}${p.shifted ? ' · перенос с выходного' : ''}</small></span>
        <span class="pay-st">${p.received ? `<b class="up">✓ ${p.amount != null ? M(p.amount) : 'получено'}</b>` : p.status === 'late' ? '<span class="down">не отмечено</span>' : p.status === 'today' ? '<b class="pend-inline">ожидается</b>' : `<span class="muted">${daysWord(p.daysLeft)}</span>`}</span>
      </button>`).join('')}
      <p class="hint">Нажмите на выплату, чтобы отметить, что она пришла, и записать сумму. Если дата выпадает на выходной или праздник, выплата ожидается раньше.</p></div>`;
  }
  function openPayoutSheet(idx, id) {
    const { y, m } = C.ymOf(idx);
    const p = C.payoutSchedule(state, m, y, todayKey()).find((x) => x.id === id);
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${p.icon} ${p.name}</div><div class="sheet-sub">${p.forMonth} · ${C.MONTHS[m]} ${y} · ${p.dateTo ? `ориентировочно ${C.fmtDateShort(p.date)}–${C.fmtDateShort(p.dateTo)}` : `по плану ${dShort(p.date)}`}</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="pay-form" autocomplete="off" novalidate>
        <div class="field"><label for="pf-amount">Пришло, ₽</label><input class="input big num" id="pf-amount" inputmode="decimal" placeholder="0" value="${p.amount != null ? String(p.amount).replace('.', ',') : ''}"></div>
        <div class="field"><label for="pf-date">Дата поступления</label><input class="input" type="date" id="pf-date" value="${p.receivedOn || (todayKey() >= p.date ? todayKey() : p.date)}"></div>
        <p class="error" id="pf-error"></p>
        <button class="btn btn-primary" type="submit">✓ Выплата пришла</button>
        ${p.received ? '<button class="btn btn-danger" type="button" data-unpay>Отменить отметку</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    sh.onclick = (e) => {
      if (e.target.closest('[data-close]')) return closeModal();
      if (e.target.closest('[data-unpay]')) { C.setPayout(state, m, y, id, { received: false, amount: null }); save(); closeModal(); renderAll(); toast('Отметка снята'); }
    };
    $('#pay-form').onsubmit = (e) => {
      e.preventDefault();
      const r = C.setPayout(state, m, y, id, { received: true, amount: $('#pf-amount').value, date: $('#pf-date').value });
      if (!r.ok) { $('#pf-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast(`${p.name}: получено`); }
    };
    openModal(sh, $('#backdrop'));
  }
  function bonusCard(s, idx) {
    const x = s.extras, b = x.cfg, m = C.ymOf(idx).m;
    const prodLine = x.prodAvg === null
      ? `<span class="muted">укажите производительность в сменах</span>`
      : x.prodOk ? `<b class="pend-val">+${M(x.prodBonus)}</b><div class="pend-note">ожидается · не в итоге</div>`
      : `<span class="muted">${s.needProd !== null && s.needProd <= 300 ? `нужно в среднем ${N(s.needProd, 1)}% в оставшиеся смены` : `ниже ${N(b.prodThreshold, 0)}%`}</span>`;
    const zone = x.zone ? ZONES[x.zone] : null;
    return `<div class="card bonus-card"><h2>Премии и штраф <small>${C.MONTHS[m].toLowerCase()}</small></h2>
      <div class="bonus-row"><div><div>За производительность</div><div class="hint" style="margin:2px 0 0">средняя ${x.prodAvg === null ? '—' : N(x.prodAvg, 2) + '%'} · нужно от ${N(b.prodThreshold, 0)}%</div>
        ${x.prodAvg !== null ? `<div class="meter"><i style="width:${Math.min(100, (x.prodAvg / (b.prodThreshold * 1.25)) * 100).toFixed(1)}%" class="${x.prodOk ? 'ok' : ''}"></i><s style="left:${(100 / 1.25).toFixed(1)}%"></s></div>` : ''}</div>
        <div class="bonus-val">${prodLine}</div></div>
      <div class="bonus-row"><div><div>За сервис ${zone ? `<span class="zone ${zone[1]}">${zone[0]}</span>` : ''}</div><div class="hint" style="margin:2px 0 0">${x.service === null ? 'качество за месяц не указано' : `качество ${N(x.service, 3)}%`} · зелёная от ${N(b.greenThreshold, 2)}%</div></div>
        <div class="bonus-val">${x.service === null ? '<span class="muted">—</span>' : x.serviceBonus ? `<b class="pend-val">+${M(x.serviceBonus)}</b><div class="pend-note">ожидается · не в итоге</div>` : '<span class="muted">0 ₽</span>'}</div></div>
      <div class="bonus-row"><div><div>Штраф за ошибки (сервис)</div><div class="hint" style="margin:2px 0 0">за месяц, вносится вручную</div></div>
        <div class="bonus-val">${x.penalty ? `<b class="down">−${M(x.penalty)}</b>` : '<span class="muted">0 ₽</span>'}</div></div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}">${x.service === null && !x.penalty ? 'Указать сервис и штраф' : 'Изменить сервис и штраф'}</button></div>`;
  }
  function openManualSheet(idx) {
    const { y, m } = C.ymOf(idx);
    const s = C.monthSummary(state, m, todayKey(), y);
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">Итог за ${C.MONTHS[m].toLowerCase()} ${y}</div><div class="sheet-sub">Сколько фактически получили за месяц</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="manual-form" autocomplete="off" novalidate>
        <div class="calc"><div><div class="formula">по календарю ожидалось</div><div class="formula">смены${s.extras.penalty ? ' − штраф' : ''}</div></div><div class="res num">${M(s.calc)}</div></div>
        <div class="field"><label for="mt-sum">Заработано итого, ₽ <span>из расчётного листа</span></label>
          <input class="input big num" id="mt-sum" inputmode="decimal" placeholder="${Math.round(s.calc)}" value="${s.manual !== null ? String(s.manual).replace('.', ',') : ''}"></div>
        <div class="note" id="mt-diff"></div>
        <p class="hint" style="margin:-4px 0 14px">Эта сумма заменит расчётный итог месяца на главной и в статистике. Ожидаемые премии к ней не прибавляются — если их уже выплатили, они входят в эту сумму.</p>
        <p class="error" id="mt-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        ${s.manual !== null ? '<button class="btn btn-danger" type="button" data-clear>Убрать — считать по календарю</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const upd = () => {
      const raw = $('#mt-sum').value.trim(), n = Number(raw.replace(',', '.').replace(/\s/g, '')), el = $('#mt-diff');
      if (!raw || !Number.isFinite(n)) { el.className = 'note'; el.textContent = ''; return; }
      const d = C.round2(n - s.calc);
      el.className = 'note ' + (d > 0 ? 'good' : d < 0 ? 'bad' : '');
      el.textContent = d === 0 ? 'Совпадает с расчётом' : `На ${M(Math.abs(d))} ${d > 0 ? 'больше' : 'меньше'}, чем ожидалось`;
    };
    $('#manual-form').addEventListener('input', upd); upd();
    const done = (val) => {
      const r = C.setMonthData(state, m, { actualTotal: val }, y);
      if (!r.ok) { $('#mt-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast(val === '' ? 'Итог снова считается по календарю' : 'Итог сохранён'); }
    };
    sh.onclick = (e) => { if (e.target.closest('[data-close]')) closeModal(); else if (e.target.closest('[data-clear]')) done(''); };
    $('#manual-form').onsubmit = (e) => { e.preventDefault(); if (!$('#mt-sum').value.trim()) return done(''); done($('#mt-sum').value); };
    openModal(sh, $('#backdrop'));
    if (s.manual === null) setTimeout(() => $('#mt-sum') && $('#mt-sum').focus(), 320);
  }
  function openMonthSheet(idx) {
    const { y, m } = C.ymOf(idx);
    const sh = $('#sheet');
    const md = (state.months || {})[C.monthId(m, y)] || {};
    const b = { ...C.DEFAULT_BONUS, ...state.settings.bonus };
    const v = (x) => (x === null || x === undefined || x === 0 ? '' : String(x).replace('.', ','));
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${C.MONTHS[m]} ${y}</div><div class="sheet-sub">Сервис и штраф за ошибки за месяц</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="month-form" autocomplete="off" novalidate>
        <div class="field"><label for="m-service">Сервис (качество без ошибок), % <span>из отчёта</span></label>
          <input class="input big num" id="m-service" inputmode="decimal" placeholder="99,95" value="${v(md.service)}"></div>
        <div class="note" id="m-zone"></div>
        <div class="field"><label for="m-penalty">Штраф за ошибки (сервис) за месяц, ₽ <span>0 — нет штрафа</span></label>
          <input class="input num" id="m-penalty" inputmode="decimal" placeholder="0" value="${v(md.penalty)}"></div>
        <p class="hint" style="margin:-4px 0 14px">Зоны: зелёная от ${N(b.greenThreshold, 2)}% (премия ${M(b.greenAmount)}), жёлтая от ${N(b.yellowThreshold, 2)}% (${M(b.yellowAmount)}), ниже — красная (${M(b.redAmount)}). Суммы меняются в настройках.</p>
        <p class="error" id="m-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const upd = () => {
      const raw = $('#m-service').value.trim(), n = Number(raw.replace(',', '.'));
      const el = $('#m-zone');
      if (!raw || !Number.isFinite(n)) { el.className = 'note'; el.textContent = ''; return; }
      const z = C.serviceZone(n, b);
      el.className = 'note';
      el.innerHTML = `<span class="zone ${ZONES[z][1]}">${ZONES[z][0]} зона</span> премия за сервис ${M(b[z + 'Amount'])}`;
    };
    $('#month-form').addEventListener('input', upd); upd();
    sh.onclick = (e) => { if (e.target.closest('[data-close]')) closeModal(); };
    $('#month-form').onsubmit = (e) => {
      e.preventDefault();
      const r = C.setMonthData(state, m, { service: $('#m-service').value, penalty: $('#m-penalty').value }, y);
      if (!r.ok) { $('#m-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast('Сохранено'); }
    };
    openModal(sh, $('#backdrop'));
  }
  function rowHtml(d) {
    const e = state.entries[d.key], p = C.parseKey(d.key);
    return `<button class="list-row" data-act="open-day" data-key="${d.key}">
      <div class="date-badge num">${p.d}<small>${C.WEEKDAYS[C.weekdayMon(d.key)]}</small></div>
      <div class="grow"><div>${e.mood ? C.MOODS[e.mood - 1].icon + ' ' : ''}${N(e.lines)} линий${e.prod !== null && e.prod !== undefined ? ` · ${N(e.prod, 2)}%` : ''}${e.hours ? ` · ${N(e.hours, 2)} ч` : ''}</div><div>${e.start && e.end ? `${e.start}–${e.end} · ` : ''}${e.actual !== null ? `факт · расчёт ${M(C.estimated(e))}` : `${N(e.lines)} × ${M(e.rate)}`}${e.comment ? ' · ' + esc(e.comment) : ''}</div></div>
      <div class="amount num">${M(C.total(e))}</div></button>`;
  }
  const plural = (n, a, b, c) => { n = Math.abs(n) % 100; const n1 = n % 10; return n > 10 && n < 20 ? c : n1 > 1 && n1 < 5 ? b : n1 === 1 ? a : c; };

  // ---------- Календарь ----------
  function renderCal(anim) {
    const idx = ui.calMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.summarize(state.entries, C.monthKeys(m, y));
    const ex = C.monthExtras(state, m, s, y);
    const payMap = {};
    C.payoutSchedule(state, m, y).forEach((p) => { const k = p.received && p.receivedOn && C.inYear(p.receivedOn, y) ? p.receivedOn : p.date; payMap[k] = (payMap[k] || '') + p.icon; });
    $('#view-cal').innerHTML = `
      ${monthSwitch(idx, 'cal')}
      <div class="cal" id="cal-swipe">
        <div class="cal-head">${C.WEEKDAYS.map((w) => `<div>${w}</div>`).join('')}</div>
        <div class="cal-grid ${anim ? 'anim-' + anim : ''}">
          ${C.calendarGrid(m, y).flat().map((k) => {
            if (!k) return '<div class="day empty"></div>';
            const info = C.dayStatus(state, k), e = state.entries[k];
            const cls = ['day', info.off ? 'off' : '', info.mark ? 'mark-' + info.mark : '', k === today ? 'today' : '', e ? 'has' : '', e && e.actual !== null ? 'actual' : ''].join(' ');
            return `<button class="${cls}" data-act="open-day" data-key="${k}" aria-label="${C.fmtDateLong(k)}, ${info.label}">
              <span class="num">${C.parseKey(k).d}</span>${payMap[k] ? `<span class="pay-badge">${payMap[k]}</span>` : ''}
              ${e ? `<span class="d-lines num">${e.lines ? N(e.lines) : '₽'}</span><span class="d-money num">${C.fmtMoneyShort(C.total(e))}</span>` : info.mark ? `<span class="d-mark">${info.short}</span>` : ''}
            </button>`;
          }).join('')}
        </div>
        <div class="legend">
          <span><i style="background:var(--accent-soft);border:1px solid var(--accent)"></i>Смена внесена</span>
          <span><i style="background:var(--weekend)"></i>Выходной (сб, вс)</span>
          <span><i style="background:var(--good);border-radius:50%;width:8px;height:8px"></i>Указан факт</span>
          <span><i class="lg-sick"></i>Больничный</span>
          <span><i class="lg-vacation"></i>Отпуск</span>
          <span>💳 ✉️ 💰 Выплаты</span>
        </div>
      </div>
      <div class="cal-summary">
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Итого</div><div class="t-value num">${C.fmtMoneyShort(s.total + ex.net)}&nbsp;₽</div></div>
      </div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}" style="margin-top:12px">Сервис и штраф за ${C.MONTHS[m].toLowerCase()}${ex.penalty ? ` · −${M(ex.penalty)}` : ''}</button>
      <p class="hint" style="text-align:center">Рабочих дней в месяце: ${C.workdaysInMonth(m, y, state)}${(() => { const t = marksText(C.marksInMonth(state, m, y)); return t ? ` (с учётом отметок: ${t})` : ''; })()}. Выходной, больничный или отпуск можно отметить, нажав на день. Листайте календарь свайпом.</p>`;
    bindSwipe();
    updateChip();
  }
  function bindSwipe() {
    const el = $('#cal-swipe');
    let x0 = null, y0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dy) < 50) shiftCal(dx < 0 ? 1 : -1);
    }, { passive: true });
  }
  function shiftCal(d) {
    const i = ui.calMonth + d;
    if (i < 0 || i >= C.MONTH_COUNT) return;
    ui.calMonth = i; renderCal(d > 0 ? 'left' : 'right');
  }

  // ---------- Форма дня ----------
  function openDay(k) {
    if (!C.isValidKey(k) || !C.inYear(k)) return;
    const sh = $('#sheet');
    const already = modalStack.length && modalStack[modalStack.length - 1].el === sh;
    fillDaySheet(k);
    if (!already) {
      openModal(sh, $('#backdrop'));
      if (!state.entries[k]) setTimeout(() => { const i = $('#f-lines'); if (i) i.focus(); }, 320);
    }
  }
  function fillDaySheet(k) {
    const sh = $('#sheet');
    const e = state.entries[k];
    const info = C.dayStatus(state, k);
    const curRate = C.rateFor(state.settings.rateHistory, k);
    const rate = e ? e.rate : curRate;
    const v = (x) => (x === null || x === undefined ? '' : String(x).replace('.', ','));
    const prevK = C.addDays(k, -1), nextK = C.addDays(k, 1);
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head">
        <button class="icon-btn" data-day="${prevK}" ${C.inYear(prevK) ? '' : 'disabled style="opacity:.3"'} aria-label="Предыдущий день">‹</button>
        <div class="grow"><div class="sheet-title">${C.fmtDateLong(k)}</div>
          <div class="sheet-sub ${info.off ? 'holiday' : ''}">${C.WEEKDAYS_FULL[C.weekdayMon(k)]} · ${esc(info.label)}</div></div>
        <button class="icon-btn" data-day="${nextK}" ${C.inYear(nextK) ? '' : 'disabled style="opacity:.3"'} aria-label="Следующий день">›</button>
      </div>
      <div class="marks-row">${(info.weekend ? [['work', '💼 Рабочий день']] : [['off', '🛋 Выходной'], ['sick', '🤒 Больничный'], ['vacation', '🌴 Отпуск']])
        .map(([kd, t]) => `<button type="button" data-mark="${kd}" class="${info.mark === kd ? 'active' : ''}">${t}</button>`).join('')}</div>
      ${info.mark && info.off ? `<div class="mark-banner"><div><b>${esc(info.label)}</b><div class="hint" style="margin:2px 0 0">День не считается рабочим — смен в месяце меньше</div></div><button type="button" data-mark="">Снять</button></div>
        <p class="hint" style="margin:0 0 12px">Если смена всё-таки была — просто заполните её ниже, отметка снимется.</p>` : ''}
      ${info.mark === 'work' ? `<div class="mark-banner"><div><b>Рабочий выходной</b><div class="hint" style="margin:2px 0 0">День добавлен к рабочим дням месяца</div></div><button type="button" data-mark="">Снять</button></div>` : ''}
      <form id="day-form" autocomplete="off" novalidate>
        <div class="field"><label for="f-lines">Количество собранных линий</label>
          <input class="input big num" id="f-lines" inputmode="numeric" pattern="[0-9]*" placeholder="0" value="${e ? v(e.lines || '') : ''}">
          <div class="quick">${[10, 50, 100].map((n) => `<button type="button" data-add="${n}">+${n}</button>`).join('')}<button type="button" data-add="0">Сброс</button></div>
        </div>
        <div class="field"><label for="f-prod">Производительность за день, % <span>из отчёта</span></label>
          <input class="input num" id="f-prod" inputmode="decimal" placeholder="Например, 124,5" value="${e ? v(e.prod) : ''}"></div>
        <div class="note" id="f-prodnote"></div>
        <div class="calc"><div><div class="formula num" id="f-formula"></div><div class="formula">расчётный заработок</div></div><div class="res num" id="f-est"></div></div>
        ${e && e.rate !== curRate ? `<label class="check"><input type="checkbox" id="f-rerate"><span>Запись сохранена по тарифу <b>${M(e.rate)}</b>. Пересчитать по тарифу на эту дату — <b>${M(curRate)}</b>?</span></label>` : ''}
        <div class="field"><label for="f-actual">Фактически заработано, ₽ <span>необязательно</span></label>
          <input class="input num" id="f-actual" inputmode="decimal" placeholder="Например, по расчётному листу" value="${e ? v(e.actual) : ''}"></div>
        <div class="note" id="f-diff"></div>
        <div class="field"><label>Время смены <span>ночная — на дату начала</span></label>
          <div class="time-row">
            <div><small>Начало</small><input class="input num" type="time" id="f-start" value="${e ? (e.start || '') : (state.settings.shiftStart || '21:00')}"></div>
            <div class="time-arrow">→</div>
            <div><small>Конец</small><input class="input num" type="time" id="f-end" value="${e ? (e.end || '') : ''}"></div>
          </div>
          <div class="quick">${['06:00', '07:00', '08:00'].map((t) => `<button type="button" data-end="${t}">до ${t.replace(/^0/, '')}</button>`).join('')}</div></div>
        <div class="field"><label for="f-hours">Отработано часов <span>считается по времени</span></label>
          <input class="input num" id="f-hours" inputmode="decimal" placeholder="Например, 10" value="${e ? v(e.hours) : ''}"></div>
        <div class="field"><label>Самочувствие за смену <span>необязательно</span></label>
          <div class="moods">${C.MOODS.map((md) => `<button type="button" data-mood="${md.v}" class="${e && e.mood === md.v ? 'active' : ''}"><span>${md.icon}</span><small>${md.label}</small></button>`).join('')}</div>
          <input type="hidden" id="f-mood" value="${e && e.mood ? e.mood : ''}"></div>
        <div class="note" id="f-perhour"></div>
        <div class="field"><label for="f-comment">Комментарий <span>необязательно</span></label>
          <textarea class="input" id="f-comment" maxlength="500" placeholder="Ночная смена, переработка…">${e ? esc(e.comment) : ''}</textarea></div>
        <p class="error" id="f-error"></p>
        <button class="btn btn-primary" type="submit">${e ? 'Сохранить изменения' : 'Сохранить смену'}</button>
        ${e ? '<button class="btn btn-danger" type="button" data-del>Удалить запись</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const f = $('#day-form');
    const rateNow = () => ($('#f-rerate') && $('#f-rerate').checked ? curRate : rate);
    const parse = (s) => { const n = Number(String(s).replace(',', '.').replace(/\s/g, '')); return s.trim() === '' || !Number.isFinite(n) ? null : n; };
    const update = () => {
      const lines = parse($('#f-lines').value), actual = parse($('#f-actual').value), hours = parse($('#f-hours').value);
      const r = rateNow(), est = C.round2((lines || 0) * r);
      $('#f-formula').textContent = `${N(lines || 0)} × ${M(r)}`;
      $('#f-est').textContent = M(est);
      const diff = $('#f-diff');
      if (actual !== null && lines) {
        const d = C.round2(actual - est);
        diff.className = 'note ' + (d >= 0 ? 'good' : 'bad');
        diff.textContent = d === 0 ? 'Факт совпадает с расчётом' : `Факт ${d > 0 ? 'больше' : 'меньше'} расчёта на ${M(Math.abs(d))}. В итог пойдёт фактическая сумма.`;
      } else { diff.className = 'note'; diff.textContent = actual !== null ? 'В итог пойдёт фактическая сумма.' : ''; }
      const prod = parse($('#f-prod').value), pn = $('#f-prodnote');
      const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
      if (prod !== null) { pn.className = 'note ' + (prod >= thr ? 'good' : 'bad'); pn.textContent = prod >= thr ? `Не ниже ${N(thr, 0)}% — уровень премии` : `Ниже ${N(thr, 0)}% на ${N(thr - prod, 2)}%`; }
      else { pn.className = 'note'; pn.textContent = ''; }
      const total = actual !== null ? actual : est;
      $('#f-perhour').textContent = hours ? `≈ ${N((lines || 0) / hours, 1)} линий/час · ${M(C.round2(total / hours))}/час` : '';
    };
    // Часы считаются по времени начала и конца, пока вы не ввели их вручную
    let hoursTouched = !!(e && e.hours && !(e.start && e.end && C.shiftHours(e.start, e.end) === e.hours));
    const syncHours = () => {
      const h = C.shiftHours($('#f-start').value, $('#f-end').value);
      if (h !== null && !hoursTouched) $('#f-hours').value = String(h).replace('.', ',');
    };
    $('#f-hours').addEventListener('input', () => { hoursTouched = $('#f-hours').value.trim() !== ''; });
    $('#f-start').addEventListener('input', syncHours); $('#f-end').addEventListener('input', syncHours);
    f.addEventListener('input', update);
    f.addEventListener('change', update);
    update();
    sh.onclick = async (ev) => {
      const t = ev.target;
      if (t.closest('[data-close]')) return closeModal();
      const dayBtn = t.closest('[data-day]');
      if (dayBtn && !dayBtn.disabled) return fillDaySheet(dayBtn.dataset.day);
      const mb = t.closest('[data-mark]');
      if (mb) {
        const kind = mb.dataset.mark || null;
        const toggleOff = kind && info.mark === kind; // повторное нажатие снимает отметку
        const target = toggleOff ? null : kind;
        if (target && C.MARKS[target].off && state.entries[k]
          && !(await confirmDlg(`${C.MARKS[target].label}?`, `Смена за ${C.fmtDateLong(k)} будет удалена — в этот день вы не работали.`, 'Да, отметить', true))) return;
        C.setMark(state, k, target); save(); renderAll();
        toast(target ? `${C.fmtDateLong(k)}: ${C.MARKS[target].label.toLowerCase()}` : 'Отметка снята');
        if (target && C.MARKS[target].off) return closeModal();
        return fillDaySheet(k);
      }
      const endBtn = t.closest('[data-end]');
      if (endBtn) { $('#f-end').value = endBtn.dataset.end; syncHours(); update(); return; }
      const moodBtn = t.closest('[data-mood]');
      if (moodBtn) {
        const cur = $('#f-mood').value === moodBtn.dataset.mood;
        $('#f-mood').value = cur ? '' : moodBtn.dataset.mood;
        sh.querySelectorAll('[data-mood]').forEach((x) => x.classList.toggle('active', !cur && x === moodBtn));
        return;
      }
      const add = t.closest('[data-add]');
      if (add) {
        const inp = $('#f-lines'), n = +add.dataset.add;
        inp.value = n ? String((parseInt(inp.value, 10) || 0) + n) : '';
        update(); return;
      }
      if (t.closest('[data-del]')) {
        if (await confirmDlg('Удалить запись?', `Смена за ${C.fmtDateLong(k)} будет удалена.`, 'Удалить', true)) {
          C.deleteEntry(state, k); save(); closeModal(); renderAll(); toast('Запись удалена');
        }
      }
    };
    f.onsubmit = (ev) => {
      ev.preventDefault();
      const res = C.saveEntry(state, k, { lines: $('#f-lines').value, actual: $('#f-actual').value, hours: $('#f-hours').value, prod: $('#f-prod').value,
          start: $('#f-start').value, end: $('#f-end').value, mood: $('#f-mood').value, comment: $('#f-comment').value },
        { useCurrentRate: !!($('#f-rerate') && $('#f-rerate').checked) });
      if (!res.ok) { $('#f-error').textContent = res.error; return; }
      if (save()) {
        closeModal(); renderAll();
        toast(`Сохранено: ${M(C.total(res.entry))}`);
        if (window.Pet) Pet.react(k);
      }
    };
  }

  // ---------- Графики (SVG без библиотек) ----------
  const W = 340, H = 170, PL = 34, PR = 6, PT = 10, PB = 22;
  function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
  function axes(max, fmtAxis) {
    let s = '';
    for (let i = 0; i <= 3; i++) {
      const y = PT + (H - PT - PB) * (1 - i / 3);
      s += `<line class="gridline" x1="${PL}" x2="${W - PR}" y1="${y}" y2="${y}"/><text x="${PL - 5}" y="${y + 3}" text-anchor="end">${fmtAxis((max * i) / 3)}</text>`;
    }
    return s;
  }
  function xLabels(labels, xs) {
    const step = Math.ceil(labels.filter(Boolean).length / 8);
    let c = 0;
    return labels.map((l, i) => (l && c++ % step === 0 ? `<text x="${xs(i)}" y="${H - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  }
  // Возвращает HTML карточки графика. items: [{label, tip, value}]
  let chartSeq = 0;
  function chartCard({ title, items, kind = 'bar', fmt = M, fmtAxis = C.fmtMoneyShort, avg = null, alt = false, summary }) {
    const id = 'ch' + ++chartSeq;
    const has = items.some((it) => it.value > 0);
    if (!has) return `<div class="card chart-card"><h2>${esc(title)}</h2><div class="empty-chart">Нет данных за выбранный период</div></div>`;
    const max = niceMax(Math.max(...items.map((i) => i.value), avg || 0));
    const iw = (W - PL - PR) / items.length;
    const xs = (i) => PL + iw * i + iw / 2;
    const ys = (v) => PT + (H - PT - PB) * (1 - v / max);
    let body = '';
    if (kind === 'bar') {
      const bw = Math.max(1.5, Math.min(26, iw * 0.68));
      body = items.map((it, i) => it.value > 0
        ? `<rect class="bar ${alt ? 'alt' : ''}" data-i="${i}" x="${xs(i) - bw / 2}" y="${ys(it.value)}" width="${bw}" height="${Math.max(0, H - PB - ys(it.value))}" rx="${Math.min(4, bw / 3)}" style="animation-delay:${Math.min(i * 12, 400)}ms"/>` : '').join('');
    } else {
      const pts = items.map((it, i) => [xs(i), ys(it.value)]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
      body = `<path class="area" d="${d}L${pts[pts.length - 1][0].toFixed(1)} ${H - PB}L${pts[0][0].toFixed(1)} ${H - PB}Z"/><path class="line" d="${d}"/>` +
        (items.length <= 40 ? items.map((it, i) => (it.value > 0 ? `<circle class="dot" data-i="${i}" cx="${xs(i)}" cy="${ys(it.value)}" r="3"/>` : '')).join('') : '');
    }
    const hits = items.map((_, i) => `<rect class="hit" data-i="${i}" x="${PL + iw * i}" y="${PT}" width="${iw}" height="${H - PT}"/>`).join('');
    const avgLine = avg ? `<line class="avg" x1="${PL}" x2="${W - PR}" y1="${ys(avg)}" y2="${ys(avg)}"/>` : '';
    chartData[id] = { items, fmt, summary };
    return `<div class="card chart-card"><h2>${esc(title)}</h2>
      <div class="readout" id="${id}-ro">${summary}</div>
      <svg class="chart" id="${id}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px">
        ${axes(max, fmtAxis)}${body}${avgLine}${xLabels(items.map((i) => i.label), xs)}${hits}</svg></div>`;
  }
  const chartData = {};
  document.addEventListener('click', (e) => {
    const hit = e.target.closest('svg.chart [data-i]');
    if (!hit) return;
    const svg = hit.closest('svg'), cd = chartData[svg.id], i = +hit.dataset.i, it = cd.items[i];
    svg.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel'));
    svg.querySelectorAll(`.bar[data-i="${i}"], .dot[data-i="${i}"]`).forEach((x) => x.classList.add('sel'));
    $('#' + svg.id + '-ro').innerHTML = `<b class="num">${cd.fmt(it.value)}</b><span>${esc(it.tip || it.label)}</span>`;
  });

  // ---------- Статистика ----------
  function periodKeys() {
    const st = ui.stats;
    if (st.mode === 'month') { const { y, m } = C.ymOf(st.month); return C.monthKeys(m, y); }
    if (st.mode === 'year') return C.yearKeys(st.year);
    return C.rangeKeys(st.from, st.to).filter((k) => C.inYear(k));
  }
  function periodTitle() {
    const st = ui.stats;
    if (st.mode === 'month') return monthName(st.month);
    if (st.mode === 'year') return `${st.year} год`;
    return `${C.fmtDateShort(st.from <= st.to ? st.from : st.to)} — ${C.fmtDateShort(st.from <= st.to ? st.to : st.from)}`;
  }
  function renderStats() {
    chartSeq = 0;
    const st = ui.stats, keys = periodKeys();
    const s = C.summarize(state.entries, keys);
    const wk = C.weekly(state.entries, keys);
    // Год для раздела «год целиком»: год выбранного месяца / выбранный год / год начала периода
    const statYear = st.mode === 'month' ? C.ymOf(st.month).y : st.mode === 'year' ? st.year : C.parseKey(st.from <= st.to ? st.from : st.to).y;
    const months = C.yearByMonths(state, statYear);
    const yearTotal = C.round2(months.reduce((a, x) => a + x.grand, 0));
    const yearPending = C.round2(months.reduce((a, x) => a + (x.manual !== null ? 0 : x.pending), 0));
    const manualMonths = months.filter((x) => x.manual !== null).length;
    const yearPenalty = C.round2(months.reduce((a, x) => a + x.extras.penalty, 0));
    const yearProd = (() => { const d = months.reduce((a, x) => a + x.prodDays, 0); return d ? months.reduce((a, x) => a + x.prodSum, 0) / d : null; })();
    // Премии и штраф — помесячные: учитываются в режимах «Месяц» и «Весь год»
    const curM = st.mode === 'month' ? months[C.ymOf(st.month).m] : null;
    const pex = curM ? { penalty: curM.extras.penalty, pending: curM.manual !== null ? 0 : curM.pending, manual: curM.manual, diff: curM.manualDiff, calc: curM.calc }
      : st.mode === 'year' ? { penalty: yearPenalty, pending: yearPending, manual: null } : null;
    const periodGrand = curM ? curM.grand : st.mode === 'year' ? yearTotal : s.total;
    const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
    const yearLines = months.reduce((a, x) => a + x.lines, 0);
    const yearShifts = months.reduce((a, x) => a + x.shifts, 0);
    const daily = keys.length <= 62;
    const dayItems = keys.map((k) => { const e = state.entries[k]; return { label: daily ? String(C.parseKey(k).d) : C.MONTHS_SHORT[C.parseKey(k).m], tip: `${C.fmtDateLong(k)}, ${C.WEEKDAYS_FULL[C.weekdayMon(k)].toLowerCase()}`, value: e ? C.total(e) : 0, lines: e ? e.lines : 0 }; });
    if (!daily) dayItems.forEach((it, i) => { if (C.parseKey(keys[i]).d !== 1) it.label = ''; });
    const opt = (v, cur, t) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${t}</option>`;
    const maxMonth = months.reduce((b, x, i) => (x.grand > months[b].grand ? i : b), 0);
    const prodItems = keys.filter((k) => state.entries[k] && state.entries[k].prod !== null && state.entries[k].prod !== undefined)
      .map((k) => ({ label: daily ? String(C.parseKey(k).d) : C.fmtDateShort(k), tip: C.fmtDateLong(k), value: state.entries[k].prod }));

    $('#view-stats').innerHTML = `
      <div class="seg" role="tablist">
        ${[['month', 'Месяц'], ['year', 'Весь год'], ['range', 'Период']].map(([v, t]) => `<button data-mode="${v}" class="${st.mode === v ? 'active' : ''}">${t}</button>`).join('')}
      </div>
      ${st.mode === 'month' ? `<div class="field"><select class="input" id="st-month">${C.YEARS.map((y) => `<optgroup label="${y}">${C.MONTHS.map((n, m) => opt(C.indexOf(y, m), st.month, `${n} ${y}`)).join('')}</optgroup>`).join('')}</select></div>` : ''}
      ${st.mode === 'year' ? `<div class="seg">${C.YEARS.map((y) => `<button data-year="${y}" class="${y === st.year ? 'active' : ''}">${y}</button>`).join('')}</div>` : ''}
      ${st.mode === 'range' ? `<div class="period-inputs">
          <div><label for="st-from">С</label><input class="input" type="date" id="st-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.from}"></div>
          <div><label for="st-to">По</label><input class="input" type="date" id="st-to" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.to}"></div></div>` : ''}

      <div class="card"><h2>${esc(periodTitle())}</h2>
        <div class="year-total num">${M(periodGrand)}</div>
        ${pex && pex.manual !== null ? `<p class="hint" style="margin-top:2px">Фактически получено (введено вручную) · по календарю ${M(pex.calc)} · <b class="${pex.diff >= 0 ? 'up' : 'down'}">${pex.diff >= 0 ? '+' : '−'}${M(Math.abs(pex.diff))}</b></p>`
          : pex && pex.penalty ? `<p class="hint" style="margin-top:2px">Смены ${M(s.total)} − штраф ${M(pex.penalty)}</p>` : ''}
        ${st.mode === 'year' && manualMonths ? `<p class="hint" style="margin-top:2px">В ${manualMonths} ${plural(manualMonths, 'месяце', 'месяцах', 'месяцах')} учтена фактическая сумма, введённая вручную</p>` : ''}
        ${pex && pex.pending ? `<div class="pending ok card-pending"><div class="pending-top"><span class="pending-tag">⏳ Премии — ожидаются</span><b class="num">+${M(pex.pending)}</b></div><div class="pending-sub">за производительность и сервис · не входят в итог</div></div>` : ''}
        ${st.mode === 'range' ? '<p class="hint" style="margin-top:2px">За произвольный период — только смены. Премии и штраф помесячные, смотрите их в режимах «Месяц» и «Весь год».</p>' : ''}
        <p class="hint" style="margin-top:2px">Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт ${M(s.actual)} (${s.actualCount} ${plural(s.actualCount, 'смена', 'смены', 'смен')})` : ''}${s.diffCount ? ` · разница факт−расчёт ${s.diff >= 0 ? '+' : '−'}${M(Math.abs(s.diff))}` : ''}</p>
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за неделю</div><div class="t-value num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</div><div class="t-sub">${wk.workedWeeks ? `по ${wk.workedWeeks} ${plural(wk.workedWeeks, 'неделе', 'неделям', 'неделям')} со сменами` : ''}</div></div>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${s.prodAvg === null ? '' : s.prodAvg >= thr ? 'up' : 'down'}">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</div><div class="t-sub">${s.prodDays ? `по ${s.prodDays} ${plural(s.prodDays, 'смене', 'сменам', 'сменам')}` : 'не указана'}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div></div>
        <div class="tile"><div class="t-label">Лучший день</div><div class="t-value num">${s.best ? C.fmtDateShort(s.best.key) : '—'}</div><div class="t-sub num">${s.best ? `${N(s.best.lines)} линий` : ''}</div></div>
        ${s.hours ? `<div class="tile wide"><div class="t-label">Выработка в час (по сменам с указанными часами)</div><div class="t-value num">${N(s.linesPerHour, 1)} линий/ч · ${M(s.earnPerHour)}/ч</div><div class="t-sub num">${N(s.hours, 1)} ч всего</div></div>` : ''}
      </div>

      ${chartCard({ title: 'Ежедневный заработок', items: dayItems, kind: daily ? 'bar' : 'line', avg: s.shifts ? s.avgPerShift : null,
        summary: `<b class="num">${M(s.total)}</b><span>${daily ? 'пунктир — среднее за смену · нажмите на столбец' : 'нажмите на график'}</span>` })}
      ${chartCard({ title: 'Собранные линии по дням', items: dayItems.map((d) => ({ ...d, value: d.lines })), kind: 'line', fmt: (v) => N(v) + ' линий', fmtAxis: (v) => N(v),
        summary: `<b class="num">${N(s.lines)}</b><span>линий за период</span>` })}
      ${chartCard({ title: 'Производительность по дням', items: prodItems, kind: prodItems.length > 40 ? 'line' : 'bar', fmt: (v) => N(v, 2) + '%', fmtAxis: (v) => N(v) + '%', avg: thr, alt: true,
        summary: `<b class="num">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</b><span>средняя · пунктир — ${N(thr, 0)}% для премии</span>` })}
      ${wk.weeks.length > 1 ? chartCard({ title: 'Заработок по неделям', items: wk.weeks.map((w) => ({ label: C.fmtDateShort(w.monday).split(' ')[0], tip: `Неделя ${C.fmtDateShort(w.monday)} — ${C.fmtDateShort(w.sunday)}, ${w.shifts} ${plural(w.shifts, 'смена', 'смены', 'смен')}`, value: w.total })),
        avg: wk.avgWeekly || null, alt: true, summary: `<b class="num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</b><span>в среднем за неделю</span>` }) : ''}

      <h2 style="margin:22px 4px 10px;font-size:20px">${statYear} год целиком</h2>
      <div class="card"><div class="muted" style="font-size:14px">Общая сумма заработка за ${statYear} год</div>
        <div class="year-total num">${M(yearTotal)}</div>
        ${yearPenalty ? `<p class="hint" style="margin-top:2px">с учётом штрафов −${M(yearPenalty)}</p>` : ''}
        ${yearPending ? `<div class="pending ok card-pending"><div class="pending-top"><span class="pending-tag">⏳ Премии — отдельно</span><b class="num">+${M(yearPending)}</b></div><div class="pending-sub">за производительность и сервис за год · не входят в итог</div></div>` : ''}
        <p class="hint" style="margin-top:2px">${N(yearLines)} линий · ${yearShifts} ${plural(yearShifts, 'смена', 'смены', 'смен')}${yearProd !== null ? ` · средняя производительность ${N(yearProd, 2)}%` : ''}</p></div>
      ${chartCard({ title: 'Заработок по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.grand })),
        summary: yearShifts ? `<b class="num">${M(months[maxMonth].grand)}</b><span>лучший месяц — ${C.MONTHS[maxMonth].toLowerCase()}</span>` : '' })}
      ${chartCard({ title: 'Линии по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.lines })), alt: true, fmt: (v) => N(v) + ' линий', fmtAxis: (v) => C.fmtMoneyShort(v),
        summary: `<b class="num">${N(yearLines)}</b><span>линий за год</span>` })}
      <div class="card"><h2>Сравнение месяцев</h2>
        <table class="table num"><thead><tr><th>Месяц</th><th>Смен</th><th>Произв.</th><th>Итого</th><th>к пред.</th></tr></thead><tbody>
        ${months.map((x, i) => `<tr class="${x.shifts ? '' : 'zero'}"><td>${C.MONTHS[i]}</td><td>${x.shifts || '—'}</td><td class="${x.prodAvg === null ? '' : x.extras.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</td><td>${x.shifts || x.grand ? M(x.grand) : '—'}${x.manual !== null ? ' ✎' : ''}${x.pending && x.manual === null ? `<br><small class="pend-inline">+${C.fmtMoneyShort(x.pending)} ожид.</small>` : ''}</td>
          <td class="${x.change > 0 ? 'up' : x.change < 0 ? 'down' : ''}">${x.change === null || !x.shifts ? '—' : (x.change > 0 ? '+' : '') + N(x.change * 100, 0) + '%'}</td></tr>`).join('')}
        </tbody><tfoot><tr><td>Итого</td><td>${yearShifts}</td><td>${yearProd === null ? '—' : N(yearProd, 1) + '%'}</td><td>${M(yearTotal)}</td><td></td></tr></tfoot></table><p class="hint">«Итого» — смены − штраф, или фактическая сумма, если вы её ввели (✎). Премии показаны отдельно («ожид.»).</p></div>`;

    $('#view-stats').onclick = (e) => {
      const b = e.target.closest('[data-mode]'); if (b) { st.mode = b.dataset.mode; return renderStats(); }
      const yb = e.target.closest('[data-year]'); if (yb) { st.year = +yb.dataset.year; renderStats(); }
    };
    const sm = $('#st-month'); if (sm) sm.onchange = () => { st.month = +sm.value; renderStats(); };
    const f = $('#st-from'), t = $('#st-to');
    if (f) {
      const upd = () => { if (C.isValidKey(f.value) && C.isValidKey(t.value)) { st.from = f.value; st.to = t.value; renderStats(); } };
      f.onchange = upd; t.onchange = upd;
    }
    updateChip();
  }

  // ---------- Итоги месяца: истории на весь экран ----------
  const W_DUR = 6500;
  function wrappedSlides(w) {
    const S = [];
    const monthGen = C.MONTHS_GEN[w.m];
    const prevName = w.prev ? C.MONTHS[C.MONTHS.indexOf(w.prev.name)] : '';
    const days = w.hours ? C.round2(w.hours / 24) : 0;
    S.push({ bg: 'g-intro', dur: 4200, html: `
      <div class="w-shapes"><i></i><i></i><i></i><i></i></div>
      <div class="w-kicker a1">Итоги месяца</div>
      <div class="w-huge a2">${w.name}</div>
      <div class="w-year a3">${w.y}</div>
      <div class="w-sub a4">Смотрим, как он прошёл 🌙</div>` });
    S.push({ bg: 'g-night', html: `
      <div class="w-kicker a1">В ${w.name === 'Май' ? 'мае' : monthPrep(w.m)} ты вышел на смену</div>
      <div class="w-num a2"><span data-count="${w.shifts}">0</span></div>
      <div class="w-unit a2">${plural(w.shifts, 'раз', 'раза', 'раз')}</div>
      ${w.hours ? `<div class="w-line a3">Это <b><span data-count="${w.hours}" data-fmt="num1">0</span> ${plural(Math.round(w.hours), 'час', 'часа', 'часов')}</b> на складе</div>
        <div class="w-line a4">≈ ${N(days, 1)} ${plural(Math.round(days), 'сутки', 'суток', 'суток')} без перерыва 🌙</div>` : ''}
      ${w.marks.sick || w.marks.vacation ? `<div class="w-line a5 w-dim">${w.marks.sick ? `больничный: ${w.marks.sick} дн.` : ''}${w.marks.sick && w.marks.vacation ? ' · ' : ''}${w.marks.vacation ? `отпуск: ${w.marks.vacation} дн.` : ''}</div>` : ''}` });
    S.push({ bg: 'g-lines', html: `
      <div class="w-boxes"><i>📦</i><i>📦</i><i>📦</i><i>📦</i><i>📦</i><i>📦</i></div>
      <div class="w-kicker a1">Ты собрал</div>
      <div class="w-num a2"><span data-count="${w.lines}">0</span></div>
      <div class="w-unit a2">${plural(w.lines, 'линию', 'линии', 'линий')}</div>
      <div class="w-line a3">в среднем <b>${N(w.avgLines, 0)}</b> за смену</div>
      ${w.prev && w.prev.lines ? `<div class="w-chip a4">${w.lines >= w.prev.lines ? '▲' : '▼'} ${N(Math.abs(w.lines - w.prev.lines))} к ${monthDat(prevName)}</div>` : ''}` });
    S.push({ bg: 'g-money', html: `
      <div class="w-coins"><i>💰</i><i>💵</i><i>🪙</i><i>💵</i><i>💰</i></div>
      <div class="w-kicker a1">${w.manual !== null ? 'Ты получил' : 'Ты заработал'}</div>
      <div class="w-num w-money a2"><span data-count="${Math.round(w.earned)}" data-fmt="money">0</span></div>
      <div class="w-line a3">${N(w.perShift, 0)} ₽ за смену в среднем</div>
      ${w.prev && w.prev.change !== null ? `<div class="w-chip ${w.prev.change >= 0 ? 'up' : 'down'} a4">${w.prev.change >= 0 ? '▲ +' : '▼ '}${N(w.prev.change * 100, 0)}% к ${monthDat(prevName)}</div>` : ''}
      ${w.pending ? `<div class="w-line a5">+ <b>${M(w.pending)}</b> премий ожидается ⏳</div>` : ''}` });
    const tp = w.top, tpd = C.parseKey(tp.key);
    S.push({ bg: 'g-star', html: `
      <div class="w-kicker a1">Твоя лучшая смена</div>
      <div class="w-date a2"><b>${tpd.d}</b><span>${C.MONTHS_GEN[tpd.m]}</span></div>
      <div class="w-line a3">${C.WEEKDAYS_FULL[C.weekdayMon(tp.key)].toLowerCase()}</div>
      <div class="w-stats a4">
        <div><b data-count="${tp.lines}">0</b><small>линий</small></div>
        ${tp.prod !== null ? `<div><b>${N(tp.prod, 1)}%</b><small>производит.</small></div>` : ''}
        <div><b>${C.fmtMoneyShort(tp.total)}</b><small>рублей</small></div>
        ${tp.mood ? `<div><b>${C.MOODS[tp.mood - 1].icon}</b><small>${C.MOODS[tp.mood - 1].label.toLowerCase()}</small></div>` : ''}
      </div>` });
    if (w.prodAvg !== null) {
      const pct = Math.min(1, w.prodAvg / (w.prodThreshold * 1.25)), R = 88, L = 2 * Math.PI * R;
      S.push({ bg: w.prodOk ? 'g-win' : 'g-try', html: `
        <div class="w-kicker a1">Средняя производительность</div>
        <div class="w-ring a2"><svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="${R}" class="rg-bg"/><circle cx="100" cy="100" r="${R}" class="rg-fg" style="--L:${L.toFixed(1)};--off:${(L * (1 - pct)).toFixed(1)}"/>
          <line x1="100" y1="4" x2="100" y2="22" class="rg-mark" transform="rotate(${(360 / 1.25).toFixed(1)} 100 100)"/></svg>
          <div class="w-ring-val"><span data-count="${w.prodAvg}" data-fmt="pct">0</span></div></div>
        <div class="w-line a3">${w.prodOk ? `Премия <b>${M(w.prodBonus)}</b> — твоя! 🎉` : `До ${N(w.prodThreshold, 0)}% не хватило <b>${N(w.prodThreshold - w.prodAvg, 1)}%</b>`}</div>
        ${w.prodOk ? '<div class="w-confetti">' + '<i></i>'.repeat(24) + '</div>' : '<div class="w-line a4 w-dim">В следующем месяце получится 💪</div>'}` });
    }
    if (w.service !== null) S.push({ bg: 'g-' + w.zone, html: `
      <div class="w-kicker a1">Работа без ошибок</div>
      <div class="w-zone a2"><span>${N(w.service, 2)}%</span></div>
      <div class="w-unit a3">${w.zone === 'green' ? 'зелёная зона ✅' : w.zone === 'yellow' ? 'жёлтая зона' : 'красная зона'}</div>
      ${w.serviceBonus ? `<div class="w-line a4">премия за сервис <b>${M(w.serviceBonus)}</b></div>` : ''}
      ${w.penalty ? `<div class="w-line a5 w-dim">штраф за ошибки ${M(w.penalty)}</div>` : '<div class="w-line a5">без штрафов ✨</div>'}` });
    if (w.bestRun >= 2) S.push({ bg: 'g-fire', html: `
      <div class="w-fire a1">🔥</div>
      <div class="w-kicker a2">Лучшая серия</div>
      <div class="w-num a3"><span data-count="${w.bestRun}">0</span></div>
      <div class="w-unit a3">${plural(w.bestRun, 'смена', 'смены', 'смен')} подряд</div>
      <div class="w-line a4">с производительностью от ${N(w.prodThreshold, 0)}%</div>` });
    if (w.mood) S.push({ bg: 'g-mood', html: `
      <div class="w-rain">${Array.from({ length: 16 }, () => `<i>${w.mood.icon}</i>`).join('')}</div>
      <div class="w-kicker a1">Чаще всего после смены было</div>
      <div class="w-emoji a2">${w.mood.icon}</div>
      <div class="w-unit a3">${w.mood.label}</div>
      <div class="w-line a4">${w.mood.count} из ${w.mood.total} ${plural(w.mood.total, 'смены', 'смен', 'смен')}</div>` });
    if (w.bestWeekday) S.push({ bg: 'g-week', html: `
      <div class="w-kicker a1">Самая прибыльная ночь</div>
      <div class="w-huge w-mid a2">${w.bestWeekday.name}</div>
      <div class="w-line a3">в среднем <b>${M(w.bestWeekday.avg)}</b> за смену</div>
      ${w.bestWeekday.vs ? `<div class="w-chip up a4">+${N(w.bestWeekday.vs * 100, 0)}% к обычной смене</div>` : ''}` });
    if (w.monthsInYear >= 2) S.push({ bg: 'g-rank', html: `
      <div class="w-fire a1">${w.rankInYear === 1 ? '🏆' : w.rankInYear <= 3 ? '🥈' : '📈'}</div>
      <div class="w-kicker a2">${w.rankInYear === 1 ? 'Лучший месяц года!' : 'Место в году'}</div>
      <div class="w-num a3">#${w.rankInYear}</div>
      <div class="w-line a4">из ${w.monthsInYear} ${plural(w.monthsInYear, 'месяца', 'месяцев', 'месяцев')} ${w.y} года по заработку</div>` });
    S.push({ bg: 'g-outro', dur: 15000, html: `
      <div class="w-kicker a1">${w.name} ${w.y} · итоги</div>
      <div class="w-card a2">
        <div class="wc-big"><small>${w.manual !== null ? 'Получено' : 'Заработано'}</small><b>${M(w.earned)}</b></div>
        <div class="wc-grid">
          <div><b>${w.shifts}</b><small>смен</small></div>
          <div><b>${N(w.lines)}</b><small>линий</small></div>
          <div><b>${w.prodAvg !== null ? N(w.prodAvg, 1) + '%' : '—'}</b><small>производит.</small></div>
          <div><b>${w.hours ? N(w.hours, 0) : '—'}</b><small>часов</small></div>
          <div><b>${w.bestRun || '—'}</b><small>серия</small></div>
          <div><b>${w.mood ? w.mood.icon : '—'}</b><small>настроение</small></div>
        </div>
        ${w.pending ? `<div class="wc-pend">+ ${M(w.pending)} премий ожидается</div>` : ''}
      </div>
      <div class="w-btns a3"><button data-w="replay">↻ Ещё раз</button><button data-w="close">Готово</button></div>` });
    return S;
  }
  const monthPrep = (m) => ['январе', 'феврале', 'марте', 'апреле', 'мае', 'июне', 'июле', 'августе', 'сентябре', 'октябре', 'ноябре', 'декабре'][m];
  const monthDat = (name) => { const i = C.MONTHS.indexOf(name); return ['январю', 'февралю', 'марту', 'апрелю', 'маю', 'июню', 'июлю', 'августу', 'сентябрю', 'октябрю', 'ноябрю', 'декабрю'][i] || ''; };

  function openWrapped(y, m) {
    const w = C.monthWrapped(state, m, y);
    if (!w) return toast('За этот месяц ещё нет смен');
    const slides = wrappedSlides(w);
    const el = $('#wrapped');
    el.innerHTML = `<div class="w-bars">${slides.map(() => '<div><i></i></div>').join('')}</div>
      <button class="w-close" data-w="close" aria-label="Закрыть">×</button>
      <div class="w-stage"></div><div class="w-tap left"></div><div class="w-tap right"></div>`;
    const stage = $('.w-stage', el), bars = el.querySelectorAll('.w-bars > div');
    let i = 0, timer = null, started = 0, remain = 0, paused = false;
    const fmt = (v, f) => (f === 'money' ? M(Math.round(v)) : f === 'pct' ? N(v, 1) + '%' : f === 'num1' ? N(v, 1) : N(Math.round(v)));
    const countUp = () => stage.querySelectorAll('[data-count]').forEach((c) => {
      const to = Number(c.dataset.count), f = c.dataset.fmt, t0 = performance.now(), d = 1400, delay = 350;
      const step = (t) => { const p = Math.min(1, Math.max(0, (t - t0 - delay) / d)), e = 1 - Math.pow(1 - p, 4); c.textContent = fmt(p < 1 ? to * e : to, f); if (p < 1 && el.classList.contains('show')) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
    const show = (n) => {
      i = Math.max(0, Math.min(slides.length - 1, n));
      const sl = slides[i], dur = sl.dur || W_DUR;
      el.className = 'wrapped show ' + sl.bg;
      stage.innerHTML = `<div class="w-slide">${sl.html}</div>`;
      bars.forEach((b, j) => { b.className = j < i ? 'done' : j === i ? 'run' : ''; b.firstChild.style.animationDuration = dur + 'ms'; b.firstChild.style.animationPlayState = 'running'; });
      countUp();
      clearTimeout(timer); remain = dur; started = Date.now(); paused = false;
      timer = setTimeout(next, dur);
    };
    const next = () => (i < slides.length - 1 ? show(i + 1) : null);
    const prev = () => show(i - 1);
    const pause = () => { if (paused) return; paused = true; clearTimeout(timer); remain -= Date.now() - started; bars[i].firstChild.style.animationPlayState = 'paused'; };
    const resume = () => { if (!paused) return; paused = false; started = Date.now(); bars[i].firstChild.style.animationPlayState = 'running'; timer = setTimeout(next, Math.max(300, remain)); };
    let downAt = 0, y0 = null;
    el.onpointerdown = (e) => { if (e.target.closest('button')) return; downAt = Date.now(); y0 = e.clientY; pause(); };
    el.onpointerup = (e) => {
      if (e.target.closest('button')) return;
      const held = Date.now() - downAt > 350, dy = y0 !== null ? e.clientY - y0 : 0; y0 = null;
      if (dy > 90) return closeModal();                 // свайп вниз — закрыть
      if (held) return resume();                         // удержание — пауза, отпустили — дальше
      if (e.target.closest('.w-tap.left')) prev(); else next();
    };
    el.onpointercancel = () => resume();
    el.onclick = (e) => {
      const b = e.target.closest('[data-w]');
      if (!b) return;
      if (b.dataset.w === 'close') closeModal(); else if (b.dataset.w === 'replay') show(0);
    };
    openModal(el, $('#w-backdrop'));
    modalStack[modalStack.length - 1].onClose = () => { clearTimeout(timer); el.className = 'wrapped'; setTimeout(() => { if (!el.classList.contains('show')) el.innerHTML = ''; }, 400); };
    show(0);
  }

  // ---------- Успехи: рекорды, серии, рейтинг, дни недели, накопления, достижения ----------
  function renderSuccess() {
    chartSeq = 0;
    const sc = ui.success, { y, m } = C.ymOf(ui.homeMonth), today = todayKey();
    const keys = sc.scope === 'month' ? C.monthKeys(m, y) : sc.scope === 'year' ? C.yearKeys(y) : null;
    const scopeName = sc.scope === 'month' ? `${C.MONTHS[m]} ${y}` : sc.scope === 'year' ? `${y} год` : 'всё время';
    const b = { ...C.DEFAULT_BONUS, ...state.settings.bonus };
    const rec = C.records(state), stk = C.streaks(state, b.prodThreshold);
    const rank = C.rankShifts(state, keys);
    const last = C.rankShifts(state).map((x) => x.key).sort().pop();
    const lastPlace = last ? rank.find((x) => x.key === last) : null;
    const wd = C.weekdayStats(state, keys);
    const wb = C.wellbeingStats(state, keys);
    const moodIcon = (v) => (v === null ? '—' : C.MOODS[Math.min(4, Math.max(0, Math.round(v) - 1))].icon);
    const idxWorked = wb.byIdx.filter((r) => r.shifts);
    const fatigue = wb.byIdx[0].avgProd !== null && idxWorked.length > 2 ? (() => { const lastR = [...wb.byIdx].reverse().find((r) => r.avgProd !== null); return lastR && lastR.n > 1 ? { first: wb.byIdx[0].avgProd, last: lastR.avgProd, n: lastR.n } : null; })() : null;
    const ach = C.achievements(state), achDone = ach.filter((a) => a.done).length;
    const sv = state.settings.savings || { goal: 100000, saved: 0, percent: 100 };
    const plan = C.savingsPlan(state, sv, today);
    const medal = (i) => ['🥇', '🥈', '🥉'][i] || `<span class="place">${i + 1}</span>`;
    const recTile = (label, val, sub, key) => `<button class="tile ${key ? 'clickable' : ''}" ${key ? `data-act="open-day" data-key="${key}"` : 'disabled'} style="text-align:left"><div class="t-label">${label}</div><div class="t-value num">${val}</div><div class="t-sub num">${sub}</div></button>`;

    const wm = C.wrappedMonths(state).reverse();
    $('#view-success').innerHTML = `
      ${wm.length ? `<div class="wrap-entry">
        <div class="we-head"><div><div class="we-title">🎬 Итоги месяца</div><div class="we-sub">Истории о вашем месяце — нажмите, чтобы посмотреть</div></div></div>
        <div class="we-list">${wm.map(({ y: wy, m: wmm }) => `<button data-act="wrapped" data-y="${wy}" data-mm="${wmm}"><b>${C.MONTHS[wmm]}</b><small>${wy}</small></button>`).join('')}</div>
      </div>` : ''}
      <div class="streak-card">
        <div class="streak-fire">${stk.current ? '🔥' : '💤'}</div>
        <div class="grow"><div class="streak-num num">${stk.current} ${plural(stk.current, 'смена', 'смены', 'смен')} подряд</div>
          <div class="streak-sub">с производительностью от ${N(b.prodThreshold, 0)}% · рекорд серии: <b>${stk.best}</b></div>
          ${stk.best ? `<div class="meter streak-meter"><i class="ok" style="width:${Math.min(100, (stk.current / Math.max(stk.best, 1)) * 100)}%"></i></div>` : ''}
          <div class="streak-sub">${!rec.shifts ? 'Внесите смены с производительностью — начнём считать' : stk.current && stk.current >= stk.best ? 'Вы на рекордной серии!' : stk.best ? `До рекорда: ${stk.best - stk.current + 1} ${plural(stk.best - stk.current + 1, 'смена', 'смены', 'смен')}` : 'Первая смена от ' + N(b.prodThreshold, 0) + '% начнёт серию'}</div></div>
      </div>

      <h2 class="sec">🏆 Личные рекорды</h2>
      <div class="tiles">
        ${recTile('Больше всего линий', rec.lines ? N(rec.lines.value) : '—', rec.lines ? C.fmtDateLong(rec.lines.key) : 'нет данных', rec.lines && rec.lines.key)}
        ${recTile('Лучшая производительность', rec.prod ? N(rec.prod.value, 2) + '%' : '—', rec.prod ? C.fmtDateLong(rec.prod.key) : 'укажите % в сменах', rec.prod && rec.prod.key)}
        ${recTile('Лучший заработок за смену', rec.total ? M(rec.total.value) : '—', rec.total ? C.fmtDateLong(rec.total.key) : 'нет данных', rec.total && rec.total.key)}
        ${recTile('Лучшая неделя', rec.week ? M(rec.week.value) : '—', rec.week ? `с ${C.fmtDateShort(rec.week.key)} · ${rec.week.shifts} ${plural(rec.week.shifts, 'смена', 'смены', 'смен')}` : 'нет данных')}
        ${recTile('Лучший месяц', rec.month ? M(rec.month.value) : '—', rec.month ? `${C.MONTHS[rec.month.m]} ${rec.month.y}` : 'нет данных')}
        ${recTile('Всего', `${rec.shifts} ${plural(rec.shifts, 'смена', 'смены', 'смен')}`, `${N(rec.linesTotal)} линий · ${M(rec.earned)}`)}
      </div>

      <div class="seg" id="succ-scope">${[['month', 'Месяц'], ['year', 'Год'], ['all', 'Всё время']].map(([v, t]) => `<button data-scope="${v}" class="${sc.scope === v ? 'active' : ''}">${t}</button>`).join('')}</div>
      <p class="hint" style="margin:-4px 4px 12px">Рейтинг и дни недели — за ${scopeName}${sc.scope !== 'all' ? ' (месяц выбирается на главной)' : ''}</p>

      <div class="card"><h2>📊 Рейтинг смен <small>${rank.length} ${plural(rank.length, 'смена', 'смены', 'смен')}</small></h2>
        ${rank.length ? `${lastPlace ? `<div class="rank-last">Последняя смена (${C.fmtDateShort(lastPlace.key)}) — <b>${lastPlace.place} место</b> из ${rank.length}</div>` : ''}
          ${rank.slice(0, sc.showAll ? 100 : 10).map((x, i) => `<button class="list-row rank-row" data-act="open-day" data-key="${x.key}">
            <div class="medal">${medal(i)}</div>
            <div class="grow"><div>${C.fmtDateLong(x.key)}, ${C.WEEKDAYS[C.weekdayMon(x.key)].toLowerCase()}</div><div>${N(x.lines)} линий · ${M(x.total)}</div></div>
            <div class="amount num ${x.prod === null ? 'muted' : x.prod >= b.prodThreshold ? 'up' : ''}">${x.prod === null ? '—' : N(x.prod, 1) + '%'}</div></button>`).join('')}
          ${rank.length > 10 && !sc.showAll ? `<button class="btn btn-secondary" data-act="rank-all" style="margin-top:6px">Показать все (${Math.min(rank.length, 100)})</button>` : ''}
          <p class="hint">Порядок: по производительности %, затем по количеству линий.</p>`
        : '<div class="empty-chart">Смен за этот период ещё нет</div>'}
      </div>

      ${chartCard({ title: '📅 Выгодность дней недели', items: wd.rows.map((r) => ({ label: C.WEEKDAYS[r.wd], tip: `${r.name}: ${r.shifts} ${plural(r.shifts, 'смена', 'смены', 'смен')}${r.avgProd !== null ? ` · ${N(r.avgProd, 1)}%` : ''}`, value: r.avg })),
        avg: wd.overall || null, summary: wd.best ? `<b class="num">${wd.best.name}</b><span>самый прибыльный · в среднем ${M(wd.best.avg)}</span>` : '' })}
      ${wd.shifts ? `<div class="card"><h2>Средние по дням недели</h2>
        <table class="table num"><thead><tr><th>День</th><th>Смен</th><th>Ср. заработок</th><th>Линий</th><th>Произв.</th></tr></thead><tbody>
        ${wd.rows.map((r) => `<tr class="${r.shifts ? '' : 'zero'} ${wd.best && r.wd === wd.best.wd ? 'best-row' : ''}"><td>${C.WEEKDAYS[r.wd]}${wd.best && r.wd === wd.best.wd ? ' 👑' : ''}</td><td>${r.shifts || '—'}</td>
          <td>${r.shifts ? M(r.avg) : '—'}${r.vsAvg !== null && Math.abs(r.vsAvg) >= 0.005 ? `<br><small class="${r.vsAvg > 0 ? 'up' : 'down'}">${r.vsAvg > 0 ? '+' : ''}${N(r.vsAvg * 100, 0)}%</small>` : ''}</td>
          <td>${r.shifts ? N(r.avgLines, 0) : '—'}</td><td>${r.avgProd === null ? '—' : N(r.avgProd, 1) + '%'}</td></tr>`).join('')}
        </tbody></table>
        ${wd.best && wd.worst && wd.best.wd !== wd.worst.wd ? `<p class="hint">💡 ${wd.best.name} приносит в среднем на ${M(wd.best.avg - wd.worst.avg)} больше, чем ${wd.worst.name.toLowerCase()} (${M(wd.best.avg)} против ${M(wd.worst.avg)}). Процент — отклонение от средней смены ${M(wd.overall)}.</p>` : ''}</div>` : ''}

      <div class="card"><h2>😊 Самочувствие и усталость</h2>
        ${wb.moodDays || idxWorked.length ? `
        ${wb.moodDays ? `<div class="mood-sum"><span class="mood-big">${moodIcon(wb.avgMood)}</span><div><b>Среднее самочувствие: ${C.MOODS[Math.round(wb.avgMood) - 1].label.toLowerCase()}</b><div class="hint" style="margin:2px 0 0">по ${wb.moodDays} ${plural(wb.moodDays, 'смене', 'сменам', 'сменам')} с отметкой</div></div></div>
        <div class="mood-bars">${wb.byMood.map((r) => `<div class="mb"><div class="mb-bar"><i style="height:${wb.moodDays ? Math.max(4, r.shifts / wb.moodDays * 100) : 0}%"></i></div><div class="mb-ic">${r.icon}</div><small class="num">${r.avgProd === null ? '—' : N(r.avgProd, 0) + '%'}</small></div>`).join('')}</div>
        <p class="hint" style="text-align:center;margin-top:4px">Столбик — сколько смен, под ним — средняя производительность</p>
        ${wb.goodProd !== null && wb.badProd !== null ? `<p class="insight">💡 Когда самочувствие хорошее, производительность в среднем <b>${N(wb.goodProd, 1)}%</b>, когда плохое — <b>${N(wb.badProd, 1)}%</b>${wb.goodProd > wb.badProd ? ` (разница ${N(wb.goodProd - wb.badProd, 1)}%)` : ''}.</p>` : ''}` : '<p class="hint">Отмечайте самочувствие в сменах — появится связь с производительностью.</p>'}
        ${idxWorked.length ? `<table class="table num" style="margin-top:10px"><thead><tr><th>Смена подряд</th><th>Смен</th><th>Произв.</th><th>Самочувств.</th><th>Заработок</th></tr></thead><tbody>
          ${wb.byIdx.map((r) => `<tr class="${r.shifts ? '' : 'zero'}"><td>${r.n === 5 ? '5-я и дальше' : r.n + '-я'}</td><td>${r.shifts || '—'}</td><td>${r.avgProd === null ? '—' : N(r.avgProd, 1) + '%'}</td><td>${moodIcon(r.avgMood)}</td><td>${r.shifts ? M(r.avg) : '—'}</td></tr>`).join('')}
          </tbody></table>
          ${fatigue ? `<p class="insight">💡 В ${fatigue.n}-ю ночь подряд производительность ${fatigue.last < fatigue.first ? `ниже на ${N(fatigue.first - fatigue.last, 1)}%` : fatigue.last > fatigue.first ? `выше на ${N(fatigue.last - fatigue.first, 1)}%` : 'такая же'}, чем в первую (${N(fatigue.last, 1)}% против ${N(fatigue.first, 1)}%).</p>` : ''}` : ''}`
        : '<div class="empty-chart">Отмечайте самочувствие и производительность в сменах</div>'}
      </div>

      <div class="card"><h2>🐷 Планировщик накоплений</h2>
        <div class="inline-form">
          <div><label for="sv-goal">Цель, ₽</label><input class="input num" id="sv-goal" inputmode="decimal" value="${sv.goal || ''}" placeholder="100000"></div>
          <div><label for="sv-saved">Уже накоплено, ₽</label><input class="input num" id="sv-saved" inputmode="decimal" value="${sv.saved || ''}" placeholder="0"></div>
        </div>
        <div class="field"><label for="sv-pct">Откладываю от заработка: <b id="sv-pct-val">${sv.percent}%</b></label>
          <input type="range" id="sv-pct" min="5" max="100" step="5" value="${sv.percent}" class="range"></div>
        <div id="sv-result">${savingsHtml(plan, sv)}</div>
      </div>

      <h2 class="sec">🎖 Достижения <small>${achDone} из ${ach.length}</small></h2>
      <div class="ach-grid">${ach.map((a) => `<div class="ach ${a.done ? 'done' : ''}">
        <div class="ach-icon">${a.icon}</div><div class="ach-title">${esc(a.title)}</div><div class="ach-desc">${esc(a.desc)}</div>
        ${a.done ? '<div class="ach-ok">✓ получено</div>' : `<div class="meter"><i style="width:${(a.value / a.target * 100).toFixed(0)}%"></i></div><div class="ach-desc num">${a.target > 1 ? `${N(a.value)} / ${N(a.target)}` : 'ещё нет'}</div>`}
      </div>`).join('')}</div>`;

    $('#succ-scope').onclick = (e) => { const bt = e.target.closest('[data-scope]'); if (bt) { sc.scope = bt.dataset.scope; sc.showAll = false; renderSuccess(); } };
    const updPlan = (commit) => {
      const g = Number(String($('#sv-goal').value).replace(',', '.').replace(/\s/g, '')) || 0;
      const sd = Number(String($('#sv-saved').value).replace(',', '.').replace(/\s/g, '')) || 0;
      const pc = Number($('#sv-pct').value) || 100;
      $('#sv-pct-val').textContent = pc + '%';
      const nsv = { goal: Math.max(0, g), saved: Math.max(0, sd), percent: pc };
      $('#sv-result').innerHTML = savingsHtml(C.savingsPlan(state, nsv, today), nsv);
      if (commit) { state.settings.savings = nsv; save(); }
    };
    ['sv-goal', 'sv-saved', 'sv-pct'].forEach((id) => { const el = $('#' + id); el.oninput = () => updPlan(false); el.onchange = () => updPlan(true); });
  }
  function savingsHtml(p, sv) {
    if (!p.ok) return `<div class="empty-chart" style="padding:14px 0">${p.reason === 'goal' ? 'Укажите цель' : 'Внесите хотя бы одну смену — посчитаю по вашему среднему заработку'}</div>`;
    if (p.done) return `<div class="plan-done">🎉 Цель достигнута!</div>`;
    const prog = sv.goal ? Math.min(100, (sv.saved / sv.goal) * 100) : 0;
    return `<div class="progress plan-progress"><i style="width:${prog.toFixed(1)}%"></i></div>
      <div class="hint" style="margin:4px 0 12px">${Math.round(prog)}% · осталось ${M(p.left)}</div>
      <div class="plan-big"><b class="num">${p.shifts}</b> ${plural(p.shifts, 'смена', 'смены', 'смен')}</div>
      <div class="plan-sub">≈ ${p.weeks} ${plural(p.weeks, 'неделя', 'недели', 'недель')} · цель к <b>${C.fmtDateLong(p.date)}</b></div>
      <p class="hint">Средняя смена ${M(p.perShift)}${p.percent < 100 ? `, откладываете ${p.percent}% — это ${M(p.perShiftSaved)} со смены` : ''}. Считается по последним ${p.basis} ${plural(p.basis, 'смене', 'сменам', 'сменам')}, без учёта премий. Дата — по рабочим дням (пн–пт) с учётом ваших отметок.</p>`;
  }

  // ---------- Настройки ----------
  function renderSettings() {
    const set = state.settings, today = todayKey();
    const refKey = C.inYear(today) ? today : C.FIRST_DAY;
    const count = Object.keys(state.entries).length;
    const hist = [...set.rateHistory].sort((a, b) => (a.from < b.from ? 1 : -1));
    $('#view-settings').innerHTML = `
      <div class="card"><h2>Стоимость одной линии</h2>
        <div class="rate-now"><b class="num">${M(C.rateFor(set.rateHistory, refKey))}</b><span class="muted">${C.inYear(today) ? 'действует сегодня' : `на ${C.fmtDateLong(refKey)}`}</span></div>
        <div class="inline-form">
          <div><label for="s-rate">Новая стоимость, ₽</label><input class="input num" id="s-rate" inputmode="decimal" placeholder="5"></div>
          <div><label for="s-from">Действует с</label><input class="input" type="date" id="s-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${refKey}"></div>
        </div>
        <button class="btn btn-primary" data-act="set-rate">Применить тариф</button>
        <p class="hint">Новые записи с этой даты считаются по новой стоимости. Уже сохранённые смены не пересчитываются — у каждой хранится свой тариф.</p>
        <div style="margin-top:12px">${hist.map((h) => `<div class="hist-row num"><span>с ${C.fmtDateLong(h.from)} — <b>${M(h.rate)}</b></span>${hist.length > 1 ? `<button data-act="del-rate" data-from="${h.from}">Удалить</button>` : ''}</div>`).join('')}</div>
      </div>
      <div class="card"><h2>Цели на месяц</h2>
        <div class="field"><label for="s-target">Целевая зарплата за месяц, ₽ <span>0 — без цели</span></label><input class="input num" id="s-target" inputmode="decimal" value="${set.target || ''}" placeholder="Например, 60000"></div>
        <div class="field"><label for="s-planned">Планируемое количество смен в месяц <span>0 — по календарю</span></label><input class="input num" id="s-planned" inputmode="numeric" value="${set.plannedShifts || ''}" placeholder="Например, 15"></div>
        <button class="btn btn-primary" data-act="save-goals">Сохранить цели</button>
        <p class="hint">Прогноз = уже заработано + средний заработок за смену × оставшиеся смены. Без плана оставшиеся смены — это будние дни (пн–пт) до конца месяца.</p>
      </div>
      <div class="card"><h2>🔒 Безопасность</h2>
        ${(() => { const lc = lockCfg(); return `
        <label class="switch-row"><span><b>Вход по PIN-коду</b><small>4 цифры при открытии приложения</small></span><input type="checkbox" class="switch" id="sec-pin" ${lc.enabled ? 'checked' : ''}></label>
        ${lc.enabled ? `<label class="switch-row"><span><b>Вход по отпечатку пальца</b><small id="sec-bio-note">${isNative() ? 'если отпечаток настроен в телефоне' : 'работает в приложении (APK)'}</small></span><input type="checkbox" class="switch" id="sec-bio" ${lc.bio ? 'checked' : ''} ${isNative() ? '' : 'disabled'}></label>
          <div class="field" style="margin-top:8px"><label for="sec-after">Блокировать после сворачивания</label>
            <select class="input" id="sec-after">${[[0, 'Сразу'], [60, 'Через 1 минуту'], [300, 'Через 5 минут'], [1800, 'Через 30 минут']].map(([v, t]) => `<option value="${v}" ${(lc.after ?? 60) === v ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
          <div class="btn-row"><button class="btn btn-secondary" data-act="pin-change">Сменить PIN</button><button class="btn btn-secondary" data-act="lock-now">Заблокировать</button></div>` : ''}
        <p class="hint">Отключить можно в любой момент. PIN хранится только на этом телефоне в зашифрованном виде.</p>`; })()}
      </div>
      <div class="card"><h2>💰 Выплаты</h2>
        ${(() => { const pd = { ...C.DEFAULT_PAYDAYS, ...(set.paydays || {}) }; const f = (id, label, val) => `<div><label for="${id}">${label}</label><input class="input num" id="${id}" inputmode="numeric" value="${val}"></div>`;
          return `<div class="inline-form">${f('pd-sal', 'Зарплата, число', pd.salary)}${f('pd-adv', 'Аванс, число', pd.advance)}</div>
          <div class="inline-form">${f('pd-ef', 'Конверт с', pd.envelopeFrom)}${f('pd-et', 'Конверт по', pd.envelopeTo)}</div>`; })()}
        <button class="btn btn-primary" data-act="save-paydays">Сохранить даты</button>
        <p class="hint">Зарплата и конверт — за прошлый месяц, аванс — за текущий. Если дата выпадает на субботу, воскресенье или праздник — выплата ожидается в ближайший рабочий день раньше. Если в месяце меньше дней (февраль), берётся последний день.</p>
      </div>
      <div class="card"><h2>🐱 Питомец</h2>
        ${(() => { const pt = set.pet || { on: true, name: 'Мурка' }; return `
        <label class="switch-row"><span><b>Показывать кошку</b><small>гуляет по экранам и радуется вашим сменам</small></span><input type="checkbox" class="switch" id="pet-on" ${pt.on !== false ? 'checked' : ''}></label>
        <div class="field" style="margin-top:8px"><label for="pet-name">Имя</label><input class="input" id="pet-name" maxlength="20" value="${esc(pt.name || 'Мурка')}"></div>`; })()}
        <p class="hint">Нажмите на кошку — она расскажет, как идёт месяц. Довольна, когда премия и сервис в порядке, грустит, если ночь выдалась тяжёлой. Ночью (с 0 до 6) иногда спит.</p>
      </div>
      <div class="card"><h2>🌙 Смена</h2>
        <div class="field"><label for="sh-start">Начало смены по умолчанию</label><input class="input num" type="time" id="sh-start" value="${set.shiftStart || '21:00'}"></div>
        <p class="hint">Подставляется в новую смену. Время окончания выбирается в смене (до 6, 7 или 8 утра) — часы посчитаются сами. Ночная смена записывается на дату её начала.</p>
      </div>
      <div class="card"><h2>Премии</h2>
        ${(() => { const b = { ...C.DEFAULT_BONUS, ...set.bonus }; const f = (id, label, val) => `<div><label for="${id}">${label}</label><input class="input num" id="${id}" inputmode="decimal" value="${String(val).replace('.', ',')}"></div>`;
          return `<p class="hint" style="margin:0 0 8px">За производительность — по средней за месяц</p>
          <div class="inline-form">${f('b-pthr', 'Порог, %', b.prodThreshold)}${f('b-pamt', 'Премия, ₽', b.prodAmount)}</div>
          <p class="hint" style="margin:6px 0 8px">За сервис (работа без ошибок) — по зонам</p>
          <div class="inline-form">${f('b-gthr', 'Зелёная от, %', b.greenThreshold)}${f('b-gamt', 'Премия, ₽', b.greenAmount)}</div>
          <div class="inline-form">${f('b-ythr', 'Жёлтая от, %', b.yellowThreshold)}${f('b-yamt', 'Премия, ₽', b.yellowAmount)}</div>
          <div class="inline-form"><div><label>Красная</label><div class="input num" style="color:var(--muted);font-size:15px;display:flex;align-items:center">ниже жёлтой</div></div>${f('b-ramt', 'Премия, ₽', b.redAmount)}</div>`; })()}
        <button class="btn btn-primary" data-act="save-bonus">Сохранить премии</button>
        <p class="hint">Сервис и штраф за ошибки вносятся на главном экране для каждого месяца. Если узнаете сумму премии за жёлтую зону, укажите её здесь.</p>
      </div>
      <div class="card"><h2>Оформление</h2>
        <div class="seg" id="s-theme">${[['system', 'Как в системе'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, t]) => `<button data-theme="${v}" class="${set.theme === v ? 'active' : ''}">${t}</button>`).join('')}</div>
        <div class="muted" style="font-size:14px;margin:6px 0 10px">Цветовая гамма — меняется во всём приложении</div>
        <div class="palettes" id="s-palettes">${C.PALETTES.map((p) => `<button data-pal="${p.id}" class="${set.palette && set.palette.id === p.id ? 'active' : ''}" aria-label="${p.name}">
          <span class="sw" style="background:linear-gradient(135deg, ${p.accent} 0 58%, ${p.accent2} 58% 100%)"></span><small>${p.name}</small></button>`).join('')}</div>
        <div class="inline-form" style="margin-top:12px">
          <div><label for="s-acc">Свой основной цвет</label><input class="input color" type="color" id="s-acc" value="${(set.palette || C.PALETTES[0]).accent}"></div>
          <div><label for="s-acc2">Цвет графиков</label><input class="input color" type="color" id="s-acc2" value="${(set.palette || C.PALETTES[0]).accent2}"></div>
        </div>
        <p class="hint">Основной цвет — кнопки, календарь, главная карточка, вкладки. Цвет графиков — линии и вторые столбцы в статистике.</p>
      </div>
      <div class="card"><h2>Резервная копия <small>${count} ${plural(count, 'запись', 'записи', 'записей')}</small></h2>
        <button class="btn btn-primary" data-act="export">Сохранить копию в файл</button>
        <button class="btn btn-secondary" data-act="import">Восстановить из файла</button>
        <div class="btn-row" style="margin-top:10px"><button class="btn btn-secondary" data-act="export-text">Копировать текстом</button><button class="btn btn-secondary" data-act="import-text">Вставить текст</button></div>
        <button class="btn btn-secondary" data-act="csv">Таблица для Excel (CSV)</button>
        <p class="hint">${meta.lastBackup ? `Последняя копия: ${new Date(meta.lastBackup).toLocaleString('ru-RU')}.` : 'Копия ещё не создавалась.'} Данные хранятся только на этом телефоне — сохраняйте копию раз в неделю (например, в Telegram «Избранное» или на Google Диск).</p>
        <input type="file" id="s-file" accept=".json,application/json,text/plain" hidden>
      </div>
      <div class="card"><h2>Данные</h2><button class="btn btn-danger" data-act="wipe">Удалить все записи</button></div>
      <div class="about">Калькулятор ЗП · версия 3.1<br>Годы ${C.YEARS.join(', ')} · выходные — суббота и воскресенье<br>Работает без интернета · данные хранятся на устройстве</div>`;
  }

  async function settingsAction(act, el) {
    const set = state.settings;
    if (act === 'set-rate') {
      const r = Number(String($('#s-rate').value).replace(',', '.'));
      const from = $('#s-from').value;
      try {
        if (!C.inYear(from)) throw new Error(`Укажите дату с ${C.YEARS[0]} по ${C.YEARS[C.YEARS.length - 1]} год`);
        C.setRate(state, from, r); save(); renderAll(); toast(`Тариф ${M(r)} с ${C.fmtDateLong(from)}`);
      } catch (e) { toast(e.message || 'Введите стоимость больше нуля'); }
    } else if (act === 'del-rate') {
      if (await confirmDlg('Удалить тариф?', 'Сохранённые смены не изменятся.', 'Удалить', true)) {
        try { C.removeRate(state, el.dataset.from); save(); renderAll(); } catch (e) { toast(e.message); }
      }
    } else if (act === 'pin-change') {
      if (await setupPin()) toast('PIN-код изменён');
    } else if (act === 'lock-now') {
      showLock();
    } else if (act === 'save-paydays') {
      const g = (id) => Math.round(Number($('#' + id).value));
      const pd = { advance: g('pd-adv'), salary: g('pd-sal'), envelopeFrom: g('pd-ef'), envelopeTo: g('pd-et') };
      if (Object.values(pd).some((v) => !(v >= 1 && v <= 31))) return toast('Числа месяца — от 1 до 31');
      if (pd.envelopeTo < pd.envelopeFrom) return toast('«Конверт по» не может быть раньше «с»');
      set.paydays = pd; save(); renderAll(); toast('Даты выплат сохранены');
    } else if (act === 'save-bonus') {
      const g = (id) => Number(String($('#' + id).value).replace(',', '.').replace(/\s/g, ''));
      const nb = { prodThreshold: g('b-pthr'), prodAmount: g('b-pamt'), greenThreshold: g('b-gthr'), greenAmount: g('b-gamt'), yellowThreshold: g('b-ythr'), yellowAmount: g('b-yamt'), redAmount: g('b-ramt') };
      if (Object.values(nb).some((v) => !Number.isFinite(v) || v < 0)) return toast('Проверьте значения: числа не меньше 0');
      if (nb.greenThreshold > 100 || nb.yellowThreshold > nb.greenThreshold) return toast('Порог жёлтой зоны должен быть не выше зелёной, а зелёной — не выше 100%');
      set.bonus = nb; save(); renderAll(); toast('Премии сохранены');
    } else if (act === 'save-goals') {
      const t = Number(String($('#s-target').value || 0).replace(',', '.').replace(/\s/g, ''));
      const p = Number($('#s-planned').value || 0);
      if (!(t >= 0) || !(p >= 0) || !Number.isInteger(p) || p > 31) return toast('Проверьте значения: смен от 0 до 31');
      set.target = C.round2(t); set.plannedShifts = p; save(); renderAll(); toast('Цели сохранены');
    } else if (act === 'export') {
      await saveFile(`zarplata-backup-${todayKey()}.json`, C.exportData(state), 'application/json');
      meta.lastBackup = Date.now(); saveMeta(); renderSettings();
    } else if (act === 'csv') {
      await saveFile(`zarplata-${todayKey()}.csv`, C.toCSV(state), 'text/csv');
    } else if (act === 'import') {
      const inp = $('#s-file'); inp.value = '';
      inp.onchange = () => { const file = inp.files[0]; if (!file) return; const rd = new FileReader(); rd.onload = () => importText(String(rd.result)); rd.readAsText(file); };
      inp.click();
    } else if (act === 'export-text') {
      const txt = C.exportData(state);
      let copied = false;
      try { await navigator.clipboard.writeText(txt); copied = true; } catch {}
      if (copied) { meta.lastBackup = Date.now(); saveMeta(); renderSettings(); toast('Копия скопирована — вставьте её в заметки или мессенджер'); }
      else dialog({ title: 'Резервная копия', text: 'Выделите весь текст и скопируйте:', html: `<textarea class="input" readonly>${esc(txt)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    } else if (act === 'import-text') {
      const txt = await dialog({ title: 'Вставьте резервную копию', html: '<textarea class="input" id="imp-text" placeholder="{ ... }"></textarea>',
        buttons: [{ text: 'Восстановить', cls: 'btn-primary', read: (d) => $('#imp-text', d).value }, { text: 'Отмена', value: null }] });
      if (txt) importText(txt);
    } else if (act === 'wipe') {
      if (await confirmDlg('Удалить все записи?', 'Все смены будут удалены без возможности восстановления. Сначала сохраните резервную копию.', 'Удалить всё', true)
        && await confirmDlg('Точно удалить?', `${Object.keys(state.entries).length} записей будет удалено.`, 'Да, удалить', true)) {
        state.entries = {}; save(); renderAll(); toast('Все записи удалены');
      }
    }
  }
  async function importText(txt) {
    let parsed;
    try { parsed = C.normalizeState(JSON.parse(txt)); } catch (e) { return toast('Не удалось прочитать копию: ' + (e.message || 'неверный формат')); }
    const n = Object.keys(parsed.state.entries).length;
    const choice = await dialog({ title: 'Восстановление', text: `В копии ${n} ${plural(n, 'запись', 'записи', 'записей')}${parsed.skipped ? `, пропущено повреждённых: ${parsed.skipped}` : ''}.\nЗаменить текущие данные или объединить?`,
      buttons: [{ text: 'Заменить всё', cls: 'btn-primary', value: 'replace' }, { text: 'Объединить', value: 'merge' }, { text: 'Отмена', value: null }] });
    if (!choice) return;
    state = choice === 'replace' ? parsed.state : C.mergeStates(state, parsed.state);
    save(); applyTheme(); renderAll(); toast('Данные восстановлены');
  }
  async function saveFile(name, text, mime) {
    const cap = window.Capacitor;
    if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
      const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
      if (FS && SH) {
        try {
          const r = await FS.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
          await SH.share({ title: name, files: [r.uri], url: r.uri, dialogTitle: 'Сохранить или отправить копию' });
          return;
        } catch (e) { if (String(e && e.message).match(/cancel/i)) return; console.warn(e); }
      }
      return dialog({ title: name, text: 'Скопируйте текст и сохраните его в надёжном месте:', html: `<textarea class="input" readonly>${esc(text)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    }
    const file = new File([text], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android/i.test(navigator.userAgent)) {
      try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Файл сохранён в «Загрузки»');
  }

  // ---------- Навигация ----------
  const TITLES = { home: 'Главная', cal: 'Календарь', stats: 'Статистика', success: 'Успехи', settings: 'Настройки' };
  function setTab(tab) {
    const prev = ui.tab;
    ui.tab = tab;
    document.querySelectorAll('.tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + tab));
    $('#title').textContent = TITLES[tab];
    renderTab(tab);
    updateChip();
    window.scrollTo({ top: 0 });
    if (window.Pet && prev) Pet.tab(prev, tab);
  }
  function renderTab(tab) { ({ home: renderHome, cal: renderCal, stats: renderStats, success: renderSuccess, settings: renderSettings })[tab](); }
  function renderAll() { renderTab(ui.tab); updateChip(); if (window.Pet) Pet.refresh(); }
  function updateChip() {
    const chip = $('.year-chip');
    const y = ui.tab === 'home' ? C.ymOf(ui.homeMonth).y : ui.tab === 'cal' ? C.ymOf(ui.calMonth).y
      : ui.tab === 'stats' ? (ui.stats.mode === 'month' ? C.ymOf(ui.stats.month).y : ui.stats.mode === 'year' ? ui.stats.year : null)
      : ui.tab === 'success' && ui.success.scope !== 'all' ? C.ymOf(ui.homeMonth).y : null;
    chip.textContent = y || `${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]}`;
  }

  document.addEventListener('click', async (e) => {
    const tabBtn = e.target.closest('.tabbar button');
    if (tabBtn) return setTab(tabBtn.dataset.tab);
    const el = e.target.closest('[data-act]');
    if (!el || el.closest('#sheet') || el.disabled) return;
    const act = el.dataset.act;
    if (act === 'open-day') return el.dataset.key && openDay(el.dataset.key);
    if (act === 'open-today') return openDay(todayKey());
    if (act === 'month-extras') return openMonthSheet(+el.dataset.m);
    if (act === 'manual-total') return openManualSheet(+el.dataset.m);
    if (act === 'payout') return openPayoutSheet(+el.dataset.m, el.dataset.id);
    if (act === 'wrapped') return openWrapped(+el.dataset.y, +el.dataset.mm);
    if (act === 'rank-all') { ui.success.showAll = true; return renderSuccess(); }
    if (act === 'go-cal') { ui.calMonth = ui.homeMonth; return setTab('cal'); }
    if (act === 'home-prev' || act === 'home-next') { ui.homeMonth += act.endsWith('next') ? 1 : -1; ui.homeMonth = Math.max(0, Math.min(C.MONTH_COUNT - 1, ui.homeMonth)); return renderHome(); }
    if (act === 'cal-prev' || act === 'cal-next') return shiftCal(act.endsWith('next') ? 1 : -1);
    if (act === 'home-pick' || act === 'cal-pick') {
      const cur = act === 'home-pick' ? ui.homeMonth : ui.calMonth;
      const m = await pickMonth(cur);
      if (m === null) return;
      if (act === 'home-pick') { ui.homeMonth = m; renderHome(); } else { ui.calMonth = m; renderCal(m > cur ? 'left' : 'right'); }
      return;
    }
    if (el.closest('#view-settings')) return settingsAction(act, el);
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-theme [data-theme]');
    if (!b) return;
    state.settings.theme = b.dataset.theme; save(); applyTheme(); renderSettings();
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-palettes [data-pal]');
    if (!b) return;
    const p = C.PALETTES.find((x) => x.id === b.dataset.pal);
    state.settings.palette = { id: p.id, accent: p.accent, accent2: p.accent2 };
    save(); applyTheme(); renderSettings(); toast(`Гамма «${p.name}»`);
  });
  const customColor = (e, commit) => {
    if (!e.target.matches('#s-acc, #s-acc2')) return;
    const pal = { ...(state.settings.palette || C.PALETTES[0]), id: 'custom' };
    pal[e.target.id === 's-acc' ? 'accent' : 'accent2'] = e.target.value;
    state.settings.palette = pal; applyTheme();
    if (commit) { save(); document.querySelectorAll('#s-palettes [data-pal]').forEach((x) => x.classList.remove('active')); }
  };
  document.addEventListener('input', (e) => customColor(e, false));
  document.addEventListener('change', (e) => customColor(e, true));
  // Переключатели безопасности и время смены
  document.addEventListener('change', async (e) => {
    const t = e.target;
    if (t.id === 'sec-pin') {
      if (t.checked) { const ok = await setupPin(); if (ok) toast('PIN-код включён'); }
      else if (await confirmDlg('Отключить PIN-код?', 'Приложение будет открываться без кода.', 'Отключить', true)) { meta.lock = { enabled: false, after: lockCfg().after }; saveMeta(); toast('PIN-код отключён'); }
      return renderSettings();
    }
    if (t.id === 'sec-bio') {
      if (t.checked) {
        if (!(await bioAvailable())) { toast('Отпечаток не настроен в телефоне или недоступен'); return renderSettings(); }
        if (!(await bioVerify())) { toast('Отпечаток не подтверждён'); return renderSettings(); }
      }
      meta.lock = { ...lockCfg(), bio: t.checked }; saveMeta(); toast(t.checked ? 'Вход по отпечатку включён' : 'Вход по отпечатку отключён');
      return renderSettings();
    }
    if (t.id === 'sec-after') { meta.lock = { ...lockCfg(), after: Number(t.value) }; saveMeta(); return toast('Сохранено'); }
    if (t.id === 'pet-on' || t.id === 'pet-name') {
      const pt = { ...(state.settings.pet || { on: true, name: 'Мурка' }) };
      if (t.id === 'pet-on') pt.on = t.checked; else pt.name = t.value.trim().slice(0, 20) || 'Мурка';
      state.settings.pet = pt; save(); if (window.Pet) Pet.refresh();
      return toast(t.id === 'pet-on' ? (t.checked ? `${pt.name} снова с вами` : `${pt.name} ушла спать`) : `Теперь её зовут ${pt.name}`);
    }
    if (t.id === 'sh-start' && C.isTime(t.value)) { state.settings.shiftStart = t.value; save(); toast('Начало смены: ' + t.value); }
  });
  $('#backdrop').addEventListener('click', closeModal);
  $('#dlg-backdrop').addEventListener('click', closeModal);
  // Свайп вниз по шапке листа закрывает его
  (() => {
    const sh = $('#sheet'); let y0 = null;
    sh.addEventListener('touchstart', (e) => { y0 = sh.scrollTop <= 0 && e.target.closest('.grabber, .sheet-head') ? e.touches[0].clientY : null; }, { passive: true });
    sh.addEventListener('touchend', (e) => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 70) closeModal(); y0 = null; }, { passive: true });
  })();

  // ---------- Запуск ----------
  function init() {
    document.querySelectorAll('.tabbar button').forEach((b) => b.insertAdjacentHTML('afterbegin', icon(b.dataset.icon)));
    applyTheme();
    setTab('home');
    showLock();
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const cap = window.Capacitor;
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !(cap && cap.isNativePlatform && cap.isNativePlatform())) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
    // Обновляем «сегодня» при возврате в приложение (например, на следующий день)
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !modalStack.length && !lockShown) renderAll(); });
    if (window.Pet) Pet.init({ getState: () => state, C, todayKey, M, N, plural, esc });
    window.__app = { get state() { return state; }, openDay, setTab, ui };
  }
  init();
})();
