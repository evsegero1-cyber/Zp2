/* Интерфейс приложения. Зависит от Core (core.js). */
(() => {
  'use strict';
  const C = Core;
  const STORE_KEY = 'zarplata2027:v1';
  const META_KEY = 'zarplata2027:meta';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const M = C.fmtMoney, N = C.fmtNum;

  // ---------- Хранилище ----------
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const obj = JSON.parse(raw), st = C.normalizeState(obj).state;
        // Старые данные: убираем удалённую игру и переносим выплаты на новую схему — сразу сохраняем
        if (obj.game || !obj.settings || obj.settings.payV !== C.PAY_V) { try { localStorage.setItem(STORE_KEY, JSON.stringify(st)); } catch (e) { /* сохранится при следующем изменении */ } }
        return st;
      }
    } catch (e) { console.warn('Не удалось прочитать данные', e); }
    return C.defaultState();
  }
  function saveLocal() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); return true; }
    catch (e) { toast('Ошибка сохранения: память устройства недоступна'); return false; }
  }
  // Сохранение на устройстве + отправка изменений в облако (если вошли в аккаунт)
  function save() {
    const ok = saveLocal();
    if (ok && window.Cloud && window.Cloud.sync) window.Cloud.sync.changed();
    if (ok) setTimeout(checkAchievements, 600);
    return ok;
  }
  // ---------- Потянуть вниз — обновить с сервера (любая вкладка) ----------
  (function pullToRefresh() {
    const TH = 72;                     // насколько потянуть, чтобы сработало
    let y0 = null, pull = 0, busy = false, el = null;
    const indicator = () => { if (!el) { el = document.createElement('div'); el.id = 'ptr'; el.innerHTML = '<i></i>'; document.body.appendChild(el); } return el; };
    const blocked = (t) => modalStack.length || busy
      || t.closest('#chat-dock, input, textarea, select, canvas, .rp-crop-box, [data-no-ptr]')
      || (window.scrollY || document.documentElement.scrollTop) > 0;
    document.addEventListener('touchstart', (e) => { y0 = e.touches.length === 1 && !blocked(e.target) ? e.touches[0].clientY : null; pull = 0; }, { passive: true });
    document.addEventListener('touchmove', (e) => {
      if (y0 === null) return;
      const dy = e.touches[0].clientY - y0;
      if (dy <= 0 || window.scrollY > 0) { if (pull) { pull = 0; indicator().style.transform = ''; indicator().classList.remove('show'); } return; }
      pull = Math.min(130, dy * 0.5);
      const ind = indicator(); ind.classList.add('show'); ind.classList.toggle('ready', pull >= TH);
      ind.style.transform = `translate(-50%, ${pull}px) rotate(${pull * 4}deg)`;
    }, { passive: true });
    document.addEventListener('touchend', async () => {
      if (y0 === null) return; y0 = null;
      const ind = el; if (!ind || !pull) return;
      if (pull < TH) { ind.style.transform = ''; ind.classList.remove('show', 'ready'); pull = 0; return; }
      pull = 0; busy = true; ind.classList.add('spin'); ind.style.transform = `translate(-50%, ${TH * 0.8}px)`;
      try { await manualRefresh(); }
      finally { busy = false; ind.classList.remove('spin', 'ready'); ind.style.transform = ''; setTimeout(() => ind.classList.remove('show'), 250); }
    });
  })();
  async function manualRefresh() {
    const Cl = window.Cloud;
    if (!Cl || !Cl.ready || !Cl.account || !Cl.account.user) { renderAll(); return; }
    if (!navigator.onLine) { toast('Нет сети — обновлю, когда появится интернет'); return; }
    try {
      const r = await Cl.refresh();
      profilesAt = 0;
      if (ui.tab === 'crew') { loadChatProfiles(); if (ui.crew.sub !== 'chat') renderCrew(); }
      else renderAll();
      refreshAccountCard();
      // заодно проверить, нет ли новой версии приложения (сайт)
      if (navigator.serviceWorker && navigator.serviceWorker.getRegistration) navigator.serviceWorker.getRegistration().then((reg) => reg && reg.update()).catch(() => {});
      toast(r && r.ok === false ? 'Не всё обновилось — повторите позже' : 'Обновлено');
    } catch (ex) { toast('Не удалось обновить: ' + (Cl.errText ? Cl.errText(ex) : ex.message)); }
  }
  // ---------- Нет сети: плашка под заголовком ----------
  function netBanner() {
    let b = document.getElementById('net-banner');
    if (navigator.onLine) { if (b) { b.classList.add('back'); b.textContent = 'Сеть есть — отправляю изменения'; setTimeout(() => { if (navigator.onLine && b.isConnected) b.remove(); }, 2500); } return; }
    if (!b) { b = document.createElement('div'); b.id = 'net-banner'; document.body.appendChild(b); }
    b.classList.remove('back'); b.textContent = 'Нет сети · всё сохраняется на телефоне';
  }
  window.addEventListener('online', netBanner); window.addEventListener('offline', netBanner);
  window.addEventListener('online', () => refreshAccountCard()); window.addEventListener('offline', () => refreshAccountCard());
  setTimeout(netBanner, 0);
  // ---------- Сезонные темы: 🍂 осень (сен–ноя), 🎄 Новый год (1 дек – 14 янв), 🌸 весна (мар–май) ----------
  // По умолчанию выключены. В свой сезон в «Оформлении» появляется переключатель, а при запуске один раз предлагаем включить.
  // Администратор может проверить любую тему заранее (только на своём телефоне).
  const SEASONS = {
    xmas: { icon: '🎄', name: 'Новогодняя тема', desc: 'падающий снег и гирлянда — до 14 января', from: '1 декабря', on: (d) => d.getMonth() === 11 || (d.getMonth() === 0 && d.getDate() <= 14) },
    autumn: { icon: '🍂', name: 'Осенняя тема', desc: 'падающие листья — до 30 ноября', from: '1 сентября', on: (d) => d.getMonth() >= 8 && d.getMonth() <= 10 },
    spring: { icon: '🌸', name: 'Весенняя тема', desc: 'лепестки и цветы — до 31 мая', from: '1 марта', on: (d) => d.getMonth() >= 2 && d.getMonth() <= 4 },
  };
  const SEASON_ORDER = ['xmas', 'spring', 'autumn'];
  const sKey = (k, what) => `zarplata2027:${k}-${what}`;
  const sFlag = (k, what) => { try { return localStorage.getItem(sKey(k, what)) === '1'; } catch { return false; } };
  const seasonTest = (k) => sFlag(k, 'test'), seasonOn = (k) => sFlag(k, 'on');
  // Какая тема сейчас показывается: сначала проверяемая администратором, потом по календарю
  const activeSeason = () => SEASON_ORDER.find((k) => seasonTest(k)) || SEASON_ORDER.find((k) => SEASONS[k].on(new Date()) && seasonOn(k)) || null;
  let seasonStop = null, seasonNow = null;
  function applySeason() {
    const k = activeSeason();
    SEASON_ORDER.forEach((s) => document.body.classList.toggle(s === 'xmas' ? 'xmas' : 'season-' + s, s === k));
    if (k === seasonNow) return;
    if (seasonStop) { seasonStop(); seasonStop = null; }
    seasonNow = k;
    if (k) seasonStop = startSeasonFx(k);
  }
  const applyXmas = applySeason;
  function startSeasonFx(kind) {
    const cv = document.createElement('canvas'); cv.id = 'xmas-snow'; cv.setAttribute('aria-hidden', 'true');
    const gar = document.createElement('div'); gar.id = 'xmas-garland'; gar.className = 'gar-' + kind; gar.setAttribute('aria-hidden', 'true');
    const deco = { autumn: ['🍁', '🍂', '🍁', '🌰', '🍂'], spring: ['🌸', '🌷', '🌼', '🌸', '🦋'] }[kind];
    gar.innerHTML = Array.from({ length: deco ? 11 : 18 }, (_, i) => deco ? `<i style="--d:${(i * 0.43) % 2.6}s">${deco[i % deco.length]}</i>` : `<i style="--d:${(i * 0.37) % 2.2}s"></i>`).join('');
    document.body.append(cv, gar);
    const g = cv.getContext('2d'), dpr = Math.min(2, window.devicePixelRatio || 1);
    let W = 0, H = 0;
    const size = () => { W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0); };
    size(); addEventListener('resize', size);
    const R = Math.random;
    const LEAF = ['#E8590C', '#F08C00', '#D9480F', '#C92A2A', '#FAB005', '#A0522D'], PETAL = ['#FFC9DE', '#FFB3CF', '#FCC2D7', '#FFE3EC', '#F8D7E8'];
    const n = kind === 'xmas' ? Math.round(Math.min(34, W / 12)) : kind === 'autumn' ? Math.round(Math.min(7, W / 55)) : Math.round(Math.min(10, W / 40));
    const mk = (top) => ({ x: R() * W, y: top ? -12 - R() * 40 : R() * H, r: kind === 'xmas' ? 0.8 + R() * 1.9 : 0.7 + R() * 0.6,
      v: kind === 'xmas' ? 10 + R() * 22 : kind === 'autumn' ? 22 + R() * 26 : 14 + R() * 18,
      a: R() * 6.28, rot: R() * 6.28, spin: (R() - 0.5) * 3, flip: R() * 6.28, c: kind === 'autumn' ? LEAF[Math.floor(R() * LEAF.length)] : PETAL[Math.floor(R() * PETAL.length)], star: R() < 0.18 });
    const flakes = Array.from({ length: n }, () => mk(false));
    // Лист клёна/берёзы — простая форма из кривых; лепесток — капля с выемкой
    const leaf = (s) => { g.beginPath(); g.moveTo(0, -s); g.bezierCurveTo(s * 0.9, -s * 0.6, s * 0.8, s * 0.5, 0, s); g.bezierCurveTo(-s * 0.8, s * 0.5, -s * 0.9, -s * 0.6, 0, -s); g.fill();
      g.strokeStyle = 'rgba(90,40,10,.35)'; g.lineWidth = 0.7; g.beginPath(); g.moveTo(0, -s * 0.8); g.lineTo(0, s * 1.35); g.stroke(); };
    const petal = (s) => { g.beginPath(); g.moveTo(0, s); g.bezierCurveTo(s * 1.1, s * 0.3, s * 0.7, -s, s * 0.15, -s * 0.8); g.lineTo(0, -s * 0.5); g.lineTo(-s * 0.15, -s * 0.8); g.bezierCurveTo(-s * 0.7, -s, -s * 1.1, s * 0.3, 0, s); g.fill(); };
    let last = performance.now(), raf = 0, alive = true;
    const frame = (now) => {
      if (!alive) return; raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (document.hidden) return;
      const dark = document.documentElement.dataset.theme === 'dark' || (document.documentElement.dataset.theme !== 'light' && matchMedia('(prefers-color-scheme: dark)').matches);
      g.clearRect(0, 0, W, H);
      if (kind === 'xmas') { g.fillStyle = dark ? 'rgba(255,255,255,.75)' : 'rgba(150,185,215,.7)'; g.font = '11px system-ui'; g.textAlign = 'center'; }
      for (const f of flakes) {
        f.y += f.v * dt; f.a += dt * (kind === 'xmas' ? 0.8 : 1.3); f.x += Math.sin(f.a) * (kind === 'xmas' ? 0.25 : 0.7);
        if (f.y > H + 14) Object.assign(f, mk(true));
        if (kind === 'xmas') { if (f.star) g.fillText('❄', f.x, f.y); else { g.beginPath(); g.arc(f.x, f.y, f.r, 0, 6.28); g.fill(); } continue; }
        f.rot += f.spin * dt; f.flip += dt * 2.2;
        g.save(); g.translate(f.x, f.y); g.rotate(f.rot); g.scale(Math.max(0.15, Math.abs(Math.cos(f.flip))), 1);
        g.globalAlpha = kind === 'autumn' ? 0.82 : 0.9; g.fillStyle = f.c;
        if (kind === 'autumn') leaf(6 * f.r + 3); else petal(4.5 * f.r + 2);
        g.restore();
      }
    };
    raf = requestAnimationFrame(frame);
    return () => { alive = false; cancelAnimationFrame(raf); removeEventListener('resize', size); cv.remove(); gar.remove(); };
  }
  document.addEventListener('change', (e) => {
    const m = /^season-(on|test)-(\w+)$/.exec(e.target.id || ''); if (!m) return;
    const k = m[2]; if (!SEASONS[k]) return;
    try {
      if (m[1] === 'on') localStorage.setItem(sKey(k, 'on'), e.target.checked ? '1' : '0');
      else { localStorage.setItem(sKey(k, 'test'), e.target.checked ? '1' : '0'); if (e.target.checked) SEASON_ORDER.forEach((s) => s !== k && localStorage.setItem(sKey(s, 'test'), '0')); }
    } catch {}
    applySeason(); if (m[1] === 'test') renderTabSafe();
  });
  const seasonSwitches = () => SEASON_ORDER.filter((k) => SEASONS[k].on(new Date())).map((k) => `<label class="switch-row" style="margin-top:8px"><span><b>${SEASONS[k].icon} ${SEASONS[k].name}</b><small>${SEASONS[k].desc}</small></span><input type="checkbox" class="switch" id="season-on-${k}" ${seasonOn(k) ? 'checked' : ''}></label>`).join('');
  // Один раз за сезон предложить включить тему (решение запоминается на этот сезон)
  function offerSeason() {
    const d = new Date(), k = SEASON_ORDER.find((x) => SEASONS[x].on(d)); if (!k || seasonOn(k) || seasonTest(k)) return;
    const yr = k === 'xmas' && d.getMonth() === 0 ? d.getFullYear() - 1 : d.getFullYear(), ask = sKey(k, 'asked-' + yr);
    try { if (localStorage.getItem(ask)) return; } catch { return; }
    if (modalStack.length || document.querySelector('#lock:not([hidden])')) return setTimeout(offerSeason, 4000);
    try { localStorage.setItem(ask, '1'); } catch {}
    dialog({ title: `${SEASONS[k].icon} ${SEASONS[k].name}`, text: `Включить? ${SEASONS[k].desc[0].toUpperCase() + SEASONS[k].desc.slice(1)}. Выключить можно в Профиль → Настройки → Оформление.`,
      buttons: [{ text: 'Включить', cls: 'btn-primary', value: true }, { text: 'Не надо', value: false }] }).then((v) => {
      if (!v) return; try { localStorage.setItem(sKey(k, 'on'), '1'); } catch {} applySeason(); if (ui.tab === 'settings') renderTabSafe();
    });
  }
  setTimeout(offerSeason, 3500);
  const seasonAdmin = () => ['autumn', 'xmas', 'spring'].map((k) => `<div class="card"><label class="switch-row" style="margin:0"><span><b>${SEASONS[k].icon} ${SEASONS[k].name} — проверить</b><small>только на этом телефоне. У всех тема включается сама с ${SEASONS[k].from}, тогда же в «Оформлении» появляется переключатель, чтобы её выключить</small></span><input type="checkbox" class="switch" id="season-test-${k}" ${seasonTest(k) ? 'checked' : ''}></label></div>`).join('');
  const renderTabSafe = () => { try { renderAll(); } catch {} };
  setTimeout(applySeason, 400);
  // в полночь начала сезона тема включится сама, даже если приложение открыто
  setInterval(applySeason, 10 * 60e3);
  // Груша удалена — стереть её данные с устройства
  try { ['zarplata2027:punch-face', 'zarplata2027:punch-best'].forEach((k) => localStorage.removeItem(k)); } catch {}
  // Фото профиля сотрудника — открыть крупно
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-av-open]'); if (b) { const im = b.querySelector('img'); if (im) openPhoto(im.src); } });
  // ---------- Достижения: тост о новом и значки в рейтинге ----------
  // Вес товара: до тонны — в кг, дальше — в тоннах с одним знаком
  function fmtKg(kg) { return kg < 1000 ? `${N(Math.round(kg))} кг` : `${N(kg / 1000, 1)} т`; }
  const ACH_KEY = 'zarplata2027:ach-seen';
  const achs = () => C.achievements(state, { backup: !!meta.lastBackup });
  function checkAchievements() {
    const done = achs().filter((a) => a.done);
    let seen = null; try { seen = JSON.parse(localStorage.getItem(ACH_KEY)); } catch {}
    const ids = done.map((a) => a.id);
    if (Array.isArray(seen)) {
      const fresh = done.filter((a) => !seen.includes(a.id));
      fresh.slice(0, 2).forEach((a, i) => setTimeout(() => toast(`${a.icon} Новое достижение: ${a.title}`), 1400 * i + 300));
    }
    try { localStorage.setItem(ACH_KEY, JSON.stringify(ids)); } catch {}
    publishBadges();
  }
  function publishBadges() {
    const Cl = window.Cloud;
    if (!Cl || !Cl.ready || !Cl.social || !Cl.social.my || !Cl.social.my.visible) return;
    Cl.social.setBadges(achs().filter((a) => a.done).map((a) => a.id)).catch(() => {});
  }
  // Значки по id (публичная статистика): известные — по списку достижений, от сложных к простым
  function badgeList(ids, max) {
    if (!Array.isArray(ids) || !ids.length) return [];
    const all = badgeList.all || (badgeList.all = C.achievements(C.defaultState()));
    return all.filter((a) => ids.includes(a.id)).reverse().slice(0, max || 40);
  }
  const badgesHtml = (ids, max, cls = '') => { const l = badgeList(ids, max); return l.length ? `<span class="badges ${cls}">${l.map((a) => `<i title="${esc(a.title)}">${a.icon}</i>`).join('')}</span>` : ''; };
  const meta = (() => { try { return JSON.parse(localStorage.getItem(META_KEY)) || {}; } catch { return {}; } })();
  const saveMeta = () => { try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch {} };

  let state = load();
  const todayKey = () => C.keyOfDate(new Date());
  // Сквозной номер месяца (0 = январь 2026 … 35 = декабрь 2028). Основной год — 2027:
  // если сегодня 2027 год, открываем текущий месяц, иначе январь 2027.
  // При запуске открывается текущий месяц и год (если вне 2026–2028 — ближайший край)
  const defaultMonth = () => {
    const t = todayKey();
    if (t < C.FIRST_DAY) return 0;
    if (t > C.LAST_DAY) return C.MONTH_COUNT - 1;
    const p = C.parseKey(t); return C.indexOf(p.y, p.m);
  };
  const monthName = (i) => { const { y, m } = C.ymOf(i); return `${C.MONTHS[m]} ${y}`; };
  const ui = {
    tab: 'home', homeMonth: defaultMonth(), calMonth: defaultMonth(),
    stats: { mode: 'month', month: defaultMonth(), year: C.ymOf(defaultMonth()).y, from: `${C.ymOf(defaultMonth()).y}-01-01`, to: `${C.ymOf(defaultMonth()).y}-12-31` },
    success: { scope: 'month' },
  };
  const prevHero = {};

  // ---------- Тема ----------
  const mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  // Цвета: смешивание hex и яркость — чтобы гамма читалась и в светлой, и в тёмной теме
  const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const rgbHex = (a) => '#' + a.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  const mixHex = (a, b, t) => { const x = hexRgb(a), y = hexRgb(b); return rgbHex(x.map((v, i) => v + (y[i] - v) * t)); };
  const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  function applyTheme() {
    const t = state.settings.theme === 'system' ? (mq && mq.matches ? 'dark' : 'light') : state.settings.theme;
    document.documentElement.dataset.theme = t;
    const pal = state.settings.palette || C.PALETTES[0], dark = t === 'dark';
    const acc = dark ? mixHex(pal.accent, '#ffffff', 0.18) : pal.accent;
    const acc2 = dark ? mixHex(pal.accent2, '#ffffff', 0.22) : pal.accent2;
    const rs = document.documentElement.style;
    rs.setProperty('--accent', acc);
    rs.setProperty('--chart', acc);
    rs.setProperty('--chart-2', acc2);
    rs.setProperty('--accent-ink', lum(acc) > 0.45 ? '#1a1a1a' : '#ffffff');
    rs.setProperty('--accent-soft', dark ? mixHex(acc, '#1d1d1c', 0.74) : mixHex(acc, '#ffffff', 0.85));
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = t === 'dark' ? '#121212' : '#f4f3ef';
  }
  if (mq) (mq.addEventListener ? mq.addEventListener('change', applyTheme) : mq.addListener(applyTheme));

  // ---------- Иконки ----------
  const ICONS = {
    camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 13h6M9 17h6"/>',
    send: '<path d="M4 12 20 4l-6 16-3-7z"/><path d="m11 13 9-9"/>',
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
    stats: '<path d="M4 20V11M10 20V4M16 20v-7M22 20H2"/>',
    people: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.6"/><path d="M16 14.2a5 5 0 0 1 6 4.8"/>',
    user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
    trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M17 5h3v2a4 4 0 0 1-4 4M7 5H4v2a4 4 0 0 0 4 4"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;

  // ---------- Нативные плагины (только в APK) ----------
  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const pluginCache = {};
  function nativePlugin(name) {
    const cap = window.Capacitor;
    if (!isNative() || !cap.registerPlugin || (cap.isPluginAvailable && !cap.isPluginAvailable(name))) return null;
    if (!pluginCache[name]) pluginCache[name] = (cap.Plugins && cap.Plugins[name]) || cap.registerPlugin(name);
    return pluginCache[name];
  }

  // ---------- Блокировка: PIN-код и отпечаток пальца ----------
  // Настройки блокировки хранятся только на этом устройстве (не попадают в резервную копию).
  const lockCfg = () => meta.lock || { enabled: false };
  async function hashPin(pin, salt) {
    const data = new TextEncoder().encode(salt + ':' + pin + ':zp');
    try { const h = await crypto.subtle.digest('SHA-256', data); return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, '0')).join(''); }
    catch { let h = 2166136261; for (const b of data) { h ^= b; h = Math.imul(h, 16777619) >>> 0; } return 'f' + h.toString(16); }
  }
  let authBusy = false, hiddenAt = null;
  async function bioAvailable() {
    const B = nativePlugin('NativeBiometric');
    if (!B) return false;
    try { const r = await B.isAvailable({ useFallback: false }); return !!(r && r.isAvailable); } catch { return false; }
  }
  async function bioVerify() {
    const B = nativePlugin('NativeBiometric');
    if (!B) return false;
    authBusy = true;
    try { await B.verifyIdentity({ title: 'Вход', subtitle: 'Калькулятор ЗП', reason: 'Подтвердите вход', negativeButtonText: 'PIN-код', maxAttempts: 3 }); return true; }
    catch { return false; }
    finally { setTimeout(() => { authBusy = false; hiddenAt = null; }, 800); }
  }
  // Цифровая клавиатура PIN. opts: { title, sub, onPin(pin) → true | 'текст ошибки', bio, forgot }
  function pinPad(el, opts) {
    let pin = '';
    el.innerHTML = `<div class="pin-box">
      <div class="pin-logo">🔒</div><div class="pin-title">${esc(opts.title)}</div><div class="pin-sub" id="pin-sub">${esc(opts.sub || '')}</div>
      <div class="pin-dots">${'<i></i>'.repeat(4)}</div>
      <div class="pin-keys">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button type="button" data-k="${n}">${n}</button>`).join('')}
        ${opts.bio ? '<button type="button" data-bio class="pin-fn">👆</button>' : '<span></span>'}<button type="button" data-k="0">0</button><button type="button" data-del class="pin-fn">⌫</button></div>
      ${opts.forgot ? '<button type="button" class="pin-link" data-forgot>Забыли PIN-код?</button>' : ''}
      ${opts.cancel ? '<button type="button" class="pin-link" data-cancel>Отмена</button>' : ''}</div>`;
    const dots = el.querySelectorAll('.pin-dots i');
    const draw = () => dots.forEach((d, i) => d.classList.toggle('on', i < pin.length));
    el.onclick = async (e) => {
      const k = e.target.closest('[data-k]');
      if (k && pin.length < 4) {
        pin += k.dataset.k; draw();
        if (pin.length === 4) {
          const r = await opts.onPin(pin);
          if (r !== true) {
            el.querySelector('.pin-dots').classList.add('shake');
            $('#pin-sub', el).textContent = r || 'Неверный PIN-код';
            setTimeout(() => { pin = ''; draw(); const d = el.querySelector('.pin-dots'); if (d) d.classList.remove('shake'); }, 450);
          }
        }
        return;
      }
      if (e.target.closest('[data-del]')) { pin = pin.slice(0, -1); draw(); return; }
      if (e.target.closest('[data-bio]') && opts.onBio) return opts.onBio();
      if (e.target.closest('[data-forgot]') && opts.forgot) return opts.forgot();
      if (e.target.closest('[data-cancel]') && opts.cancel) return opts.cancel();
    };
  }
  let lockShown = false;
  async function showLock() {
    const cfg = lockCfg();
    if (!cfg.enabled || !cfg.hash || lockShown) return;
    lockShown = true;
    const el = $('#lock');
    el.hidden = false; document.body.classList.add('locked');
    let fails = 0;
    const unlock = () => { el.hidden = true; lockShown = false; document.body.classList.remove('locked'); el.innerHTML = ''; renderAll(); };
    const tryBio = async () => { if (await bioVerify()) unlock(); };
    const useBio = cfg.bio && await bioAvailable();
    pinPad(el, {
      title: 'Введите PIN-код', sub: useBio ? 'или приложите палец' : '', bio: useBio, onBio: tryBio,
      onPin: async (pin) => {
        if (fails >= 5) return 'Слишком много попыток — подождите 30 секунд';
        if ((await hashPin(pin, cfg.salt)) === cfg.hash) { unlock(); return true; }
        fails++;
        if (fails >= 5) setTimeout(() => { fails = 0; const sub = $('#pin-sub'); if (sub) sub.textContent = 'Можно снова вводить PIN'; }, 30000);
        return `Неверный PIN-код${fails >= 3 && fails < 5 ? ` · осталось попыток: ${5 - fails}` : ''}`;
      },
      forgot: async () => {
        const ok = await confirmDlg('Сбросить PIN-код?', 'Чтобы защитить данные, сброс PIN удалит все записи на этом телефоне. Потом их можно восстановить из резервной копии.', 'Сбросить и удалить данные', true);
        if (!ok) return;
        state = C.defaultState(); save(); meta.lock = { enabled: false }; saveMeta(); applyTheme(); unlock(); toast('PIN сброшен, данные удалены');
      },
    });
    if (useBio) setTimeout(tryBio, 300);
  }
  // Включение PIN: ввод дважды
  function setupPin() {
    return new Promise((resolve) => {
      const sh = $('#sheet');
      let first = null;
      const step = () => pinPad(sh, {
        title: first ? 'Повторите PIN-код' : 'Придумайте PIN-код', sub: first ? '' : '4 цифры', cancel: () => closeModal(),
        onPin: async (pin) => {
          if (!first) { first = pin; setTimeout(step, 150); return true; }
          if (pin !== first) { first = null; setTimeout(step, 600); return 'Не совпадает — начните заново'; }
          const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
          meta.lock = { ...lockCfg(), enabled: true, salt, hash: await hashPin(pin, salt), after: lockCfg().after ?? 60 };
          saveMeta(); resolved = true; closeModal(); return true;
        },
      });
      let resolved = false;
      step();
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(resolved);
    });
  }
  document.addEventListener('visibilitychange', () => {
    if (authBusy) return;
    if (document.hidden) { hiddenAt = Date.now(); return; }
    const cfg = lockCfg();
    if (cfg.enabled && hiddenAt !== null && Date.now() - hiddenAt >= (cfg.after ?? 60) * 1000) showLock();
    hiddenAt = null;
  });

  // ---------- Модальные окна + кнопка «Назад» Android ----------
  const modalStack = [];
  function openModal(el, backdrop, onClose) {
    modalStack.push({ el, backdrop, onClose });
    backdrop.classList.add('show'); el.classList.add('show');
    try { history.pushState({ modal: modalStack.length }, ''); } catch {}
  }
  function hideTop() {
    const m = modalStack.pop();
    if (!m) return;
    m.el.classList.remove('show'); m.backdrop.classList.remove('show');
    if (m.onClose) m.onClose();
    if (document.activeElement && m.el.contains(document.activeElement)) document.activeElement.blur();
  }
  function closeModal() {
    if (!modalStack.length) return;
    if (history.state && history.state.modal) history.back(); else hideTop();
  }
  window.addEventListener('popstate', () => { if (modalStack.length) hideTop(); });

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2400);
  }

  // Диалог с произвольными кнопками. buttons: [{text, cls, value}]
  function dialog({ title, text = '', buttons, html = '' }) {
    return new Promise((resolve) => {
      const d = $('#dialog');
      d.innerHTML = `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${html}` +
        buttons.map((b, i) => `<button class="btn ${b.cls || 'btn-secondary'}" data-i="${i}">${esc(b.text)}</button>`).join('');
      let result = null;
      d.onclick = (e) => {
        const b = e.target.closest('button[data-i]');
        if (!b) return;
        const btn = buttons[+b.dataset.i];
        result = btn.value;
        if (btn.read) result = btn.read(d);
        closeModal();
      };
      openModal(d, $('#dlg-backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(result);
    });
  }
  const confirmDlg = (title, text, okText = 'Да', danger = false) =>
    dialog({ title, text, buttons: [{ text: okText, cls: danger ? 'btn-danger' : 'btn-primary', value: true }, { text: 'Отмена', value: false }] });

  // ---------- Переключатель месяца ----------
  const monthSwitch = (i, id) => `
    <div class="month-switch">
      <button class="arrow" data-act="${id}-prev" ${i === 0 ? 'disabled' : ''} aria-label="Предыдущий месяц">‹</button>
      <button class="title" data-act="${id}-pick">${monthName(i)}</button>
      <button class="arrow" data-act="${id}-next" ${i === C.MONTH_COUNT - 1 ? 'disabled' : ''} aria-label="Следующий месяц">›</button>
    </div>`;

  function pickMonth(current) {
    return new Promise((resolve) => {
      const sh = $('#sheet');
      let year = C.ymOf(current).y;
      const draw = () => {
        const months = C.yearByMonths(state, year);
        sh.innerHTML = `<div class="grabber"></div>
          <div class="sheet-head"><div class="grow"><div class="sheet-title">Выберите месяц</div></div><button class="icon-btn" data-close>×</button></div>
          <div class="seg">${C.YEARS.map((y) => `<button data-y="${y}" class="${y === year ? 'active' : ''}">${y}${y === C.YEAR ? ' ★' : ''}</button>`).join('')}</div>
          <div class="month-picker">${C.MONTHS.map((n, m) => { const i = C.indexOf(year, m); return `<button data-m="${i}" class="${i === current ? 'current' : ''}"><b>${n}</b><small>${months[m].shifts || months[m].grand ? M(months[m].grand) : '—'}</small></button>`; }).join('')}</div>`;
      };
      draw();
      let chosen = null;
      sh.onclick = (e) => {
        if (e.target.closest('[data-close]')) return closeModal();
        const yb = e.target.closest('[data-y]');
        if (yb) { year = +yb.dataset.y; return draw(); }
        const b = e.target.closest('[data-m]');
        if (b) { chosen = +b.dataset.m; closeModal(); }
      };
      openModal(sh, $('#backdrop'));
      modalStack[modalStack.length - 1].onClose = () => resolve(chosen);
    });
  }

  // ---------- Анимация чисел ----------
  function countUp(el, to, fmt) {
    const id = el.id, from = prevHero[id] ?? 0;
    prevHero[id] = to;
    if (from === to || matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 500;
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(p < 1 ? Math.round(from + (to - from) * e) : to);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---------- Главная ----------
  function renderHome() {
    const idx = ui.homeMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.monthSummary(state, m, today, y);
    const x = s.extras, b = x.cfg;
    const tgt = s.target;
    const best = s.best ? `${C.fmtDateShort(s.best.key)}` : '—';
    const recent = s.days.slice().reverse().slice(0, 5);
    const canToday = C.inYear(today);
    const projHint = s.projected === null ? 'внесите первую смену'
      : s.projectionBasis === 'year' ? 'по средней за год'
      : s.remainingShifts ? `ещё ~${s.remainingShifts} ${plural(s.remainingShifts, 'смена', 'смены', 'смен')}` : 'месяц завершён';

    $('#view-home').innerHTML = `
      ${monthSwitch(idx, 'home')}
      <div class="hero">
        <div class="hero-head"><div class="label">${s.manual !== null ? `Получено за ${C.MONTHS[m].toLowerCase()} · факт` : `Заработок за ${C.MONTHS[m].toLowerCase()}`}</div>
          <button class="hero-edit" data-act="manual-total" data-m="${idx}">✎ ${s.manual !== null ? 'Изменить' : 'Ввести итог'}</button></div>
        <div class="big num" id="hero-total">${M(s.grand)}</div>
        ${s.manual !== null ? `<div class="manual-diff ${s.manualDiff > 0 ? 'plus' : s.manualDiff < 0 ? 'minus' : ''}">${s.manualDiff === 0 ? 'Совпадает с расчётом' : `На ${M(Math.abs(s.manualDiff))} ${s.manualDiff > 0 ? 'больше' : 'меньше'}, чем ожидалось`}</div>
          <div class="sub num">По календарю ожидалось ${M(s.calc)}${x.penalty ? ` (с учётом штрафа ${M(x.penalty)})` : ''}</div>`
        : `<div class="sub num">${x.penalty ? `Смены ${M(s.total)} − штраф ${M(x.penalty)}` : `Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт указан в ${s.actualCount} ${plural(s.actualCount, 'смене', 'сменах', 'сменах')}` : ''}`}</div>`}
        ${tgt ? `<div class="progress"><i style="width:${Math.min(100, s.targetProgress * 100).toFixed(1)}%"></i></div>
          <div class="progress-label num"><span>${Math.round(s.targetProgress * 100)}% от цели ${M(tgt)}</span><span>${s.grand >= tgt ? 'Цель достигнута 🎉' : s.needPerShift ? `нужно ≈${M(s.needPerShift)}/смену` : `осталось ${M(tgt - s.grand)}`}</span></div>` : ''}
        ${pendingBlock(s)}
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Отработано смен</div><div class="t-value num">${s.shifts}</div><div class="t-sub">из ${s.plannedTotal} ${s.plannedByUser ? 'по плану' : 'рабочих дней'}${marksText(s.marks) ? ` · ${marksText(s.marks)}` : ''}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div><div class="t-sub">в среднем</div></div>
        <div class="tile"><div class="t-label">Заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div><div class="t-sub">в среднем</div></div>
        <button class="tile clickable" data-act="open-day" data-key="${s.best ? s.best.key : ''}" ${s.best ? '' : 'disabled'} style="text-align:left">
          <div class="t-label">Самый продуктивный день</div><div class="t-value num">${best}</div>
          <div class="t-sub num">${s.best ? `${N(s.best.lines)} линий · ${M(s.best.total)}` : 'нет данных'}</div></button>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${x.prodAvg === null ? '' : x.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</div><div class="t-sub">${x.prodAvg === null ? 'не указана' : `по ${x.prodDays} ${plural(x.prodDays, 'смене', 'сменам', 'сменам')}`}</div></div>
        <div class="tile wide"><div class="t-label">Прогноз на месяц</div><div class="t-value num">${s.projected === null ? '—' : M(s.projected)}</div><div class="t-sub">${projHint}${s.projected !== null && (x.prodOk || s.needProd !== null) ? ` · <span class="pend-inline">${x.pending ? `+${M(x.pending)} премии ожидаются` : `до +${M(b.prodAmount)} премия при средней от ${N(b.prodThreshold, 0)}%`}</span>` : ''}</div></div>
      </div>
      ${payoutCard(idx)}
      ${bonusCard(s, idx)}
      ${s.shifts ? `<button class="wrap-btn" data-act="wrapped" data-y="${y}" data-mm="${m}"><span>🎬</span><div class="grow"><b>Итоги месяца · ${C.MONTHS[m].toLowerCase()}</b><small>истории о вашем месяце</small></div><i>›</i></button>` : ''}
      <button class="btn btn-primary" data-act="${canToday ? 'open-today' : 'go-cal'}">＋ ${canToday ? 'Записать сегодняшнюю смену' : 'Записать смену'}</button>
      ${recent.length ? `<div class="card" style="margin-top:14px"><h2>Смены за месяц <small>${s.shifts}</small></h2>
        ${recent.map(rowHtml).join('')}
        ${s.shifts > 5 ? `<button class="btn btn-secondary" data-act="go-cal" style="margin-top:6px">Все смены в календаре</button>` : ''}</div>`
      : `<p class="hint" style="text-align:center;margin-top:18px">${canToday ? '' : `Календарь рассчитан на ${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]} годы. `}Нажмите на любой день в календаре, чтобы внести смену.</p>`}`;
    countUp($('#hero-total'), Math.round(s.grand), (v) => (v === Math.round(s.grand) ? M(s.grand) : M(v)));
    updateChip();
  }
  // Отдельный блок «премия за производительность ожидается» — не входит в итог месяца
  // Премии за производительность и сервис — «ожидается», в итог не входят
  function pendingBlock(s) {
    const x = s.extras, b = x.cfg;
    const rows = [];
    if (x.prodAvg !== null) rows.push(x.prodOk
      ? `<div class="pend-row"><span>✓ Производительность ${N(x.prodAvg, 1)}%</span><b class="num">+${M(x.prodBonus)}</b></div>`
      : `<div class="pend-row dim"><span>🎯 Производительность ${N(x.prodAvg, 1)}% из ${N(b.prodThreshold, 0)}%</span><b class="num">+${M(b.prodAmount)}?</b></div>`);
    if (x.zone) rows.push(x.serviceBonus
      ? `<div class="pend-row"><span>✓ Сервис ${N(x.service, 2)}% · ${ZONES[x.zone][0].toLowerCase()}</span><b class="num">+${M(x.serviceBonus)}</b></div>`
      : `<div class="pend-row dim"><span>Сервис ${N(x.service, 2)}% · ${ZONES[x.zone][0].toLowerCase()} зона</span><b class="num">0 ₽</b></div>`);
    if (!rows.length) return '';
    return `<div class="pending ${x.pending ? 'ok' : ''}">
        <div class="pending-top"><span class="pending-tag">⏳ Премии — ожидаются</span>${x.pending ? `<b class="num">+${M(x.pending)}</b>` : ''}</div>
        ${rows.join('')}
        <div class="pending-sub num">${x.pending ? `не входят в итог${s.manual === null ? ` · вместе с ними: <b>${M(s.grandWithPending)}</b>` : ''}` : 'не входят в итог'}</div></div>`;
  }
  const marksText = (mk) => mk ? [['sick', 'больн.'], ['vacation', 'отпуск'], ['off', 'вых.'], ['work', 'раб. сб/вс']].filter(([k]) => mk[k]).map(([k, t]) => `${t} ${mk[k]}`).join(', ') : '';
  const ZONES = { green: ['Зелёная', 'zone-green'], yellow: ['Жёлтая', 'zone-yellow'], red: ['Красная', 'zone-red'] };
  // ---------- Выплаты: аванс, конверт, зарплата ----------
  const daysWord = (n) => (n === 0 ? 'сегодня' : n === 1 ? 'завтра' : n === -1 ? 'вчера' : n > 0 ? `через ${n} ${plural(n, 'день', 'дня', 'дней')}` : `${-n} ${plural(-n, 'день', 'дня', 'дней')} назад`);
  const dShort = (k) => `${C.WEEKDAYS[C.weekdayMon(k)].toLowerCase()} ${C.fmtDateShort(k)}`;
  function payoutCard(idx) {
    const { y, m } = C.ymOf(idx), today = todayKey();
    const list = C.payoutSchedule(state, m, y, today);
    const next = C.nextPayout(state, today);
    const got = C.payoutsTotal(state, m, y);
    const nextHtml = next ? `<div class="next-pay">
        <div class="np-icon">${next.icon}</div>
        <div class="grow"><div class="np-label">Ближайшая выплата</div><div class="np-title">${next.name} · ${next.dateTo ? `${C.fmtDateShort(next.date)}–${C.fmtDateShort(next.dateTo)}` : dShort(next.date)}</div></div>
        <div class="np-days num">${next.dateTo && next.daysLeft <= 0 ? 'ждём' : next.daysLeft <= 0 ? 'сегодня' : `<b>${next.daysLeft}</b><small>${plural(next.daysLeft, 'день', 'дня', 'дней')}</small>`}</div></div>` : '';
    return `<div class="card pay-card"><h2>Выплаты <small>${C.MONTHS[m].toLowerCase()}${got ? ` · получено ${M(got)}` : ''}</small></h2>
      ${nextHtml}
      ${list.map((p) => `<button class="pay-row ${p.status}" data-act="payout" data-m="${idx}" data-id="${p.id}">
        <span class="pay-ic">${p.icon}</span>
        <span class="grow"><b>${p.name} <span class="pay-for">${p.forMonth}</span></b><small>${p.dateTo ? `ориентировочно ${C.fmtDateShort(p.date)}–${C.fmtDateShort(p.dateTo)}` : dShort(p.date)}${p.shifted ? ' · перенос с выходного' : ''}</small></span>
        <span class="pay-st">${p.received ? `<b class="up">✓ ${p.amount != null ? M(p.amount) : 'получено'}</b>` : p.status === 'late' ? '<span class="down">не отмечено</span>' : p.status === 'today' ? '<b class="pend-inline">ожидается</b>' : `<span class="muted">${daysWord(p.daysLeft)}</span>`}</span>
      </button>`).join('')}
      <p class="hint">Нажмите на выплату, чтобы отметить, что она пришла, и записать сумму. Если дата выпадает на выходной или праздник, выплата ожидается раньше.</p></div>`;
  }
  function openPayoutSheet(idx, id) {
    const { y, m } = C.ymOf(idx);
    const p = C.payoutSchedule(state, m, y, todayKey()).find((x) => x.id === id);
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${p.icon} ${p.name}</div><div class="sheet-sub">${p.forMonth} · ${C.MONTHS[m]} ${y} · ${p.dateTo ? `ориентировочно ${C.fmtDateShort(p.date)}–${C.fmtDateShort(p.dateTo)}` : `по плану ${dShort(p.date)}`}</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="pay-form" autocomplete="off" novalidate>
        <div class="field"><label for="pf-amount">Пришло, ₽</label><input class="input big num" id="pf-amount" inputmode="decimal" placeholder="0" value="${p.amount != null ? String(p.amount).replace('.', ',') : ''}"></div>
        <div class="field"><label for="pf-date">Дата поступления</label><input class="input" type="date" id="pf-date" value="${p.receivedOn || (todayKey() >= p.date ? todayKey() : p.date)}"></div>
        <p class="error" id="pf-error"></p>
        <button class="btn btn-primary" type="submit">✓ Выплата пришла</button>
        ${p.received ? '<button class="btn btn-danger" type="button" data-unpay>Отменить отметку</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    sh.onclick = (e) => {
      if (e.target.closest('[data-close]')) return closeModal();
      if (e.target.closest('[data-unpay]')) { C.setPayout(state, m, y, id, { received: false, amount: null }); save(); closeModal(); renderAll(); toast('Отметка снята'); }
    };
    $('#pay-form').onsubmit = (e) => {
      e.preventDefault();
      const r = C.setPayout(state, m, y, id, { received: true, amount: $('#pf-amount').value, date: $('#pf-date').value });
      if (!r.ok) { $('#pf-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast(`${p.name}: получено`); }
    };
    openModal(sh, $('#backdrop'));
  }
  function bonusCard(s, idx) {
    const x = s.extras, b = x.cfg, m = C.ymOf(idx).m;
    const prodLine = x.prodAvg === null
      ? `<span class="muted">укажите производительность в сменах</span>`
      : x.prodOk ? `<b class="pend-val">+${M(x.prodBonus)}</b><div class="pend-note">ожидается · не в итоге</div>`
      : `<span class="muted">${s.needProd !== null && s.needProd <= 300 ? `нужно в среднем ${N(s.needProd, 1)}% в оставшиеся смены` : `ниже ${N(b.prodThreshold, 0)}%`}</span>`;
    const zone = x.zone ? ZONES[x.zone] : null;
    return `<div class="card bonus-card"><h2>Премии и штраф <small>${C.MONTHS[m].toLowerCase()}</small></h2>
      <div class="bonus-row"><div><div>За производительность</div><div class="hint" style="margin:2px 0 0">средняя ${x.prodAvg === null ? '—' : N(x.prodAvg, 2) + '%'} · нужно от ${N(b.prodThreshold, 0)}%</div>
        ${x.prodAvg !== null ? `<div class="meter"><i style="width:${Math.min(100, (x.prodAvg / (b.prodThreshold * 1.25)) * 100).toFixed(1)}%" class="${x.prodOk ? 'ok' : ''}"></i><s style="left:${(100 / 1.25).toFixed(1)}%"></s></div>` : ''}</div>
        <div class="bonus-val">${prodLine}</div></div>
      <div class="bonus-row"><div><div>За сервис ${zone ? `<span class="zone ${zone[1]}">${zone[0]}</span>` : ''}</div><div class="hint" style="margin:2px 0 0">${x.service === null ? 'качество за месяц не указано' : `качество ${N(x.service, 3)}%`} · зелёная от ${N(b.greenThreshold, 2)}%</div></div>
        <div class="bonus-val">${x.service === null ? '<span class="muted">—</span>' : x.serviceBonus ? `<b class="pend-val">+${M(x.serviceBonus)}</b><div class="pend-note">ожидается · не в итоге</div>` : '<span class="muted">0 ₽</span>'}</div></div>
      <div class="bonus-row"><div><div>Штраф за ошибки (сервис)</div><div class="hint" style="margin:2px 0 0">за месяц, вносится вручную</div></div>
        <div class="bonus-val">${x.penalty ? `<b class="down">−${M(x.penalty)}</b>` : '<span class="muted">0 ₽</span>'}</div></div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}">${x.service === null && !x.penalty ? 'Указать сервис и штраф' : 'Изменить сервис и штраф'}</button></div>`;
  }
  function openManualSheet(idx) {
    const { y, m } = C.ymOf(idx);
    const s = C.monthSummary(state, m, todayKey(), y);
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">Итог за ${C.MONTHS[m].toLowerCase()} ${y}</div><div class="sheet-sub">Сколько фактически получили за месяц</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="manual-form" autocomplete="off" novalidate>
        <div class="calc"><div><div class="formula">по календарю ожидалось</div><div class="formula">смены${s.extras.penalty ? ' − штраф' : ''}</div></div><div class="res num">${M(s.calc)}</div></div>
        <div class="field"><label for="mt-sum">Заработано итого, ₽ <span>из расчётного листа</span></label>
          <input class="input big num" id="mt-sum" inputmode="decimal" placeholder="${Math.round(s.calc)}" value="${s.manual !== null ? String(s.manual).replace('.', ',') : ''}"></div>
        <div class="note" id="mt-diff"></div>
        <p class="hint" style="margin:-4px 0 14px">Эта сумма заменит расчётный итог месяца на главной и в статистике. Ожидаемые премии к ней не прибавляются — если их уже выплатили, они входят в эту сумму.</p>
        <p class="error" id="mt-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        ${s.manual !== null ? '<button class="btn btn-danger" type="button" data-clear>Убрать — считать по календарю</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const upd = () => {
      const raw = $('#mt-sum').value.trim(), n = Number(raw.replace(',', '.').replace(/\s/g, '')), el = $('#mt-diff');
      if (!raw || !Number.isFinite(n)) { el.className = 'note'; el.textContent = ''; return; }
      const d = C.round2(n - s.calc);
      el.className = 'note ' + (d > 0 ? 'good' : d < 0 ? 'bad' : '');
      el.textContent = d === 0 ? 'Совпадает с расчётом' : `На ${M(Math.abs(d))} ${d > 0 ? 'больше' : 'меньше'}, чем ожидалось`;
    };
    $('#manual-form').addEventListener('input', upd); upd();
    const done = (val) => {
      const r = C.setMonthData(state, m, { actualTotal: val }, y);
      if (!r.ok) { $('#mt-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast(val === '' ? 'Итог снова считается по календарю' : 'Итог сохранён'); }
    };
    sh.onclick = (e) => { if (e.target.closest('[data-close]')) closeModal(); else if (e.target.closest('[data-clear]')) done(''); };
    $('#manual-form').onsubmit = (e) => { e.preventDefault(); if (!$('#mt-sum').value.trim()) return done(''); done($('#mt-sum').value); };
    openModal(sh, $('#backdrop'));
    if (s.manual === null) setTimeout(() => $('#mt-sum') && $('#mt-sum').focus(), 320);
  }
  function openMonthSheet(idx) {
    const { y, m } = C.ymOf(idx);
    const sh = $('#sheet');
    const md = (state.months || {})[C.monthId(m, y)] || {};
    const b = { ...C.DEFAULT_BONUS, ...state.settings.bonus };
    const v = (x) => (x === null || x === undefined || x === 0 ? '' : String(x).replace('.', ','));
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${C.MONTHS[m]} ${y}</div><div class="sheet-sub">Сервис и штраф за ошибки за месяц</div></div><button class="icon-btn" data-close>×</button></div>
      <form id="month-form" autocomplete="off" novalidate>
        <div class="field"><label for="m-service">Сервис (качество без ошибок), % <span>из отчёта</span></label>
          <input class="input big num" id="m-service" inputmode="decimal" placeholder="99,95" value="${v(md.service)}"></div>
        <div class="note" id="m-zone"></div>
        <div class="field"><label for="m-penalty">Штраф за ошибки (сервис) за месяц, ₽ <span>0 — нет штрафа</span></label>
          <input class="input num" id="m-penalty" inputmode="decimal" placeholder="0" value="${v(md.penalty)}"></div>
        <p class="hint" style="margin:-4px 0 14px">Зоны: зелёная от ${N(b.greenThreshold, 2)}% (премия ${M(b.greenAmount)}), жёлтая от ${N(b.yellowThreshold, 2)}% (${M(b.yellowAmount)}), ниже — красная (${M(b.redAmount)}). Суммы меняются в настройках.</p>
        <p class="error" id="m-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const upd = () => {
      const raw = $('#m-service').value.trim(), n = Number(raw.replace(',', '.'));
      const el = $('#m-zone');
      if (!raw || !Number.isFinite(n)) { el.className = 'note'; el.textContent = ''; return; }
      const z = C.serviceZone(n, b);
      el.className = 'note';
      el.innerHTML = `<span class="zone ${ZONES[z][1]}">${ZONES[z][0]} зона</span> премия за сервис ${M(b[z + 'Amount'])}`;
    };
    $('#month-form').addEventListener('input', upd); upd();
    sh.onclick = (e) => { if (e.target.closest('[data-close]')) closeModal(); };
    $('#month-form').onsubmit = (e) => {
      e.preventDefault();
      const r = C.setMonthData(state, m, { service: $('#m-service').value, penalty: $('#m-penalty').value }, y);
      if (!r.ok) { $('#m-error').textContent = r.error; return; }
      if (save()) { closeModal(); renderAll(); toast('Сохранено'); }
    };
    openModal(sh, $('#backdrop'));
  }
  function rowHtml(d) {
    const e = state.entries[d.key], p = C.parseKey(d.key);
    return `<button class="list-row" data-act="open-day" data-key="${d.key}">
      <div class="date-badge num">${p.d}<small>${C.WEEKDAYS[C.weekdayMon(d.key)]}</small></div>
      <div class="grow"><div>${e.mood ? C.MOODS[e.mood - 1].icon + ' ' : ''}${N(e.lines)} линий${e.prod !== null && e.prod !== undefined ? ` · ${N(e.prod, 2)}%` : ''}${e.hours ? ` · ${N(e.hours, 2)} ч` : ''}</div><div>${e.start && e.end ? `${e.start}–${e.end} · ` : ''}${e.actual !== null ? `факт · расчёт ${M(C.estimated(e))}` : `${N(e.lines)} × ${M(e.rate)}`}${e.comment ? ' · ' + esc(e.comment) : ''}</div></div>
      <div class="amount num">${M(C.total(e))}</div></button>`;
  }
  const plural = (n, a, b, c) => { n = Math.abs(n) % 100; const n1 = n % 10; return n > 10 && n < 20 ? c : n1 > 1 && n1 < 5 ? b : n1 === 1 ? a : c; };

  // ---------- Календарь ----------
  function renderCal(anim) {
    const idx = ui.calMonth, { y, m } = C.ymOf(idx), today = todayKey();
    const s = C.summarize(state.entries, C.monthKeys(m, y));
    const ex = C.monthExtras(state, m, s, y);
    const payMap = {};
    const cloudOn = !!(window.Cloud && window.Cloud.ready && window.Cloud.sync && window.Cloud.sync.dayState && window.Cloud.account.user);
    C.payoutSchedule(state, m, y).forEach((p) => { const k = p.received && p.receivedOn && C.inYear(p.receivedOn, y) ? p.receivedOn : p.date; payMap[k] = (payMap[k] || '') + p.icon; });
    $('#view-cal').innerHTML = `
      ${monthSwitch(idx, 'cal')}
      <div class="cal" id="cal-swipe">
        <div class="cal-head">${C.WEEKDAYS.map((w) => `<div>${w}</div>`).join('')}</div>
        <div class="cal-grid ${anim ? 'anim-' + anim : ''}">
          ${C.calendarGrid(m, y).flat().map((k) => {
            if (!k) return '<div class="day empty"></div>';
            const info = C.dayStatus(state, k), e = state.entries[k];
            const cls = ['day', info.off ? 'off' : '', info.mark ? 'mark-' + info.mark : '', k === today ? 'today' : '', e ? 'has' : '', e && e.actual !== null ? 'actual' : '', e && e.weight ? 'kg' : ''].join(' ');
            const cs = e && cloudOn ? window.Cloud.sync.dayState(k, e) : null;
            return `<button class="${cls}" data-act="open-day" data-key="${k}" aria-label="${C.fmtDateLong(k)}, ${info.label}">
              <span class="num">${C.parseKey(k).d}</span>${payMap[k] ? `<span class="pay-badge">${payMap[k]}</span>` : ''}${cs ? `<i class="cs cs-${cs}"></i>` : ''}
              ${e ? `<span class="d-lines num">${e.lines ? N(e.lines) : '₽'}</span><span class="d-money num">${C.fmtMoneyShort(C.total(e))}</span>${e.weight ? `<span class="d-kg num">${e.weight < 1000 ? Math.round(e.weight) + 'кг' : N(e.weight / 1000, 1) + 'т'}</span>` : ''}` : info.mark ? `<span class="d-mark">${info.short}</span>` : ''}
            </button>`;
          }).join('')}
        </div>
        <div class="legend">
          <span><i style="background:var(--accent-soft);border:1px solid var(--accent)"></i>Смена внесена</span>
          <span><i style="background:var(--weekend)"></i>Выходной (сб, вс)</span>
          <span><i class="lg-sick"></i>Больничный</span>
          <span><i class="lg-vacation"></i>Отпуск</span>
          <span>💳 ✉️ 💰 Выплаты</span>
          ${cloudOn ? '<span class="lg-cloud">В облаке: <i class="cs cs-ok"></i>сохранено <i class="cs cs-pending"></i>отправляется <i class="cs cs-offline"></i>ждёт сети</span>' : ''}
        </div>
      </div>
      <div class="cal-summary">
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Итого</div><div class="t-value num">${C.fmtMoneyShort(s.total + ex.net)}&nbsp;₽</div></div>
      </div>
      <button class="btn btn-secondary" data-act="month-extras" data-m="${idx}" style="margin-top:12px">Сервис и штраф за ${C.MONTHS[m].toLowerCase()}${ex.penalty ? ` · −${M(ex.penalty)}` : ''}</button>
      <p class="hint" style="text-align:center">Рабочих дней в месяце: ${C.workdaysInMonth(m, y, state)}${(() => { const t = marksText(C.marksInMonth(state, m, y)); return t ? ` (с учётом отметок: ${t})` : ''; })()}. Выходной, больничный или отпуск можно отметить, нажав на день. Листайте календарь свайпом.</p>`;
    bindSwipe();
    updateChip();
  }
  function bindSwipe() {
    const el = $('#cal-swipe');
    let x0 = null, y0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dy) < 50) shiftCal(dx < 0 ? 1 : -1);
    }, { passive: true });
  }
  function shiftCal(d) {
    const i = ui.calMonth + d;
    if (i < 0 || i >= C.MONTH_COUNT) return;
    ui.calMonth = i; renderCal(d > 0 ? 'left' : 'right');
  }

  // ---------- Форма дня ----------
  // Производительность: 100% = 78,32 линии в час
  const PROD_100_LPH = 78.32;
  const lphToPct = (lph) => C.round2((lph / PROD_100_LPH) * 100);
  // ---------- Распознавание речи: браузер (Chrome, Safari) или Android (плагин Capacitor) ----------
  const Speech = {
    native() { const c = window.Capacitor; return c && c.isNativePlatform && c.isNativePlatform() && c.Plugins && c.Plugins.SpeechRecognition ? c.Plugins.SpeechRecognition : null; },
    web() { return window.SpeechRecognition || window.webkitSpeechRecognition || null; },
    supported() { return !!(this.native() || this.web()); },
    // → варианты фразы (самый вероятный первым)
    async listen() {
      const n = this.native();
      if (n) {
        const av = await n.available().catch(() => ({ available: false }));
        if (!av.available) throw new Error('На телефоне нет службы распознавания речи (нужно приложение Google)');
        const perm = await n.requestPermissions();
        if (perm && perm.speechRecognition && perm.speechRecognition !== 'granted') throw new Error('Разрешите приложению доступ к микрофону');
        const r = await n.start({ language: 'ru-RU', maxResults: 5, prompt: 'Например: 344 линии 153,32 производительность', partialResults: false, popup: true });
        return (r && r.matches) || [];
      }
      const R = this.web(); if (!R) throw new Error('Голосовой ввод в этом браузере недоступен');
      return new Promise((res, rej) => {
        const rec = new R(); rec.lang = 'ru-RU'; rec.interimResults = false; rec.maxAlternatives = 5; rec.continuous = false;
        let done = false;
        rec.onresult = (e) => { done = true; const alts = []; const r0 = e.results[0]; for (let i = 0; i < r0.length; i++) alts.push(r0[i].transcript); res(alts); };
        rec.onerror = (e) => { done = true; rej(new Error(e.error === 'not-allowed' || e.error === 'service-not-allowed' ? 'Разрешите доступ к микрофону' : e.error === 'no-speech' ? 'Ничего не расслышал — попробуйте ещё раз' : e.error === 'network' ? 'Для распознавания речи нужен интернет' : 'Не удалось распознать речь')); };
        rec.onend = () => { if (!done) res([]); };
        rec.start();
        setTimeout(() => { try { rec.stop(); } catch {} }, 12000);
      });
    },
  };

  function openDay(k) {
    if (!C.isValidKey(k) || !C.inYear(k)) return;
    const sh = $('#sheet');
    const already = modalStack.length && modalStack[modalStack.length - 1].el === sh;
    fillDaySheet(k);
    if (!already) {
      openModal(sh, $('#backdrop'));
      if (!state.entries[k]) setTimeout(() => { const i = $('#f-lines'); if (i) i.focus(); }, 320);
    }
  }
  function fillDaySheet(k) {
    const sh = $('#sheet');
    const e = state.entries[k];
    const info = C.dayStatus(state, k);
    const curRate = C.rateFor(state.settings.rateHistory, k);
    const rate = e ? e.rate : curRate;
    const v = (x) => (x === null || x === undefined ? '' : String(x).replace('.', ','));
    const prevK = C.addDays(k, -1), nextK = C.addDays(k, 1);
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head">
        <button class="icon-btn" data-day="${prevK}" ${C.inYear(prevK) ? '' : 'disabled style="opacity:.3"'} aria-label="Предыдущий день">‹</button>
        <div class="grow"><div class="sheet-title">${C.fmtDateLong(k)}</div>
          <div class="sheet-sub ${info.off ? 'holiday' : ''}">${C.WEEKDAYS_FULL[C.weekdayMon(k)]} · ${esc(info.label)}</div></div>
        <button class="icon-btn" data-day="${nextK}" ${C.inYear(nextK) ? '' : 'disabled style="opacity:.3"'} aria-label="Следующий день">›</button>
      </div>
      <div class="marks-row">${(info.weekend ? [['work', '💼 Рабочий день']] : [['off', '🛋 Выходной'], ['sick', '🤒 Больничный'], ['vacation', '🌴 Отпуск']])
        .map(([kd, t]) => `<button type="button" data-mark="${kd}" class="${info.mark === kd ? 'active' : ''}">${t}</button>`).join('')}</div>
      ${info.mark && info.off ? `<div class="mark-banner"><div><b>${esc(info.label)}</b><div class="hint" style="margin:2px 0 0">День не считается рабочим — смен в месяце меньше</div></div><button type="button" data-mark="">Снять</button></div>
        <p class="hint" style="margin:0 0 12px">Если смена всё-таки была — просто заполните её ниже, отметка снимется.</p>` : ''}
      ${info.mark === 'work' ? `<div class="mark-banner"><div><b>Рабочий выходной</b><div class="hint" style="margin:2px 0 0">День добавлен к рабочим дням месяца</div></div><button type="button" data-mark="">Снять</button></div>` : ''}
      <form id="day-form" autocomplete="off" novalidate>
        ${Speech.supported() ? `<button type="button" class="voice-btn" data-voice>${icon('mic')}<span><b>Сказать голосом</b><small>например: «344 линии 153,32 производительность»</small></span></button>` : ''}
        <div class="field"><label for="f-lines">Количество собранных линий</label>
          <input class="input big num" id="f-lines" inputmode="numeric" pattern="[0-9]*" placeholder="0" value="${e ? v(e.lines || '') : ''}">
          <div class="quick">${[10, 50, 100].map((n) => `<button type="button" data-add="${n}">+${n}</button>`).join('')}<button type="button" data-add="0">Сброс</button></div>
        </div>
        <div class="field"><div class="prod-head"><label for="f-prod">Производительность</label>
            <span class="prod-mode" role="group" aria-label="Ввод производительности"><button type="button" class="on" data-pm="pct">%</button><button type="button" data-pm="lph">лин/ч</button></span></div>
          <input class="input num" id="f-prod" inputmode="decimal" placeholder="Например, 124,5" value="${e ? v(e.prod) : ''}">
          <input class="input num" id="f-lph" inputmode="decimal" placeholder="Линий в час, например 95,8" hidden></div>
        <div class="note" id="f-prodnote"></div>
        <div class="calc"><div><div class="formula num" id="f-formula"></div><div class="formula">расчётный заработок</div></div><div class="res num" id="f-est"></div></div>
        ${e && e.rate !== curRate ? `<label class="check"><input type="checkbox" id="f-rerate"><span>Запись сохранена по тарифу <b>${M(e.rate)}</b>. Пересчитать по тарифу на эту дату — <b>${M(curRate)}</b>?</span></label>` : ''}
        <div class="field"><label for="f-actual">Фактически заработано, ₽ <span>необязательно</span></label>
          <input class="input num" id="f-actual" inputmode="decimal" placeholder="Например, по расчётному листу" value="${e ? v(e.actual) : ''}"></div>
        <div class="note" id="f-diff"></div>
        <div class="field"><label for="f-weight">Вес товара за смену, кг <span>необязательно</span></label>
          <input class="input num" id="f-weight" inputmode="decimal" placeholder="Например, 3 250" value="${e ? v(e.weight) : ''}"></div>
        <div class="field"><label>Время смены <span>ночная — на дату начала</span></label>
          <div class="time-row">
            <div><small>Начало</small><input class="input num" type="time" id="f-start" value="${e ? (e.start || '') : (state.settings.shiftStart || '21:00')}"></div>
            <div class="time-arrow">→</div>
            <div><small>Конец</small><input class="input num" type="time" id="f-end" value="${e ? (e.end || '') : ''}"></div>
          </div>
          <div class="quick">${['06:00', '07:00', '08:00'].map((t) => `<button type="button" data-end="${t}">до ${t.replace(/^0/, '')}</button>`).join('')}</div></div>
        <div class="field"><label for="f-hours">Отработано часов <span>считается по времени</span></label>
          <input class="input num" id="f-hours" inputmode="decimal" placeholder="Например, 10" value="${e ? v(e.hours) : ''}"></div>
        <div class="field"><label>Самочувствие за смену <span>необязательно</span></label>
          <div class="moods">${C.MOODS.map((md) => `<button type="button" data-mood="${md.v}" class="${e && e.mood === md.v ? 'active' : ''}"><span>${md.icon}</span><small>${md.label}</small></button>`).join('')}</div>
          <input type="hidden" id="f-mood" value="${e && e.mood ? e.mood : ''}"></div>
        <div class="note" id="f-perhour"></div>
        <div class="field"><label for="f-comment">Комментарий <span>необязательно</span></label>
          <textarea class="input" id="f-comment" maxlength="500" placeholder="Ночная смена, переработка…">${e ? esc(e.comment) : ''}</textarea></div>
        <p class="error" id="f-error"></p>
        <button class="btn btn-primary" type="submit">${e ? 'Сохранить изменения' : 'Сохранить смену'}</button>
        ${e ? '<button class="btn btn-danger" type="button" data-del>Удалить запись</button>' : ''}
        <button class="btn btn-secondary" type="button" data-close>Отмена</button>
      </form>`;
    const f = $('#day-form');
    const rateNow = () => ($('#f-rerate') && $('#f-rerate').checked ? curRate : rate);
    const parse = (s) => { const n = Number(String(s).replace(',', '.').replace(/\s/g, '')); return s.trim() === '' || !Number.isFinite(n) ? null : n; };
    const update = () => {
      const lines = parse($('#f-lines').value), actual = parse($('#f-actual').value), hours = parse($('#f-hours').value);
      const r = rateNow(), est = C.round2((lines || 0) * r);
      $('#f-formula').textContent = `${N(lines || 0)} × ${M(r)}`;
      $('#f-est').textContent = M(est);
      const diff = $('#f-diff');
      if (actual !== null && lines) {
        const d = C.round2(actual - est);
        diff.className = 'note ' + (d >= 0 ? 'good' : 'bad');
        diff.textContent = d === 0 ? 'Факт совпадает с расчётом' : `Факт ${d > 0 ? 'больше' : 'меньше'} расчёта на ${M(Math.abs(d))}. В итог пойдёт фактическая сумма.`;
      } else { diff.className = 'note'; diff.textContent = actual !== null ? 'В итог пойдёт фактическая сумма.' : ''; }
      const lphMode = !$('#f-lph').hidden, lph = parse($('#f-lph').value);
      const prod = lphMode ? (lph !== null ? lphToPct(lph) : null) : parse($('#f-prod').value), pn = $('#f-prodnote');
      const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
      if (prod !== null) { pn.className = 'note ' + (prod >= thr ? 'good' : 'bad'); pn.textContent = (lphMode ? `= ${N(prod, 2)}% · ` : '') + (prod >= thr ? `Не ниже ${N(thr, 0)}% — уровень премии` : `Ниже ${N(thr, 0)}% на ${N(thr - prod, 2)}%`); }
      else { pn.className = 'note'; pn.textContent = lphMode ? `100% = ${N(PROD_100_LPH, 2)} линии в час` : ''; }
      const total = actual !== null ? actual : est;
      $('#f-perhour').textContent = hours ? `≈ ${N((lines || 0) / hours, 1)} линий/час · ${M(C.round2(total / hours))}/час` : '';
    };
    // Часы считаются по времени начала и конца, пока вы не ввели их вручную
    let hoursTouched = !!(e && e.hours && !(e.start && e.end && C.shiftHours(e.start, e.end) === e.hours));
    const syncHours = () => {
      const h = C.shiftHours($('#f-start').value, $('#f-end').value);
      if (h !== null && !hoursTouched) $('#f-hours').value = String(h).replace('.', ',');
    };
    $('#f-hours').addEventListener('input', () => { hoursTouched = $('#f-hours').value.trim() !== ''; });
    $('#f-start').addEventListener('input', syncHours); $('#f-end').addEventListener('input', syncHours);
    f.addEventListener('input', update);
    f.addEventListener('change', update);
    update();
    sh.onclick = async (ev) => {
      const t = ev.target;
      if (t.closest('[data-close]')) return closeModal();
      const dayBtn = t.closest('[data-day]');
      if (dayBtn && !dayBtn.disabled) return fillDaySheet(dayBtn.dataset.day);
      const mb = t.closest('[data-mark]');
      if (mb) {
        const kind = mb.dataset.mark || null;
        const toggleOff = kind && info.mark === kind; // повторное нажатие снимает отметку
        const target = toggleOff ? null : kind;
        if (target && C.MARKS[target].off && state.entries[k]
          && !(await confirmDlg(`${C.MARKS[target].label}?`, `Смена за ${C.fmtDateLong(k)} будет удалена — в этот день вы не работали.`, 'Да, отметить', true))) return;
        C.setMark(state, k, target); save(); renderAll();
        toast(target ? `${C.fmtDateLong(k)}: ${C.MARKS[target].label.toLowerCase()}` : 'Отметка снята');
        if (target && C.MARKS[target].off) return closeModal();
        return fillDaySheet(k);
      }
      const endBtn = t.closest('[data-end]');
      if (endBtn) { $('#f-end').value = endBtn.dataset.end; syncHours(); update(); return; }
      if (t.closest('[data-voice]')) {
        const vb = t.closest('[data-voice]');
        try {
          vb.classList.add('on'); vb.querySelector('b').textContent = 'Слушаю…';
          const variants = await Speech.listen();
          // из вариантов распознавания берём первый, где нашлись числа
          let r = null, heard = variants[0] || '';
          for (const v of variants) { const x = Voice.parseShift(v); if (x.lines !== null || x.prod !== null || x.actual !== null) { r = x; heard = v; break; } }
          if (!r) { toast(heard ? `Не нашёл чисел в «${heard}»` : 'Ничего не расслышал — попробуйте ещё раз'); return; }
          const put = (id, v) => { if (v !== null && v !== undefined) $(id).value = String(v).replace('.', ','); };
          put('#f-lines', r.lines); put('#f-prod', r.prod); put('#f-actual', r.actual);
          if (r.hours !== null) { put('#f-hours', r.hours); hoursTouched = true; }
          if (r.comment) $('#f-comment').value = ($('#f-comment').value ? $('#f-comment').value + ' ' : '') + r.comment;
          update();
          const got = [r.lines !== null && `${N(r.lines)} ${plural(r.lines, 'линия', 'линии', 'линий')}`, r.prod !== null && `${N(r.prod, 2)}%`, r.actual !== null && M(r.actual), r.hours !== null && `${N(r.hours, 1)} ч`].filter(Boolean);
          toast(`Записал: ${got.join(', ')} — проверьте и сохраните`);
        } catch (ex) { toast(ex && ex.message ? ex.message : 'Голосовой ввод недоступен'); }
        finally { vb.classList.remove('on'); vb.querySelector('b').textContent = 'Сказать голосом'; }
        return;
      }
      const moodBtn = t.closest('[data-mood]');
      if (moodBtn) {
        const cur = $('#f-mood').value === moodBtn.dataset.mood;
        $('#f-mood').value = cur ? '' : moodBtn.dataset.mood;
        sh.querySelectorAll('[data-mood]').forEach((x) => x.classList.toggle('active', !cur && x === moodBtn));
        return;
      }
      const add = t.closest('[data-add]');
      if (add) {
        const inp = $('#f-lines'), n = +add.dataset.add;
        inp.value = n ? String((parseInt(inp.value, 10) || 0) + n) : '';
        update(); return;
      }
      if (t.closest('[data-del]')) {
        if (await confirmDlg('Удалить запись?', `Смена за ${C.fmtDateLong(k)} будет удалена.`, 'Удалить', true)) {
          C.deleteEntry(state, k); save(); closeModal(); renderAll(); toast('Запись удалена');
        }
      }
    };
    // Ввод производительности линиями в час: 100% = 78,32 лин/ч → пересчёт в % и обратно на «%»
    const setProdMode = (mode) => {
      const pct = mode === 'pct';
      if (pct && !$('#f-lph').hidden) {
        const l = parse($('#f-lph').value);
        if (l !== null && l > 0) { const r = lphToPct(l); $('#f-prod').value = String(r).replace('.', ','); toast(`${N(l, 2)} лин/ч = ${N(r, 2)}%`); }
      }
      if (!pct) { const p = parse($('#f-prod').value); $('#f-lph').value = p !== null ? String(C.round2(p * PROD_100_LPH / 100)).replace('.', ',') : ''; }
      $('#f-prod').hidden = !pct; $('#f-lph').hidden = pct;
      f.querySelectorAll('[data-pm]').forEach((b) => b.classList.toggle('on', b.dataset.pm === mode));
      (pct ? $('#f-prod') : $('#f-lph')).focus();
      update();
    };
    f.querySelectorAll('[data-pm]').forEach((b) => (b.onclick = () => setProdMode(b.dataset.pm)));
    $('#f-lph').addEventListener('change', () => { if (parse($('#f-lph').value) !== null) setProdMode('pct'); });
    f.onsubmit = (ev) => {
      ev.preventDefault();
      if (!$('#f-lph').hidden) setProdMode('pct');
      const res = C.saveEntry(state, k, { lines: $('#f-lines').value, actual: $('#f-actual').value, hours: $('#f-hours').value, prod: $('#f-prod').value,
          start: $('#f-start').value, end: $('#f-end').value, mood: $('#f-mood').value, comment: $('#f-comment').value, weight: String($('#f-weight').value).replace(/\s/g, '') },
        { useCurrentRate: !!($('#f-rerate') && $('#f-rerate').checked) });
      if (!res.ok) { $('#f-error').textContent = res.error; return; }
      if (save()) {
        closeModal(); renderAll();
        toast(`Сохранено: ${M(C.total(res.entry))}`);
        if (window.Pet) Pet.react(k);
      }
    };
  }

  // ---------- Графики (SVG без библиотек) ----------
  const W = 340, H = 170, PL = 34, PR = 6, PT = 10, PB = 22;
  function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
  function axes(max, fmtAxis) {
    let s = '';
    for (let i = 0; i <= 3; i++) {
      const y = PT + (H - PT - PB) * (1 - i / 3);
      s += `<line class="gridline" x1="${PL}" x2="${W - PR}" y1="${y}" y2="${y}"/><text x="${PL - 5}" y="${y + 3}" text-anchor="end">${fmtAxis((max * i) / 3)}</text>`;
    }
    return s;
  }
  function xLabels(labels, xs) {
    const step = Math.ceil(labels.filter(Boolean).length / 8);
    let c = 0;
    return labels.map((l, i) => (l && c++ % step === 0 ? `<text x="${xs(i)}" y="${H - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  }
  // Возвращает HTML карточки графика. items: [{label, tip, value}]
  let chartSeq = 0;
  function chartCard({ title, items, kind = 'bar', fmt = M, fmtAxis = C.fmtMoneyShort, avg = null, alt = false, summary }) {
    const id = 'ch' + ++chartSeq;
    const has = items.some((it) => it.value > 0);
    if (!has) return `<div class="card chart-card"><h2>${esc(title)}</h2><div class="empty-chart">Нет данных за выбранный период</div></div>`;
    const max = niceMax(Math.max(...items.map((i) => i.value), avg || 0));
    const iw = (W - PL - PR) / items.length;
    const xs = (i) => PL + iw * i + iw / 2;
    const ys = (v) => PT + (H - PT - PB) * (1 - v / max);
    let body = '';
    if (kind === 'bar') {
      const bw = Math.max(1.5, Math.min(26, iw * 0.68));
      body = items.map((it, i) => it.value > 0
        ? `<rect class="bar ${alt ? 'alt' : ''}" data-i="${i}" x="${xs(i) - bw / 2}" y="${ys(it.value)}" width="${bw}" height="${Math.max(0, H - PB - ys(it.value))}" rx="${Math.min(4, bw / 3)}" style="animation-delay:${Math.min(i * 12, 400)}ms"/>` : '').join('');
    } else {
      const pts = items.map((it, i) => [xs(i), ys(it.value)]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
      body = `<path class="area" d="${d}L${pts[pts.length - 1][0].toFixed(1)} ${H - PB}L${pts[0][0].toFixed(1)} ${H - PB}Z"/><path class="line" d="${d}"/>` +
        (items.length <= 40 ? items.map((it, i) => (it.value > 0 ? `<circle class="dot" data-i="${i}" cx="${xs(i)}" cy="${ys(it.value)}" r="3"/>` : '')).join('') : '');
    }
    const hits = items.map((_, i) => `<rect class="hit" data-i="${i}" x="${PL + iw * i}" y="${PT}" width="${iw}" height="${H - PT}"/>`).join('');
    const avgLine = avg ? `<line class="avg" x1="${PL}" x2="${W - PR}" y1="${ys(avg)}" y2="${ys(avg)}"/>` : '';
    chartData[id] = { items, fmt, summary };
    return `<div class="card chart-card"><h2>${esc(title)}</h2>
      <div class="readout" id="${id}-ro">${summary}</div>
      <svg class="chart" id="${id}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px">
        ${axes(max, fmtAxis)}${body}${avgLine}${xLabels(items.map((i) => i.label), xs)}${hits}</svg></div>`;
  }
  const chartData = {};
  document.addEventListener('click', (e) => {
    const hit = e.target.closest('svg.chart [data-i]');
    if (!hit) return;
    const svg = hit.closest('svg'), cd = chartData[svg.id], i = +hit.dataset.i, it = cd.items[i];
    svg.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel'));
    svg.querySelectorAll(`.bar[data-i="${i}"], .dot[data-i="${i}"]`).forEach((x) => x.classList.add('sel'));
    $('#' + svg.id + '-ro').innerHTML = `<b class="num">${cd.fmt(it.value)}</b><span>${esc(it.tip || it.label)}</span>`;
  });

  // ---------- Статистика ----------
  function periodKeys() {
    const st = ui.stats;
    if (st.mode === 'month') { const { y, m } = C.ymOf(st.month); return C.monthKeys(m, y); }
    if (st.mode === 'year') return C.yearKeys(st.year);
    return C.rangeKeys(st.from, st.to).filter((k) => C.inYear(k));
  }
  function periodTitle() {
    const st = ui.stats;
    if (st.mode === 'month') return monthName(st.month);
    if (st.mode === 'year') return `${st.year} год`;
    return `${C.fmtDateShort(st.from <= st.to ? st.from : st.to)} — ${C.fmtDateShort(st.from <= st.to ? st.to : st.from)}`;
  }
  function renderStats() {
    chartSeq = 0;
    const st = ui.stats, keys = periodKeys();
    const s = C.summarize(state.entries, keys);
    const wk = C.weekly(state.entries, keys);
    // Год для раздела «год целиком»: год выбранного месяца / выбранный год / год начала периода
    const statYear = st.mode === 'month' ? C.ymOf(st.month).y : st.mode === 'year' ? st.year : C.parseKey(st.from <= st.to ? st.from : st.to).y;
    const months = C.yearByMonths(state, statYear);
    const yearTotal = C.round2(months.reduce((a, x) => a + x.grand, 0));
    const yearPending = C.round2(months.reduce((a, x) => a + (x.manual !== null ? 0 : x.pending), 0));
    const manualMonths = months.filter((x) => x.manual !== null).length;
    const yearPenalty = C.round2(months.reduce((a, x) => a + x.extras.penalty, 0));
    const yearProd = (() => { const d = months.reduce((a, x) => a + x.prodDays, 0); return d ? months.reduce((a, x) => a + x.prodSum, 0) / d : null; })();
    // Премии и штраф — помесячные: учитываются в режимах «Месяц» и «Весь год»
    const curM = st.mode === 'month' ? months[C.ymOf(st.month).m] : null;
    const pex = curM ? { penalty: curM.extras.penalty, pending: curM.manual !== null ? 0 : curM.pending, manual: curM.manual, diff: curM.manualDiff, calc: curM.calc }
      : st.mode === 'year' ? { penalty: yearPenalty, pending: yearPending, manual: null } : null;
    const periodGrand = curM ? curM.grand : st.mode === 'year' ? yearTotal : s.total;
    const thr = (state.settings.bonus || C.DEFAULT_BONUS).prodThreshold;
    const yearLines = months.reduce((a, x) => a + x.lines, 0);
    const yearShifts = months.reduce((a, x) => a + x.shifts, 0);
    const daily = keys.length <= 62;
    const dayItems = keys.map((k) => { const e = state.entries[k]; return { label: daily ? String(C.parseKey(k).d) : C.MONTHS_SHORT[C.parseKey(k).m], tip: `${C.fmtDateLong(k)}, ${C.WEEKDAYS_FULL[C.weekdayMon(k)].toLowerCase()}`, value: e ? C.total(e) : 0, lines: e ? e.lines : 0 }; });
    if (!daily) dayItems.forEach((it, i) => { if (C.parseKey(keys[i]).d !== 1) it.label = ''; });
    const opt = (v, cur, t) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${t}</option>`;
    const maxMonth = months.reduce((b, x, i) => (x.grand > months[b].grand ? i : b), 0);
    const prodItems = keys.filter((k) => state.entries[k] && state.entries[k].prod !== null && state.entries[k].prod !== undefined)
      .map((k) => ({ label: daily ? String(C.parseKey(k).d) : C.fmtDateShort(k), tip: C.fmtDateLong(k), value: state.entries[k].prod }));

    $('#view-stats').innerHTML = statsSubnav('stats') + `
      <div class="seg" role="tablist">
        ${[['month', 'Месяц'], ['year', 'Весь год'], ['range', 'Период']].map(([v, t]) => `<button data-mode="${v}" class="${st.mode === v ? 'active' : ''}">${t}</button>`).join('')}
      </div>
      ${st.mode === 'month' ? `<div class="field"><select class="input" id="st-month">${C.YEARS.map((y) => `<optgroup label="${y}">${C.MONTHS.map((n, m) => opt(C.indexOf(y, m), st.month, `${n} ${y}`)).join('')}</optgroup>`).join('')}</select></div>` : ''}
      ${st.mode === 'year' ? `<div class="seg">${C.YEARS.map((y) => `<button data-year="${y}" class="${y === st.year ? 'active' : ''}">${y}</button>`).join('')}</div>` : ''}
      ${st.mode === 'range' ? `<div class="period-inputs">
          <div><label for="st-from">С</label><input class="input" type="date" id="st-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.from}"></div>
          <div><label for="st-to">По</label><input class="input" type="date" id="st-to" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${st.to}"></div></div>` : ''}

      <div class="card"><h2>${esc(periodTitle())}</h2>
        <div class="year-total num">${M(periodGrand)}</div>
        ${pex && pex.manual !== null ? `<p class="hint" style="margin-top:2px">Фактически получено (введено вручную) · по календарю ${M(pex.calc)} · <b class="${pex.diff >= 0 ? 'up' : 'down'}">${pex.diff >= 0 ? '+' : '−'}${M(Math.abs(pex.diff))}</b></p>`
          : pex && pex.penalty ? `<p class="hint" style="margin-top:2px">Смены ${M(s.total)} − штраф ${M(pex.penalty)}</p>` : ''}
        ${st.mode === 'year' && manualMonths ? `<p class="hint" style="margin-top:2px">В ${manualMonths} ${plural(manualMonths, 'месяце', 'месяцах', 'месяцах')} учтена фактическая сумма, введённая вручную</p>` : ''}
        ${pex && pex.pending ? `<div class="pending ok card-pending"><div class="pending-top"><span class="pending-tag">⏳ Премии — ожидаются</span><b class="num">+${M(pex.pending)}</b></div><div class="pending-sub">за производительность и сервис · не входят в итог</div></div>` : ''}
        ${st.mode === 'range' ? '<p class="hint" style="margin-top:2px">За произвольный период — только смены. Премии и штраф помесячные, смотрите их в режимах «Месяц» и «Весь год».</p>' : ''}
        <p class="hint" style="margin-top:2px">Расчёт ${M(s.estimated)}${s.actualCount ? ` · факт ${M(s.actual)} (${s.actualCount} ${plural(s.actualCount, 'смена', 'смены', 'смен')})` : ''}${s.diffCount ? ` · разница факт−расчёт ${s.diff >= 0 ? '+' : '−'}${M(Math.abs(s.diff))}` : ''}</p>
      </div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Смен</div><div class="t-value num">${s.shifts}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за смену</div><div class="t-value num">${s.shifts ? M(s.avgPerShift) : '—'}</div></div>
        <div class="tile"><div class="t-label">Средний заработок за неделю</div><div class="t-value num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</div><div class="t-sub">${wk.workedWeeks ? `по ${wk.workedWeeks} ${plural(wk.workedWeeks, 'неделе', 'неделям', 'неделям')} со сменами` : ''}</div></div>
        <div class="tile"><div class="t-label">Средняя производительность</div><div class="t-value num ${s.prodAvg === null ? '' : s.prodAvg >= thr ? 'up' : 'down'}">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</div><div class="t-sub">${s.prodDays ? `по ${s.prodDays} ${plural(s.prodDays, 'смене', 'сменам', 'сменам')}` : 'не указана'}</div></div>
        <div class="tile"><div class="t-label">Линий за смену</div><div class="t-value num">${s.shifts ? N(s.avgLines, 1) : '—'}</div></div>
        <div class="tile"><div class="t-label">Лучший день</div><div class="t-value num">${s.best ? C.fmtDateShort(s.best.key) : '—'}</div><div class="t-sub num">${s.best ? `${N(s.best.lines)} линий` : ''}</div></div>
        ${s.weightDays ? (() => {
          const like = C.weightLike(s.weight);
          const pw = curM ? (() => { const { y: py, m: pm } = C.ymOf(st.month - 1); return st.month > 0 ? C.summarize(state.entries, C.monthKeys(pm, py)).weight : 0; })() : 0;
          const ch = pw ? (s.weight - pw) / pw : null;
          return `<div class="tile wide"><div class="t-label">⚖️ Собрано товара</div><div class="t-value num">${fmtKg(s.weight)}</div>${ch !== null ? `<div class="t-sub num ${ch >= 0 ? 'up' : 'down'}">${ch >= 0 ? '▲ +' : '▼ '}${N(ch * 100, 0)}% к прошлому месяцу</div>` : ''}
            <div class="t-sub num">в среднем ${fmtKg(s.avgWeight)} за смену · по ${s.weightDays} ${plural(s.weightDays, 'смене', 'сменам', 'сменам')}${s.weightLines ? ` · ≈${N(s.weight / s.weightLines, 1)} кг на линию` : ''}</div>
            ${like ? `<div class="t-sub">Это как ${N(like.n, like.n < 10 ? 1 : 0)} ${like.word} 😮</div>` : ''}</div>`; })() : ''}
        ${s.hours ? `<div class="tile wide"><div class="t-label">Выработка в час (по сменам с указанными часами)</div><div class="t-value num">${N(s.linesPerHour, 1)} линий/ч · ${M(s.earnPerHour)}/ч</div><div class="t-sub num">${N(s.hours, 1)} ч всего</div></div>` : ''}
      </div>

      ${chartCard({ title: 'Ежедневный заработок', items: dayItems, kind: daily ? 'bar' : 'line', avg: s.shifts ? s.avgPerShift : null,
        summary: `<b class="num">${M(s.total)}</b><span>${daily ? 'пунктир — среднее за смену · нажмите на столбец' : 'нажмите на график'}</span>` })}
      ${chartCard({ title: 'Собранные линии по дням', items: dayItems.map((d) => ({ ...d, value: d.lines })), kind: 'line', fmt: (v) => N(v) + ' линий', fmtAxis: (v) => N(v),
        summary: `<b class="num">${N(s.lines)}</b><span>линий за период</span>` })}
      ${s.weightDays ? chartCard({ title: 'Вес товара по дням', items: keys.map((k, i) => ({ ...dayItems[i], value: (state.entries[k] && state.entries[k].weight) || 0 })), kind: daily ? 'bar' : 'line', fmt: (v) => fmtKg(v), fmtAxis: (v) => (v >= 1000 ? N(v / 1000, 1) + ' т' : N(v)), alt: true, avg: s.avgWeight || null,
        summary: `<b class="num">${fmtKg(s.weight)}</b><span>за период · пунктир — в среднем за смену</span>` }) : ''}
      ${chartCard({ title: 'Производительность по дням', items: prodItems, kind: prodItems.length > 40 ? 'line' : 'bar', fmt: (v) => N(v, 2) + '%', fmtAxis: (v) => N(v) + '%', avg: thr, alt: true,
        summary: `<b class="num">${s.prodAvg === null ? '—' : N(s.prodAvg, 2) + '%'}</b><span>средняя · пунктир — ${N(thr, 0)}% для премии</span>` })}
      ${wk.weeks.length > 1 ? chartCard({ title: 'Заработок по неделям', items: wk.weeks.map((w) => ({ label: C.fmtDateShort(w.monday).split(' ')[0], tip: `Неделя ${C.fmtDateShort(w.monday)} — ${C.fmtDateShort(w.sunday)}, ${w.shifts} ${plural(w.shifts, 'смена', 'смены', 'смен')}`, value: w.total })),
        avg: wk.avgWeekly || null, alt: true, summary: `<b class="num">${wk.workedWeeks ? M(wk.avgWeekly) : '—'}</b><span>в среднем за неделю</span>` }) : ''}

      <h2 style="margin:22px 4px 10px;font-size:20px">${statYear} год целиком</h2>
      <div class="card"><div class="muted" style="font-size:14px">Общая сумма заработка за ${statYear} год</div>
        <div class="year-total num">${M(yearTotal)}</div>
        ${yearPenalty ? `<p class="hint" style="margin-top:2px">с учётом штрафов −${M(yearPenalty)}</p>` : ''}
        ${yearPending ? `<div class="pending ok card-pending"><div class="pending-top"><span class="pending-tag">⏳ Премии — отдельно</span><b class="num">+${M(yearPending)}</b></div><div class="pending-sub">за производительность и сервис за год · не входят в итог</div></div>` : ''}
        <p class="hint" style="margin-top:2px">${N(yearLines)} линий · ${yearShifts} ${plural(yearShifts, 'смена', 'смены', 'смен')}${yearProd !== null ? ` · средняя производительность ${N(yearProd, 2)}%` : ''}</p></div>
      ${chartCard({ title: 'Заработок по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.grand })),
        summary: yearShifts ? `<b class="num">${M(months[maxMonth].grand)}</b><span>лучший месяц — ${C.MONTHS[maxMonth].toLowerCase()}</span>` : '' })}
      ${chartCard({ title: 'Линии по месяцам', items: months.map((x, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: x.lines })), alt: true, fmt: (v) => N(v) + ' линий', fmtAxis: (v) => C.fmtMoneyShort(v),
        summary: `<b class="num">${N(yearLines)}</b><span>линий за год</span>` })}
      ${(() => { const wm = months.map((x, i) => C.summarize(state.entries, C.monthKeys(i, statYear)).weight), tot = wm.reduce((a, v) => a + v, 0);
        return tot ? chartCard({ title: 'Вес товара по месяцам', items: wm.map((v, i) => ({ label: C.MONTHS_SHORT[i], tip: C.MONTHS[i], value: v })), fmt: (v) => fmtKg(v), fmtAxis: (v) => (v >= 1000 ? N(v / 1000, 0) + ' т' : N(v)),
          summary: `<b class="num">${fmtKg(tot)}</b><span>за ${statYear} год</span>` }) : ''; })()}
      <div class="card"><h2>Сравнение месяцев</h2>
        <table class="table num"><thead><tr><th>Месяц</th><th>Смен</th><th>Произв.</th><th>Итого</th><th>к пред.</th></tr></thead><tbody>
        ${months.map((x, i) => `<tr class="${x.shifts ? '' : 'zero'}"><td>${C.MONTHS[i]}</td><td>${x.shifts || '—'}</td><td class="${x.prodAvg === null ? '' : x.extras.prodOk ? 'up' : 'down'}">${x.prodAvg === null ? '—' : N(x.prodAvg, 1) + '%'}</td><td>${x.shifts || x.grand ? M(x.grand) : '—'}${x.manual !== null ? ' ✎' : ''}${x.pending && x.manual === null ? `<br><small class="pend-inline">+${C.fmtMoneyShort(x.pending)} ожид.</small>` : ''}</td>
          <td class="${x.change > 0 ? 'up' : x.change < 0 ? 'down' : ''}">${x.change === null || !x.shifts ? '—' : (x.change > 0 ? '+' : '') + N(x.change * 100, 0) + '%'}</td></tr>`).join('')}
        </tbody><tfoot><tr><td>Итого</td><td>${yearShifts}</td><td>${yearProd === null ? '—' : N(yearProd, 1) + '%'}</td><td>${M(yearTotal)}</td><td></td></tr></tfoot></table><p class="hint">«Итого» — смены − штраф, или фактическая сумма, если вы её ввели (✎). Премии показаны отдельно («ожид.»).</p></div>`;

    $('#view-stats').onclick = (e) => {
      const b = e.target.closest('[data-mode]'); if (b) { st.mode = b.dataset.mode; return renderStats(); }
      const yb = e.target.closest('[data-year]'); if (yb) { st.year = +yb.dataset.year; renderStats(); }
    };
    const sm = $('#st-month'); if (sm) sm.onchange = () => { st.month = +sm.value; renderStats(); };
    const f = $('#st-from'), t = $('#st-to');
    if (f) {
      const upd = () => { if (C.isValidKey(f.value) && C.isValidKey(t.value)) { st.from = f.value; st.to = t.value; renderStats(); } };
      f.onchange = upd; t.onchange = upd;
    }
    updateChip();
  }

  // ---------- Итоги месяца: истории на весь экран ----------
  const W_DUR = 6500;
  function wrappedSlides(w) {
    const S = [];
    const monthGen = C.MONTHS_GEN[w.m];
    const prevName = w.prev ? C.MONTHS[C.MONTHS.indexOf(w.prev.name)] : '';
    const days = w.hours ? C.round2(w.hours / 24) : 0;
    S.push({ bg: 'g-intro', dur: 4200, html: `
      <div class="w-shapes"><i></i><i></i><i></i><i></i></div>
      <div class="w-kicker a1">Итоги месяца</div>
      <div class="w-huge a2">${w.name}</div>
      <div class="w-year a3">${w.y}</div>
      <div class="w-sub a4">Смотрим, как он прошёл 🌙</div>` });
    S.push({ bg: 'g-night', html: `
      <div class="w-kicker a1">В ${w.name === 'Май' ? 'мае' : monthPrep(w.m)} ты вышел на смену</div>
      <div class="w-num a2"><span data-count="${w.shifts}">0</span></div>
      <div class="w-unit a2">${plural(w.shifts, 'раз', 'раза', 'раз')}</div>
      ${w.hours ? `<div class="w-line a3">Это <b><span data-count="${w.hours}" data-fmt="num1">0</span> ${plural(Math.round(w.hours), 'час', 'часа', 'часов')}</b> на складе</div>
        <div class="w-line a4">≈ ${N(days, 1)} ${plural(Math.round(days), 'сутки', 'суток', 'суток')} без перерыва 🌙</div>` : ''}
      ${w.marks.sick || w.marks.vacation ? `<div class="w-line a5 w-dim">${w.marks.sick ? `больничный: ${w.marks.sick} дн.` : ''}${w.marks.sick && w.marks.vacation ? ' · ' : ''}${w.marks.vacation ? `отпуск: ${w.marks.vacation} дн.` : ''}</div>` : ''}` });
    S.push({ bg: 'g-lines', html: `
      <div class="w-boxes"><i>📦</i><i>📦</i><i>📦</i><i>📦</i><i>📦</i><i>📦</i></div>
      <div class="w-kicker a1">Ты собрал</div>
      <div class="w-num a2"><span data-count="${w.lines}">0</span></div>
      <div class="w-unit a2">${plural(w.lines, 'линию', 'линии', 'линий')}</div>
      <div class="w-line a3">в среднем <b>${N(w.avgLines, 0)}</b> за смену</div>
      ${w.prev && w.prev.lines ? `<div class="w-chip a4">${w.lines >= w.prev.lines ? '▲' : '▼'} ${N(Math.abs(w.lines - w.prev.lines))} к ${monthDat(prevName)}</div>` : ''}` });
    if (w.weight) {
      const like = C.weightLike(w.weight), hv = w.heavy;
      S.push({ bg: 'g-lines', html: `
      <div class="w-boxes"><i>⚖️</i><i>📦</i><i>🏋️</i><i>📦</i><i>⚖️</i><i>📦</i></div>
      <div class="w-kicker a1">Через твои руки прошло</div>
      <div class="w-num a2">${w.weight >= 1000 ? `<span data-count="${C.round2(w.weight / 1000)}" data-fmt="num1">0</span>` : `<span data-count="${Math.round(w.weight)}">0</span>`}</div>
      <div class="w-unit a2">${w.weight >= 1000 ? 'тонн товара' : 'кг товара'}</div>
      ${like ? `<div class="w-line a3">Это как <b>${N(like.n, like.n < 10 ? 1 : 0)} ${like.word}</b> 😮</div>` : ''}
      ${hv ? `<div class="w-line a4">самая тяжёлая смена — ${C.parseKey(hv.key).d} ${C.MONTHS_GEN[C.parseKey(hv.key).m]}: <b>${fmtKg(hv.kg)}</b></div>` : ''}
      ${w.prev && w.prev.weight ? `<div class="w-chip ${w.weight >= w.prev.weight ? 'up' : 'down'} a5">${w.weight >= w.prev.weight ? '▲' : '▼'} ${fmtKg(Math.abs(w.weight - w.prev.weight))} к ${monthDat(prevName)}</div>` : ''}` });
    }
    S.push({ bg: 'g-money', html: `
      <div class="w-coins"><i>💰</i><i>💵</i><i>🪙</i><i>💵</i><i>💰</i></div>
      <div class="w-kicker a1">${w.manual !== null ? 'Ты получил' : 'Ты заработал'}</div>
      <div class="w-num w-money a2"><span data-count="${Math.round(w.earned)}" data-fmt="money">0</span></div>
      <div class="w-line a3">${N(w.perShift, 0)} ₽ за смену в среднем</div>
      ${w.prev && w.prev.change !== null ? `<div class="w-chip ${w.prev.change >= 0 ? 'up' : 'down'} a4">${w.prev.change >= 0 ? '▲ +' : '▼ '}${N(w.prev.change * 100, 0)}% к ${monthDat(prevName)}</div>` : ''}
      ${w.pending ? `<div class="w-line a5">+ <b>${M(w.pending)}</b> премий ожидается ⏳</div>` : ''}` });
    const tp = w.top, tpd = C.parseKey(tp.key);
    S.push({ bg: 'g-star', html: `
      <div class="w-kicker a1">Твоя лучшая смена</div>
      <div class="w-date a2"><b>${tpd.d}</b><span>${C.MONTHS_GEN[tpd.m]}</span></div>
      <div class="w-line a3">${C.WEEKDAYS_FULL[C.weekdayMon(tp.key)].toLowerCase()}</div>
      <div class="w-stats a4">
        <div><b data-count="${tp.lines}">0</b><small>линий</small></div>
        ${tp.prod !== null ? `<div><b>${N(tp.prod, 1)}%</b><small>производит.</small></div>` : ''}
        <div><b>${C.fmtMoneyShort(tp.total)}</b><small>рублей</small></div>
        ${tp.mood ? `<div><b>${C.MOODS[tp.mood - 1].icon}</b><small>${C.MOODS[tp.mood - 1].label.toLowerCase()}</small></div>` : ''}
      </div>` });
    if (w.prodAvg !== null) {
      const pct = Math.min(1, w.prodAvg / (w.prodThreshold * 1.25)), R = 88, L = 2 * Math.PI * R;
      S.push({ bg: w.prodOk ? 'g-win' : 'g-try', html: `
        <div class="w-kicker a1">Средняя производительность</div>
        <div class="w-ring a2"><svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="${R}" class="rg-bg"/><circle cx="100" cy="100" r="${R}" class="rg-fg" style="--L:${L.toFixed(1)};--off:${(L * (1 - pct)).toFixed(1)}"/>
          <line x1="100" y1="4" x2="100" y2="22" class="rg-mark" transform="rotate(${(360 / 1.25).toFixed(1)} 100 100)"/></svg>
          <div class="w-ring-val"><span data-count="${w.prodAvg}" data-fmt="pct">0</span></div></div>
        <div class="w-line a3">${w.prodOk ? `Премия <b>${M(w.prodBonus)}</b> — твоя! 🎉` : `До ${N(w.prodThreshold, 0)}% не хватило <b>${N(w.prodThreshold - w.prodAvg, 1)}%</b>`}</div>
        ${w.prodOk ? '<div class="w-confetti">' + '<i></i>'.repeat(24) + '</div>' : '<div class="w-line a4 w-dim">В следующем месяце получится 💪</div>'}` });
    }
    if (w.service !== null) S.push({ bg: 'g-' + w.zone, html: `
      <div class="w-kicker a1">Работа без ошибок</div>
      <div class="w-zone a2"><span>${N(w.service, 2)}%</span></div>
      <div class="w-unit a3">${w.zone === 'green' ? 'зелёная зона ✅' : w.zone === 'yellow' ? 'жёлтая зона' : 'красная зона'}</div>
      ${w.serviceBonus ? `<div class="w-line a4">премия за сервис <b>${M(w.serviceBonus)}</b></div>` : ''}
      ${w.penalty ? `<div class="w-line a5 w-dim">штраф за ошибки ${M(w.penalty)}</div>` : '<div class="w-line a5">без штрафов ✨</div>'}` });
    if (w.bestRun >= 2) S.push({ bg: 'g-fire', html: `
      <div class="w-fire a1">🔥</div>
      <div class="w-kicker a2">Лучшая серия</div>
      <div class="w-num a3"><span data-count="${w.bestRun}">0</span></div>
      <div class="w-unit a3">${plural(w.bestRun, 'смена', 'смены', 'смен')} подряд</div>
      <div class="w-line a4">с производительностью от ${N(w.prodThreshold, 0)}%</div>` });
    if (w.mood) S.push({ bg: 'g-mood', html: `
      <div class="w-rain">${Array.from({ length: 16 }, () => `<i>${w.mood.icon}</i>`).join('')}</div>
      <div class="w-kicker a1">Чаще всего после смены было</div>
      <div class="w-emoji a2">${w.mood.icon}</div>
      <div class="w-unit a3">${w.mood.label}</div>
      <div class="w-line a4">${w.mood.count} из ${w.mood.total} ${plural(w.mood.total, 'смены', 'смен', 'смен')}</div>` });
    if (w.bestWeekday) S.push({ bg: 'g-week', html: `
      <div class="w-kicker a1">Самая прибыльная ночь</div>
      <div class="w-huge w-mid a2">${w.bestWeekday.name}</div>
      <div class="w-line a3">в среднем <b>${M(w.bestWeekday.avg)}</b> за смену</div>
      ${w.bestWeekday.vs ? `<div class="w-chip up a4">+${N(w.bestWeekday.vs * 100, 0)}% к обычной смене</div>` : ''}` });
    if (w.monthsInYear >= 2) S.push({ bg: 'g-rank', html: `
      <div class="w-fire a1">${w.rankInYear === 1 ? '🏆' : w.rankInYear <= 3 ? '🥈' : '📈'}</div>
      <div class="w-kicker a2">${w.rankInYear === 1 ? 'Лучший месяц года!' : 'Место в году'}</div>
      <div class="w-num a3">#${w.rankInYear}</div>
      <div class="w-line a4">из ${w.monthsInYear} ${plural(w.monthsInYear, 'месяца', 'месяцев', 'месяцев')} ${w.y} года по заработку</div>` });
    S.push({ bg: 'g-outro', dur: 15000, html: `
      <div class="w-kicker a1">${w.name} ${w.y} · итоги</div>
      <div class="w-card a2">
        <div class="wc-big"><small>${w.manual !== null ? 'Получено' : 'Заработано'}</small><b>${M(w.earned)}</b></div>
        <div class="wc-grid">
          <div><b>${w.shifts}</b><small>смен</small></div>
          <div><b>${N(w.lines)}</b><small>линий</small></div>
          <div><b>${w.prodAvg !== null ? N(w.prodAvg, 1) + '%' : '—'}</b><small>производит.</small></div>
          <div><b>${w.hours ? N(w.hours, 0) : '—'}</b><small>часов</small></div>
          <div><b>${w.bestRun || '—'}</b><small>серия</small></div>
          <div><b>${w.mood ? w.mood.icon : '—'}</b><small>настроение</small></div>
        </div>
        ${w.pending ? `<div class="wc-pend">+ ${M(w.pending)} премий ожидается</div>` : ''}
      </div>
      <div class="w-btns a3"><button data-w="replay">↻ Ещё раз</button><button data-w="close">Готово</button></div>` });
    return S;
  }
  const monthPrep = (m) => ['январе', 'феврале', 'марте', 'апреле', 'мае', 'июне', 'июле', 'августе', 'сентябре', 'октябре', 'ноябре', 'декабре'][m];
  const monthDat = (name) => { const i = C.MONTHS.indexOf(name); return ['январю', 'февралю', 'марту', 'апрелю', 'маю', 'июню', 'июлю', 'августу', 'сентябрю', 'октябрю', 'ноябрю', 'декабрю'][i] || ''; };

  function openWrapped(y, m) {
    const w = C.monthWrapped(state, m, y);
    if (!w) return toast('За этот месяц ещё нет смен');
    const slides = wrappedSlides(w);
    const el = $('#wrapped');
    el.innerHTML = `<div class="w-bars">${slides.map(() => '<div><i></i></div>').join('')}</div>
      <button class="w-close" data-w="close" aria-label="Закрыть">×</button>
      <div class="w-stage"></div><div class="w-tap left"></div><div class="w-tap right"></div>`;
    const stage = $('.w-stage', el), bars = el.querySelectorAll('.w-bars > div');
    let i = 0, timer = null, started = 0, remain = 0, paused = false;
    const fmt = (v, f) => (f === 'money' ? M(Math.round(v)) : f === 'pct' ? N(v, 1) + '%' : f === 'num1' ? N(v, 1) : N(Math.round(v)));
    const countUp = () => stage.querySelectorAll('[data-count]').forEach((c) => {
      const to = Number(c.dataset.count), f = c.dataset.fmt, t0 = performance.now(), d = 1400, delay = 350;
      const step = (t) => { const p = Math.min(1, Math.max(0, (t - t0 - delay) / d)), e = 1 - Math.pow(1 - p, 4); c.textContent = fmt(p < 1 ? to * e : to, f); if (p < 1 && el.classList.contains('show')) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
    const show = (n) => {
      i = Math.max(0, Math.min(slides.length - 1, n));
      const sl = slides[i], dur = sl.dur || W_DUR;
      el.className = 'wrapped show ' + sl.bg;
      stage.innerHTML = `<div class="w-slide">${sl.html}</div>`;
      bars.forEach((b, j) => { b.className = j < i ? 'done' : j === i ? 'run' : ''; b.firstChild.style.animationDuration = dur + 'ms'; b.firstChild.style.animationPlayState = 'running'; });
      countUp();
      clearTimeout(timer); remain = dur; started = Date.now(); paused = false;
      timer = setTimeout(next, dur);
    };
    const next = () => (i < slides.length - 1 ? show(i + 1) : null);
    const prev = () => show(i - 1);
    const pause = () => { if (paused) return; paused = true; clearTimeout(timer); remain -= Date.now() - started; bars[i].firstChild.style.animationPlayState = 'paused'; };
    const resume = () => { if (!paused) return; paused = false; started = Date.now(); bars[i].firstChild.style.animationPlayState = 'running'; timer = setTimeout(next, Math.max(300, remain)); };
    let downAt = 0, y0 = null;
    el.onpointerdown = (e) => { if (e.target.closest('button')) return; downAt = Date.now(); y0 = e.clientY; pause(); };
    el.onpointerup = (e) => {
      if (e.target.closest('button')) return;
      const held = Date.now() - downAt > 350, dy = y0 !== null ? e.clientY - y0 : 0; y0 = null;
      if (dy > 90) return closeModal();                 // свайп вниз — закрыть
      if (held) return resume();                         // удержание — пауза, отпустили — дальше
      if (e.target.closest('.w-tap.left')) prev(); else next();
    };
    el.onpointercancel = () => resume();
    el.onclick = (e) => {
      const b = e.target.closest('[data-w]');
      if (!b) return;
      if (b.dataset.w === 'close') closeModal(); else if (b.dataset.w === 'replay') show(0);
    };
    openModal(el, $('#w-backdrop'));
    modalStack[modalStack.length - 1].onClose = () => { clearTimeout(timer); el.className = 'wrapped'; setTimeout(() => { if (!el.classList.contains('show')) el.innerHTML = ''; }, 400); };
    show(0);
  }

  // ---------- Успехи: рекорды, серии, рейтинг, дни недели, накопления, достижения ----------
  function renderSuccess() {
    chartSeq = 0;
    const sc = ui.success, { y, m } = C.ymOf(ui.homeMonth), today = todayKey();
    const keys = sc.scope === 'month' ? C.monthKeys(m, y) : sc.scope === 'year' ? C.yearKeys(y) : null;
    const scopeName = sc.scope === 'month' ? `${C.MONTHS[m]} ${y}` : sc.scope === 'year' ? `${y} год` : 'всё время';
    const b = { ...C.DEFAULT_BONUS, ...state.settings.bonus };
    const rec = C.records(state), stk = C.streaks(state, b.prodThreshold);
    const rank = C.rankShifts(state, keys);
    const last = C.rankShifts(state).map((x) => x.key).sort().pop();
    const lastPlace = last ? rank.find((x) => x.key === last) : null;
    const wd = C.weekdayStats(state, keys);
    const wb = C.wellbeingStats(state, keys);
    const moodIcon = (v) => (v === null ? '—' : C.MOODS[Math.min(4, Math.max(0, Math.round(v) - 1))].icon);
    const idxWorked = wb.byIdx.filter((r) => r.shifts);
    const fatigue = wb.byIdx[0].avgProd !== null && idxWorked.length > 2 ? (() => { const lastR = [...wb.byIdx].reverse().find((r) => r.avgProd !== null); return lastR && lastR.n > 1 ? { first: wb.byIdx[0].avgProd, last: lastR.avgProd, n: lastR.n } : null; })() : null;
    const ach = achs(), achDone = ach.filter((a) => a.done).length;
    const sv = state.settings.savings || { goal: 100000, saved: 0, percent: 100 };
    const plan = C.savingsPlan(state, sv, today);
    const medal = (i) => ['🥇', '🥈', '🥉'][i] || `<span class="place">${i + 1}</span>`;
    const recTile = (label, val, sub, key) => `<button class="tile ${key ? 'clickable' : ''}" ${key ? `data-act="open-day" data-key="${key}"` : 'disabled'} style="text-align:left"><div class="t-label">${label}</div><div class="t-value num">${val}</div><div class="t-sub num">${sub}</div></button>`;

    const wm = C.wrappedMonths(state).reverse();
    $('#view-success').innerHTML = statsSubnav('success') + `
      ${wm.length ? `<div class="wrap-entry">
        <div class="we-head"><div><div class="we-title">🎬 Итоги месяца</div><div class="we-sub">Истории о вашем месяце — нажмите, чтобы посмотреть</div></div></div>
        <div class="we-list">${wm.map(({ y: wy, m: wmm }) => `<button data-act="wrapped" data-y="${wy}" data-mm="${wmm}"><b>${C.MONTHS[wmm]}</b><small>${wy}</small></button>`).join('')}</div>
      </div>` : ''}
      <div class="streak-card">
        <div class="streak-fire">${stk.current ? '🔥' : '💤'}</div>
        <div class="grow"><div class="streak-num num">${stk.current} ${plural(stk.current, 'смена', 'смены', 'смен')} подряд</div>
          <div class="streak-sub">с производительностью от ${N(b.prodThreshold, 0)}% · рекорд серии: <b>${stk.best}</b></div>
          ${stk.best ? `<div class="meter streak-meter"><i class="ok" style="width:${Math.min(100, (stk.current / Math.max(stk.best, 1)) * 100)}%"></i></div>` : ''}
          <div class="streak-sub">${!rec.shifts ? 'Внесите смены с производительностью — начнём считать' : stk.current && stk.current >= stk.best ? 'Вы на рекордной серии!' : stk.best ? `До рекорда: ${stk.best - stk.current + 1} ${plural(stk.best - stk.current + 1, 'смена', 'смены', 'смен')}` : 'Первая смена от ' + N(b.prodThreshold, 0) + '% начнёт серию'}</div></div>
      </div>

      <h2 class="sec">🏆 Личные рекорды</h2>
      <div class="tiles">
        ${recTile('Больше всего линий', rec.lines ? N(rec.lines.value) : '—', rec.lines ? C.fmtDateLong(rec.lines.key) : 'нет данных', rec.lines && rec.lines.key)}
        ${recTile('Лучшая производительность', rec.prod ? N(rec.prod.value, 2) + '%' : '—', rec.prod ? C.fmtDateLong(rec.prod.key) : 'укажите % в сменах', rec.prod && rec.prod.key)}
        ${recTile('Лучший заработок за смену', rec.total ? M(rec.total.value) : '—', rec.total ? C.fmtDateLong(rec.total.key) : 'нет данных', rec.total && rec.total.key)}
        ${recTile('Лучшая неделя', rec.week ? M(rec.week.value) : '—', rec.week ? `с ${C.fmtDateShort(rec.week.key)} · ${rec.week.shifts} ${plural(rec.week.shifts, 'смена', 'смены', 'смен')}` : 'нет данных')}
        ${recTile('Лучший месяц', rec.month ? M(rec.month.value) : '—', rec.month ? `${C.MONTHS[rec.month.m]} ${rec.month.y}` : 'нет данных')}
        ${rec.weight ? recTile('⚖️ Самая тяжёлая смена', fmtKg(rec.weight.value), C.fmtDateLong(rec.weight.key), rec.weight.key) : ''}
        ${recTile('Всего', `${rec.shifts} ${plural(rec.shifts, 'смена', 'смены', 'смен')}`, `${N(rec.linesTotal)} линий · ${M(rec.earned)}${rec.weightTotal ? ` · ${fmtKg(rec.weightTotal)}` : ''}`)}
      </div>

      <div class="seg" id="succ-scope">${[['month', 'Месяц'], ['year', 'Год'], ['all', 'Всё время']].map(([v, t]) => `<button data-scope="${v}" class="${sc.scope === v ? 'active' : ''}">${t}</button>`).join('')}</div>
      <p class="hint" style="margin:-4px 4px 12px">Рейтинг и дни недели — за ${scopeName}${sc.scope !== 'all' ? ' (месяц выбирается на главной)' : ''}</p>

      <div class="card"><h2>📊 Рейтинг смен <small>${rank.length} ${plural(rank.length, 'смена', 'смены', 'смен')}</small></h2>
        ${rank.length ? `${lastPlace ? `<div class="rank-last">Последняя смена (${C.fmtDateShort(lastPlace.key)}) — <b>${lastPlace.place} место</b> из ${rank.length}</div>` : ''}
          ${rank.slice(0, sc.showAll ? 100 : 10).map((x, i) => `<button class="list-row rank-row" data-act="open-day" data-key="${x.key}">
            <div class="medal">${medal(i)}</div>
            <div class="grow"><div>${C.fmtDateLong(x.key)}, ${C.WEEKDAYS[C.weekdayMon(x.key)].toLowerCase()}</div><div>${N(x.lines)} линий · ${M(x.total)} · <span class="${x.prod === null ? 'muted' : x.prod >= b.prodThreshold ? 'up' : ''}">${x.prod === null ? 'без %' : N(x.prod, 1) + '%'}</span></div></div>
            <div class="amount num ${x.score >= 110 ? 'up' : x.score < 90 ? 'down' : ''}">${x.score}<small class="score-u">баллов</small></div></button>`).join('')}
          ${rank.length > 10 && !sc.showAll ? `<button class="btn btn-secondary" data-act="rank-all" style="margin-top:6px">Показать все (${Math.min(rank.length, 100)})</button>` : ''}
          <p class="hint">Баллы: половина — производительность, половина — заработок за смену, оба относительно ваших средних за период. 100 — обычная смена, больше 100 — лучше обычного. Если % не указан, он берётся из линий в час (когда указаны часы), иначе считается только заработок.</p>`
        : '<div class="empty-chart">Смен за этот период ещё нет</div>'}
      </div>

      ${chartCard({ title: '📅 Выгодность дней недели', items: wd.rows.map((r) => ({ label: C.WEEKDAYS[r.wd], tip: `${r.name}: ${r.shifts} ${plural(r.shifts, 'смена', 'смены', 'смен')}${r.avgProd !== null ? ` · ${N(r.avgProd, 1)}%` : ''}`, value: r.avg })),
        avg: wd.overall || null, summary: wd.best ? `<b class="num">${wd.best.name}</b><span>самый прибыльный · в среднем ${M(wd.best.avg)}</span>` : '' })}
      ${wd.shifts ? `<div class="card"><h2>Средние по дням недели</h2>
        <table class="table num"><thead><tr><th>День</th><th>Смен</th><th>Ср. заработок</th><th>Линий</th><th>Произв.</th></tr></thead><tbody>
        ${wd.rows.map((r) => `<tr class="${r.shifts ? '' : 'zero'} ${wd.best && r.wd === wd.best.wd ? 'best-row' : ''}"><td>${C.WEEKDAYS[r.wd]}${wd.best && r.wd === wd.best.wd ? ' 👑' : ''}</td><td>${r.shifts || '—'}</td>
          <td>${r.shifts ? M(r.avg) : '—'}${r.vsAvg !== null && Math.abs(r.vsAvg) >= 0.005 ? `<br><small class="${r.vsAvg > 0 ? 'up' : 'down'}">${r.vsAvg > 0 ? '+' : ''}${N(r.vsAvg * 100, 0)}%</small>` : ''}</td>
          <td>${r.shifts ? N(r.avgLines, 0) : '—'}</td><td>${r.avgProd === null ? '—' : N(r.avgProd, 1) + '%'}</td></tr>`).join('')}
        </tbody></table>
        ${wd.best && wd.worst && wd.best.wd !== wd.worst.wd ? `<p class="hint">💡 ${wd.best.name} приносит в среднем на ${M(wd.best.avg - wd.worst.avg)} больше, чем ${wd.worst.name.toLowerCase()} (${M(wd.best.avg)} против ${M(wd.worst.avg)}). Процент — отклонение от средней смены ${M(wd.overall)}.</p>` : ''}</div>` : ''}

      <div class="card"><h2>😊 Самочувствие и усталость</h2>
        ${wb.moodDays || idxWorked.length ? `
        ${wb.moodDays ? `<div class="mood-sum"><span class="mood-big">${moodIcon(wb.avgMood)}</span><div><b>Среднее самочувствие: ${C.MOODS[Math.round(wb.avgMood) - 1].label.toLowerCase()}</b><div class="hint" style="margin:2px 0 0">по ${wb.moodDays} ${plural(wb.moodDays, 'смене', 'сменам', 'сменам')} с отметкой</div></div></div>
        <div class="mood-bars">${wb.byMood.map((r) => `<div class="mb"><div class="mb-bar"><i style="height:${wb.moodDays ? Math.max(4, r.shifts / wb.moodDays * 100) : 0}%"></i></div><div class="mb-ic">${r.icon}</div><small class="num">${r.avgProd === null ? '—' : N(r.avgProd, 0) + '%'}</small></div>`).join('')}</div>
        <p class="hint" style="text-align:center;margin-top:4px">Столбик — сколько смен, под ним — средняя производительность</p>
        ${wb.goodProd !== null && wb.badProd !== null ? `<p class="insight">💡 Когда самочувствие хорошее, производительность в среднем <b>${N(wb.goodProd, 1)}%</b>, когда плохое — <b>${N(wb.badProd, 1)}%</b>${wb.goodProd > wb.badProd ? ` (разница ${N(wb.goodProd - wb.badProd, 1)}%)` : ''}.</p>` : ''}` : '<p class="hint">Отмечайте самочувствие в сменах — появится связь с производительностью.</p>'}
        ${idxWorked.length ? `<table class="table num" style="margin-top:10px"><thead><tr><th>Смена подряд</th><th>Смен</th><th>Произв.</th><th>Самочувств.</th><th>Заработок</th></tr></thead><tbody>
          ${wb.byIdx.map((r) => `<tr class="${r.shifts ? '' : 'zero'}"><td>${r.n === 5 ? '5-я и дальше' : r.n + '-я'}</td><td>${r.shifts || '—'}</td><td>${r.avgProd === null ? '—' : N(r.avgProd, 1) + '%'}</td><td>${moodIcon(r.avgMood)}</td><td>${r.shifts ? M(r.avg) : '—'}</td></tr>`).join('')}
          </tbody></table>
          ${fatigue ? `<p class="insight">💡 В ${fatigue.n}-ю ночь подряд производительность ${fatigue.last < fatigue.first ? `ниже на ${N(fatigue.first - fatigue.last, 1)}%` : fatigue.last > fatigue.first ? `выше на ${N(fatigue.last - fatigue.first, 1)}%` : 'такая же'}, чем в первую (${N(fatigue.last, 1)}% против ${N(fatigue.first, 1)}%).</p>` : ''}` : ''}`
        : '<div class="empty-chart">Отмечайте самочувствие и производительность в сменах</div>'}
      </div>

      <div class="card"><h2>🐷 Планировщик накоплений</h2>
        <div class="inline-form">
          <div><label for="sv-goal">Цель, ₽</label><input class="input num" id="sv-goal" inputmode="decimal" value="${sv.goal || ''}" placeholder="100000"></div>
          <div><label for="sv-saved">Уже накоплено, ₽</label><input class="input num" id="sv-saved" inputmode="decimal" value="${sv.saved || ''}" placeholder="0"></div>
        </div>
        <div class="field"><label for="sv-pct">Откладываю от заработка: <b id="sv-pct-val">${sv.percent}%</b></label>
          <input type="range" id="sv-pct" min="5" max="100" step="5" value="${sv.percent}" class="range"></div>
        <div id="sv-result">${savingsHtml(plan, sv)}</div>
      </div>

      <h2 class="sec">🎖 Достижения <small>${achDone} из ${ach.length}</small></h2>
      <div class="ach-grid">${ach.map((a) => `<div class="ach ${a.done ? 'done' : ''}">
        <div class="ach-icon">${a.icon}</div><div class="ach-title">${esc(a.title)}</div><div class="ach-desc">${esc(a.desc)}</div>
        ${a.done ? '<div class="ach-ok">✓ получено</div>' : `<div class="meter"><i style="width:${(a.value / a.target * 100).toFixed(0)}%"></i></div><div class="ach-desc num">${a.target > 1 ? `${N(a.value)} / ${N(a.target)}` : 'ещё нет'}</div>`}
      </div>`).join('')}</div>`;

    $('#succ-scope').onclick = (e) => { const bt = e.target.closest('[data-scope]'); if (bt) { sc.scope = bt.dataset.scope; sc.showAll = false; renderSuccess(); } };
    const updPlan = (commit) => {
      const g = Number(String($('#sv-goal').value).replace(',', '.').replace(/\s/g, '')) || 0;
      const sd = Number(String($('#sv-saved').value).replace(',', '.').replace(/\s/g, '')) || 0;
      const pc = Number($('#sv-pct').value) || 100;
      $('#sv-pct-val').textContent = pc + '%';
      const nsv = { goal: Math.max(0, g), saved: Math.max(0, sd), percent: pc };
      $('#sv-result').innerHTML = savingsHtml(C.savingsPlan(state, nsv, today), nsv);
      if (commit) { state.settings.savings = nsv; save(); }
    };
    ['sv-goal', 'sv-saved', 'sv-pct'].forEach((id) => { const el = $('#' + id); el.oninput = () => updPlan(false); el.onchange = () => updPlan(true); });
  }
  function savingsHtml(p, sv) {
    if (!p.ok) return `<div class="empty-chart" style="padding:14px 0">${p.reason === 'goal' ? 'Укажите цель' : 'Внесите хотя бы одну смену — посчитаю по вашему среднему заработку'}</div>`;
    if (p.done) return `<div class="plan-done">🎉 Цель достигнута!</div>`;
    const prog = sv.goal ? Math.min(100, (sv.saved / sv.goal) * 100) : 0;
    return `<div class="progress plan-progress"><i style="width:${prog.toFixed(1)}%"></i></div>
      <div class="hint" style="margin:4px 0 12px">${Math.round(prog)}% · осталось ${M(p.left)}</div>
      <div class="plan-big"><b class="num">${p.shifts}</b> ${plural(p.shifts, 'смена', 'смены', 'смен')}</div>
      <div class="plan-sub">≈ ${p.weeks} ${plural(p.weeks, 'неделя', 'недели', 'недель')} · цель к <b>${C.fmtDateLong(p.date)}</b></div>
      <p class="hint">Средняя смена ${M(p.perShift)}${p.percent < 100 ? `, откладываете ${p.percent}% — это ${M(p.perShiftSaved)} со смены` : ''}. Считается по последним ${p.basis} ${plural(p.basis, 'смене', 'сменам', 'сменам')}, без учёта премий. Дата — по рабочим дням (пн–пт) с учётом ваших отметок.</p>`;
  }

  // ---------- Настройки ----------
  // Группы настроек: какие раскрыты — помним
  const SET_OPEN = 'zarplata2027:set-open';
  const setOpen = (g) => { try { return (JSON.parse(localStorage.getItem(SET_OPEN)) || []).includes(g); } catch { return false; } };
  document.addEventListener('toggle', (e) => {
    const d = e.target; if (!d.classList || !d.classList.contains('set-group')) return;
    try { const l = new Set(JSON.parse(localStorage.getItem(SET_OPEN)) || []); if (d.open) l.add(d.dataset.g); else l.delete(d.dataset.g); localStorage.setItem(SET_OPEN, JSON.stringify([...l])); } catch {}
  }, true);
  document.addEventListener('click', (e) => {
    const b = e.target.closest('.pet-coats [data-coat], .pet-accs [data-acc]'); if (!b) return;
    const pt = { ...(state.settings.pet || { on: false, name: 'Мурка' }), v: 2 };
    if (b.dataset.coat) { pt.coat = b.dataset.coat; toast(`Окрас: ${C.PET_COATS.find((c) => c.id === pt.coat).name.toLowerCase()}`); }
    else {
      if (b.classList.contains('locked')) return toast(`Откроется за достижение: ${b.dataset.need}`);
      pt.acc = b.dataset.acc; const a = C.PET_ACCS.find((x) => x.id === pt.acc); toast(pt.acc === 'none' ? 'Без аксессуара' : `${a.icon} ${a.name}`);
    }
    state.settings.pet = pt; save(); if (window.Pet) Pet.refresh(); renderSettings();
  });
  function renderSettings() {
    const set = state.settings, today = todayKey();
    const refKey = C.inYear(today) ? today : C.FIRST_DAY;
    const count = Object.keys(state.entries).length;
    const hist = [...set.rateHistory].sort((a, b) => (a.from < b.from ? 1 : -1));
    $('#view-settings').innerHTML = accountCardHtml() + adminCardHtml() + `
      <h2 class="set-title">Настройки</h2>
      <details class="set-group" data-g="work" ${setOpen('work') ? 'open' : ''}><summary><span class="sg-ic">💼</span><span class="grow"><b>Работа и заработок</b><small>тариф, цели, премии, выплаты, время смены</small></span><span class="chev">›</span></summary>
      <div class="sg-body">
      <div class="card"><h2>Стоимость одной линии</h2>
        <div class="rate-now"><b class="num">${M(C.rateFor(set.rateHistory, refKey))}</b><span class="muted">${C.inYear(today) ? 'действует сегодня' : `на ${C.fmtDateLong(refKey)}`}</span></div>
        <div class="inline-form">
          <div><label for="s-rate">Новая стоимость, ₽</label><input class="input num" id="s-rate" inputmode="decimal" placeholder="5"></div>
          <div><label for="s-from">Действует с</label><input class="input" type="date" id="s-from" min="${C.FIRST_DAY}" max="${C.LAST_DAY}" value="${refKey}"></div>
        </div>
        <button class="btn btn-primary" data-act="set-rate">Применить тариф</button>
        <p class="hint">Новые записи с этой даты считаются по новой стоимости. Уже сохранённые смены не пересчитываются — у каждой хранится свой тариф.</p>
        <div style="margin-top:12px">${hist.map((h) => `<div class="hist-row num"><span>с ${C.fmtDateLong(h.from)} — <b>${M(h.rate)}</b></span>${hist.length > 1 ? `<button data-act="del-rate" data-from="${h.from}">Удалить</button>` : ''}</div>`).join('')}</div>
      </div>
      <div class="card"><h2>Цели на месяц</h2>
        <div class="field"><label for="s-target">Целевая зарплата за месяц, ₽ <span>0 — без цели</span></label><input class="input num" id="s-target" inputmode="decimal" value="${set.target || ''}" placeholder="Например, 60000"></div>
        <div class="field"><label for="s-planned">Планируемое количество смен в месяц <span>0 — по календарю</span></label><input class="input num" id="s-planned" inputmode="numeric" value="${set.plannedShifts || ''}" placeholder="Например, 15"></div>
        <button class="btn btn-primary" data-act="save-goals">Сохранить цели</button>
        <p class="hint">Прогноз = уже заработано + средний заработок за смену × оставшиеся смены. Без плана оставшиеся смены — это будние дни (пн–пт) до конца месяца.</p>
      </div>
      <div class="card"><h2>Премии</h2>
        ${(() => { const b = { ...C.DEFAULT_BONUS, ...set.bonus }; const f = (id, label, val) => `<div><label for="${id}">${label}</label><input class="input num" id="${id}" inputmode="decimal" value="${String(val).replace('.', ',')}"></div>`;
          return `<p class="hint" style="margin:0 0 8px">За производительность — по средней за месяц</p>
          <div class="inline-form">${f('b-pthr', 'Порог, %', b.prodThreshold)}${f('b-pamt', 'Премия, ₽', b.prodAmount)}</div>
          <p class="hint" style="margin:6px 0 8px">За сервис (работа без ошибок) — по зонам</p>
          <div class="inline-form">${f('b-gthr', 'Зелёная от, %', b.greenThreshold)}${f('b-gamt', 'Премия, ₽', b.greenAmount)}</div>
          <div class="inline-form">${f('b-ythr', 'Жёлтая от, %', b.yellowThreshold)}${f('b-yamt', 'Премия, ₽', b.yellowAmount)}</div>
          <div class="inline-form"><div><label>Красная</label><div class="input num" style="color:var(--muted);font-size:15px;display:flex;align-items:center">ниже жёлтой</div></div>${f('b-ramt', 'Премия, ₽', b.redAmount)}</div>`; })()}
        <button class="btn btn-primary" data-act="save-bonus">Сохранить премии</button>
        <p class="hint">Сервис и штраф за ошибки вносятся на главном экране для каждого месяца. Если узнаете сумму премии за жёлтую зону, укажите её здесь.</p>
      </div>
      <div class="card"><h2>Даты выплат</h2>
        ${(() => { const pd = { ...C.DEFAULT_PAYDAYS, ...(set.paydays || {}) }; const f = (id, label, val) => `<div><label for="${id}">${label}</label><input class="input num" id="${id}" inputmode="numeric" value="${val}"></div>`;
          return `<div class="inline-form">${f('pd-sal', 'Зарплата, число', pd.salary)}${f('pd-adv', 'Аванс, число', pd.advance)}</div>
          <div class="inline-form">${f('pd-ef', 'Конверт с', pd.envelopeFrom)}${f('pd-et', 'Конверт по', pd.envelopeTo)}</div>`; })()}
        <button class="btn btn-primary" data-act="save-paydays">Сохранить даты</button>
        <p class="hint">Зарплата и конверт — за прошлый месяц, аванс — за текущий. Если дата выпадает на субботу, воскресенье или праздник — выплата ожидается в ближайший рабочий день раньше. Если в месяце меньше дней (февраль), берётся последний день.</p>
      </div>
      <div class="card"><h2>Время смены</h2>
        <div class="field"><label for="sh-start">Начало смены по умолчанию</label><input class="input num" type="time" id="sh-start" value="${set.shiftStart || '21:00'}"></div>
        <p class="hint">Подставляется в новую смену. Время окончания выбирается в смене (до 6, 7 или 8 утра) — часы посчитаются сами. Ночная смена записывается на дату её начала.</p>
      </div>
      </div></details>
      <details class="set-group" data-g="look" ${setOpen('look') ? 'open' : ''}><summary><span class="sg-ic">🎨</span><span class="grow"><b>Оформление</b><small>тема, цвета, сезонные темы, рейтинг, кошка</small></span><span class="chev">›</span></summary>
      <div class="sg-body">
      <div class="card"><h2>Тема и цвета</h2>
        <div class="seg" id="s-theme">${[['system', 'Как в системе'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, t]) => `<button data-theme="${v}" class="${set.theme === v ? 'active' : ''}">${t}</button>`).join('')}</div>
        <div class="muted" style="font-size:14px;margin:6px 0 10px">Цветовая гамма — меняется во всём приложении</div>
        <div class="palettes" id="s-palettes">${C.PALETTES.map((p) => `<button data-pal="${p.id}" class="${set.palette && set.palette.id === p.id ? 'active' : ''}" aria-label="${p.name}">
          <span class="sw" style="background:linear-gradient(135deg, ${p.accent} 0 58%, ${p.accent2} 58% 100%)"></span><small>${p.name}</small></button>`).join('')}</div>
        <div class="inline-form" style="margin-top:12px">
          <div><label for="s-acc">Свой основной цвет</label><input class="input color" type="color" id="s-acc" value="${(set.palette || C.PALETTES[0]).accent}"></div>
          <div><label for="s-acc2">Цвет графиков</label><input class="input color" type="color" id="s-acc2" value="${(set.palette || C.PALETTES[0]).accent2}"></div>
        </div>
        <p class="hint">Основной цвет — кнопки, календарь, главная карточка, вкладки. Цвет графиков — линии и вторые столбцы в статистике.</p>
        ${seasonSwitches()}
      </div>
      <div class="card"><h2>Рейтинг сборщиков</h2>
        <label class="switch-row"><span><b>Анимации и фоны карточек</b><small>живые фоны профилей, анимированные рамки и имена</small></span><input type="checkbox" class="switch" id="rank-fx" ${rankFx() ? 'checked' : ''}></label>
      </div>
      <div class="card"><h2>Кошка</h2>
        ${(() => { const pt = set.pet || { on: false, name: 'Мурка', v: 2 }; return `
        <label class="switch-row"><span><b>Показывать кошку</b><small>гуляет по экранам и радуется вашим сменам</small></span><input type="checkbox" class="switch" id="pet-on" ${pt.on === true ? 'checked' : ''}></label>
        <div class="field" style="margin-top:8px"><label for="pet-name">Имя</label><input class="input" id="pet-name" maxlength="20" value="${esc(pt.name || 'Мурка')}"></div>
        <label class="pet-lbl">Окрас</label>
        <div class="pet-coats">${C.PET_COATS.map((c) => `<button type="button" data-coat="${c.id}" class="${(pt.coat || 'ginger') === c.id ? 'on' : ''}"><i style="background:${c.c}"></i><small>${c.name}</small></button>`).join('')}</div>
        <label class="pet-lbl">Аксессуар <small>открываются за достижения</small></label>
        <div class="pet-accs">${(() => { const done = new Set(achs().filter((a) => a.done).map((a) => a.id)), all = achs();
          return C.PET_ACCS.map((a) => { const open = !a.ach || done.has(a.ach), need = a.ach && all.find((x) => x.id === a.ach);
            return `<button type="button" data-acc="${a.id}" class="${(pt.acc || 'none') === a.id ? 'on' : ''} ${open ? '' : 'locked'}" data-need="${need ? esc(need.icon + ' ' + need.title + ' — ' + need.desc) : ''}" title="${esc(a.name)}"><span>${a.icon}</span>${open ? '' : '<i>🔒</i>'}</button>`; }).join(''); })()}</div>`; })()}
        <p class="hint">Нажмите на кошку — она расскажет, как идёт месяц. Довольна, когда премия и сервис в порядке, грустит, если ночь выдалась тяжёлой. Ночью (с 0 до 6) иногда спит.</p>
      </div>
      </div></details>
      <details class="set-group" data-g="sec" ${setOpen('sec') ? 'open' : ''}><summary><span class="sg-ic">🔒</span><span class="grow"><b>Безопасность</b><small>PIN-код и отпечаток пальца</small></span><span class="chev">›</span></summary>
      <div class="sg-body">
      <div class="card"><h2>Вход в приложение</h2>
        ${(() => { const lc = lockCfg(); return `
        <label class="switch-row"><span><b>Вход по PIN-коду</b><small>4 цифры при открытии приложения</small></span><input type="checkbox" class="switch" id="sec-pin" ${lc.enabled ? 'checked' : ''}></label>
        ${lc.enabled ? `<label class="switch-row"><span><b>Вход по отпечатку пальца</b><small id="sec-bio-note">${isNative() ? 'если отпечаток настроен в телефоне' : 'работает в приложении (APK)'}</small></span><input type="checkbox" class="switch" id="sec-bio" ${lc.bio ? 'checked' : ''} ${isNative() ? '' : 'disabled'}></label>
          <div class="field" style="margin-top:8px"><label for="sec-after">Блокировать после сворачивания</label>
            <select class="input" id="sec-after">${[[0, 'Сразу'], [60, 'Через 1 минуту'], [300, 'Через 5 минут'], [1800, 'Через 30 минут']].map(([v, t]) => `<option value="${v}" ${(lc.after ?? 60) === v ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
          <div class="btn-row"><button class="btn btn-secondary" data-act="pin-change">Сменить PIN</button><button class="btn btn-secondary" data-act="lock-now">Заблокировать</button></div>` : ''}
        <p class="hint">Отключить можно в любой момент. PIN хранится только на этом телефоне в зашифрованном виде.</p>`; })()}
      </div>
      </div></details>
      <details class="set-group" data-g="data" ${setOpen('data') ? 'open' : ''}><summary><span class="sg-ic">💾</span><span class="grow"><b>Данные</b><small>резервная копия, экспорт, удаление</small></span><span class="chev">›</span></summary>
      <div class="sg-body">
      <div class="card"><h2>Резервная копия <small>${count} ${plural(count, 'запись', 'записи', 'записей')}</small></h2>
        <button class="btn btn-primary" data-act="export">Сохранить копию в файл</button>
        <button class="btn btn-secondary" data-act="import">Восстановить из файла</button>
        <div class="btn-row" style="margin-top:10px"><button class="btn btn-secondary" data-act="export-text">Копировать текстом</button><button class="btn btn-secondary" data-act="import-text">Вставить текст</button></div>
        <button class="btn btn-secondary" data-act="csv">Таблица для Excel (CSV)</button>
        <p class="hint">${meta.lastBackup ? `Последняя копия: ${new Date(meta.lastBackup).toLocaleString('ru-RU')}.` : 'Копия ещё не создавалась.'} Данные хранятся только на этом телефоне — сохраняйте копию раз в неделю (например, в Telegram «Избранное» или на Google Диск).</p>
        <input type="file" id="s-file" accept=".json,application/json,text/plain" hidden>
      </div>
      <div class="card"><h2>Удаление</h2><button class="btn btn-danger" data-act="wipe">Удалить все записи</button></div>
      </div></details>
      <div class="about"><span data-act="ota-check">Калькулятор ЗП · версия 3.29</span><br>Годы ${C.YEARS.join(', ')} · выходные — суббота и воскресенье<br>Работает без интернета · данные хранятся на устройстве${window.Cloud && window.Cloud.configured ? ' и, после входа, в облаке' : ''}</div>`;
  }

  async function settingsAction(act, el) {
    const set = state.settings;
    if (act === 'set-rate') {
      const r = Number(String($('#s-rate').value).replace(',', '.'));
      const from = $('#s-from').value;
      try {
        if (!C.inYear(from)) throw new Error(`Укажите дату с ${C.YEARS[0]} по ${C.YEARS[C.YEARS.length - 1]} год`);
        C.setRate(state, from, r); save(); renderAll(); toast(`Тариф ${M(r)} с ${C.fmtDateLong(from)}`);
      } catch (e) { toast(e.message || 'Введите стоимость больше нуля'); }
    } else if (act === 'del-rate') {
      if (await confirmDlg('Удалить тариф?', 'Сохранённые смены не изменятся.', 'Удалить', true)) {
        try { C.removeRate(state, el.dataset.from); save(); renderAll(); } catch (e) { toast(e.message); }
      }
    } else if (act === 'pin-change') {
      if (await setupPin()) toast('PIN-код изменён');
    } else if (act === 'lock-now') {
      showLock();
    } else if (act === 'save-paydays') {
      const g = (id) => Math.round(Number($('#' + id).value));
      const pd = { advance: g('pd-adv'), salary: g('pd-sal'), envelopeFrom: g('pd-ef'), envelopeTo: g('pd-et') };
      if (Object.values(pd).some((v) => !(v >= 1 && v <= 31))) return toast('Числа месяца — от 1 до 31');
      if (pd.envelopeTo < pd.envelopeFrom) return toast('«Конверт по» не может быть раньше «с»');
      set.paydays = pd; save(); renderAll(); toast('Даты выплат сохранены');
    } else if (act === 'save-bonus') {
      const g = (id) => Number(String($('#' + id).value).replace(',', '.').replace(/\s/g, ''));
      const nb = { prodThreshold: g('b-pthr'), prodAmount: g('b-pamt'), greenThreshold: g('b-gthr'), greenAmount: g('b-gamt'), yellowThreshold: g('b-ythr'), yellowAmount: g('b-yamt'), redAmount: g('b-ramt') };
      if (Object.values(nb).some((v) => !Number.isFinite(v) || v < 0)) return toast('Проверьте значения: числа не меньше 0');
      if (nb.greenThreshold > 100 || nb.yellowThreshold > nb.greenThreshold) return toast('Порог жёлтой зоны должен быть не выше зелёной, а зелёной — не выше 100%');
      set.bonus = nb; save(); renderAll(); toast('Премии сохранены');
    } else if (act === 'save-goals') {
      const t = Number(String($('#s-target').value || 0).replace(',', '.').replace(/\s/g, ''));
      const p = Number($('#s-planned').value || 0);
      if (!(t >= 0) || !(p >= 0) || !Number.isInteger(p) || p > 31) return toast('Проверьте значения: смен от 0 до 31');
      set.target = C.round2(t); set.plannedShifts = p; save(); renderAll(); toast('Цели сохранены');
    } else if (act === 'export') {
      await saveFile(`zarplata-backup-${todayKey()}.json`, C.exportData(state), 'application/json');
      meta.lastBackup = Date.now(); saveMeta(); renderSettings(); checkAchievements();
    } else if (act === 'csv') {
      await saveFile(`zarplata-${todayKey()}.csv`, C.toCSV(state), 'text/csv');
    } else if (act === 'import') {
      const inp = $('#s-file'); inp.value = '';
      inp.onchange = () => { const file = inp.files[0]; if (!file) return; const rd = new FileReader(); rd.onload = () => importText(String(rd.result)); rd.readAsText(file); };
      inp.click();
    } else if (act === 'export-text') {
      const txt = C.exportData(state);
      let copied = false;
      try { await navigator.clipboard.writeText(txt); copied = true; } catch {}
      if (copied) { meta.lastBackup = Date.now(); saveMeta(); renderSettings(); checkAchievements(); toast('Копия скопирована — вставьте её в заметки или мессенджер'); }
      else dialog({ title: 'Резервная копия', text: 'Выделите весь текст и скопируйте:', html: `<textarea class="input" readonly>${esc(txt)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    } else if (act === 'import-text') {
      const txt = await dialog({ title: 'Вставьте резервную копию', html: '<textarea class="input" id="imp-text" placeholder="{ ... }"></textarea>',
        buttons: [{ text: 'Восстановить', cls: 'btn-primary', read: (d) => $('#imp-text', d).value }, { text: 'Отмена', value: null }] });
      if (txt) importText(txt);
    } else if (act === 'wipe') {
      if (await confirmDlg('Удалить все записи?', 'Все смены будут удалены без возможности восстановления. Сначала сохраните резервную копию.', 'Удалить всё', true)
        && await confirmDlg('Точно удалить?', `${Object.keys(state.entries).length} записей будет удалено.`, 'Да, удалить', true)) {
        state.entries = {}; save(); renderAll(); toast('Все записи удалены');
      }
    }
  }
  async function importText(txt) {
    let parsed;
    try { parsed = C.normalizeState(JSON.parse(txt)); } catch (e) { return toast('Не удалось прочитать копию: ' + (e.message || 'неверный формат')); }
    const n = Object.keys(parsed.state.entries).length;
    const choice = await dialog({ title: 'Восстановление', text: `В копии ${n} ${plural(n, 'запись', 'записи', 'записей')}${parsed.skipped ? `, пропущено повреждённых: ${parsed.skipped}` : ''}.\nЗаменить текущие данные или объединить?`,
      buttons: [{ text: 'Заменить всё', cls: 'btn-primary', value: 'replace' }, { text: 'Объединить', value: 'merge' }, { text: 'Отмена', value: null }] });
    if (!choice) return;
    state = choice === 'replace' ? parsed.state : C.mergeStates(state, parsed.state);
    save(); applyTheme(); renderAll(); toast('Данные восстановлены');
  }
  async function saveFile(name, text, mime) {
    const cap = window.Capacitor;
    if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
      const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
      if (FS && SH) {
        try {
          const r = await FS.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
          await SH.share({ title: name, files: [r.uri], url: r.uri, dialogTitle: 'Сохранить или отправить копию' });
          return;
        } catch (e) { if (String(e && e.message).match(/cancel/i)) return; console.warn(e); }
      }
      return dialog({ title: name, text: 'Скопируйте текст и сохраните его в надёжном месте:', html: `<textarea class="input" readonly>${esc(text)}</textarea>`, buttons: [{ text: 'Готово', value: true }] });
    }
    const file = new File([text], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android/i.test(navigator.userAgent)) {
      try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Файл сохранён в «Загрузки»');
  }

  // ---------- Навигация ----------
  // Переключатель «Статистика / Успехи» внутри раздела статистики
  const statsSubnav = (cur) => `<div class="seg subnav"><button data-act="sub-stats" class="${cur === 'stats' ? 'active' : ''}">Статистика</button><button data-act="sub-success" class="${cur === 'success' ? 'active' : ''}">Успехи</button></div>`;
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-act="sub-stats"],[data-act="sub-success"]'); if (b) setTab(b.dataset.act === 'sub-stats' ? 'stats' : 'success'); });
  const TITLES = { home: 'Главная', cal: 'Календарь', stats: 'Статистика', success: 'Успехи', crew: 'Сборщики', settings: 'Профиль' };
  function setTab(tab) {
    const prev = ui.tab;
    if (tab !== 'crew' && typeof stopCrewWatch === 'function') { stopCrewWatch(); leaveChat(); }
    ui.tab = tab;
    const btnTab = tab === 'success' ? 'stats' : tab; // «Успехи» — часть раздела «Статистика»
    document.querySelectorAll('.tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.tab === btnTab));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + tab));
    $('#title').textContent = TITLES[tab];
    renderTab(tab);
    updateChip();
    window.scrollTo({ top: 0 });
    if (window.Pet && prev) Pet.tab(prev, tab);
    rememberTab();
  }
  // Открытая вкладка переживает обновление страницы / перезапуск приложения
  const TAB_KEY = 'zarplata2027:ui-tab';
  function rememberTab() { try { localStorage.setItem(TAB_KEY, JSON.stringify({ tab: ui.tab, crew: ui.crew ? ui.crew.sub : undefined })); } catch {} }
  function savedTab() {
    try { const v = JSON.parse(localStorage.getItem(TAB_KEY)); if (v && TITLES[v.tab]) return v; } catch {}
    return { tab: 'home' };
  }
  function renderTab(tab) { ({ home: renderHome, cal: renderCal, stats: renderStats, success: renderSuccess, crew: renderCrew, settings: renderSettings })[tab](); }
  function renderAll() { renderTab(ui.tab); updateChip(); if (window.Pet) Pet.refresh(); }
  function updateChip() {
    const chip = $('.year-chip');
    const y = ui.tab === 'home' ? C.ymOf(ui.homeMonth).y : ui.tab === 'cal' ? C.ymOf(ui.calMonth).y
      : ui.tab === 'stats' ? (ui.stats.mode === 'month' ? C.ymOf(ui.stats.month).y : ui.stats.mode === 'year' ? ui.stats.year : null)
      : ui.tab === 'success' && ui.success.scope !== 'all' ? C.ymOf(ui.homeMonth).y : null;
    chip.textContent = y || `${C.YEARS[0]}–${C.YEARS[C.YEARS.length - 1]}`;
  }

  document.addEventListener('click', async (e) => {
    const tabBtn = e.target.closest('.tabbar button');
    if (tabBtn) return setTab(tabBtn.dataset.tab);
    const el = e.target.closest('[data-act]');
    if (!el || el.closest('#sheet') || el.disabled) return;
    const act = el.dataset.act;
    if (act === 'open-day') return el.dataset.key && openDay(el.dataset.key);
    if (act === 'open-today') return openDay(todayKey());
    if (act === 'month-extras') return openMonthSheet(+el.dataset.m);
    if (act === 'manual-total') return openManualSheet(+el.dataset.m);
    if (act === 'payout') return openPayoutSheet(+el.dataset.m, el.dataset.id);
    if (act === 'wrapped') return openWrapped(+el.dataset.y, +el.dataset.mm);
    if (act === 'rank-all') { ui.success.showAll = true; return renderSuccess(); }
    if (act === 'go-cal') { ui.calMonth = ui.homeMonth; return setTab('cal'); }
    if (act === 'home-prev' || act === 'home-next') { ui.homeMonth += act.endsWith('next') ? 1 : -1; ui.homeMonth = Math.max(0, Math.min(C.MONTH_COUNT - 1, ui.homeMonth)); return renderHome(); }
    if (act === 'cal-prev' || act === 'cal-next') return shiftCal(act.endsWith('next') ? 1 : -1);
    if (act === 'home-pick' || act === 'cal-pick') {
      const cur = act === 'home-pick' ? ui.homeMonth : ui.calMonth;
      const m = await pickMonth(cur);
      if (m === null) return;
      if (act === 'home-pick') { ui.homeMonth = m; renderHome(); } else { ui.calMonth = m; renderCal(m > cur ? 'left' : 'right'); }
      return;
    }
    if (el.closest('#view-settings')) return settingsAction(act, el);
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-theme [data-theme]');
    if (!b) return;
    state.settings.theme = b.dataset.theme; save(); applyTheme(); renderSettings();
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#s-palettes [data-pal]');
    if (!b) return;
    const p = C.PALETTES.find((x) => x.id === b.dataset.pal);
    state.settings.palette = { id: p.id, accent: p.accent, accent2: p.accent2 };
    save(); applyTheme(); renderSettings(); toast(`Гамма «${p.name}»`);
  });
  const customColor = (e, commit) => {
    if (!e.target.matches('#s-acc, #s-acc2')) return;
    const pal = { ...(state.settings.palette || C.PALETTES[0]), id: 'custom' };
    pal[e.target.id === 's-acc' ? 'accent' : 'accent2'] = e.target.value;
    state.settings.palette = pal; applyTheme();
    if (commit) { save(); document.querySelectorAll('#s-palettes [data-pal]').forEach((x) => x.classList.remove('active')); }
  };
  document.addEventListener('input', (e) => customColor(e, false));
  document.addEventListener('change', (e) => customColor(e, true));
  // Переключатели безопасности и время смены
  document.addEventListener('change', async (e) => {
    const t = e.target;
    if (t.id === 'sec-pin') {
      if (t.checked) { const ok = await setupPin(); if (ok) toast('PIN-код включён'); }
      else if (await confirmDlg('Отключить PIN-код?', 'Приложение будет открываться без кода.', 'Отключить', true)) { meta.lock = { enabled: false, after: lockCfg().after }; saveMeta(); toast('PIN-код отключён'); }
      return renderSettings();
    }
    if (t.id === 'sec-bio') {
      if (t.checked) {
        if (!(await bioAvailable())) { toast('Отпечаток не настроен в телефоне или недоступен'); return renderSettings(); }
        if (!(await bioVerify())) { toast('Отпечаток не подтверждён'); return renderSettings(); }
      }
      meta.lock = { ...lockCfg(), bio: t.checked }; saveMeta(); toast(t.checked ? 'Вход по отпечатку включён' : 'Вход по отпечатку отключён');
      return renderSettings();
    }
    if (t.id === 'sec-after') { meta.lock = { ...lockCfg(), after: Number(t.value) }; saveMeta(); return toast('Сохранено'); }
    if (t.id === 'pet-on' || t.id === 'pet-name') {
      const pt = { ...(state.settings.pet || { on: false, name: 'Мурка' }), v: 2 };
      if (t.id === 'pet-on') pt.on = t.checked; else pt.name = t.value.trim().slice(0, 20) || 'Мурка';
      state.settings.pet = pt; save(); if (window.Pet) Pet.refresh();
      return toast(t.id === 'pet-on' ? (t.checked ? `${pt.name} снова с вами` : `${pt.name} ушла спать`) : `Теперь её зовут ${pt.name}`);
    }
    if (t.id === 'sh-start' && C.isTime(t.value)) { state.settings.shiftStart = t.value; save(); toast('Начало смены: ' + t.value); }
  });
  $('#backdrop').addEventListener('click', closeModal);
  $('#dlg-backdrop').addEventListener('click', closeModal);
  // Свайп вниз по шапке листа закрывает его
  (() => {
    const sh = $('#sheet'); let y0 = null;
    sh.addEventListener('touchstart', (e) => { y0 = sh.scrollTop <= 0 && e.target.closest('.grabber, .sheet-head') ? e.touches[0].clientY : null; }, { passive: true });
    sh.addEventListener('touchend', (e) => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 70) closeModal(); y0 = null; }, { passive: true });
  })();

  // ---------- Запуск ----------
  // =====================================================================
  // ---------- Облако: аккаунт, профиль, синхронизация (window.Cloud из cloud.js) ----------
  // Всё необязательно: без ключей Firebase (Cloud.configured = false) раздел не показывается.
  // =====================================================================
  const CL = () => (window.Cloud && window.Cloud.configured && window.Cloud.ready ? window.Cloud : null);
  const acc = () => (CL() ? CL().account : null);
  function avatarHtml(av, size = 44) {
    const st = `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.55)}px`;
    if (av && av.kind === 'photo' && /^data:image\//.test(av.v)) return `<img class="avatar" alt="" src="${esc(av.v)}" style="${st}">`;
    const [emo, col] = (av && av.kind === 'preset' ? av.v : '👤|#868E96').split('|');
    return `<span class="avatar" style="${st};background:${/^#[0-9a-f]{6}$/i.test(col) ? col : '#868E96'}">${esc(emo)}</span>`;
  }
  const SYNC_TEXT = {
    loading: ['wait', 'Подключение к облаку…'], syncing: ['wait', 'Сохраняю в облако…'], synced: ['ok', 'Синхронизировано'],
    offline: ['warn', 'Нет сети — всё сохранено на телефоне и уйдёт в облако, когда появится интернет'], error: ['bad', 'Ошибка синхронизации'],
    'needs-choice': ['warn', 'Нужно выбрать, как объединить данные'], off: ['wait', ''],
  };
  function myStats() {
    const es = Object.values(state.entries);
    const lines = es.reduce((a, e) => a + (e.lines || 0), 0), days = es.length;
    return { lines, days, earn: es.reduce((a, e) => a + C.total(e), 0), avg: days ? lines / days : 0, best: es.reduce((a, e) => Math.max(a, e.lines || 0), 0) };
  }
  const fmtDateTs = (ts) => { const d = ts && ts.toDate ? ts.toDate() : null; return d ? d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) : '—'; };

  function accountCardHtml() {
    const Cl = window.Cloud;
    if (!Cl || !Cl.configured) return '';
    if (!Cl.ready) return `<div class="card acc-card"><h2>Аккаунт</h2><p class="hint" style="margin:0">Облако недоступно: ${esc(Cl.error || 'загрузка…')}</p></div>`;
    const a = Cl.account, u = a.user;
    // Вход ещё восстанавливается (без сети бывает долго) — показываем профиль из копии на телефоне
    if (!u && !a.authReady && a.cachedUser) {
      const p = a.profile, off = !navigator.onLine;
      return `<div class="card acc-card"><h2>Аккаунт</h2>
        <div class="acc-row">${p ? avatarFx(p.avatar, 52, p) : avatarHtml(null, 52)}
          <div class="grow"><div class="acc-name">${p ? nameFx(p.name, p) : esc(a.cachedUser.email || 'Аккаунт')}</div><div class="muted">${p ? '@' + esc(p.nick) + ' · ' : ''}${esc(a.cachedUser.email || '')}</div></div></div>
        <div class="sync-line ${off ? 'warn' : ''}"><i></i>${off ? 'Офлайн — всё сохраняется на телефоне и уйдёт в облако, когда появится интернет' : 'Подключаюсь к облаку…'}</div>
        ${myBadgesHtml()}
      </div>`;
    }
    if (!u && !a.authReady) return `<div class="card acc-card"><h2>Аккаунт</h2><p class="hint" style="margin:0">Восстанавливаю вход…</p></div>`;
    if (!u) return `<div class="card acc-card"><h2>Аккаунт</h2>
        <p class="muted" style="margin:0 0 12px">Войдите, чтобы смены хранились в облаке и были на всех устройствах — Android, iPhone, компьютер. Калькулятором можно пользоваться и без аккаунта.</p>
        <div class="btn-row"><button class="btn btn-primary" data-act="acc-login">Войти</button><button class="btn btn-secondary" data-act="acc-register">Создать аккаунт</button></div></div>`;
    const p = a.profile, sy = Cl.sync, [cls, txt] = SYNC_TEXT[sy.status] || SYNC_TEXT.off;
    const bk = sy.backup();
    return `<div class="card acc-card"><h2>Аккаунт</h2>
      <div class="acc-row" data-act="acc-profile">${p ? avatarFx(p.avatar, 52, p) : avatarHtml(null, 52)}
        <div class="grow"><div class="acc-name">${p ? nameFx(p.name, p) : 'Профиль не заполнен'}</div><div class="muted">${p ? '@' + esc(p.nick) + ' · ' : ''}${esc(u.email || '')}</div></div><span class="chev">›</span></div>
      ${!navigator.onLine && sy.status !== 'offline' ? '<div class="sync-line warn"><i></i>Офлайн — всё сохраняется на телефоне</div>' : ''}
      ${txt ? `<div class="sync-line ${cls}"><i></i>${esc(txt)}${sy.status === 'synced' && sy.lastSynced ? ` · ${new Date(sy.lastSynced).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}` : ''}</div>` : ''}
      ${sy.status === 'needs-choice' ? '<button class="btn btn-primary" data-act="acc-choice">Выбрать</button>' : ''}
      ${!p && a.profileLoaded ? '<button class="btn btn-primary" data-act="acc-create-profile">Выбрать ник и имя</button>' : ''}
      ${myBadgesHtml()}
      ${privacyHtml()}
      <div class="btn-row" style="margin-top:10px"><button class="btn btn-secondary" data-act="acc-profile">Профиль</button><button class="btn btn-secondary" data-act="acc-logout">Выйти</button></div>
      ${bk ? `<p class="hint">Копия данных до первой синхронизации сохранена ${new Date(bk.at).toLocaleDateString('ru-RU')}. <a href="#" data-act="acc-backup">Восстановить из неё</a></p>` : ''}
    </div>`;
  }
  // Значки достижений в профиле: полученные + сколько всего; нажатие — к «Успехам»
  function myBadgesHtml() {
    const all = achs(), done = all.filter((a) => a.done);
    return `<button class="my-badges" data-act="acc-badges"><span class="mb-head"><b>Достижения</b><small>${done.length} из ${all.length}</small></span>
      <span class="badges big">${done.length ? done.slice().reverse().slice(0, 10).map((a) => `<i title="${esc(a.title)}">${a.icon}</i>`).join('') : '<small class="muted">Пока нет — внесите первую смену</small>'}</span><span class="chev">›</span></button>`;
  }
  document.addEventListener('click', (e) => { if (e.target.closest('[data-act="acc-badges"]')) setTab('success'); });
  function refreshAccountCard() {
    const old = $('#view-settings .acc-card') || $('#view-settings .card');
    if (ui.tab !== 'settings' || !old) return;
    const html = accountCardHtml();
    if (old.classList.contains('acc-card')) { if (html) old.outerHTML = html; else old.remove(); }
    else if (html) old.insertAdjacentHTML('beforebegin', html);
    const oa = $('#view-settings .admin-card'), ah = adminCardHtml();
    if (oa) { if (ah) oa.outerHTML = ah; else oa.remove(); }
    else if (ah) { const ac = $('#view-settings .acc-card'); if (ac) ac.insertAdjacentHTML('afterend', ah); }
  }

  // ---------- Вход и регистрация ----------
  function openAuthSheet(mode = 'login') {
    const a = acc(); if (!a) return;
    const sh = $('#sheet');
    const reg = mode === 'register';
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${reg ? 'Создать аккаунт' : 'Вход'}</div><div class="sheet-sub">Смены будут храниться в облаке</div></div><button class="icon-btn" data-close>×</button></div>
      <div class="seg"><button type="button" class="${reg ? '' : 'active'}" data-auth-mode="login">Вход</button><button type="button" class="${reg ? 'active' : ''}" data-auth-mode="register">Регистрация</button></div>
      <form id="auth-form" autocomplete="on" novalidate>
        ${reg ? `<div class="field"><label for="a-name">Имя <span>видно другим сборщикам</span></label><input class="input" id="a-name" maxlength="40" autocomplete="nickname" placeholder="Например, Евгений"></div>
        <div class="field"><label for="a-nick">Ник <span>латиница, цифры, _ и .</span></label><input class="input" id="a-nick" maxlength="20" autocapitalize="none" autocomplete="username" placeholder="evgen_picker"><div class="hint" id="a-nick-hint"></div></div>` : ''}
        <div class="field"><label for="a-email">Почта</label><input class="input" id="a-email" type="email" inputmode="email" autocapitalize="none" autocomplete="email" placeholder="you@mail.ru"></div>
        <div class="field"><label for="a-pass">Пароль ${reg ? '<span>не меньше 6 символов</span>' : ''}</label><input class="input" id="a-pass" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}"></div>
        <p class="error" id="a-error"></p>
        <button class="btn btn-primary" type="submit" id="a-submit">${reg ? 'Зарегистрироваться' : 'Войти'}</button>
        ${a.canGoogle ? `<button class="btn btn-secondary" type="button" id="a-google"><span class="g-logo">G</span> ${reg ? 'Регистрация' : 'Вход'} через Google</button>` : '<p class="hint">Вход через Google в приложении для Android появится позже — пока используйте почту. На сайте и iPhone он уже работает.</p>'}
        ${reg ? '' : '<button class="btn btn-ghost" type="button" id="a-reset">Забыли пароль?</button>'}
      </form>`;
    sh.querySelectorAll('[data-auth-mode]').forEach((b) => (b.onclick = () => openAuthSheet(b.dataset.authMode)));
    const err = (t) => { $('#a-error').textContent = t || ''; };
    const busy = (on) => { sh.querySelectorAll('button, input').forEach((x) => (x.disabled = on)); };
    if (reg) $('#a-nick').addEventListener('blur', () => checkNickField('#a-nick', '#a-nick-hint'));
    $('#auth-form').onsubmit = async (e) => {
      e.preventDefault(); err('');
      const email = $('#a-email').value.trim(), password = $('#a-pass').value;
      if (!email) return err('Введите почту');
      busy(true);
      try {
        if (reg) {
          const nick = window.Cloud.normNick($('#a-nick').value), name = $('#a-name').value.trim();
          if (!name) throw { code: 'name-bad' };
          if (!window.Cloud.NICK_RE.test(nick)) throw { code: 'nick-bad' };
          signupDraft = { name };
          await a.signUp({ email, password, nick, name, avatar: window.Cloud.avatars.defaultAvatar(nick) });
          toast('Аккаунт создан');
        } else { await a.signIn({ email, password }); toast('Вы вошли'); }
        closeModal();
      } catch (ex) {
        if (ex && ex.afterSignup) { closeModal(); toast('Аккаунт создан, но ' + window.Cloud.errText(ex).toLowerCase()); setTimeout(() => { if (!$('#sheet.show #pe-form')) openProfileEdit(true); }, 400); }
        else err(window.Cloud.errText(ex));
      } finally { busy(false); }
    };
    const g = $('#a-google');
    if (g) g.onclick = async () => {
      err(''); busy(true);
      try { const u = await a.signInGoogle(); if (u) { closeModal(); toast('Вы вошли через Google'); } }
      catch (ex) {
        // iPhone, приложение с экрана «Домой»: окно Google иногда не может вернуть результат — подсказываем почту
        const standalone = window.navigator.standalone === true || matchMedia('(display-mode: standalone)').matches;
        err(window.Cloud.errText(ex) + (standalone && /iPhone|iPad/.test(navigator.userAgent) && ex.code !== 'auth/popup-closed-by-user' ? ' На iPhone в приложении с экрана «Домой» вход через Google иногда не срабатывает — войдите по почте (можно добавить пароль к Google-аккаунту через «Забыли пароль?»).' : ''));
      } finally { busy(false); }
    };
    const r = $('#a-reset');
    if (r) r.onclick = async () => {
      const email = $('#a-email').value.trim(); err('');
      if (!email) return err('Введите почту — пришлём на неё ссылку для смены пароля');
      busy(true); try { await a.resetPassword(email); toast('Письмо для смены пароля отправлено'); } catch (ex) { err(window.Cloud.errText(ex)); } finally { busy(false); }
    };
    openModal(sh, $('#backdrop'));
  }
  async function checkNickField(inputSel, hintSel) {
    const inp = $(inputSel), hint = $(hintSel); if (!inp || !hint) return true;
    const nick = window.Cloud.normNick(inp.value); inp.value = nick;
    if (!nick) { hint.textContent = ''; return false; }
    if (!window.Cloud.NICK_RE.test(nick)) { hint.textContent = window.Cloud.errText({ code: 'nick-bad' }); hint.className = 'hint bad'; return false; }
    if (!acc().user) { hint.textContent = ''; return true; } // до входа занятость проверит регистрация
    try { const free = await acc().isNickFree(nick); hint.textContent = free ? '✓ Ник свободен' : 'Ник занят'; hint.className = 'hint ' + (free ? 'good' : 'bad'); return free; }
    catch { hint.textContent = ''; return true; }
  }

  // ---------- Профиль ----------
  let chatProfiles = {}, profilesAt = 0; // публичные профили (фото, оформление) — общие для чата, рейтинга и людей
  // ---------- Оформление профиля (как в Telegram): статус, живой фон шапки, рамка аватара, имя, цвет ----------
  const LOOK = {
    bg: [['none', 'Без фона'], ['aurora', 'Сияние'], ['stars', 'Звёзды'], ['snow', 'Снег'], ['bokeh', 'Огоньки'], ['bubbles', 'Пузыри'], ['confetti', 'Конфетти'], ['storm', 'Гроза'], ['fire', 'Пламя'],
      ['hearts', 'Сердечки'], ['matrix', 'Матрица'], ['fireflies', 'Светлячки'], ['rain', 'Дождь'], ['sakura', 'Сакура'], ['galaxy', 'Галактика']],
    frame: [['none', 'Без рамки'], ['fire', 'Огонь'], ['neon', 'Неон'], ['gold', 'Золото'], ['rainbow', 'Радуга'], ['sparks', 'Искры'], ['ice', 'Лёд'],
      ['love', 'Любовь'], ['electric', 'Молния'], ['toxic', 'Кислота'], ['cosmos', 'Космос'], ['lava', 'Лава'], ['silver', 'Серебро']],
    cover: [['none', 'Без обложки'], ['night', 'Ночной город'], ['mount', 'Горы'], ['sea', 'Море'], ['space', 'Космос'], ['forest', 'Лес'], ['sklad', 'Склад'], ['synth', 'Ретро-неон'], ['sakura', 'Сакура']],
    name: [['none', 'Обычное'], ['gold', 'Золото'], ['fire', 'Огонь'], ['ocean', 'Океан'], ['rainbow', 'Радуга'], ['glow', 'Свечение'], ['neon', 'Неон']],
    theme: [['none', '', 'Как в приложении'], ['orange', '#E8590C'], ['red', '#E03131'], ['pink', '#D6336C'], ['violet', '#7048E8'], ['blue', '#1C7ED6'], ['teal', '#0CA678'], ['green', '#37B24D'], ['gold', '#F59F00']],
    status: ['', '🔥', '😎', '😴', '🏆', '💪', '⚡', '🚀', '👑', '💎', '🎯', '📦', '🛒', '☕', '🍕', '🎧', '🎮', '❤️', '💔', '😂', '🤬', '🥶', '🥵', '🤯', '🙏', '👻', '🐺', '🦁', '🐱', '🌙', '⭐', '🌈', '🍀', '💤', '🤑', '🥊'],
  };
  const lookOf = (o) => {
    const f = (o && o.fx) || {}, ok = (k, v) => LOOK[k].some((x) => x[0] === v);
    return { bg: ok('bg', f.bg) ? f.bg : 'none', frame: ok('frame', f.frame) ? f.frame : 'none', name: ok('name', f.name) ? f.name : 'none', theme: ok('theme', f.theme) ? f.theme : 'none', cover: ok('cover', f.cover) ? f.cover : 'none' };
  };
  const themeColor = (fx) => { const t = LOOK.theme.find((x) => x[0] === (fx && fx.theme)); return t && t[1] ? t[1] : ''; };
  // Аватар в рамке (рамка — анимация CSS). Если загружен полный профиль — берём его фото (чётче копии из рейтинга)
  function avatarFx(av, size, o) {
    const full = o && o.uid && chatProfiles[o.uid] && chatProfiles[o.uid].avatar;
    if (full && full.kind === 'photo' && av && av.kind === 'photo' && full.v.length > av.v.length) av = full;
    const fx = lookOf(o), inner = avatarHtml(av, size);
    return fx.frame === 'none' ? inner : `<span class="av-fr fr-${fx.frame}" style="--s:${size}px">${inner}</span>`;
  }
  // Отображаемое имя: если администратор задал подмену — видят её все, кроме выбранных им (и самого сборщика)
  function shownName(uid, name) {
    const Cl = CL(), al = uid && Cl && Cl.social && Cl.social.aliases && Cl.social.aliases[uid];
    if (!al) return name;
    const me = myUid();
    if (me && (me === uid || al.allow.includes(me) || (Cl.admin && Cl.admin.isAdmin()))) return name;
    return al.alias;
  }
  // Цитата в чате: имя автора по исходному сообщению или по профилю
  function replyName(r, msgs) {
    const t = msgs && msgs.find((x) => x.id === r.id);
    if (t) return shownName(t.uid, r.name);
    const p = Object.values(chatProfiles).find((x) => x.name === r.name);
    return p ? shownName(p.uid, r.name) : r.name;
  }
  // Имя с эффектом и статусом
  function nameFx(name, o) {
    const fx = lookOf(o), st = o && o.status ? `<span class="st-emo">${esc(o.status)}</span>` : '';
    return `<span class="nm ${fx.name !== 'none' ? 'nm-' + fx.name : ''}">${esc(shownName(o && o.uid, name))}</span>${st}`;
  }
  // Онлайн: по отметкам присутствия в чате
  function seenText(uid) {
    const Cl = CL(), m = Cl && Cl.chat && Cl.chat.members && Cl.chat.members[uid];
    if (!m || !m.lastSeen) return '';
    const d = Date.now() - m.lastSeen;
    if (d < 150e3) return '<b class="online">в сети</b>';
    const min = Math.round(d / 60e3), h = Math.round(d / 3600e3), days = Math.round(d / 86400e3);
    return 'был(а) ' + (min < 60 ? `${min} ${plural(min, 'минуту', 'минуты', 'минут')} назад` : h < 24 ? `${h} ${plural(h, 'час', 'часа', 'часов')} назад` : days === 1 ? 'вчера' : `${days} ${plural(days, 'день', 'дня', 'дней')} назад`);
  }
  // Шапка профиля: живой фон + аватар + имя
  function heroHtml(p, sub, opts = {}) {
    const fx = lookOf(p), col = themeColor(fx) || 'var(--accent)';
    const av = p.avatar && p.avatar.kind === 'photo' && !opts.noOpen ? `<button class="av-open" data-av-open aria-label="Открыть фото">${avatarFx(p.avatar, 96, p)}</button>` : avatarFx(p.avatar, 96, p);
    return `<div class="phero ${fx.bg !== 'none' ? 'has-bg' : ''} ${fx.cover !== 'none' ? 'has-cover' : ''}" style="--hc:${col}"><canvas class="phero-bg" data-fx="${fx.bg}"></canvas>${coverHtml(fx.cover)}
      <div class="phero-in">${av}<div class="phero-name">${nameFx(p.name, p)}</div><div class="phero-sub">${sub}</div></div></div>`;
  }
  // Обложки профиля: рисованные сцены (SVG), без загрузки картинок
  function coverHtml(id) {
    const S = {
      night: `<defs><linearGradient id="cvN" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b1a3a"/><stop offset="1" stop-color="#3b2a6b"/></linearGradient></defs><rect width="400" height="120" fill="url(#cvN)"/><circle cx="330" cy="30" r="14" fill="#fff4c2"/><circle cx="336" cy="26" r="13" fill="#1b2350"/>
        ${[[0, 70, 40], [38, 52, 30], [66, 80, 34], [98, 40, 26], [122, 62, 44], [164, 30, 30], [192, 74, 36], [226, 50, 28], [252, 66, 40], [290, 44, 30], [318, 78, 36], [352, 56, 48]].map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="${120 - y}" fill="#0a1024"/>${Array.from({ length: 6 }, (_, i) => `<rect x="${x + 5 + (i % 3) * (w / 3.4)}" y="${y + 8 + Math.floor(i / 3) * 14}" width="4" height="6" fill="${(x + i) % 3 ? '#ffd76a' : '#2a3560'}"/>`).join('')}`).join('')}`,
      mount: `<defs><linearGradient id="cvM" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff9a62"/><stop offset="1" stop-color="#ffd8a8"/></linearGradient></defs><rect width="400" height="120" fill="url(#cvM)"/><circle cx="270" cy="62" r="22" fill="#fff1d6"/>
        <path d="M0 90 L60 40 L110 80 L170 30 L240 85 L300 45 L360 80 L400 55 V120 H0Z" fill="#b5577a" opacity=".75"/><path d="M0 105 L80 66 L150 100 L220 60 L300 104 L360 78 L400 96 V120 H0Z" fill="#6b3a6e"/>`,
      sea: `<defs><linearGradient id="cvS" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffb37a"/><stop offset="1" stop-color="#ffd59e"/></linearGradient><linearGradient id="cvS2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b8ac4"/><stop offset="1" stop-color="#145a8a"/></linearGradient></defs><rect width="400" height="120" fill="url(#cvS)"/><circle cx="200" cy="66" r="20" fill="#fff0c4"/><rect y="66" width="400" height="54" fill="url(#cvS2)"/><path d="M178 72 h44 M186 78 h28 M193 84 h14" stroke="#fff0c4" stroke-width="2" opacity=".6"/>
        ${[78, 92, 106].map((y, i) => `<path d="M0 ${y} q25 -6 50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0" fill="none" stroke="rgba(255,255,255,${0.5 - i * 0.12})" stroke-width="2"/>`).join('')}`,
      space: `<rect width="400" height="120" fill="#140b2e"/>${Array.from({ length: 40 }, (_, i) => `<circle cx="${(i * 97) % 400}" cy="${(i * 53) % 120}" r="${(i % 3) * 0.5 + 0.5}" fill="#fff" opacity="${0.4 + (i % 4) * 0.15}"/>`).join('')}
        <circle cx="300" cy="58" r="26" fill="#ff8a65"/><circle cx="292" cy="50" r="26" fill="#ffab91" opacity=".5"/><ellipse cx="300" cy="60" rx="46" ry="9" fill="none" stroke="#ffe0b2" stroke-width="3" transform="rotate(-14 300 60)"/><circle cx="80" cy="34" r="9" fill="#90caf9"/>`,
      forest: `<defs><linearGradient id="cvF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a5d8ff"/><stop offset="1" stop-color="#d3f9d8"/></linearGradient></defs><rect width="400" height="120" fill="url(#cvF)"/>
        ${Array.from({ length: 18 }, (_, i) => { const x = i * 24 - 4, h = 50 + ((i * 37) % 40), c = i % 2 ? '#2b8a3e' : '#2f9e44'; return `<path d="M${x} 120 L${x + 14} ${120 - h} L${x + 28} 120Z" fill="${c}"/>`; }).join('')}
        ${Array.from({ length: 14 }, (_, i) => { const x = i * 30 + 6, h = 30 + ((i * 23) % 26); return `<path d="M${x} 120 L${x + 16} ${120 - h} L${x + 32} 120Z" fill="#1b5e20"/>`; }).join('')}`,
      sklad: `<rect width="400" height="120" fill="#ffe8cc"/>${[0, 1, 2, 3, 4].map((c) => `<g transform="translate(${8 + c * 80} 0)"><rect x="0" y="10" width="4" height="110" fill="#e8590c"/><rect x="66" y="10" width="4" height="110" fill="#e8590c"/>
        ${[34, 66, 98].map((y) => `<rect x="0" y="${y}" width="70" height="4" fill="#f08c00"/>`).join('')}${[[6, 16, 20, 18], [30, 20, 16, 14], [48, 14, 16, 20], [8, 48, 24, 18], [36, 52, 26, 14], [10, 82, 18, 16], [32, 78, 30, 20]].map(([x, y, w, h], i) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="1.5" fill="${['#c98b52', '#d9a066', '#b97a45'][(i + c) % 3]}"/><rect x="${x + w / 2 - 1}" y="${y}" width="2" height="${h}" fill="#e9c08a"/>`).join('')}</g>`).join('')}`,
      synth: `<defs><linearGradient id="cvY" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a0536"/><stop offset=".55" stop-color="#7b1fa2"/><stop offset=".56" stop-color="#12002a"/><stop offset="1" stop-color="#12002a"/></linearGradient><linearGradient id="cvSun" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe259"/><stop offset="1" stop-color="#ff2fa0"/></linearGradient></defs>
        <rect width="400" height="120" fill="url(#cvY)"/><circle cx="200" cy="66" r="30" fill="url(#cvSun)"/>${[54, 60, 64].map((y) => `<rect x="160" y="${y}" width="80" height="2.5" fill="#1a0536"/>`).join('')}
        ${Array.from({ length: 7 }, (_, i) => `<line x1="0" y1="${68 + i * i * 1.2 + i * 4}" x2="400" y2="${68 + i * i * 1.2 + i * 4}" stroke="#ff2fa0" stroke-width="1" opacity=".8"/>`).join('')}${Array.from({ length: 13 }, (_, i) => `<line x1="200" y1="67" x2="${-200 + i * 66}" y2="120" stroke="#ff2fa0" stroke-width="1" opacity=".7"/>`).join('')}`,
      sakura: `<defs><linearGradient id="cvK" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe3ec"/><stop offset="1" stop-color="#fff5f8"/></linearGradient></defs><rect width="400" height="120" fill="url(#cvK)"/>
        <path d="M400 8 C330 20 300 40 250 46 C210 50 180 70 150 66 M300 34 C290 60 270 70 262 92 M220 50 C200 30 180 26 160 14" fill="none" stroke="#6d4c41" stroke-width="5" stroke-linecap="round"/>
        ${Array.from({ length: 26 }, (_, i) => { const pts = [[380, 14], [350, 22], [320, 28], [290, 40], [260, 44], [230, 48], [200, 58], [170, 64], [150, 64], [296, 52], [280, 70], [268, 86], [206, 36], [184, 26], [166, 16]]; const [x, y] = pts[i % pts.length]; const dx = ((i * 13) % 18) - 9, dy = ((i * 7) % 14) - 7; return `<g transform="translate(${x + dx} ${y + dy})">${[0, 72, 144, 216, 288].map((a) => `<ellipse rx="3.2" ry="5" cy="-4.5" fill="${i % 3 ? '#ffafcc' : '#ff8fb8'}" transform="rotate(${a})"/>`).join('')}<circle r="1.8" fill="#fff3bf"/></g>`; }).join('')}`,
    };
    return S[id] ? `<svg class="phero-cover" viewBox="0 0 400 120" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${S[id]}</svg>` : '';
  }
  // Живые фоны: лёгкие частицы на canvas, останавливаются, когда шапку закрыли
  function startHeroFx(root) {
    (root || document).querySelectorAll('canvas.phero-bg').forEach((cv) => {
      if (cv.dataset.on) return; cv.dataset.on = '1';
      const kind = cv.dataset.fx; if (!kind || kind === 'none') return;
      const g = cv.getContext('2d'), dpr = Math.min(2, window.devicePixelRatio || 1);
      const hc = getComputedStyle(cv.parentNode).getPropertyValue('--hc').trim() || '#E8590C';
      let W = 0, H = 0;
      const size = () => { const r = cv.getBoundingClientRect(); W = r.width; H = r.height; cv.width = W * dpr; cv.height = H * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0); };
      size();
      const R = Math.random, P = [];
      const n = Math.round(({ stars: 70, snow: 60, bokeh: 16, bubbles: 22, confetti: 60, storm: 70, fire: 50, aurora: 0, hearts: 18, matrix: 26, fireflies: 22, rain: 80, sakura: 26, galaxy: 140 }[kind] || 0) * Math.min(1, Math.max(0.3, (W * H) / 90000)));
      for (let i = 0; i < n; i++) P.push({ x: R() * W, y: R() * H, r: R(), v: R(), a: R() * 6.28, c: R() });
      const CONF = ['#ff6b6b', '#ffd43b', '#69db7c', '#4dabf7', '#da77f2', '#ff922b'];
      let t0 = performance.now(), flash = 0, bolt = null;
      const frame = (now) => {
        if (!cv.isConnected) return;
        requestAnimationFrame(frame);
        if (document.hidden) return;
        const t = (now - t0) / 1000, dt = 1 / 60;
        const rc = cv.getBoundingClientRect();
        if (rc.bottom < 0 || rc.top > innerHeight) return; // за экраном — не рисуем, бережём батарею
        if (rc.width !== W) size();
        g.clearRect(0, 0, W, H);
        if (kind === 'aurora') {
          for (let i = 0; i < 4; i++) {
            const x = W * (0.2 + 0.6 * (0.5 + 0.5 * Math.sin(t * 0.4 + i * 1.7))), y = H * (0.3 + 0.3 * Math.sin(t * 0.3 + i));
            const gr = g.createRadialGradient(x, y, 0, x, y, W * 0.55);
            gr.addColorStop(0, ['rgba(80,255,180,.55)', 'rgba(120,120,255,.5)', 'rgba(255,90,200,.45)', 'rgba(60,200,255,.5)'][i]); gr.addColorStop(1, 'rgba(0,0,0,0)');
            g.fillStyle = gr; g.fillRect(0, 0, W, H);
          }
        }
        for (const p of P) {
          if (kind === 'stars') {
            const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * (0.6 + p.v * 2) + p.a));
            g.fillStyle = `rgba(255,255,240,${tw})`; g.beginPath(); g.arc(p.x, p.y, 0.6 + p.r * 1.4, 0, 6.28); g.fill();
          } else if (kind === 'snow') {
            p.y += (12 + p.v * 26) * dt; p.x += Math.sin(t + p.a) * 0.3; if (p.y > H + 4) { p.y = -4; p.x = R() * W; }
            g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(p.x, p.y, 1 + p.r * 2.2, 0, 6.28); g.fill();
          } else if (kind === 'bokeh') {
            p.x += Math.cos(p.a) * 8 * dt; p.y += Math.sin(p.a) * 6 * dt; if (p.x < -40) p.x = W + 40; if (p.x > W + 40) p.x = -40; if (p.y < -40) p.y = H + 40; if (p.y > H + 40) p.y = -40;
            const rr = 10 + p.r * 28, gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, rr);
            gr.addColorStop(0, `hsla(${30 + p.c * 300},90%,70%,.45)`); gr.addColorStop(1, 'hsla(0,0%,100%,0)');
            g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, rr, 0, 6.28); g.fill();
          } else if (kind === 'bubbles') {
            p.y -= (14 + p.v * 22) * dt; p.x += Math.sin(t * 1.5 + p.a) * 0.4; if (p.y < -12) { p.y = H + 12; p.x = R() * W; }
            g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1.2; g.beginPath(); g.arc(p.x, p.y, 3 + p.r * 8, 0, 6.28); g.stroke();
            g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.arc(p.x - 1.5, p.y - 1.5, 1.2, 0, 6.28); g.fill();
          } else if (kind === 'confetti') {
            p.y += (30 + p.v * 40) * dt; p.a += (2 + p.v * 4) * dt; p.x += Math.sin(p.a) * 0.6; if (p.y > H + 8) { p.y = -8; p.x = R() * W; }
            g.save(); g.translate(p.x, p.y); g.rotate(p.a); g.scale(1, Math.abs(Math.cos(p.a * 1.3)));
            g.fillStyle = CONF[Math.floor(p.c * CONF.length)]; g.fillRect(-3, -5, 6, 10); g.restore();
          } else if (kind === 'storm') {
            p.y += (260 + p.v * 160) * dt; p.x -= 40 * dt; if (p.y > H) { p.y = -20; p.x = R() * (W + 60); }
            g.strokeStyle = 'rgba(180,200,255,.45)'; g.lineWidth = 1; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(p.x - 3, p.y + 12); g.stroke();
          } else if (kind === 'hearts') {
            p.y -= (16 + p.v * 20) * dt; p.x += Math.sin(t * 1.2 + p.a) * 0.4; if (p.y < -12) { p.y = H + 12; p.x = R() * W; }
            const sz = 5 + p.r * 7; g.fillStyle = `hsla(${340 + p.c * 25},90%,${62 + p.r * 15}%,${0.45 + p.v * 0.4})`;
            g.beginPath(); g.moveTo(p.x, p.y + sz * 0.35); g.bezierCurveTo(p.x - sz, p.y - sz * 0.4, p.x - sz * 0.4, p.y - sz, p.x, p.y - sz * 0.45); g.bezierCurveTo(p.x + sz * 0.4, p.y - sz, p.x + sz, p.y - sz * 0.4, p.x, p.y + sz * 0.35); g.fill();
          } else if (kind === 'matrix') {
            p.y += (40 + p.v * 70) * dt; if (p.y > H + 60) { p.y = -R() * 60; p.x = Math.floor(R() * (W / 11)) * 11 + 4; }
            g.font = '11px monospace';
            for (let j = 0; j < 6; j++) { g.fillStyle = j ? `rgba(80,255,120,${0.6 - j * 0.1})` : 'rgba(200,255,210,.95)'; g.fillText(String.fromCharCode(0x30A0 + ((Math.floor(t * 8 + p.a * 10 + j * 7)) % 90)), p.x, p.y - j * 12); }
          } else if (kind === 'fireflies') {
            p.x += Math.cos(p.a + t * 0.5) * 10 * dt; p.y += Math.sin(p.a * 1.3 + t * 0.4) * 8 * dt;
            if (p.x < 0) p.x = W; if (p.x > W) p.x = 0; if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
            const gl = 0.25 + 0.75 * Math.abs(Math.sin(t * (0.8 + p.v) + p.a)), rr = 6 + p.r * 6;
            const gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, rr); gr.addColorStop(0, `rgba(230,255,120,${gl})`); gr.addColorStop(1, 'rgba(230,255,120,0)');
            g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, rr, 0, 6.28); g.fill();
          } else if (kind === 'rain') {
            p.y += (320 + p.v * 200) * dt; if (p.y > H) { p.y = -14; p.x = R() * W; }
            g.strokeStyle = 'rgba(170,210,255,.5)'; g.lineWidth = 1; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(p.x, p.y + 10 + p.r * 6); g.stroke();
          } else if (kind === 'sakura') {
            p.y += (18 + p.v * 22) * dt; p.a += dt * 1.6; p.x += Math.sin(p.a) * 0.7 + 10 * dt; if (p.y > H + 8 || p.x > W + 8) { p.y = -8; p.x = R() * W - 20; }
            g.save(); g.translate(p.x, p.y); g.rotate(p.a); g.scale(Math.max(0.2, Math.abs(Math.cos(p.a * 1.4))), 1);
            g.fillStyle = p.c < 0.5 ? 'rgba(255,183,213,.9)' : 'rgba(255,214,231,.9)'; g.beginPath(); g.ellipse(0, 0, 3 + p.r * 2, 5 + p.r * 2, 0, 0, 6.28); g.fill(); g.restore();
          } else if (kind === 'galaxy') {
            const arm = Math.floor(p.c * 3), d = 8 + p.r * Math.min(W, H) * 0.6, ang = arm * 2.09 + d * 0.035 + t * 0.15 + (p.v - 0.5) * 0.5;
            const x = W / 2 + Math.cos(ang) * d * 1.6, y = H / 2 + Math.sin(ang) * d * 0.7;
            g.fillStyle = `hsla(${220 + p.c * 100},90%,${70 + p.v * 25}%,${0.35 + 0.5 * (1 - p.r)})`; g.beginPath(); g.arc(x, y, 0.6 + (1 - p.r) * 1.2, 0, 6.28); g.fill();
          } else if (kind === 'fire') {
            p.y -= (25 + p.v * 45) * dt; p.x += Math.sin(t * 3 + p.a) * 0.5; p.r -= 0.25 * dt; if (p.y < -10 || p.r < 0) { p.y = H + 5; p.x = R() * W; p.r = 0.6 + R() * 0.4; }
            g.fillStyle = `hsla(${20 + p.c * 30},100%,${55 + p.r * 20}%,${p.r})`; g.beginPath(); g.arc(p.x, p.y, 1 + p.r * 2.4, 0, 6.28); g.fill();
          }
        }
        if (kind === 'fire') { const gr = g.createLinearGradient(0, H, 0, H * 0.4); gr.addColorStop(0, 'rgba(255,90,20,.55)'); gr.addColorStop(1, 'rgba(255,90,20,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
        if (kind === 'stars' && R() < 0.006) bolt = { x: R() * W, y: R() * H * 0.5, life: 1, shoot: true };
        if (kind === 'storm' && R() < 0.008) { flash = 1; const pts = [[R() * W, 0]]; while (pts[pts.length - 1][1] < H) { const [x, y] = pts[pts.length - 1]; pts.push([x + (R() - 0.5) * 40, y + 12 + R() * 20]); } bolt = { pts, life: 1 }; }
        if (bolt && bolt.shoot) { bolt.x += 260 * dt; bolt.y += 110 * dt; bolt.life -= dt * 1.5; const gr = g.createLinearGradient(bolt.x - 40, bolt.y - 17, bolt.x, bolt.y); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(1, `rgba(255,255,255,${bolt.life})`); g.strokeStyle = gr; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bolt.x - 40, bolt.y - 17); g.lineTo(bolt.x, bolt.y); g.stroke(); if (bolt.life <= 0) bolt = null; }
        else if (bolt && bolt.pts) { g.strokeStyle = `rgba(220,230,255,${bolt.life})`; g.lineWidth = 2; g.shadowColor = '#9cf'; g.shadowBlur = 12; g.beginPath(); bolt.pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke(); g.shadowBlur = 0; bolt.life -= dt * 3; if (bolt.life <= 0) bolt = null; }
        if (flash > 0) { g.fillStyle = `rgba(200,215,255,${flash * 0.35})`; g.fillRect(0, 0, W, H); flash -= dt * 4; }
      };
      requestAnimationFrame(frame);
      void hc;
    });
  }
  // Полка значков
  const shelfHtml = (list) => list.length ? `<div class="card shelf-card"><h2>Достижения <small class="muted">${list.length}</small></h2><div class="shelf">${list.map((a) => `<div class="sh-item" title="${esc(a.desc || '')}"><i>${a.icon}</i><small>${esc(a.title)}</small></div>`).join('')}</div></div>` : '';

  // Редактор оформления
  function openLook() {
    const Cl = CL(), a = acc(); if (!a || !a.profile) return;
    const p = a.profile, cur = { status: p.status || '', fx: lookOf(p) };
    const sh = $('#sheet');
    const chip = (k, id, label) => `<button type="button" class="lk-chip ${cur.fx[k] === id ? 'on' : ''}" data-k="${k}" data-v="${id}">${label}</button>`;
    const draw = () => {
      const pv = { ...p, status: cur.status, fx: cur.fx };
      sh.innerHTML = `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">Оформление</div><div class="sheet-sub">Увидят все сборщики</div></div><button class="icon-btn" data-close>×</button></div>
        <div class="lk-prev" style="--accent:${themeColor(cur.fx) || ''}">${heroHtml(pv, '@' + esc(p.nick), { noOpen: true })}</div>
        <h3 class="adm-h">Статус</h3><div class="lk-emo">${LOOK.status.map((e) => `<button type="button" class="${cur.status === e ? 'on' : ''}" data-st="${e}">${e || '✕'}</button>`).join('')}</div>
        <h3 class="adm-h">Обложка</h3><div class="lk-row">${LOOK.cover.map(([id, l]) => chip('cover', id, l)).join('')}</div>
        <h3 class="adm-h">Фон шапки</h3><div class="lk-row">${LOOK.bg.map(([id, l]) => chip('bg', id, l)).join('')}</div>
        <h3 class="adm-h">Рамка аватарки</h3><div class="lk-row">${LOOK.frame.map(([id, l]) => chip('frame', id, l)).join('')}</div>
        <h3 class="adm-h">Имя</h3><div class="lk-row">${LOOK.name.map(([id, l]) => `<button type="button" class="lk-chip ${cur.fx.name === id ? 'on' : ''}" data-k="name" data-v="${id}"><span class="nm ${id !== 'none' ? 'nm-' + id : ''}">${l}</span></button>`).join('')}</div>
        <h3 class="adm-h">Цвет профиля</h3><div class="lk-colors">${LOOK.theme.map(([id, c, l]) => `<button type="button" class="${cur.fx.theme === id ? 'on' : ''}" data-k="theme" data-v="${id}" title="${l || ''}" style="${c ? 'background:' + c : ''}">${c ? '' : 'A'}</button>`).join('')}</div>
        <button class="btn btn-primary" id="lk-save" style="margin-top:16px">Сохранить</button>`;
      startHeroFx(sh);
    };
    draw();
    sh.onclick = async (e) => {
      const st = e.target.closest('[data-st]'); if (st) { cur.status = st.dataset.st; return draw(); }
      const c = e.target.closest('[data-k]'); if (c) { cur.fx[c.dataset.k] = c.dataset.v; return draw(); }
      if (e.target.closest('#lk-save')) {
        const b = $('#lk-save'); b.disabled = true; b.textContent = 'Сохраняю…';
        try { await Cl.account.updateLook(cur); Object.assign(a.profile, { status: cur.status, fx: { ...cur.fx } }); toast('Оформление сохранено'); closeModal(); refreshAccountCard(); loadChatProfiles(); if (ui.tab === 'crew') renderCrew(); }
        catch (ex) { toast(Cl.errText(ex)); b.disabled = false; b.textContent = 'Сохранить'; }
      }
    };
    if (!modalStack.length) openModal(sh, $('#backdrop'));
  }

  function openProfile() {
    const a = acc(); if (!a || !a.user) return;
    const p = a.profile;
    if (!p) return openProfileEdit(true);
    const s = myStats(), sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">Профиль</div></div><button class="icon-btn" data-close>×</button></div>
      <div class="prof-themed" style="${themeColor(lookOf(p)) ? '--accent:' + themeColor(lookOf(p)) : ''}">
      ${heroHtml(p, `@${esc(p.nick)} · в приложении с ${esc(fmtDateTs(p.createdAt))}`)}
      <button class="btn btn-secondary" id="p-look" style="margin-bottom:14px">🎨 Оформление профиля</button>
      <div class="tiles">
        <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.lines)}</div></div>
        <div class="tile"><div class="t-label">Рабочих дней</div><div class="t-value num">${N(s.days)}</div></div>
        <div class="tile"><div class="t-label">Примерный заработок</div><div class="t-value num">${M(s.earn)}</div><div class="t-sub">сумма смен, без премий</div></div>
        <div class="tile"><div class="t-label">В среднем за день</div><div class="t-value num">${N(Math.round(s.avg))}</div><div class="t-sub">линий</div></div>
        <div class="tile wide"><div class="t-label">Личный рекорд за день</div><div class="t-value num">${N(s.best)} линий</div></div>
      </div>
      <p class="hint" style="margin:-4px 0 14px">Эти цифры видите только вы. Показывать ли статистику другим сборщикам — переключатели в разделе «Профиль».</p>
      ${shelfHtml(achs().filter((x) => x.done).reverse())}
      <button class="btn btn-primary" id="p-edit">Изменить профиль</button>
      <button class="btn btn-danger" id="p-delete" style="margin-top:10px">Удалить аккаунт</button></div>`;
    startHeroFx(sh);
    $('#p-look').onclick = () => openLook();
    $('#p-edit').onclick = () => { closeModal(); setTimeout(() => openProfileEdit(false), 250); };
    $('#p-delete').onclick = () => { closeModal(); setTimeout(deleteAccountFlow, 250); };
    openModal(sh, $('#backdrop'));
  }
  // create = true: профиль ещё не создан (вход через Google или ник оказался занят)
  let signupDraft = null; // имя из формы регистрации — если ник оказался занят, подставим его в профиль
  function openProfileEdit(create) {
    const Cl = CL(), a = acc(); if (!a || !a.user) return;
    const p = a.profile || (signupDraft ? { name: signupDraft.name } : {});
    let avatar = p.avatar || Cl.avatars.defaultAvatar(a.user.uid);
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${create ? 'Ваш профиль' : 'Изменить профиль'}</div><div class="sheet-sub">${create ? 'Ник и имя увидят другие сборщики' : ''}</div></div>${create ? '' : '<button class="icon-btn" data-close>×</button>'}</div>
      <form id="pe-form" novalidate>
        <div class="prof-head" id="pe-av">${avatarHtml(avatar, 88)}</div>
        <div class="av-grid">${Cl.avatars.PRESETS.map((x, i) => `<button type="button" class="av-opt" data-av="${i}" aria-label="Аватар ${x[0]}">${avatarHtml(Cl.avatars.presetAvatar(i), 40)}</button>`).join('')}</div>
        <button class="btn btn-secondary" type="button" id="pe-photo" style="margin:10px 0 16px">📷 Загрузить своё фото</button>
        <input type="file" id="pe-file" accept="image/*" hidden>
        <div class="field"><label for="pe-name">Имя</label><input class="input" id="pe-name" maxlength="40" value="${esc(p.name || (a.user.displayName || ''))}"></div>
        <div class="field"><label for="pe-nick">Ник <span>латиница, цифры, _ и .</span></label><input class="input" id="pe-nick" maxlength="20" autocapitalize="none" value="${esc(p.nick || '')}"><div class="hint" id="pe-nick-hint"></div></div>
        <p class="error" id="pe-error"></p>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        ${create ? '<button class="btn btn-ghost" type="button" id="pe-later">Позже</button>' : '<button class="btn btn-secondary" type="button" data-close>Отмена</button>'}
      </form>`;
    const showAv = () => { $('#pe-av').innerHTML = avatarHtml(avatar, 88); sh.querySelectorAll('.av-opt').forEach((b) => b.classList.toggle('sel', avatar.kind === 'preset' && avatar.v === Cl.avatars.presetAvatar(+b.dataset.av).v)); };
    showAv();
    sh.querySelectorAll('.av-opt').forEach((b) => (b.onclick = () => { avatar = Cl.avatars.presetAvatar(+b.dataset.av); showAv(); }));
    $('#pe-photo').onclick = () => { const f = $('#pe-file'); f.value = ''; f.click(); };
    $('#pe-file').onchange = async () => {
      const f = $('#pe-file').files[0]; if (!f) return;
      try { avatar = await Cl.avatars.photoAvatar(f); showAv(); } catch (ex) { $('#pe-error').textContent = ex.message; }
    };
    $('#pe-nick').addEventListener('blur', () => checkNickField('#pe-nick', '#pe-nick-hint'));
    const later = $('#pe-later'); if (later) later.onclick = () => closeModal();
    $('#pe-form').onsubmit = async (e) => {
      e.preventDefault(); $('#pe-error').textContent = '';
      const name = $('#pe-name').value.trim(), nick = Cl.normNick($('#pe-nick').value);
      sh.querySelectorAll('button, input').forEach((x) => (x.disabled = true));
      try {
        if (a.profile) await a.updateProfile({ name, nick, avatar }); else await a.createProfile({ name, nick, avatar });
        signupDraft = null; closeModal(); toast('Профиль сохранён');
      } catch (ex) { $('#pe-error').textContent = Cl.errText(ex); }
      finally { sh.querySelectorAll('button, input').forEach((x) => (x.disabled = false)); }
    };
    openModal(sh, $('#backdrop'));
  }

  // ---------- Первый вход: на устройстве и в облаке разные данные ----------
  async function askSyncChoice() {
    const sy = CL() && CL().sync; if (!sy || !sy.pendingChoice || askSyncChoice.open) return;
    if (modalStack.length) { clearTimeout(askSyncChoice.t); askSyncChoice.t = setTimeout(askSyncChoice, 700); return; } // дождёмся, пока закроется окно входа
    askSyncChoice.open = true;
    const { localDays, cloudDays } = sy.pendingChoice;
    const choice = await dialog({ title: 'Данные есть и здесь, и в аккаунте',
      text: `На этом устройстве ${localDays} ${plural(localDays, 'смена', 'смены', 'смен')}, в аккаунте ${cloudDays}. Что сделать? Перед этим автоматически сохраняется копия данных устройства.`,
      buttons: [{ text: 'Объединить (рекомендуется)', cls: 'btn-primary', value: 'merge' }, { text: 'Взять данные из аккаунта', value: 'cloud' }, { text: 'Оставить данные этого устройства', value: 'local' }, { text: 'Решить позже', value: null }] });
    askSyncChoice.open = false;
    if (!choice) return;
    if (choice !== 'merge' && !(await confirmDlg('Точно?', choice === 'cloud' ? 'Смены этого устройства, которых нет в аккаунте, будут заменены данными аккаунта (копия сохранена).' : 'Смены аккаунта, которых нет на этом устройстве, будут удалены из облака (копия устройства сохранена).', 'Да'))) return;
    await sy.resolveChoice(choice);
    toast(choice === 'merge' ? 'Данные объединены' : 'Готово');
  }

  async function logoutFlow() {
    const a = acc(); if (!a) return;
    const v = await dialog({ title: 'Выйти из аккаунта?', text: 'Данные в аккаунте сохранятся. Что сделать с данными на этом устройстве?',
      buttons: [{ text: 'Выйти, оставить на устройстве', cls: 'btn-primary', value: 'keep' }, { text: 'Выйти и очистить устройство', cls: 'btn-danger', value: 'wipe' }, { text: 'Отмена', value: null }] });
    if (!v) return;
    await a.signOut();
    if (v === 'wipe') { CL().sync.forget(); state = C.defaultState(); save(); applyTheme(); renderAll(); }
    toast('Вы вышли из аккаунта');
  }
  async function deleteAccountFlow() {
    const a = acc(); if (!a || !a.user) return;
    const pwd = a.user.providerData.some((p) => p.providerId === 'password');
    const res = await dialog({ title: 'Удалить аккаунт?', text: 'Профиль, ник и все данные в облаке будут удалены без возможности восстановления. Смены на этом устройстве останутся.' + (pwd ? ' Введите пароль для подтверждения.' : ' Подтвердите вход через Google.'),
      html: pwd ? '<input class="input" id="del-pass" type="password" autocomplete="current-password" placeholder="Пароль" style="margin-bottom:12px">' : '',
      buttons: [{ text: 'Удалить навсегда', cls: 'btn-danger', read: (d) => ({ ok: true, pass: pwd ? $('#del-pass', d).value : '' }) }, { text: 'Отмена', value: null }] });
    if (!res || !res.ok) return;
    toast('Удаляю аккаунт…');
    try { await a.deleteAccount(res.pass); CL().sync.forget(); toast('Аккаунт удалён'); renderAll(); }
    catch (ex) { dialog({ title: 'Не удалось удалить', text: CL().errText(ex), buttons: [{ text: 'Понятно', value: true }] }); }
  }
  async function restoreBackup() {
    const bk = CL() && CL().sync.backup(); if (!bk) return;
    if (await confirmDlg('Восстановить копию?', `Данные устройства будут заменены копией от ${new Date(bk.at).toLocaleString('ru-RU')}. Изменения уйдут и в облако.`, 'Восстановить')) {
      state = C.normalizeState(JSON.parse(bk.data)).state; save(); applyTheme(); renderAll(); toast('Копия восстановлена');
    }
  }
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act^="acc-"]'); if (!el) return;
    e.preventDefault();
    const act = el.dataset.act;
    if (act === 'acc-login') openAuthSheet('login');
    else if (act === 'acc-register') openAuthSheet('register');
    else if (act === 'acc-profile') openProfile();
    else if (act === 'acc-create-profile') openProfileEdit(true);
    else if (act === 'acc-logout') logoutFlow();
    else if (act === 'acc-choice') askSyncChoice();
    else if (act === 'acc-backup') restoreBackup();
  });

  // =====================================================================
  // ---------- «Сборщики»: рейтинг, список, публичные профили, сравнение ----------
  // =====================================================================
  ui.crew = { sub: 'rank', period: 'week', metric: 'lines', q: '', others: [], range: 30, from: null, to: null };
  let crewUnsub = null, crewCharts = [], crewSearchT = 0;
  const stopCrewWatch = () => { if (crewUnsub) { crewUnsub(); crewUnsub = null; } };
  // «Сегодня» убрано: отчёт о производительности приходит поздно, дневной рейтинг всегда пустой
  const PERIODS = [['week', 'Неделя'], ['month', 'Месяц'], ['all', 'Всё время']];
  const METRICS = [['lines', 'Линии'], ['earn', 'Заработок'], ['avg', 'Среднее'], ['days', 'Дни']];
  const COLORS = ['#E8590C', '#2F6FDB', '#2B8A3E', '#AE3EC9'];
  const metricText = (m, v) => (m === 'earn' ? M(v) : m === 'avg' ? `${N(Math.round(v))} в день` : m === 'days' ? `${N(v)} ${plural(v, 'смена', 'смены', 'смен')}` : `${N(v)} ${plural(v, 'линия', 'линии', 'линий')}`);
  const myUid = () => (acc() && acc().user ? acc().user.uid : null);

  function renderCrew() {
    stopCrewWatch();
    const v = $('#view-crew'), Cl = window.Cloud;
    if (!Cl || !Cl.configured) { v.innerHTML = '<div class="card"><h2>Сборщики</h2><p class="muted" style="margin:0">Раздел работает через облако — в этой сборке оно не подключено.</p></div>'; return; }
    if (!Cl.ready) { v.innerHTML = '<div class="card"><p class="muted" style="margin:0">Загрузка…</p></div>'; return; }
    const a = Cl.account;
    if (!a.user && !a.authReady) { v.innerHTML = '<div class="card"><p class="muted" style="margin:0">Восстанавливаю вход…</p></div>'; return; }
    if (!a.user) {
      v.innerHTML = `<div class="card crew-intro"><div class="crew-emoji">🏆</div><h2>Сборщики</h2>
        <p class="muted">Рейтинг комплектовщиков, профили коллег и сравнение графиков. Ваши смены и зарплата не видны другим — показывать статистику или нет, решаете вы.</p>
        <div class="btn-row"><button class="btn btn-primary" data-act="acc-login">Войти</button><button class="btn btn-secondary" data-act="acc-register">Создать аккаунт</button></div></div>`;
      return;
    }
    if (!a.profile) { v.innerHTML = `<div class="card"><h2>Почти готово</h2><p class="muted">Выберите ник и имя — так вас увидят другие сборщики.</p><button class="btn btn-primary" data-act="acc-create-profile">Заполнить профиль</button></div>`; return; }
    const c = ui.crew;
    v.innerHTML = `<div class="seg subnav">${[['rank', 'Рейтинг'], ['chat', 'Чат'], ['people', 'Люди'], ['compare', 'Сравнение']].map(([k, t]) => `<button data-crew-sub="${k}" class="${c.sub === k ? 'active' : ''}">${t}</button>`).join('')}</div><div id="crew-body"></div>`;
    v.querySelectorAll('[data-crew-sub]').forEach((b) => (b.onclick = () => { c.sub = b.dataset.crewSub; rememberTab(); renderCrew(); }));
    // профили с полными фото — раз в 5 минут
    if (Date.now() - profilesAt > 5 * 60e3 && window.Cloud && window.Cloud.ready && window.Cloud.account.user) { profilesAt = Date.now(); loadChatProfiles(); }
    if (c.sub !== 'chat') leaveChat();
    ({ rank: renderRank, chat: renderChat, people: renderPeople, compare: renderCompare })[c.sub]();
    updateChatBadge();
  }

  // ---------- Рейтинг ----------
  // Дни недели, в которые сборщик внёс смену: Пн…Пт всегда, Сб/Вс — только если работал
  const WD2 = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
  function weekDaysHtml(days, wk, full) {
    const today = window.Cloud.util.dayKey();
    return WD2.map((n, i) => {
      const k = addDays(wk, i), l = days && days[k] ? days[k].lines : 0;
      if (i >= 5 && !l) return '';
      const cls = l ? 'on' : k > today ? 'fut' : 'off';
      return `<i class="wd ${cls}${k === today ? ' today' : ''}" title="${n}${l ? ': ' + N(l) + ' линий' : ''}">${n}${full ? `<b class="num">${l ? N(l) : k > today ? '' : '—'}</b>` : ''}</i>`;
    }).join('');
  }
  // Подгрузить дни периода (неделя/месяц) для карточек рейтинга: закрашенные дни недели и собранные кг.
  // Кэш — пока не изменились итоги периода у сборщика.
  const rkDaysCache = {};
  function fillPeriodDays(rows, box, period) {
    const Cl = window.Cloud, today = Cl.util.dayKey();
    const from = period === 'week' ? Cl.util.mondayOf(today) : period === 'month' ? today.slice(0, 8) + '01' : '2000-01-01';
    const to = period === 'week' ? addDays(from, 6) : period === 'month' ? today.slice(0, 8) + '31' : '2100-12-31';
    rows.forEach((x) => {
      // updatedAt меняется при любом изменении дня (в том числе только веса) — тогда перечитываем
      const sig = `${from}|${x.updatedAt && x.updatedAt.seconds}|${x.lastDay}`, ck = period + ':' + x.uid;
      const put = (days) => {
        if (period === 'week') box.querySelectorAll(`[data-wd="${x.uid}"]`).forEach((el) => { el.innerHTML = weekDaysHtml(days, from); el.classList.add('ready'); });
        let kg = 0; for (const k in days || {}) if (k >= from && k <= to) kg += Number(days[k].kg) || 0;
        box.querySelectorAll(`[data-kg="${x.uid}"]`).forEach((el) => { el.textContent = kg > 0 ? `⚖️ ${fmtKg(kg)}` : ''; });
      };
      const c = rkDaysCache[ck];
      if (c && c.sig === sig) return put(c.days);
      put(c ? c.days : {});
      Cl.social.days(x.uid, from, to).then((days) => { rkDaysCache[ck] = { sig, days }; put(days); }).catch(() => {});
    });
  }
  // Живой фон профиля на карточке рейтинга
  const RANK_FX = 'zarplata2027:rank-fx';
  const rankFx = () => { try { return localStorage.getItem(RANK_FX) === '1'; } catch { return false; } };
  document.addEventListener('change', (e) => { if (e.target.id === 'rank-fx') { try { localStorage.setItem(RANK_FX, e.target.checked ? '1' : '0'); } catch {} toast(e.target.checked ? 'Анимации и фоны в рейтинге включены' : 'Рейтинг без анимаций'); } });
  const cardBg = (x) => { const fx = lookOf(x); return fx.bg === 'none' || !rankFx() ? { cls: '', canvas: '', style: '' } : { cls: 'has-bg', canvas: `<canvas class="phero-bg" data-fx="${fx.bg}"></canvas>`, style: ` style="--hc:${themeColor(fx) || 'var(--accent)'}"` }; };
  function renderRank() {
    const c = ui.crew, Cl = window.Cloud, my = Cl.social.my;
    if (!PERIODS.some(([k]) => k === c.period)) c.period = 'week';
    const metrics = METRICS;
    $('#crew-body').innerHTML = `
      ${!(my && my.visible) ? `<div class="card banner-card"><b>Вас нет в рейтинге</b><p class="muted">Статистика скрыта. Включите показ — другие увидят только линии и рабочие дни (заработок — по отдельному разрешению).</p><button class="btn btn-primary" data-act="crew-publish">Показать мою статистику</button></div>` : ''}
      <div class="chips" id="rk-period">${PERIODS.map(([k, t]) => `<button class="chip ${c.period === k ? 'active' : ''}" data-k="${k}">${t}</button>`).join('')}</div>
      <div class="chips small" id="rk-metric">${metrics.map(([k, t]) => `<button class="chip ${c.metric === k ? 'active' : ''}" data-k="${k}">${t}</button>`).join('')}</div>
      <div id="rk-list"><div class="card"><p class="muted" style="margin:0">Загрузка рейтинга…</p></div></div>`;
    $('#rk-period').onclick = (e) => { const b = e.target.closest('[data-k]'); if (b) { c.period = b.dataset.k; renderRank(); } };
    $('#rk-metric').onclick = (e) => { const b = e.target.closest('[data-k]'); if (b) { c.metric = b.dataset.k; renderRank(); } };
    stopCrewWatch();
    crewUnsub = Cl.social.watchLeaderboard({ period: c.period, metric: c.metric }, (err, rows) => {
      const box = $('#rk-list'); if (!box) return;
      if (err) { box.innerHTML = `<div class="card"><p class="muted" style="margin:0">Не удалось загрузить рейтинг: ${esc(Cl.errText(err))}</p></div>`; return; }
      const val = (x) => (c.period === 'all' ? x.totals : x[c.period])[c.metric];
      if (!rows.length) { box.innerHTML = `<div class="card empty-rank"><div class="crew-emoji">🌙</div><p class="muted" style="margin:0">Пока пусто — здесь появятся сборщики, открывшие статистику.</p></div>`; return; }
      const me = myUid();
      const pod = rows.slice(0, 3), rest = rows.slice(3);
      const order = pod.length === 3 ? [pod[1], pod[0], pod[2]] : pod;
      const week = c.period === 'week', perDays = true; // кг — во всех периодах
      const medal = (x) => ['🥇', '🥈', '🥉'][rows.indexOf(x)];
      box.classList.toggle('rk-still', !rankFx());
      box.innerHTML = `<div class="podium n${pod.length}">${order.map((x) => `
          <button class="pod p${rows.indexOf(x) + 1} ${x.uid === me ? 'me' : ''} ${cardBg(x).cls}" data-uid="${x.uid}"${cardBg(x).style}>${cardBg(x).canvas}
            <span class="pod-medal">${medal(x)}</span>${avatarFx(x.avatar, rows.indexOf(x) === 0 ? 54 : 44, x)}
            <span class="pod-name">${nameFx(x.name, x)}</span><span class="pod-nick">@${esc(x.nick)}</span>
            <span class="pod-val num">${metricText(c.metric, val(x))}</span>${perDays ? `<span class="rk-kg num" data-kg="${x.uid}"></span>` : ''}${week ? `<span class="wdays" data-wd="${x.uid}"></span>` : ''}</button>`).join('')}</div>
        ${rest.length ? `<div class="card rank-list">${rest.map((x, i) => `<button class="rank-row ${x.uid === me ? 'me' : ''} ${cardBg(x).cls}" data-uid="${x.uid}"${cardBg(x).style}>${cardBg(x).canvas}<span class="rank-pos num">${i + 4}</span>${avatarFx(x.avatar, 34, x)}<span class="grow"><b>${nameFx(x.name, x)}</b><small>@${esc(x.nick)}${perDays ? ` <span class="rk-kg num" data-kg="${x.uid}"></span>` : ''}</small>${week ? `<span class="wdays" data-wd="${x.uid}"></span>` : ''}</span><span class="rank-val num">${metricText(c.metric, val(x))}</span></button>`).join('')}</div>` : ''}
        ${c.metric === 'earn' ? '<p class="hint" style="text-align:center">Только те, кто разрешил показывать заработок (оценка «линии × ставка»)</p>' : ''}`;
      box.querySelectorAll('[data-uid]').forEach((b) => (b.onclick = () => openPublicProfile(b.dataset.uid)));
      startHeroFx(box);
      if (perDays) fillPeriodDays(rows, box, c.period);
    });
  }

  // ---------- Список и поиск ----------
  function renderPeople() {
    const c = ui.crew;
    $('#crew-body').innerHTML = `<div class="search-box"><input class="input" id="crew-q" type="search" autocapitalize="none" placeholder="Поиск по нику" value="${esc(c.q)}"></div><div id="people-list"><div class="card"><p class="muted" style="margin:0">Загрузка…</p></div></div>`;
    const load = async () => {
      const box = $('#people-list'); if (!box) return;
      try {
        const list = await window.Cloud.social.listProfiles(c.q);
        const me = myUid();
        box.innerHTML = list.length ? `<div class="card rank-list">${list.map((x) => `<button class="rank-row ${x.uid === me ? 'me' : ''}" data-uid="${x.uid}">${avatarFx(x.avatar, 42, x)}<span class="grow"><b>${nameFx(x.name, x)}${x.uid === me ? ' <em>(вы)</em>' : ''}</b><small>@${esc(x.nick)}</small></span><span class="chev">›</span></button>`).join('')}</div>`
          : `<div class="card"><p class="muted" style="margin:0">${c.q ? 'Никого не нашлось — проверьте ник.' : 'Пока никого нет.'}</p></div>`;
        box.querySelectorAll('[data-uid]').forEach((b) => (b.onclick = () => openPublicProfile(b.dataset.uid)));
      } catch (e) { box.innerHTML = `<div class="card"><p class="muted" style="margin:0">${esc(window.Cloud.errText(e))}</p></div>`; }
    };
    $('#crew-q').oninput = (e) => { c.q = e.target.value; clearTimeout(crewSearchT); crewSearchT = setTimeout(load, 350); };
    load();
  }

  // ---------- Публичный профиль ----------
  async function openPublicProfile(uid) {
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">Сборщик</div></div><button class="icon-btn" data-close>×</button></div><p class="muted">Загрузка…</p>`;
    openModal(sh, $('#backdrop'));
    let d; try { d = await window.Cloud.social.getPublic(uid); } catch (e) { sh.querySelector('p').textContent = window.Cloud.errText(e); return; }
    if (!d.profile) { sh.querySelector('p').textContent = 'Профиль не найден'; return; }
    const p = d.profile, s = d.stats, me = uid === myUid(), today = window.Cloud.util.dayKey();
    const mk = today.slice(0, 7), wk = window.Cloud.util.mondayOf(today);
    sh.innerHTML = `<div class="grabber"></div>
      <div class="sheet-head"><div class="grow"><div class="sheet-title">${me ? 'Мой публичный профиль' : 'Сборщик'}</div></div><button class="icon-btn" data-close>×</button></div>
      <div class="prof-themed" style="${themeColor(lookOf(p)) ? '--accent:' + themeColor(lookOf(p)) : ''}">
      ${heroHtml(p, `@${esc(p.nick)}${seenText(uid) ? ' · ' + seenText(uid) : ''}<br><small>с нами с ${esc(fmtDateTs(p.createdAt))}</small>`)}
      ${s ? `<div class="tiles">
          <div class="tile"><div class="t-label">Собрано линий</div><div class="t-value num">${N(s.totals.lines)}</div></div>
          <div class="tile"><div class="t-label">Рабочих дней</div><div class="t-value num">${N(s.totals.days)}</div></div>
          <div class="tile"><div class="t-label">В среднем за день</div><div class="t-value num">${N(Math.round(s.totals.avg))}</div><div class="t-sub">линий</div></div>
          <div class="tile"><div class="t-label">Рекорд за день</div><div class="t-value num">${N(s.totals.best)}</div><div class="t-sub">линий</div></div>
          ${s.showEarn ? `<div class="tile wide"><div class="t-label">Примерный заработок</div><div class="t-value num">${M(s.totals.earn)}</div><div class="t-sub">линии × ставка, без премий</div></div>` : ''}
          <div class="tile"><div class="t-label">Эта неделя</div><div class="t-value num">${N(s.week.key === wk ? s.week.lines : 0)}</div><div class="t-sub">${N(s.week.key === wk ? s.week.days : 0)} смен</div></div>
          <div class="tile"><div class="t-label">Этот месяц</div><div class="t-value num">${N(s.month.key === mk ? s.month.lines : 0)}</div><div class="t-sub">${N(s.month.key === mk ? s.month.days : 0)} смен</div></div>
        </div>` : `<div class="card"><p class="muted" style="margin:0">🔒 ${me ? 'Ваша статистика скрыта — включите показ в профиле.' : 'Сборщик скрыл свою статистику.'}</p></div>`}
      ${s ? `<div class="card wk-card"><h2>Эта неделя по дням</h2><div class="wdays full" id="pp-week">${weekDaysHtml({}, wk, true)}</div></div>` : ''}
      ${s && s.badges && s.badges.length ? shelfHtml(badgeList(s.badges)) : ''}
      ${!me && s ? '<button class="btn btn-primary" id="pp-compare">Сравнить со мной</button>' : ''}</div>`;
    startHeroFx(sh);
    if (s) window.Cloud.social.days(uid, wk, addDays(wk, 6)).then((days) => { const el = $('#pp-week'); if (el) el.innerHTML = weekDaysHtml(days, wk, true); }).catch(() => {});
    const b = $('#pp-compare');
    if (b) b.onclick = () => {
      const c = ui.crew;
      if (!c.others.some((x) => x.uid === uid)) { c.others = [...c.others, { uid, nick: p.nick, name: p.name, avatar: p.avatar }].slice(-3); }
      c.sub = 'compare'; closeModal(); if (ui.tab !== 'crew') setTab('crew'); else renderCrew();
    };
  }

  // ---------- Сравнение ----------
  function loadCharts() {
    if (window.Chart) return Promise.resolve(window.Chart);
    return new Promise((res, rej) => {
      document.addEventListener('charts:ready', () => res(window.Chart), { once: true });
      if (!document.querySelector('script[src="charts.js"]')) { const s = document.createElement('script'); s.src = 'charts.js'; s.onerror = () => rej(new Error('Не удалось загрузить графики')); document.head.appendChild(s); }
    });
  }
  const addDays = (k, n) => { const [y, m, d] = k.split('-').map(Number); const t = new Date(y, m - 1, d + n); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; };
  const shortDate = (k) => `${+k.slice(8, 10)}.${k.slice(5, 7)}`;
  async function renderCompare() {
    const c = ui.crew, Cl = window.Cloud, today = Cl.util.dayKey();
    if (c.range !== 'custom') { c.to = today; c.from = addDays(today, -(c.range - 1)); }
    const people = [{ uid: myUid(), nick: Cl.account.profile.nick, name: 'Я', avatar: Cl.account.profile.avatar, me: true }, ...c.others];
    $('#crew-body').innerHTML = `
      <div class="card"><h2>Кого сравниваем <small>до 4 человек</small></h2>
        <div class="cmp-people">${people.map((x, i) => `<span class="cmp-chip" style="--c:${COLORS[i]}">${avatarHtml(x.avatar, 26)}<b>${esc(x.me ? 'Я' : shownName(x.uid, x.name))}</b>${x.me ? '' : `<button data-rm="${x.uid}" aria-label="Убрать">×</button>`}</span>`).join('')}
        ${people.length < 4 ? '<button class="cmp-add" id="cmp-add">+ Добавить</button>' : ''}</div></div>
      <div class="chips" id="cmp-range">${[[7, '7 дней'], [30, '30 дней'], [90, '90 дней'], ['custom', 'Свой период']].map(([k, t]) => `<button class="chip ${String(c.range) === String(k) ? 'active' : ''}" data-k="${k}">${t}</button>`).join('')}</div>
      ${c.range === 'custom' ? `<div class="inline-form" style="margin-bottom:12px"><div><label for="cmp-from">С</label><input class="input" type="date" id="cmp-from" value="${c.from}" max="${today}"></div><div><label for="cmp-to">По</label><input class="input" type="date" id="cmp-to" value="${c.to}" max="${today}"></div></div>` : ''}
      <div id="cmp-out">${people.length < 2 ? '<div class="card"><p class="muted" style="margin:0">Добавьте одного-трёх сборщиков: «+ Добавить» или кнопка «Сравнить со мной» в профиле коллеги.</p></div>' : '<div class="card"><p class="muted" style="margin:0">Загрузка данных…</p></div>'}</div>`;
    $('#crew-body').querySelectorAll('[data-rm]').forEach((b) => (b.onclick = () => { c.others = c.others.filter((x) => x.uid !== b.dataset.rm); renderCompare(); }));
    const add = $('#cmp-add'); if (add) add.onclick = pickCollector;
    $('#cmp-range').onclick = (e) => { const b = e.target.closest('[data-k]'); if (!b) return; c.range = b.dataset.k === 'custom' ? 'custom' : +b.dataset.k; if (c.range === 'custom' && !c.from) { c.to = today; c.from = addDays(today, -29); } renderCompare(); };
    const f = $('#cmp-from'), t = $('#cmp-to');
    if (f) { const upd = () => { if (f.value && t.value && f.value <= t.value) { c.from = f.value; c.to = t.value; renderCompare(); } }; f.onchange = upd; t.onchange = upd; }
    if (people.length < 2) return;
    if ((new Date(c.to) - new Date(c.from)) / 864e5 > 400) { $('#cmp-out').innerHTML = '<div class="card"><p class="muted" style="margin:0">Выберите период не больше года.</p></div>'; return; }
    try {
      const [Chart, series] = await Promise.all([loadCharts(), Promise.all(people.map(async (x) => {
        if (x.me) { const o = {}; for (const k in state.entries) if (k >= c.from && k <= c.to && state.entries[k].lines > 0) o[k] = { lines: state.entries[k].lines, earn: C.estimated(state.entries[k]), kg: state.entries[k].weight || 0 }; return { ...x, days: o, earn: true }; }
        try { const pub = await Cl.social.getPublic(x.uid); if (!pub.stats || !pub.stats.visible) return { ...x, days: null }; return { ...x, days: await Cl.social.days(x.uid, c.from, c.to), earn: !!pub.stats.showEarn }; }
        catch { return { ...x, days: null }; }
      }))]);
      drawCompare(Chart, series);
    } catch (e) { const o = $('#cmp-out'); if (o) o.innerHTML = `<div class="card"><p class="muted" style="margin:0">${esc(e.message || 'Ошибка загрузки')}</p></div>`; }
  }
  function drawCompare(Chart, series) {
    const c = ui.crew, out = $('#cmp-out'); if (!out) return;
    crewCharts.forEach((ch) => ch.destroy()); crewCharts = [];
    const hidden = series.filter((s) => !s.days);
    series = series.filter((s) => s.days);
    const keys = []; for (let k = c.from; k <= c.to; k = addDays(k, 1)) keys.push(k);
    const label = (s) => (s.me ? 'Я' : shownName(s.uid, s.name));
    const color = (s) => COLORS[[{ me: true }, ...ui.crew.others].findIndex((x) => (s.me ? x.me : x.uid === s.uid))];
    const weeks = [...new Set(keys.map((k) => window.Cloud.util.mondayOf(k)))], months = [...new Set(keys.map((k) => k.slice(0, 7)))];
    const sumBy = (s, fn, groups, field = 'lines') => groups.map((g) => Object.entries(s.days).filter(([k]) => fn(k) === g).reduce((a, [, v]) => a + (v[field] || 0), 0));
    const stats = series.map((s) => { const v = Object.values(s.days); const lines = v.reduce((a, x) => a + x.lines, 0); return { s, lines, days: v.length, avg: v.length ? lines / v.length : 0, best: v.reduce((a, x) => Math.max(a, x.lines), 0), earn: s.earn ? v.reduce((a, x) => a + (x.earn || 0), 0) : null }; });
    const earners = series.filter((s) => s.earn && Object.values(s.days).some((x) => x.earn > 0));
    const kgers = series.filter((s) => Object.values(s.days).some((x) => x.kg > 0));
    out.innerHTML = `
      ${hidden.length ? `<div class="card"><p class="muted" style="margin:0">🔒 ${hidden.map((s) => esc(shownName(s.uid, s.name))).join(', ')} — статистика скрыта.</p></div>` : ''}
      <div class="card"><h2>Итоги за период</h2><div class="cmp-table">${stats.map((x) => `<div class="cmp-row"><span class="dot" style="background:${color(x.s)}"></span><b class="grow">${esc(label(x.s))}</b><span class="num">${N(x.lines)}<small>линий</small></span><span class="num">${x.days}<small>смен</small></span><span class="num">${N(Math.round(x.avg))}<small>в день</small></span></div>`).join('')}</div></div>
      <div class="card"><h2>Линии по дням</h2><div class="chart-box"><canvas id="ch-days"></canvas></div></div>
      ${weeks.length > 1 ? '<div class="card"><h2>По неделям</h2><div class="chart-box"><canvas id="ch-weeks"></canvas></div></div>' : ''}
      ${months.length > 1 ? '<div class="card"><h2>По месяцам</h2><div class="chart-box"><canvas id="ch-months"></canvas></div></div>' : ''}
      <div class="card"><h2>Среднее за рабочий день</h2><div class="chart-box short"><canvas id="ch-avg"></canvas></div></div>
      ${kgers.length ? `<div class="card"><h2>⚖️ Вес товара по дням <small>${kgers.map((x) => `${esc(label(x))}: ${fmtKg(Object.values(x.days).reduce((a, d) => a + (d.kg || 0), 0))}`).join(' · ')}</small></h2><div class="chart-box"><canvas id="ch-kg"></canvas></div></div>` : ''}
      ${earners.length ? `<div class="card"><h2>Примерный заработок <small>линии × ставка</small></h2><div class="chart-box"><canvas id="ch-earn"></canvas></div>${earners.length < series.length ? '<p class="hint">Показаны только те, кто разрешил показывать заработок.</p>' : ''}</div>` : ''}`;
    const css = getComputedStyle(document.documentElement), muted = css.getPropertyValue('--muted').trim() || '#888', grid = 'rgba(128,128,128,.15)';
    const base = (extra = {}) => ({ locale: 'ru-RU', responsive: true, maintainAspectRatio: false, animation: { duration: 350 }, interaction: { mode: 'index', intersect: false },
      plugins: { legend: { labels: { color: muted, boxWidth: 12, usePointStyle: true } }, tooltip: { callbacks: extra.tip ? { label: extra.tip } : {} } },
      scales: { x: { ticks: { color: muted, maxRotation: 0, autoSkip: true, maxTicksLimit: 7 }, grid: { display: false } }, y: { beginAtZero: true, ticks: { color: muted, maxTicksLimit: 5 }, grid: { color: grid } } }, ...extra.opts });
    const mk = (id, cfg) => { const el = document.getElementById(id); if (el) crewCharts.push(new Chart(el, cfg)); };
    const ds = (s, data, type) => ({ label: label(s), data, borderColor: color(s), backgroundColor: type === 'bar' ? color(s) : color(s) + '33', pointRadius: keys.length > 40 ? 0 : 3, pointHoverRadius: 5, borderWidth: 2, tension: 0.3, spanGaps: true, borderRadius: 6, maxBarThickness: 26 });
    const lineTip = (ctx) => ` ${ctx.dataset.label}: ${ctx.parsed.y === null ? 'нет смены' : N(ctx.parsed.y) + ' линий'}`;
    mk('ch-days', { type: 'line', data: { labels: keys.map(shortDate), datasets: series.map((s) => ds(s, keys.map((k) => (s.days[k] ? s.days[k].lines : null)))) }, options: base({ tip: lineTip }) });
    mk('ch-weeks', { type: 'bar', data: { labels: weeks.map((w) => 'с ' + shortDate(w)), datasets: series.map((s) => ds(s, sumBy(s, (k) => window.Cloud.util.mondayOf(k), weeks), 'bar')) }, options: base() });
    mk('ch-months', { type: 'bar', data: { labels: months.map((m) => C.MONTHS[+m.slice(5) - 1].slice(0, 3)), datasets: series.map((s) => ds(s, sumBy(s, (k) => k.slice(0, 7), months), 'bar')) }, options: base() });
    mk('ch-avg', { type: 'bar', data: { labels: stats.map((x) => label(x.s)), datasets: [{ data: stats.map((x) => Math.round(x.avg)), backgroundColor: stats.map((x) => color(x.s)), borderRadius: 8, maxBarThickness: 30 }] },
      options: base({ opts: { indexAxis: 'y', plugins: { legend: { display: false } } } }) });
    mk('ch-kg', { type: 'bar', data: { labels: keys.map(shortDate), datasets: kgers.map((s) => ds(s, keys.map((k) => (s.days[k] && s.days[k].kg ? s.days[k].kg : null)), 'bar')) },
      options: base({ tip: (ctx) => ` ${ctx.dataset.label}: ${ctx.parsed.y === null ? 'нет данных' : fmtKg(ctx.parsed.y)}` }) });
    mk('ch-earn', { type: 'line', data: { labels: keys.map(shortDate), datasets: earners.map((s) => ds(s, keys.map((k) => (s.days[k] ? s.days[k].earn : null)))) },
      options: base({ tip: (ctx) => ` ${ctx.dataset.label}: ${ctx.parsed.y === null ? 'нет смены' : M(ctx.parsed.y)}` }) });
  }
  async function pickCollector() {
    const sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">Добавить в сравнение</div></div><button class="icon-btn" data-close>×</button></div>
      <input class="input" id="pk-q" type="search" autocapitalize="none" placeholder="Поиск по нику" style="margin-bottom:12px"><div id="pk-list"><p class="muted">Загрузка…</p></div>`;
    openModal(sh, $('#backdrop'));
    const load = async (q) => {
      const box = $('#pk-list'); if (!box) return;
      const me = myUid(), taken = new Set(ui.crew.others.map((x) => x.uid));
      const list = (await window.Cloud.social.listProfiles(q)).filter((x) => x.uid !== me && !taken.has(x.uid));
      box.innerHTML = list.length ? list.map((x) => `<button class="rank-row" data-uid="${x.uid}">${avatarHtml(x.avatar, 40)}<span class="grow"><b>${esc(shownName(x.uid, x.name))}</b><small>@${esc(x.nick)}</small></span><span class="chev">+</span></button>`).join('') : '<p class="muted">Никого не нашлось.</p>';
      box.querySelectorAll('[data-uid]').forEach((b) => (b.onclick = () => { const x = list.find((y) => y.uid === b.dataset.uid); ui.crew.others = [...ui.crew.others, { uid: x.uid, nick: x.nick, name: x.name, avatar: x.avatar }].slice(-3); closeModal(); renderCompare(); }));
    };
    let t = 0; $('#pk-q').oninput = (e) => { clearTimeout(t); t = setTimeout(() => load(e.target.value), 350); };
    load('');
  }

  // ---------- Приватность (в карточке аккаунта) ----------
  function privacyHtml() {
    const Cl = CL(); if (!Cl || !Cl.social || !Cl.account.profile) return '';
    const my = Cl.social.my, vis = !!(my && my.visible), earn = !!(my && my.showEarn), pr = Cl.social.progress;
    return `<div class="priv">
      <label class="switch-row"><span><b>Показывать мою статистику</b><small>линии, смены, среднее и рекорд — в рейтинге и сравнении</small></span><input type="checkbox" class="switch" id="pub-on" ${vis ? 'checked' : ''} ${pr ? 'disabled' : ''}></label>
      <label class="switch-row"><span><b>Показывать заработок</b><small>только оценка «линии × ставка», без конверта, премий и выплат</small></span><input type="checkbox" class="switch" id="pub-earn" ${earn ? 'checked' : ''} ${vis && !pr ? '' : 'disabled'}></label>
      ${pr ? `<p class="hint">Публикую статистику: ${pr.done} из ${pr.total} дней…</p>` : vis ? '<p class="hint">Записи календаря, комментарии, фактические суммы и выплаты не публикуются никогда.</p>' : ''}
    </div>`;
  }
  // Приём данных из отчёта больше не выключается: администратор вносит их прямо в календарь. Старые отправки применяются всегда.
  const acceptImports = () => true;
  // Пришли данные из отчёта: вносим в смену (остальные поля смены — время, самочувствие, комментарий — не трогаем)
  function applyImport(day, it) {
    if (!C.isValidKey(day)) return true;
    const prev = state.entries[day];
    const input = prev ? { ...prev } : { start: state.settings.shiftStart || null };
    if (typeof it.lines === 'number') input.lines = it.lines;
    if (typeof it.prod === 'number') input.prod = it.prod;
    if (typeof it.actual === 'number') input.actual = it.actual;
    if (!prev && !input.lines && !input.actual) return true; // только производительность без смены — некуда вносить
    const res = C.saveEntry(state, day, input);
    if (!res.ok) { console.warn('Импорт отчёта', day, res.error); return true; }
    return true;
  }
  function importsApplied(list) {
    save(); if (!modalStack.length) renderAll(); else updateChip();
    const it = list[list.length - 1], e = state.entries[it.day];
    const parts = e ? [e.lines && `${N(e.lines)} ${plural(e.lines, 'линия', 'линии', 'линий')}`, typeof it.prod === 'number' && `${N(it.prod, 2)}%`, typeof it.actual === 'number' && M(it.actual)].filter(Boolean) : [];
    toast(list.length > 1 ? `📥 Из отчёта внесено ${list.length} ${plural(list.length, 'смена', 'смены', 'смен')}` : `📥 Из отчёта: ${C.fmtDateLong(it.day)} — ${parts.join(', ')}`);
  }
  document.addEventListener('change', async (e) => {
    const t = e.target; if (t.id !== 'pub-on' && t.id !== 'pub-earn') return;
    const Cl = CL(); if (!Cl) return;
    const my = Cl.social.my, vis = t.id === 'pub-on' ? t.checked : true;
    const earn = t.id === 'pub-earn' ? t.checked : (vis && my ? !!my.showEarn : false);
    if (t.id === 'pub-on' && vis && !(await confirmDlg('Показать статистику?', 'Другие сборщики увидят ваши линии по дням, число смен, среднее и рекорд. Зарплата, конверт, премии и комментарии не публикуются. Выключить можно в любой момент — опубликованное удалится.', 'Показать'))) { t.checked = false; return; }
    if (t.id === 'pub-on' && !vis && !(await confirmDlg('Скрыть статистику?', 'Вы пропадёте из рейтинга и сравнения, опубликованные данные удалятся. Ваши смены на устройстве и в облаке останутся.', 'Скрыть'))) { t.checked = true; return; }
    try { toast(vis ? 'Публикую статистику…' : 'Скрываю…'); await Cl.social.setVisibility({ visible: vis, showEarn: earn }); toast(vis ? 'Статистика опубликована' : 'Статистика скрыта'); }
    catch (ex) { toast(Cl.errText(ex)); }
    refreshAccountCard(); if (ui.tab === 'crew') renderCrew();
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-act="crew-publish"]')) return;
    setTab('settings');
    setTimeout(() => { const s = $('#pub-on'); if (s) { s.scrollIntoView({ block: 'center', behavior: 'smooth' }); s.checked = true; s.dispatchEvent(new Event('change', { bubbles: true })); } }, 300);
  });

  // =====================================================================
  // ---------- Общий чат ----------
  // =====================================================================
  let chatAttach = null, chatReply = null, chatEdit = null, chatStick = true;
  const fmtTime = (t) => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  const dayLabel = (t) => {
    const d = new Date(t), today = new Date(); const y = new Date(); y.setDate(today.getDate() - 1);
    if (d.toDateString() === today.toDateString()) return 'Сегодня';
    if (d.toDateString() === y.toDateString()) return 'Вчера';
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', ...(d.getFullYear() !== today.getFullYear() ? { year: 'numeric' } : {}) });
  };
  const linkify = (s) => esc(s).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>').replace(/\n/g, '<br>');
  const chatName = (uid) => shownName(uid, (chatProfiles[uid] && chatProfiles[uid].name) || 'Сборщик');
  async function loadChatProfiles() {
    try {
      const list = await window.Cloud.social.listProfiles(''); chatProfiles = {}; list.forEach((p) => { chatProfiles[p.uid] = p; });
      if (ui.tab === 'crew' && ui.crew.sub === 'chat') drawChat(false);
      if (ui.tab === 'crew' && ui.crew.sub !== 'chat' && !modalStack.length) renderCrew(); // чёткие фото в рейтинге и списке
    } catch {}
  }
  function leaveChat() {
    Rec.cancel(); if (voicePlaying) { voicePlaying.a.pause(); voicePlaying = null; }
    const ch = CL() && CL().chat; if (ch) { if (ch.deactivate) ch.deactivate(); else ch.active = false; }
    document.body.classList.remove('chat-mode');
    const dock = document.getElementById('chat-dock'); if (dock) dock.remove();
  }
  let mentionToasted = Date.now(); // уведомляем только об упоминаниях после запуска
  function updateChatBadge() {
    const Cl = CL(), on = Cl && Cl.chat && !Cl.chat.active && Cl.chat.access === 'ok';
    const n = on ? Cl.chat.unread : 0, at = on ? Cl.chat.mentionsUnread : 0;
    const txt = (n > 99 ? '99+' : String(n)) + (at ? ' @' : '');
    const b = document.querySelector('.tabbar [data-tab="crew"]');
    if (b) { let s = b.querySelector('.tab-badge'); if (n && !s) { s = document.createElement('span'); s.className = 'tab-badge'; b.appendChild(s); } if (s) { if (n) { s.textContent = txt; s.classList.toggle('at', !!at); } else s.remove(); } }
    const seg = document.querySelector('[data-crew-sub="chat"]'); if (seg) seg.innerHTML = 'Чат' + (n ? ` <span class="seg-badge ${at ? 'at' : ''}">${txt}</span>` : '');
    // Новое упоминание, пока чат закрыт — короткое уведомление
    if (on && at) {
      const me = myUid(), last = Cl.chat.messages.filter((m) => m.uid !== me && !m.deleted && m.mentions.includes(me)).pop();
      if (last && last.createdAt > mentionToasted) {
        toast(`@ ${shownName(last.uid, last.name)} упомянул(а) вас: ${(last.text || '🎤 Голосовое').slice(0, 60)}`);
        mentionToasted = last.createdAt;
      }
    }
  }
  function renderChat() {
    const Cl = window.Cloud, ch = Cl.chat;
    document.body.classList.add('chat-mode');
    ch.active = true;
    $('#crew-body').innerHTML = `
      <div class="chat-head" id="chat-head"></div>
      <div class="chat-list" id="chat-list"></div>
      <button class="chat-down" id="chat-down" hidden aria-label="К новым сообщениям">↓</button>
      <form class="chat-compose" id="chat-compose" autocomplete="off">
        <div class="chat-reply" id="chat-reply" hidden></div>
        <div class="chat-row">
          <button type="button" class="chat-btn" id="chat-photo" aria-label="Прикрепить фото">${icon('camera')}</button>
          <textarea id="chat-text" rows="1" maxlength="${Cl.util.MAX_TEXT}" placeholder="Сообщение"></textarea>
          ${Rec.supported() ? `<button type="button" class="chat-send mic" id="chat-mic" aria-label="Голосовое сообщение">${icon('mic')}</button>` : ''}
          <button type="submit" class="chat-send" id="chat-send" aria-label="Отправить">${icon('send')}</button>
        </div>
        <div class="chat-rec" id="chat-rec" hidden><i class="rec-dot"></i><b id="rec-time" class="num">0:00</b><span class="grow">Запись… до ${Cl.util.MAX_VOICE} с</span>
          <button type="button" class="chat-btn" id="rec-cancel" aria-label="Отменить">${icon('trash')}</button>
          <button type="button" class="chat-send" id="rec-send" aria-label="Отправить голосовое">${icon('send')}</button></div>
        <div class="mention-pop" id="mention-pop" hidden></div>
        <input type="file" id="chat-file" accept="image/*" hidden>
      </form>`;
    // Поле ввода и кнопка «вниз» — прямо в body: внутри анимируемой вкладки position: fixed считается от неё
    const oldDock = document.getElementById('chat-dock'); if (oldDock) oldDock.remove();
    const dock = document.createElement('div'); dock.id = 'chat-dock';
    dock.append($('#chat-down'), $('#chat-compose')); document.body.appendChild(dock);
    chatStick = true;
    drawChat(true);
    loadChatProfiles();
    const ta = $('#chat-text');
    const grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight) + 'px'; };
    const micMode = () => { const m = $('#chat-mic'); if (!m) return; const empty = !ta.value.trim() && !chatAttach && !chatEdit; m.hidden = !empty; $('#chat-send').hidden = empty; };
    chatMicMode = micMode; micMode();
    ta.addEventListener('input', () => { grow(); micMode(); mentionPopup(); if (ta.value.trim()) ch.typingNow(); });
    ta.addEventListener('click', mentionPopup);
    // ---- голосовое сообщение ----
    const mic = $('#chat-mic');
    if (mic) mic.onclick = async () => {
      try {
        await Rec.start((sec) => { const t = $('#rec-time'); if (t) t.textContent = `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`; },
          () => sendVoice());
        $('#chat-rec').hidden = false; $('.chat-row', $('#chat-compose')).hidden = true;
      } catch (ex) { toast(ex.message || 'Нет доступа к микрофону'); }
    };
    const recUi = () => { const r = $('#chat-rec'); if (r) r.hidden = true; const row = $('#chat-compose') && $('.chat-row', $('#chat-compose')); if (row) row.hidden = false; };
    async function sendVoice() {
      recUi();
      let v; try { v = await Rec.stop(); } catch (ex) { toast(ex.message); return; }
      if (!v) return;
      if (v.duration < 0.8) { toast('Слишком короткое — держите запись хотя бы секунду'); return; }
      const p = Cl.account.profile, rep = chatReply; chatReply = null; drawReplyBar(); chatStick = true;
      try { await ch.send({ audio: v.data, duration: v.duration, replyTo: rep, name: p.name, nick: p.nick }); }
      catch (ex) { toast(Cl.errText(ex)); }
    }
    if ($('#rec-send')) $('#rec-send').onclick = sendVoice;
    if ($('#rec-cancel')) $('#rec-cancel').onclick = () => { Rec.cancel(); recUi(); };
    ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !matchMedia('(pointer: coarse)').matches) { e.preventDefault(); $('#chat-compose').requestSubmit(); } });
    $('#chat-photo').onclick = () => { const f = $('#chat-file'); f.value = ''; f.click(); };
    $('#chat-file').onchange = async () => {
      const f = $('#chat-file').files[0]; if (!f) return;
      try { toast('Сжимаю фото…'); chatAttach = await Cl.util.chatPhoto(f); chatEdit = null; drawReplyBar(); micMode(); } catch (ex) { toast(ex.message); }
    };
    $('#chat-compose').onsubmit = async (e) => {
      e.preventDefault();
      const text = ta.value; const p = Cl.account.profile;
      if (!text.trim() && !chatAttach) return;
      const att = chatAttach, rep = chatReply, ed = chatEdit;
      ta.value = ''; grow(); chatAttach = null; chatReply = null; chatEdit = null; drawReplyBar(); chatStick = true; micMode(); mentionPopup();
      try {
        if (ed) await ch.edit(ed.id, text);
        else await ch.send({ text, image: att, replyTo: rep, mentions: mentionsIn(text), name: p.name, nick: p.nick });
      } catch (ex) { toast(Cl.errText(ex)); if (!ed) { ta.value = text; micMode(); } }
    };
    $('#chat-down').onclick = () => { chatStick = true; window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }); };
  }
  function drawReplyBar() {
    const bar = $('#chat-reply'); if (!bar) return;
    const item = chatEdit ? `<b>Изменение</b><span>${esc(chatEdit.text)}</span>`
      : chatReply ? `<b>Ответ: ${esc(shownName(chatReply.uid, chatReply.name))}</b><span>${esc(chatReply.text || (chatReply.image ? '📷 Фото' : ''))}</span>` : '';
    const img = chatAttach ? `<img src="${esc(chatAttach)}" alt="">` : '';
    bar.hidden = !item && !img;
    bar.innerHTML = `${img}<div class="grow">${item || '<b>Фото</b><span>будет отправлено с сообщением</span>'}</div><button type="button" aria-label="Отменить">×</button>`;
    bar.querySelector('button').onclick = () => { if (chatEdit) $('#chat-text').value = ''; chatAttach = null; chatReply = null; chatEdit = null; drawReplyBar(); };
    if (chatMicMode) chatMicMode();
  }
  // ---------- Упоминания @ник ----------
  let chatMicMode = null;
  const NICK_AT = /(^|[^a-z0-9_.@])@([a-z0-9_.]{3,20})/gi;
  function mentionsIn(text) {
    const byNick = {}; Object.values(chatProfiles).forEach((p) => { byNick[p.nick] = p.uid; });
    const out = []; let m; NICK_AT.lastIndex = 0;
    while ((m = NICK_AT.exec(text))) { const u = byNick[m[2].toLowerCase().replace(/\.$/, '')]; if (u && !out.includes(u)) out.push(u); }
    return out;
  }
  function mentionPopup() {
    const ta = $('#chat-text'), pop = $('#mention-pop'); if (!ta || !pop) return;
    const before = ta.value.slice(0, ta.selectionStart || 0), m = before.match(/(^|\s)@([a-z0-9_.]{0,20})$/i);
    if (!m) { pop.hidden = true; return; }
    const q = m[2].toLowerCase(), me = myUid();
    const list = Object.values(chatProfiles).filter((p) => p.uid !== me && (p.nick.startsWith(q) || p.name.toLowerCase().includes(q))).slice(0, 6);
    if (!list.length) { pop.hidden = true; return; }
    pop.innerHTML = list.map((p) => `<button type="button" data-nick="${esc(p.nick)}">${avatarHtml(p.avatar, 28)}<b>${esc(shownName(p.uid, p.name))}</b><small>@${esc(p.nick)}</small></button>`).join('');
    pop.hidden = false;
    pop.onmousedown = (e) => e.preventDefault();
    pop.onclick = (e) => {
      const b = e.target.closest('[data-nick]'); if (!b) return;
      const pos = ta.selectionStart || 0, start = pos - m[2].length - 1;
      ta.value = ta.value.slice(0, start) + '@' + b.dataset.nick + ' ' + ta.value.slice(pos);
      const np = start + b.dataset.nick.length + 2; ta.setSelectionRange(np, np); ta.focus();
      pop.hidden = true; if (chatMicMode) chatMicMode();
    };
  }
  // Текст сообщения: ссылки и подсвеченные @ники
  function msgHtml(text) {
    const me = myUid(), nicks = {}; Object.values(chatProfiles).forEach((p) => { nicks[p.nick] = p.uid; });
    return linkify(text).replace(/(^|[^a-z0-9_.@\/])@([a-z0-9_.]{3,20})/gi, (all, pre, n) => {
      const u = nicks[n.toLowerCase()]; return u ? `${pre}<span class="mention ${u === me ? 'me' : ''}" data-mention="${esc(u)}">@${esc(n)}</span>` : all;
    });
  }
  // ---------- Запись голосового сообщения ----------
  const Rec = {
    rec: null, chunks: [], t0: 0, timer: 0, stream: null, onStop: null, cancelled: false,
    supported() { return !!(window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia); },
    mime() { return ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'].find((t) => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || ''; },
    async start(onTick, onLimit) {
      if (this.rec) return;
      let stream;
      try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
      catch (e) { throw new Error(e && e.name === 'NotAllowedError' ? 'Разрешите доступ к микрофону в настройках' : 'Микрофон недоступен'); }
      const mime = this.mime();
      const rec = new MediaRecorder(stream, { ...(mime ? { mimeType: mime } : {}), audioBitsPerSecond: 32000 });
      this.rec = rec; this.stream = stream; this.chunks = []; this.cancelled = false; this.t0 = Date.now();
      rec.ondataavailable = (e) => { if (e.data && e.data.size) this.chunks.push(e.data); };
      rec.start(250);
      const max = (CL() && CL().util.MAX_VOICE) || 60;
      this.timer = setInterval(() => { const sec = (Date.now() - this.t0) / 1000; onTick(sec); if (sec >= max) onLimit(); }, 250);
    },
    stop() {
      const rec = this.rec; if (!rec) return Promise.resolve(null);
      clearInterval(this.timer);
      const duration = Math.min(60, (Date.now() - this.t0) / 1000);
      return new Promise((res, rej) => {
        rec.onstop = () => {
          this.stream.getTracks().forEach((t) => t.stop()); this.rec = null;
          if (this.cancelled) return res(null);
          const blob = new Blob(this.chunks, { type: (rec.mimeType || 'audio/webm').split(';')[0] });
          const fr = new FileReader();
          fr.onload = () => { const data = String(fr.result).replace(/^data:[^;,]*/, 'data:' + blob.type); data.length > 590000 ? rej(new Error('Слишком большое голосовое — запишите короче')) : res({ data, duration: Math.round(duration * 10) / 10 }); };
          fr.onerror = () => rej(new Error('Не удалось сохранить запись'));
          fr.readAsDataURL(blob);
        };
        try { rec.stop(); } catch (e) { rej(e); }
      });
    },
    cancel() { if (!this.rec) return; this.cancelled = true; this.stop(); },
  };
  // Плеер голосового в сообщении
  function voiceHtml(m) {
    const d = Math.round(m.duration || 0);
    return `<div class="m-voice" data-voice-msg="${m.id}"><button type="button" class="vplay" data-vplay="${m.id}" aria-label="Слушать">▶</button><span class="vbar"><i></i></span><span class="vdur num">${Math.floor(d / 60)}:${String(d % 60).padStart(2, '0')}</span></div>`;
  }
  let voicePlaying = null;
  function playVoice(id) {
    const Cl = CL(), m = Cl && Cl.chat.messages.find((x) => x.id === id); if (!m || !m.audio) return;
    const box = document.querySelector(`[data-voice-msg="${CSS.escape(id)}"]`);
    if (voicePlaying && voicePlaying.id === id) { const a = voicePlaying.a; if (a.paused) a.play(); else a.pause(); return; }
    if (voicePlaying) { voicePlaying.a.pause(); voicePlaying = null; document.querySelectorAll('.m-voice.on').forEach((x) => { x.classList.remove('on'); x.querySelector('.vplay').textContent = '▶'; }); }
    const a = new Audio(m.audio); voicePlaying = { id, a };
    const btn = () => document.querySelector(`[data-voice-msg="${CSS.escape(id)}"]`);
    a.onplay = () => { const b = btn(); if (b) { b.classList.add('on'); b.querySelector('.vplay').textContent = '❚❚'; } };
    a.onpause = () => { const b = btn(); if (b) b.querySelector('.vplay').textContent = '▶'; };
    a.ontimeupdate = () => { const b = btn(); if (b && a.duration && isFinite(a.duration)) b.querySelector('.vbar i').style.width = (a.currentTime / a.duration * 100) + '%'; else if (b && m.duration) b.querySelector('.vbar i').style.width = Math.min(100, a.currentTime / m.duration * 100) + '%'; };
    a.onended = () => { const b = btn(); if (b) { b.classList.remove('on'); b.querySelector('.vplay').textContent = '▶'; b.querySelector('.vbar i').style.width = '0'; } voicePlaying = null; };
    a.play().catch(() => { toast('Не удалось воспроизвести — формат не поддерживается этим телефоном'); voicePlaying = null; });
    if (box) box.classList.add('on');
  }
  function drawChat(forceBottom) {
    const list = $('#chat-list'), head = $('#chat-head'), Cl = CL(); if (!list || !Cl) return;
    const ch = Cl.chat, me = myUid();
    const cmp = $('#chat-compose'); if (cmp) cmp.hidden = !!ch.error || ch.access !== 'ok';
    if (ch.error) { list.innerHTML = `<div class="card"><p class="muted" style="margin:0">🔒 ${esc(ch.error)}</p></div>`; return; }
    if (ch.access !== 'ok') {
      head.innerHTML = '<b>Общий чат</b>';
      list.innerHTML = ch.access === 'pending' ? `<div class="chat-empty"><div class="crew-emoji">⏳</div><p><b>Ждём одобрения администратора</b></p><p class="muted">Чат только для своих: доступ откроет администратор. Как только это случится, сообщения появятся здесь сами.</p></div>`
        : '<div class="card"><p class="muted" style="margin:0">Загрузка чата…</p></div>';
      return;
    }
    const members = Object.keys(ch.members), online = members.filter((u) => ch.online(u)).length;
    const typing = ch.typing().map(chatName);
    head.innerHTML = `<b>Общий чат</b><span>${typing.length ? `<em>${esc(typing.join(', '))} ${typing.length > 1 ? 'печатают' : 'печатает'}…</em>` : `${members.length} ${plural(members.length, 'участник', 'участника', 'участников')}${online ? ` · ${online} в сети` : ''}`}</span>`;
    const nearBottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 160;
    const msgs = ch.messages;
    if (!msgs.length) { list.innerHTML = '<div class="chat-empty"><div class="crew-emoji">💬</div><p class="muted">Здесь пока тихо. Напишите первым!</p><p class="hint">Чат видят все зарегистрированные сборщики.</p></div>'; return; }
    let html = ch.hasMore ? '<button class="chat-more" id="chat-more">Показать раньше</button>' : '';
    let lastDay = '', prev = null;
    for (const m of msgs) {
      const dl = dayLabel(m.createdAt);
      if (dl !== lastDay) { html += `<div class="chat-day"><span>${dl}</span></div>`; lastDay = dl; prev = null; }
      const mine = m.uid === me, grp = prev && prev.uid === m.uid && m.createdAt - prev.createdAt < 5 * 60e3;
      const prof = chatProfiles[m.uid] || null, av = prof ? prof.avatar : null;
      const rx = {}; for (const [u, e] of Object.entries(m.reactions || {})) (rx[e] = rx[e] || []).push(u);
      const read = mine && ch.readBy(m).length;
      const status = mine ? (m.pending ? '<i class="st">🕓</i>' : `<i class="st ${read ? 'read' : ''}">${read ? '✓✓' : '✓'}</i>`) : '';
      html += `<div class="msg ${mine ? 'me' : ''} ${grp ? 'grp' : ''}" data-id="${m.id}">
        ${mine ? '' : `<div class="m-av">${grp ? '' : avatarFx(av, 32, prof)}</div>`}
        <div class="m-col">
          <div class="bubble ${m.deleted ? 'deleted' : ''} ${m.image && !m.text ? 'only-img' : ''} ${!mine && m.mentions.includes(me) && !m.deleted ? 'mentioned' : ''}" data-msg="${m.id}">
            ${!mine && !grp ? `<b class="m-name">${prof ? nameFx(m.name, { ...prof, uid: m.uid }) : esc(shownName(m.uid, m.name))}</b>` : ''}
            ${m.deleted ? '<span class="m-text">Сообщение удалено</span>' : `
              ${m.replyTo ? `<div class="m-reply" data-jump="${esc(m.replyTo.id)}"><b>${esc(replyName(m.replyTo, msgs))}</b><span>${esc(m.replyTo.text)}</span></div>` : ''}
              ${m.image ? `<img class="m-img" src="${esc(m.image)}" alt="Фото" data-view="${m.id}">` : ''}
              ${m.audio ? voiceHtml(m) : ''}
              ${m.text ? `<span class="m-text">${msgHtml(m.text)}</span>` : ''}`}
            <span class="m-meta">${m.editedAt && !m.deleted ? 'изменено · ' : ''}${fmtTime(m.createdAt)}${status}</span>
          </div>
          ${Object.keys(rx).length ? `<div class="m-rx">${Object.entries(rx).map(([e, us]) => `<button class="rx ${us.includes(me) ? 'on' : ''}" data-rx="${esc(e)}" data-for="${m.id}">${esc(e)}<b>${us.length}</b></button>`).join('')}</div>` : ''}
        </div></div>`;
      prev = m;
    }
    list.innerHTML = html;
    // Фото догружаются позже и удлиняют ленту — держим низ, если пользователь внизу
    list.querySelectorAll('img.m-img').forEach((im) => { if (!im.complete) im.addEventListener('load', () => { if (chatStick) window.scrollTo(0, document.documentElement.scrollHeight); }, { once: true }); });
    const more = $('#chat-more'); if (more) more.onclick = () => { chatStick = false; ch.loadMore(); };
    if (forceBottom || (chatStick && nearBottom) || chatStick) { requestAnimationFrame(() => window.scrollTo(0, document.documentElement.scrollHeight)); }
    const down = $('#chat-down'); if (down) down.hidden = nearBottom || forceBottom;
    ch.markRead();
  }
  window.addEventListener('scroll', () => {
    if (!document.body.classList.contains('chat-mode')) return;
    const near = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 160;
    chatStick = near; const d = $('#chat-down'); if (d) d.hidden = near;
    if (near && CL()) CL().chat.markRead();
  }, { passive: true });
  // Клики внутри чата: реакции, ответ-цитата, фото, меню сообщения
  document.addEventListener('click', (e) => {
    if (!document.body.classList.contains('chat-mode') || !e.target.closest('#chat-list')) return;
    if (e.target.closest('a')) return;
    const Cl = CL(), ch = Cl.chat;
    const rx = e.target.closest('[data-rx]'); if (rx) { ch.react(rx.dataset.for, rx.dataset.rx).catch((ex) => toast(Cl.errText(ex))); return; }
    const jump = e.target.closest('[data-jump]'); if (jump) { const t = document.querySelector(`.msg[data-id="${CSS.escape(jump.dataset.jump)}"]`); if (t) { t.scrollIntoView({ block: 'center', behavior: 'smooth' }); t.classList.add('flash'); setTimeout(() => t.classList.remove('flash'), 1200); } else toast('Сообщение выше — нажмите «Показать раньше»'); return; }
    const img = e.target.closest('[data-view]'); if (img) { openPhoto(img.src); return; }
    const vp = e.target.closest('[data-voice-msg]'); if (vp) { playVoice(vp.dataset.voiceMsg); return; }
    const mn = e.target.closest('[data-mention]'); if (mn) { openPublicProfile(mn.dataset.mention); return; }
    const b = e.target.closest('[data-msg]'); if (b) openMsgMenu(b.dataset.msg);
  });
  function openPhoto(src) {
    const o = document.createElement('div'); o.className = 'photo-view';
    o.innerHTML = `<img src="${esc(src)}" alt="Фото"><button aria-label="Закрыть">×</button>`;
    o.onclick = () => { o.classList.remove('show'); setTimeout(() => o.remove(), 200); };
    document.body.appendChild(o); requestAnimationFrame(() => o.classList.add('show'));
  }
  function openMsgMenu(id) {
    const Cl = CL(), ch = Cl.chat, m = ch.messages.find((x) => x.id === id); if (!m) return;
    const me = myUid(), mine = m.uid === me, admin = Cl.admin.isAdmin();
    const sh = $('#sheet');
    const readers = mine ? ch.readBy(m).map(chatName) : [];
    sh.innerHTML = `<div class="grabber"></div>
      ${m.deleted ? '' : `<div class="rx-pick">${Cl.util.REACTIONS.map((e) => `<button data-pick="${e}" class="${m.reactions[me] === e ? 'on' : ''}">${e}</button>`).join('')}</div>`}
      <div class="menu-list">
        ${m.deleted ? '' : '<button data-a="reply">↩️ Ответить</button>'}
        ${!mine && !m.deleted && chatProfiles[m.uid] ? '<button data-a="mention">@ Упомянуть</button>' : ''}
        ${m.text && !m.deleted ? '<button data-a="copy">📋 Скопировать текст</button>' : ''}
        ${mine && m.text && !m.deleted ? '<button data-a="edit">✏️ Изменить</button>' : ''}
        ${(mine || admin) && !m.deleted ? `<button data-a="del" class="danger">🗑 Удалить у всех${!mine ? ' (администратор)' : ''}</button>` : ''}
        ${mine ? `<div class="menu-info">${m.pending ? 'Отправляется…' : readers.length ? 'Прочитали: ' + esc(readers.join(', ')) : 'Доставлено, ещё не прочитано'}</div>` : `<div class="menu-info">${esc(shownName(m.uid, m.name))} · ${new Date(m.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</div>`}
      </div>`;
    sh.querySelectorAll('[data-pick]').forEach((b) => (b.onclick = () => { closeModal(); ch.react(id, b.dataset.pick).catch((ex) => toast(Cl.errText(ex))); }));
    sh.querySelectorAll('[data-a]').forEach((b) => (b.onclick = async () => {
      const a = b.dataset.a; closeModal();
      if (a === 'reply') { chatReply = { id: m.id, uid: m.uid, name: m.name, text: m.text || (m.audio ? '🎤 Голосовое' : ''), image: !!m.image }; chatEdit = null; drawReplyBar(); $('#chat-text').focus(); }
      if (a === 'mention') { const ta = $('#chat-text'); ta.value = (ta.value && !/\s$/.test(ta.value) ? ta.value + ' ' : ta.value) + '@' + chatProfiles[m.uid].nick + ' '; ta.focus(); if (chatMicMode) chatMicMode(); }
      if (a === 'copy') { try { await navigator.clipboard.writeText(m.text); toast('Скопировано'); } catch { toast('Не удалось скопировать'); } }
      if (a === 'edit') { chatEdit = { id: m.id, text: m.text }; chatReply = null; chatAttach = null; $('#chat-text').value = m.text; drawReplyBar(); $('#chat-text').focus(); }
      if (a === 'del' && await confirmDlg('Удалить сообщение?', 'Оно пропадёт у всех участников чата.', 'Удалить')) ch.remove(id).catch((ex) => toast(Cl.errText(ex)));
    }));
    openModal(sh, $('#backdrop'));
  }
  // Клавиатура на iPhone: поднять поле ввода над ней
  if (window.visualViewport) {
    const kb = () => { const v = window.visualViewport; const h = Math.max(0, window.innerHeight - v.height - v.offsetTop); document.documentElement.style.setProperty('--kb', h > 80 ? h + 'px' : '0px'); };
    visualViewport.addEventListener('resize', kb); visualViewport.addEventListener('scroll', kb);
  }

  // =====================================================================
  // ---------- Админ-панель ----------
  // =====================================================================
  function adminCardHtml() {
    const Cl = CL(); if (!Cl || !Cl.admin || !Cl.account.user || !Cl.admin.isAdminEmail()) return '';
    if (!Cl.admin.isAdmin()) return `<div class="card admin-card"><h2>🛡 Администратор</h2>
      <p class="muted" style="margin:0 0 12px">Права администратора включатся, когда вы подтвердите почту ${esc(Cl.util.ADMIN_EMAIL)}.</p>
      <div class="btn-row"><button class="btn btn-primary" data-act="adm-verify">Отправить письмо</button><button class="btn btn-secondary" data-act="adm-verified">Я подтвердил</button></div></div>`;
    return `<div class="card admin-card"><h2>🛡 Администратор</h2><p class="muted" style="margin:0 0 12px">Сборщики, блокировки, рейтинг и чат.</p><button class="btn btn-primary" data-act="adm-open">Открыть админ-панель</button></div>`;
  }
  async function openAdmin() {
    const Cl = CL(), A = Cl.admin, sh = $('#sheet');
    sh.innerHTML = `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">Админ-панель</div></div><button class="icon-btn" data-close>×</button></div><p class="muted">Загрузка…</p>`;
    if (!modalStack.length) openModal(sh, $('#backdrop'));
    let users, sum;
    try { [users, sum] = await Promise.all([A.users(), A.summary()]); }
    catch (ex) { sh.querySelector('p').textContent = Cl.errText(ex); return; }
    const day = Date.now() - 864e5;
    const waiting = users.filter((u) => !u.chatAccess && !u.banned && u.uid !== myUid());
    const ranked = users.filter((u) => u.stats && u.stats.visible).length, banned = users.filter((u) => u.banned).length, active = users.filter((u) => u.lastSeen > day).length;
    const seen = (t) => (!t ? 'не заходил в чат' : Date.now() - t < 3 * 60e3 ? 'в сети' : 'был ' + new Date(t).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }));
    sh.innerHTML = `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">Админ-панель</div><div class="sheet-sub">${esc(Cl.util.ADMIN_EMAIL)}</div></div><button class="icon-btn" data-close>×</button></div>
      <div class="tiles">
        <div class="tile"><div class="t-label">Сборщиков</div><div class="t-value num">${users.length}</div></div>
        <div class="tile"><div class="t-label">Были за сутки</div><div class="t-value num">${active}</div></div>
        <div class="tile"><div class="t-label">В рейтинге</div><div class="t-value num">${ranked}</div></div>
        <div class="tile"><div class="t-label">Сообщений за сутки</div><div class="t-value num">${sum.messages24h}</div></div>
        ${banned ? `<div class="tile wide"><div class="t-label">Заблокировано</div><div class="t-value num">${banned}</div></div>` : ''}
      </div>
      <h3 class="adm-h">Сезонные темы</h3>
      ${seasonAdmin()}
      <h3 class="adm-h">Состояние Firebase</h3>
      <div class="card usage-card" id="adm-usage"><p class="muted" style="margin:0">Загрузка…</p></div>
      <h3 class="adm-h">Отчёт склада</h3>
      <p class="hint">Excel-файл или фото таблицы → программа найдёт строки сборщиков по ФИО и предложит внести им линии, производительность и заработок. ФИО каждого сборщика видите только вы.</p>
      <button class="btn btn-primary" id="adm-report">${icon('file')} Загрузить отчёт</button>
      ${waiting.length ? `<h3 class="adm-h">Ждут доступа к чату · ${waiting.length}</h3>
        <div class="rank-list adm-list">${waiting.map((u) => `<div class="rank-row">${avatarHtml(u.avatar, 36)}<span class="grow"><b>${esc(u.name)}</b><small>@${esc(u.nick)}${u.note && u.note.fio ? ' · ' + esc(u.note.fio) : ''}</small></span><button class="btn btn-small btn-primary" data-grant="${u.uid}">Открыть</button></div>`).join('')}</div>
        ${waiting.length > 1 ? '<button class="btn btn-secondary" id="adm-grant-all">Открыть доступ всем</button>' : ''}` : ''}
      <h3 class="adm-h">Сборщики</h3>
      <div class="rank-list adm-list">${users.map((u) => `<button class="rank-row" data-adm="${u.uid}">${avatarHtml(u.avatar, 40)}<span class="grow"><b>${esc(u.name)} ${u.banned ? '<em class="tag bad">заблокирован</em>' : ''}${u.stats && u.stats.visible ? '<em class="tag">в рейтинге</em>' : ''}${(CL().social.aliases || {})[u.uid] ? `<em class="tag">для других: ${esc(CL().social.aliases[u.uid].alias)}</em>` : ''}${!u.chatAccess && u.uid !== myUid() ? '<em class="tag warn">без чата</em>' : ''}</b><small>@${esc(u.nick)}${u.note && u.note.fio ? ' · ' + esc(u.note.fio) : ' · <i>ФИО не указано</i>'} · ${esc(seen(u.lastSeen))}</small></span><span class="chev">›</span></button>`).join('')}</div>
      <h3 class="adm-h">Чат</h3>
      <p class="hint">Удалить отдельное сообщение — нажмите на него в чате → «Удалить у всех».</p>
      <button class="btn btn-danger" id="adm-clear">Очистить весь чат</button>
      <p class="hint" style="margin-top:14px">Почты и пароли сборщиков приложение не показывает: список аккаунтов, сброс пароля и удаление — в консоли Firebase → Authentication → Users.</p>`;
    sh.querySelectorAll('[data-adm]').forEach((b) => (b.onclick = () => adminUser(users.find((u) => u.uid === b.dataset.adm), users)));
    sh.querySelectorAll('[data-grant]').forEach((b) => (b.onclick = async () => { b.disabled = true; try { await A.grantChat(b.dataset.grant); toast('Доступ к чату открыт'); openAdmin(); } catch (ex) { toast(Cl.errText(ex)); b.disabled = false; } }));
    if ($('#adm-grant-all')) $('#adm-grant-all').onclick = async () => { try { await Promise.all(waiting.map((u) => A.grantChat(u.uid))); toast('Доступ открыт всем'); openAdmin(); } catch (ex) { toast(Cl.errText(ex)); } };
    $('#adm-report').onclick = () => openReport(users);
    A.usage().then((u) => { const el = $('#adm-usage'); if (el) el.innerHTML = usageHtml(u); }).catch(() => { const el = $('#adm-usage'); if (el) el.innerHTML = '<p class="muted" style="margin:0">Не удалось загрузить</p>'; });
    $('#adm-clear').onclick = async () => {
      if (!(await confirmDlg('Очистить весь чат?', 'Все сообщения будут удалены у всех без возможности восстановления.', 'Очистить'))) return;
      try { await Cl.chat.clearAll(); toast('Чат очищен'); openAdmin(); } catch (ex) { toast(Cl.errText(ex)); }
    };
  }
  async function adminUser(u, users = []) {
    const Cl = CL(), A = Cl.admin, me = u.uid === myUid();
    const v = await dialog({ title: `${u.name} · @${u.nick}`,
      text: `${u.note && u.note.fio ? `ФИО в отчёте: ${u.note.fio}. ` : 'ФИО для отчёта не указано. '}${u.banned ? `Заблокирован${u.banned.reason ? ': ' + u.banned.reason : ''}. ` : ''}${u.stats && u.stats.visible ? `В рейтинге: ${N(u.stats.totals.lines)} линий, ${u.stats.totals.days} смен.` : 'Статистика не опубликована.'}`,
      buttons: [{ text: 'Открыть профиль', value: 'open' }, { text: '📅 Календарь смен', cls: 'btn-primary', value: 'cal' },
        { text: u.note && u.note.fio ? 'ФИО и данные из отчёта' : 'Указать ФИО для отчёта', value: 'fio' },
        ...(me ? [] : [{ text: (Cl.social.aliases || {})[u.uid] ? `Имя для других: ${(Cl.social.aliases || {})[u.uid].alias}` : 'Кто какое имя видит', value: 'alias' }]),
        ...(me ? [] : u.chatAccess ? [{ text: 'Закрыть доступ к чату', value: 'revoke' }] : [{ text: 'Открыть доступ к чату', cls: 'btn-primary', value: 'grant' }]),
        ...(u.stats ? [{ text: 'Убрать из рейтинга', value: 'hide' }] : []),
        ...(me ? [] : u.banned ? [{ text: 'Разблокировать', cls: 'btn-primary', value: 'unban' }] : [{ text: 'Заблокировать', cls: 'btn-danger', value: 'ban' }]),
        { text: 'Отмена', value: null }] });
    try {
      if (v === 'open') { closeModal(); setTimeout(() => openPublicProfile(u.uid), 250); return; }
      if (v === 'cal') { setTimeout(() => openUserCal(u), 250); return; }
      if (v === 'hide' && await confirmDlg('Убрать из рейтинга?', 'Опубликованная статистика сборщика будет удалена. Он сможет опубликовать её снова, если не заблокирован.', 'Убрать')) { await A.hideStats(u.uid); toast('Убрано из рейтинга'); }
      if (v === 'ban') {
        const r = await dialog({ title: `Заблокировать @${u.nick}?`, text: 'Сборщик потеряет доступ к чату и рейтингу, его статистика удалится. Калькулятор и его смены останутся.',
          html: '<input class="input" id="ban-reason" maxlength="200" placeholder="Причина (необязательно)" style="margin-bottom:12px">',
          buttons: [{ text: 'Заблокировать', cls: 'btn-danger', read: (d) => ({ ok: true, reason: $('#ban-reason', d).value }) }, { text: 'Отмена', value: null }] });
        if (r && r.ok) { await A.ban(u.uid, u.nick, r.reason); toast('Заблокирован'); }
      }
      if (v === 'unban') { await A.unban(u.uid); toast('Разблокирован'); }
      if (v === 'grant') { await A.grantChat(u.uid); toast('Доступ к чату открыт'); }
      if (v === 'revoke') { await A.revokeChat(u.uid); toast('Доступ к чату закрыт'); }
      if (v === 'fio') { if (await editFio(u)) toast('Сохранено'); }
      if (v === 'alias') { const t = await editAlias(u, users); if (t) toast(t); }
    } catch (ex) { toast(Cl.errText(ex)); }
    if (v && v !== 'open') openAdmin();
  }
  // ---------- Расход бесплатных лимитов Firebase ----------
  function usageHtml(u) {
    if (!u) return '<p class="muted" style="margin:0">Данных пока нет — GitHub считает их раз в 6 часов.</p>';
    const L = u.limits || { reads: 50000, writes: 20000, deletes: 20000, storageBytes: 1024 ** 3 };
    const bar = (label, v, max, fmt) => {
      const p = max ? Math.min(100, (v / max) * 100) : 0, cls = p >= 90 ? 'bad' : p >= 70 ? 'warn' : '';
      return `<div class="us-row"><div class="us-top"><span>${label}</span><b class="num ${cls}">${p < 1 && v > 0 ? '<1' : Math.round(p)}%</b></div>
        <div class="us-bar"><i class="${cls}" style="width:${Math.max(p, v > 0 ? 1.5 : 0)}%"></i></div><small class="muted num">${fmt(v)} из ${fmt(max)}</small></div>`;
    };
    const n = (v) => N(Math.round(v || 0));
    const mb = (b) => (b >= 1024 ** 3 ? N(b / 1024 ** 3, 2) + ' ГБ' : N(b / 1024 ** 2, b < 10 * 1024 ** 2 ? 1 : 0) + ' МБ');
    const t = u.today || {}, y = u.yesterday || {};
    const upd = u.updatedAt && u.updatedAt.toMillis ? u.updatedAt.toMillis() : 0, ago = upd ? Math.round((Date.now() - upd) / 60e3) : null;
    const reset = u.resetAt && u.resetAt.toMillis ? new Date(u.resetAt.toMillis()) : null;
    let html = '';
    const consoleUrl = `https://console.firebase.google.com/project/${CL().projectId}/firestore/databases/-default-/usage`;
    if (u.monitoringError === 'billing' || u.monitoringError === 'no-permission' || !u.today) html += `<p class="hint" style="margin-top:0">Чтения и записи за день Google на бесплатном тарифе автоматически не отдаёт — только в консоли Firebase.</p>`;
    else if (u.monitoringError) html += `<p class="hint bad">Статистика запросов недоступна: ${esc(u.monitoringError)}</p>`;
    if (u.today) html += bar('Чтения сегодня', t.reads, L.reads, n) + bar('Записи сегодня', t.writes, L.writes, n) + bar('Удаления сегодня', t.deletes, L.deletes, n);
    if (u.storage) {
      html += bar('Объём базы', u.storage.bytes, L.storageBytes, mb) + `<small class="muted">${N(u.storage.docs)} документов · пересчёт раз в 6 часов</small>`;
      const NAMES = { chats: 'чат', publicProfiles: 'профили', publicStats: 'рейтинг', publicDays: 'дни в рейтинге', users: 'смены', imports: 'из отчётов', adminNotes: 'ФИО', chatAccess: 'доступы', usernames: 'ники', banned: 'блокировки', adminMeta: 'служебное' };
      const parts = Object.entries(u.storage.byCol || {}).sort((a, b) => b[1] - a[1]).slice(0, 5);
      if (parts.length) html += `<p class="hint" style="margin:4px 0 0">Больше всего: ${parts.map(([k, v]) => `${NAMES[k] || k} ${mb(v)}`).join(' · ')}</p>`;
    }
    html += `<a class="btn btn-secondary btn-small" style="margin-top:10px;display:inline-block" href="${consoleUrl}" target="_blank" rel="noopener">Чтения и записи в консоли ↗</a>`;
    if (u.today) html += `<p class="hint" style="margin-top:10px">Вчера: ${n(y.reads)} чтений · ${n(y.writes)} записей · ${n(y.deletes)} удалений</p>`;
    html += `<p class="hint" style="margin:6px 0 0">${ago !== null ? `Обновлено ${ago < 2 ? 'только что' : ago < 60 ? ago + ' мин назад' : Math.round(ago / 60) + ' ч назад'}` : ''}${reset ? ` · сброс лимитов в ${String(reset.getHours()).padStart(2, '0')}:${String(reset.getMinutes()).padStart(2, '0')}` : ''}. Тариф Spark бесплатный: при превышении база просто перестанет отвечать до сброса, денег не спишет.</p>`;
    return html;
  }
  // ---------- Календарь сборщика (только администратор): просмотр и правка его смен ----------
  async function openUserCal(u) {
    const Cl = CL(), sh = $('#sheet');
    const head = (sub) => `<div class="grabber"></div><div class="sheet-head"><div class="grow"><div class="sheet-title">📅 ${esc(u.name)}</div><div class="sheet-sub">${sub}</div></div><button class="icon-btn" data-close>×</button></div>`;
    sh.innerHTML = head('@' + esc(u.nick)) + '<p class="muted">Загрузка…</p>';
    if (!modalStack.length) openModal(sh, $('#backdrop'));
    let data;
    try { data = await Cl.admin.userData(u.uid); } catch (ex) { sh.querySelector('p').textContent = Cl.errText(ex); return; }
    const set = (data.doc && data.doc.settings) || {}, marks = (data.doc && data.doc.marks) || {}, E = data.entries;
    Cl.social.adminReconcile(u.uid, E).then((n) => { if (n) toast(`Рейтинг сборщика сверен: обновлено ${n} ${plural(n, 'день', 'дня', 'дней')}`); }).catch(() => {});
    const hist = Array.isArray(set.rateHistory) && set.rateHistory.length ? set.rateHistory : C.defaultState().settings.rateHistory;
    const today = todayKey();
    let { y, m } = C.parseKey(C.inYear(today) ? today : C.FIRST_DAY), curDay = null;
    const drawMonth = () => {
      const keys = C.monthKeys(m, y), s = C.summarize(E, keys);
      const idx = C.indexOf(y, m);
      sh.innerHTML = head('@' + esc(u.nick)) + `
        <div class="ucal-switch"><button type="button" data-um="-1" ${idx <= 0 ? 'disabled' : ''}>‹</button><b>${C.MONTHS[m]} ${y}</b><button type="button" data-um="1" ${idx >= C.MONTH_COUNT - 1 ? 'disabled' : ''}>›</button></div>
        <div class="ucal-sum num">${s.shifts} ${plural(s.shifts, 'смена', 'смены', 'смен')} · ${N(s.lines)} линий · ${M(s.total)}${s.prodAvg !== null ? ` · ${N(s.prodAvg, 1)}%` : ''}${s.weightDays ? ` · ${N(s.weight, 0)} кг` : ''}</div>
        <div class="ucal"><div class="ucal-wd">${['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((d) => `<i>${d}</i>`).join('')}</div>
          ${C.calendarGrid(m, y).map((w) => `<div class="ucal-row">${w.map((k) => {
            if (!k) return '<span></span>';
            const e = E[k], mk = marks[k], wk = C.weekdayMon(k) >= 5;
            return `<button type="button" class="ucal-d ${e ? 'has' : ''} ${wk ? 'we' : ''} ${k === today ? 'now' : ''}" data-ud="${k}"><b>${C.parseKey(k).d}</b><small class="num">${e ? N(e.lines || 0) : mk ? ({ off: 'вых', sick: 'бол', vacation: 'отп', work: 'раб' })[mk] || '' : ''}</small>${e && e.weight ? `<em class="num">${e.weight < 1000 ? Math.round(e.weight) + 'кг' : N(e.weight / 1000, 1) + 'т'}</em>` : ''}</button>`;
          }).join('')}</div>`).join('')}</div>
        <p class="hint">Нажмите на день, чтобы внести или поправить смену. Рейтинг обновляется сразу, а на телефон сборщика правка придёт, когда он будет в сети.</p>`;
    };
    // Сразу пересчитать рейтинг сборщика (не дожидаясь его телефона)
    const rankSync = async (k, entry) => {
      try { return (await Cl.social.adminPublish(u.uid, k, entry, E)) ? ' · рейтинг обновлён' : ''; }
      catch (ex) { return ' · рейтинг обновится с его телефона'; }
    };
    const drawDay = (k) => {
      curDay = k;
      const e = E[k], v = (x) => (x === null || x === undefined ? '' : String(x).replace('.', ','));
      sh.innerHTML = head(`${esc(C.fmtDateLong(k))}, ${C.WEEKDAYS[C.weekdayMon(k)].toLowerCase()}`) + `
        <form id="ud-form" novalidate>
          <div class="field"><label for="ud-lines">Линии</label><input class="input big num" id="ud-lines" inputmode="numeric" value="${e ? v(e.lines || '') : ''}"></div>
          <div class="field"><label for="ud-prod">Производительность, % <span>необязательно</span></label><input class="input num" id="ud-prod" inputmode="decimal" value="${e ? v(e.prod) : ''}"></div>
          <div class="field"><label for="ud-actual">Фактически заработано, ₽ <span>необязательно</span></label><input class="input num" id="ud-actual" inputmode="decimal" value="${e ? v(e.actual) : ''}"></div>
          <div class="field"><label for="ud-weight">Вес товара за смену, кг <span>необязательно</span></label><input class="input num" id="ud-weight" inputmode="decimal" value="${e ? v(e.weight) : ''}"></div>
          <div class="field"><label for="ud-comment">Комментарий <span>необязательно</span></label><textarea class="input" id="ud-comment" maxlength="500">${e ? esc(e.comment || '') : ''}</textarea></div>
          <p class="hint">Тариф: ${M(e ? e.rate : C.rateFor(hist, k))} за линию${e ? ' (как в записи)' : ' (по тарифам сборщика)'}. Время смены, часы и самочувствие не меняются.</p>
          <p class="error" id="ud-error"></p>
          <button class="btn btn-primary" type="submit">${e ? 'Сохранить изменения' : 'Внести смену'}</button>
          ${e ? '<button class="btn btn-danger" type="button" data-udel>Удалить смену</button>' : ''}
          <button class="btn btn-secondary" type="button" data-uback>Назад к календарю</button>
        </form>`;
      const num = (id) => String($(id).value).replace(/\s/g, '').replace(',', '.');
      $('#ud-form').onsubmit = async (ev) => {
        ev.preventDefault();
        const input = { ...(e || { start: set.shiftStart || null }), lines: num('#ud-lines'), prod: num('#ud-prod'), actual: num('#ud-actual'), weight: num('#ud-weight'), comment: $('#ud-comment').value };
        const r = C.buildEntry(input, e ? e.rate : C.rateFor(hist, k));
        if (!r.ok) { $('#ud-error').textContent = r.error; return; }
        const b = ev.submitter || $('#ud-form button[type="submit"]'); b.disabled = true; b.textContent = 'Сохраняю…';
        try { await Cl.admin.setEntry(u.uid, k, r.entry); E[k] = r.entry; drawMonth(); toast('Смена сохранена' + (await rankSync(k, r.entry))); }
        catch (ex) { $('#ud-error').textContent = Cl.errText(ex); b.disabled = false; b.textContent = 'Сохранить'; }
      };
    };
    sh.onclick = async (ev) => {
      const t = ev.target;
      if (t.closest('[data-close]')) return closeModal();
      const mv = t.closest('[data-um]'); if (mv && !mv.disabled) { m += +mv.dataset.um; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } return drawMonth(); }
      const d = t.closest('[data-ud]'); if (d) return drawDay(d.dataset.ud);
      if (t.closest('[data-uback]')) return drawMonth();
      if (t.closest('[data-udel]')) {
        const k = curDay;
        if (!k || !E[k] || !(await confirmDlg('Удалить смену?', `${C.fmtDateLong(k)} — смена пропадёт и у сборщика.`, 'Удалить', true))) return;
        try { await Cl.admin.deleteEntry(u.uid, k); delete E[k]; drawMonth(); toast('Смена удалена' + (await rankSync(k, null))); } catch (ex) { toast(Cl.errText(ex)); }
      }
    };
    drawMonth();
  }
  // ---------- Подмена имени: кто видит настоящее имя, а кто — то, что написал администратор ----------
  async function editAlias(u, users) {
    const Cl = CL(), cur = (Cl.social.aliases || {})[u.uid] || { alias: '', allow: [] };
    const others = users.filter((x) => x.uid !== u.uid && x.uid !== myUid());
    const r = await dialog({ title: `Имя «${u.name}»`,
      text: 'Отмеченные ниже видят настоящее имя. Все остальные — то, что вы напишете. Сам сборщик и вы всегда видите настоящее.',
      html: `<input class="input" id="al-name" maxlength="40" value="${esc(cur.alias)}" placeholder="Имя для остальных" style="margin-bottom:10px">
        <div class="al-list">${others.length ? others.map((x) => `<label class="check"><input type="checkbox" data-al="${x.uid}" ${cur.allow.includes(x.uid) ? 'checked' : ''}><span>${esc(x.name)} <small class="muted">@${esc(x.nick)}</small></span></label>`).join('') : '<p class="muted">Других сборщиков пока нет.</p>'}</div>`,
      buttons: [{ text: 'Сохранить', cls: 'btn-primary', read: (d) => ({ alias: $('#al-name', d).value.trim(), allow: [...d.querySelectorAll('[data-al]:checked')].map((i) => i.dataset.al) }) },
        ...(cur.alias ? [{ text: 'Убрать подмену', cls: 'btn-danger', value: 'clear' }] : []), { text: 'Отмена', value: null }] });
    if (!r) return '';
    if (r === 'clear') { await Cl.admin.clearAlias(u.uid); return 'Все снова видят настоящее имя'; }
    if (!r.alias) { toast('Напишите имя для остальных'); return ''; }
    await Cl.admin.setAlias(u.uid, r); return 'Сохранено';
  }
  // ---------- ФИО сборщика для отчёта (видит только администратор) ----------
  async function editFio(u) {
    const Cl = CL(), f = (u.note && u.note.fields) || { lines: true, prod: true, actual: false };
    const r = await dialog({ title: `ФИО: ${u.name} · @${u.nick}`, text: 'Как в отчёте склада, например «Евсюков Сергей Петрович». Видите только вы. Отмеченное будет предлагаться для внесения из отчёта.',
      html: `<input class="input" id="fio-in" maxlength="80" placeholder="Фамилия Имя Отчество" value="${esc((u.note && u.note.fio) || '')}" style="margin-bottom:10px">
        <label class="check"><input type="checkbox" id="fio-l" ${f.lines ? 'checked' : ''}><span>Линии (пики)</span></label>
        <label class="check"><input type="checkbox" id="fio-p" ${f.prod ? 'checked' : ''}><span>Производительность</span></label>
        <label class="check"><input type="checkbox" id="fio-a" ${f.actual ? 'checked' : ''}><span>Фактически заработано</span></label>`,
      buttons: [{ text: 'Сохранить', cls: 'btn-primary', read: (d) => ({ fio: $('#fio-in', d).value, fields: { lines: $('#fio-l', d).checked, prod: $('#fio-p', d).checked, actual: $('#fio-a', d).checked } }) }, { text: 'Отмена', value: null }] });
    if (!r) return false;
    try { await Cl.admin.setNote(u.uid, r); u.note = { ...r, fio: r.fio.trim() }; return true; } catch (ex) { toast(Cl.errText(ex)); return false; }
  }

  // ---------- Отчёт склада: файл или фото → строки сборщиков → отправка ----------
  function loadScript(src, global) {
    if (window[global]) return Promise.resolve(window[global]);
    return new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = src;
      s.onload = () => (window[global] ? res(window[global]) : rej(new Error('Не удалось загрузить ' + src)));
      s.onerror = () => rej(new Error('Не удалось загрузить модуль — проверьте интернет'));
      document.head.appendChild(s);
    });
  }
  // Файлы распознавания: на сайте — рядом с приложением, в APK — с сайта приложения (в APK их нет, чтобы он был лёгким)
  function ocrBase() {
    const cap = window.Capacitor, native = cap && cap.isNativePlatform && cap.isNativePlatform();
    return native ? `https://${CL().projectId}.web.app/ocr/` : 'ocr/';
  }
  function splitCsv(line, sep) {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') q = false; else cur += ch; }
      else if (ch === '"') q = true; else if (ch === sep) { out.push(cur); cur = ''; } else cur += ch;
    }
    out.push(cur); return out;
  }
  async function readReport(file, progress) {
    const name = (file.name || '').toLowerCase();
    if (/\.xls$/.test(name)) throw new Error('Старый формат .xls — сохраните отчёт как .xlsx (Файл → Сохранить как → Книга Excel)');
    if (/\.(xlsx|xlsm)$/.test(name) || /spreadsheetml/.test(file.type)) {
      progress('Читаю Excel…');
      const X = await loadScript('excel.js', 'ReadExcel');
      const sheets = await X.readAll(file), tables = [];
      for (const sh of sheets) {
        const t = Report.fromGrid(sh.data || [], sh.sheet || '');
        if (t && t.rows.length) tables.push(t);
      }
      return { tables };
    }
    if (/\.(csv|txt)$/.test(name) || /^text\//.test(file.type)) {
      const text = await file.text(), first = text.split(/\r?\n/).slice(0, 10).join('\n');
      const sep = [';', '\t', ','].sort((a, b) => first.split(b).length - first.split(a).length)[0];
      const t = Report.fromGrid(text.split(/\r?\n/).map((l) => splitCsv(l, sep)), 'CSV');
      return { tables: t && t.rows.length ? [t] : [] };
    }
    if (/\.doc$/.test(name) || file.type === 'application/msword') throw new Error('Старый формат .doc — сохраните отчёт как .docx (Файл → Сохранить как → Документ Word)');
    if (/\.docx$/.test(name) || /wordprocessingml/.test(file.type)) {
      progress('Читаю документ Word…');
      const X = await loadScript('excel.js', 'ReadExcel');
      let xml;
      try { xml = X.text(X.unzip(new Uint8Array(await file.arrayBuffer()), { filter: (f) => f.name === 'word/document.xml' })['word/document.xml']); }
      catch { throw new Error('Не удалось открыть документ Word — возможно, файл повреждён или защищён паролем'); }
      if (!xml) throw new Error('Это не документ Word (.docx)');
      return { tables: Report.fromDocx(xml) };
    }
    if (/^image\//.test(file.type) || /\.(jpe?g|png|webp|heic)$/.test(name)) return ocrReport(file, progress);
    throw new Error('Нужен файл Excel (.xlsx), Word (.docx), CSV или фото');
  }
  async function ocrReport(file, progress) {
    progress('Загружаю распознавание (≈7 МБ, один раз)…');
    const base = ocrBase();
    const T = await loadScript(base + 'tesseract.min.js', 'Tesseract');
    const img = await new Promise((res, rej) => { const u = URL.createObjectURL(file), i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Не удалось открыть фото (нужен JPG или PNG)')); i.src = u; });
    const nw = img.naturalWidth, nh = img.naturalHeight;
    const W = Math.min(4000, nw < 2500 ? nw * 2 : nw), H = Math.round(nh * W / nw);
    const orig = document.createElement('canvas'); orig.width = W; orig.height = H;
    const g = orig.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(img, 0, 0, W, H);
    progress('Подготавливаю фото…');
    await new Promise((r) => setTimeout(r, 30));
    const id = g.getImageData(0, 0, W, H), px = id.data, gray = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) gray[i] = (px[i * 4] * 299 + px[i * 4 + 1] * 587 + px[i * 4 + 2] * 114) / 1000;
    const clean = Report.cleanTable(gray, W, H);
    const cc = document.createElement('canvas'); cc.width = W; cc.height = H;
    const cd = cc.getContext('2d').createImageData(W, H);
    for (let i = 0; i < W * H; i++) { const v = clean[i]; cd.data[i * 4] = cd.data[i * 4 + 1] = cd.data[i * 4 + 2] = v; cd.data[i * 4 + 3] = 255; }
    cc.getContext('2d').putImageData(cd, 0, 0);
    const simd = WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11]));
    const worker = await T.createWorker('rus', 1, {
      workerPath: base + 'worker.min.js', corePath: base + (simd ? 'tesseract-core-simd-lstm.wasm.js' : 'tesseract-core-lstm.wasm.js'),
      langPath: base.replace(/\/$/, ''), gzip: true,
      logger: (m) => { if (m.status === 'recognizing text') progress(`Распознаю таблицу… ${Math.round(m.progress * 100)}%`); else if (/loading/.test(m.status)) progress('Загружаю распознавание…'); },
    });
    try {
      await worker.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' });
      const r = await worker.recognize(cc, {}, { blocks: true });
      const lines = [];
      for (const b of r.data.blocks || []) for (const p of b.paragraphs) for (const l of p.lines) lines.push({ y0: l.bbox.y0, y1: l.bbox.y1, words: l.words.map((w) => ({ t: w.text, x0: w.bbox.x0, y0: w.bbox.y0, x1: w.bbox.x1, y1: w.bbox.y1 })) });
      const t = Report.fromWords(lines, { sheet: 'фото' });
      return { tables: t && t.rows.length ? [t] : [], photo: orig };
    } finally { worker.terminate(); }
  }
  // Полоска строки таблицы с фото — чтобы сверить цифры глазами
  function rowCrop(photo, box) {
    if (!photo || !box) return '';
    // строка с соседними сверху и снизу — крупно (листается вбок), чтобы цифры читались
    const rh = box.y1 - box.y0, pad = Math.round(rh * 0.9), y0 = Math.max(0, box.y0 - pad), h = Math.min(photo.height - y0, rh + pad * 2);
    const x0 = Math.max(0, (box.x0 || 0) - rh), x1 = Math.min(photo.width, (box.x1 || photo.width) + rh * 2), w = x1 - x0;
    const c = document.createElement('canvas'), k = Math.min(1, 150 / h);
    c.width = Math.round(w * k); c.height = Math.round(h * k);
    const g = c.getContext('2d'); g.drawImage(photo, x0, y0, w, h, 0, 0, c.width, c.height);
    // рамка вокруг нужной строки
    g.strokeStyle = '#e8590c'; g.lineWidth = 3; g.strokeRect(1, (box.y0 - y0) * k - 2, c.width - 2, rh * k + 4);
    return c.toDataURL('image/jpeg', 0.85);
  }

  async function openReport(users) {
    const Cl = CL(), A = Cl.admin, sh = $('#sheet');
    const R = { users: users.filter((u) => !u.banned), rows: [], dates: [], date: '', photo: null, source: '', sel: {}, sent: {}, exact: true };
    const head = (sub) => `<div class="grabber"></div><div class="sheet-head"><button class="icon-btn" id="rp-back" aria-label="Назад">‹</button><div class="grow"><div class="sheet-title">Отчёт склада</div><div class="sheet-sub">${sub}</div></div><button class="icon-btn" data-close>×</button></div>`;
    const back = () => { const b = $('#rp-back'); if (b) b.onclick = () => openAdmin(); };
    function pick() {
      const noFio = R.users.filter((u) => !(u.note && u.note.fio)).length;
      sh.innerHTML = head('Шаг 1 — выберите отчёт') + `
        <div class="rp-pick">
          <label class="rp-src"><input type="file" id="rp-file" accept=".xlsx,.xlsm,.csv,.txt,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" hidden>
            <span class="rp-ic">📊</span><b>Excel-файл</b><small>самый точный способ: .xlsx или .csv — все листы и даты</small></label>
          <label class="rp-src"><input type="file" id="rp-word" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" hidden>
            <span class="rp-ic">📄</span><b>Word-документ</b><small>.docx с таблицей отчёта — тоже точно, все таблицы документа</small></label>
          <label class="rp-src"><input type="file" id="rp-photo" accept="image/*" hidden>
            <span class="rp-ic">📷</span><b>Фото или скриншот</b><small>распознаётся на телефоне; цифры нужно сверить — рядом будет строка с фото</small></label>
        </div>
        ${noFio ? `<p class="hint">У ${noFio} ${plural(noFio, 'сборщика', 'сборщиков', 'сборщиков')} не указано ФИО — их не найти в отчёте. ФИО можно ввести и на следующем шаге.</p>` : ''}
        <p class="hint">Фото лучше делать ровно, без бликов, чтобы таблица занимала весь кадр. Скриншоты с телефона, где таблица мелкая, читаются хуже — тогда лучше отправить сам файл.</p>
        <p class="error" id="rp-err"></p>`;
      back();
      const go = async (inp) => {
        const f = inp.files[0]; if (!f) return;
        sh.querySelector('.rp-pick').innerHTML = '<div class="rp-progress"><div class="spinner"></div><p id="rp-prog">Читаю отчёт…</p></div>';
        try {
          const res = await readReport(f, (t) => { const p = $('#rp-prog'); if (p) p.textContent = t; });
          if (!res.tables.length) throw new Error(res.photo ? 'Не удалось найти таблицу на фото. Попробуйте снять ровнее и ближе или загрузите Excel-файл.' : 'В файле не нашлась таблица с колонками «ФИО» и «Количество линий».');
          R.rows = Report.mergeTables(res.tables); R.photo = res.photo || null; R.exact = !res.photo;
          R.source = (res.photo ? 'фото ' : '') + (f.name || 'отчёт').replace(/\.[a-z]+$/i, '').slice(0, 40);
          R.sheets = res.tables.map((t) => t.sheet);
          R.dates = [...new Set(R.rows.map((r) => r.date).filter(Boolean))].sort();
          // в файле нет даты — по умолчанию вчера: ночная смена записывается на дату начала, а отчёт приходит после неё
          R.date = R.dates[R.dates.length - 1] || addDays(todayKey(), -1);
          R.dateHow = (res.tables.find((t) => t.dateHow) || {}).dateHow || '';
          await review(true);
        } catch (ex) { pick(); $('#rp-err').textContent = ex.message || String(ex); }
      };
      $('#rp-file').onchange = (e) => go(e.target);
      $('#rp-photo').onchange = (e) => go(e.target);
      $('#rp-word').onchange = (e) => go(e.target);
    }
    const rowsForDate = () => R.rows.filter((r) => !r.date || r.date === R.date || R.dates.length <= 1);
    function rematch() {
      const rows = rowsForDate();
      const m = Report.matchAccounts(R.users.map((u) => ({ uid: u.uid, fio: u.note && u.note.fio })), rows);
      for (const u of R.users) {
        const f = (u.note && u.note.fields) || { lines: true, prod: true, actual: false };
        const old = R.sel[u.uid];
        const i = old && old.manual ? old.row : (u.uid in m.matches ? m.matches[u.uid] : -1);
        const r = rows[i];
        R.sel[u.uid] = { row: i, manual: !!(old && old.manual), score: m.scores[u.uid] || 0, use: old ? old.use : { ...f },
          vals: r ? { lines: r.lines, prod: r.prod, actual: r.actual } : { lines: null, prod: null, actual: null } };
      }
    }
    const fmt = (v) => (v === null || v === undefined ? '' : String(v).replace('.', ','));
    async function review(first) {
      if (first) {
        rematch();
        // что уже есть в календаре сборщика за эту дату
        R.sent = {};
        await Promise.all(R.users.map(async (u) => { const e = await A.entryOf(u.uid, R.date).catch(() => null); if (e) R.sent[u.uid] = { applied: true, lines: e.lines }; }));
      }
      const rows = rowsForDate();
      const withFio = R.users.filter((u) => (u.note && u.note.fio) || R.sel[u.uid].row >= 0);
      const noFio = R.users.filter((u) => !withFio.includes(u));
      const ready = () => withFio.filter((u) => { const s = R.sel[u.uid]; return s.row >= 0 && ['lines', 'prod', 'actual'].some((k) => s.use[k] && s.vals[k] !== null); });
      const card = (u) => {
        const s = R.sel[u.uid], r = rows[s.row], st = R.sent[u.uid];
        const fld = (k, label, unit) => `<label class="rp-f ${s.use[k] ? 'on' : ''}"><input type="checkbox" data-use="${k}" ${s.use[k] ? 'checked' : ''}><span>${label}</span>
          <input class="input num" data-val="${k}" inputmode="decimal" value="${esc(fmt(s.vals[k]))}" placeholder="—"><small>${unit}</small></label>`;
        return `<div class="card rp-card ${s.row < 0 ? 'miss' : ''}" data-u="${u.uid}">
          <div class="rp-who">${avatarHtml(u.avatar, 36)}<div class="grow"><b>${esc(u.name)}</b><small>@${esc(u.nick)}</small></div>
            ${st ? `<em class="tag">${s.row >= 0 && rows[s.row] && rows[s.row].lines === st.lines ? 'уже внесено' : 'смена есть · ' + N(st.lines || 0) + ' лин.'}</em>` : ''}</div>
          <div class="rp-fio"><input class="input" data-fio maxlength="80" placeholder="ФИО как в отчёте" value="${esc((u.note && u.note.fio) || '')}"></div>
          <select class="input rp-row" data-row><option value="-1">— нет в отчёте —</option>${rows.map((x, i) => `<option value="${i}" ${i === s.row ? 'selected' : ''}>${esc(x.name)}${x.lines !== null ? ' · ' + N(x.lines) + ' лин.' : ''}</option>`).join('')}</select>
          ${s.row >= 0 && !s.manual && s.score < 0.9 ? '<p class="hint bad">Совпадение неточное — проверьте, та ли строка</p>' : ''}
          ${r && R.photo ? `<div class="rp-crop-box"><img class="rp-crop" src="${rowCrop(R.photo, r.box)}" alt="Строка с фото"></div><p class="hint" style="margin-top:-6px">Строка с фото — листайте вбок, нажмите, чтобы увеличить</p>` : ''}
          ${s.row >= 0 ? `<div class="rp-fields">${fld('lines', 'Линии', 'шт')}${fld('prod', 'Производительность', '%')}${fld('actual', 'Заработано', '₽')}</div>` : ''}
        </div>`;
      };
      const n = ready().length;
      sh.innerHTML = head(`Шаг 2 — проверьте и отправьте · ${rows.length} ${plural(rows.length, 'строка', 'строки', 'строк')}${R.sheets && R.sheets.length > 1 ? ' · листы: ' + esc(R.sheets.join(', ')) : ''}`) + `
        <div class="field"><label>Дата смены <span>${R.dateHow ? 'взята: ' + esc(R.dateHow) + ' · ' : R.dates.length ? '' : '<b class="down">в отчёте даты нет — проверьте</b> · '}ночная — на дату начала</span></label>
          <div class="rp-date">${R.dates.length > 1 ? `<select class="input" id="rp-date">${R.dates.map((d) => `<option value="${d}" ${d === R.date ? 'selected' : ''}>${C.fmtDateLong(d)}</option>`).join('')}</select>`
            : `<input class="input" type="date" id="rp-date" value="${R.date}">`}
          <button type="button" class="btn btn-small btn-secondary" data-shift="-1">−1 день</button><button type="button" class="btn btn-small btn-secondary" data-shift="1">+1</button></div></div>
        ${R.photo ? '<p class="hint">Цифры распознаны с фото — сверьте их с полоской строки под каждым именем и исправьте, если нужно.</p>' : ''}
        ${withFio.map(card).join('') || '<div class="card"><p class="muted" style="margin:0">Укажите ФИО сборщиков ниже — тогда программа найдёт их строки.</p></div>'}
        ${noFio.length ? `<details class="rp-nofio" ${withFio.length ? '' : 'open'}><summary>Без ФИО · ${noFio.length}</summary>${noFio.map((u) => `<div class="rp-mini" data-u="${u.uid}">${avatarHtml(u.avatar, 28)}<span class="grow"><b>${esc(u.name)}</b> <small>@${esc(u.nick)}</small></span><input class="input" data-fio maxlength="80" placeholder="ФИО как в отчёте"></div>`).join('')}</details>` : ''}
        <p class="hint">Данные сразу внесутся в календарь сборщика за эту дату и в рейтинг. В его смене меняются только отмеченные поля; на телефон сборщика всё придёт, когда он будет в сети.</p>
        <button class="btn btn-primary" id="rp-send" ${n ? '' : 'disabled'}>Внести ${n} ${plural(n, 'сборщику', 'сборщикам', 'сборщикам')}</button>`;
      back();
      const dateEl = $('#rp-date');
      dateEl.onchange = async () => { if (C.isValidKey(dateEl.value)) { R.date = dateEl.value; await review(true); } };
      sh.querySelectorAll('[data-shift]').forEach((b) => (b.onclick = async () => { R.date = C.addDays(R.date, +b.dataset.shift); if (R.dates.length > 1) { R.rows.forEach((r) => { if (r.date) r.date = C.addDays(r.date, +b.dataset.shift); }); R.dates = R.dates.map((d) => C.addDays(d, +b.dataset.shift)); } await review(true); }));
      sh.querySelectorAll('[data-u]').forEach((el) => {
        const u = R.users.find((x) => x.uid === el.dataset.u), s = R.sel[u.uid];
        const fio = el.querySelector('[data-fio]');
        if (fio) fio.onchange = async () => {
          const v = fio.value.trim();
          try { await A.setNote(u.uid, { fio: v, fields: (u.note && u.note.fields) || s.use }); u.note = { fio: v, fields: (u.note && u.note.fields) || s.use }; } catch (ex) { toast(Cl.errText(ex)); }
          R.sel[u.uid].manual = false; rematch(); review();
        };
        const sel = el.querySelector('[data-row]');
        if (sel) sel.onchange = () => { const r = rows[+sel.value]; s.row = +sel.value; s.manual = true; s.vals = r ? { lines: r.lines, prod: r.prod, actual: r.actual } : { lines: null, prod: null, actual: null }; review(); };
        el.querySelectorAll('[data-use]').forEach((c) => (c.onchange = () => { s.use[c.dataset.use] = c.checked; review(); }));
        el.querySelectorAll('[data-val]').forEach((i) => (i.onchange = () => {
          const k = i.dataset.val, v = Report.parseNum(i.value);
          s.vals[k] = v === null ? null : k === 'lines' ? Math.round(v) : Math.round(v * 100) / 100; review();
        }));
      });
      sh.querySelectorAll('.rp-crop').forEach((im) => (im.onclick = () => openPhoto(im.src)));
      $('#rp-send').onclick = async () => {
        const list = ready();
        const bad = list.find((u) => { const v = R.sel[u.uid].vals; return (v.lines !== null && (v.lines < 0 || v.lines > 5000)) || (v.prod !== null && (v.prod < 0 || v.prod > 1000)) || (v.actual !== null && v.actual < 0); });
        if (bad) return toast(`Проверьте числа у ${bad.name}`);
        if (!(await confirmDlg(`Внести за ${C.fmtDateLong(R.date)}?`, `Смены ${list.length} ${plural(list.length, 'сборщика', 'сборщиков', 'сборщиков')} заполнятся данными из отчёта. Если смена за этот день уже есть — в ней обновятся только отмеченные поля.`, 'Внести'))) return;
        const btn = $('#rp-send'); btn.disabled = true; btn.textContent = 'Вношу…';
        let ok = 0, rank = 0;
        for (const u of list) {
          const s = R.sel[u.uid], vals = {};
          for (const k of ['lines', 'prod', 'actual']) if (s.use[k] && s.vals[k] !== null) vals[k] = s.vals[k];
          try {
            // прямо в календарь сборщика — так же, как правка в его календаре
            const d = await A.userData(u.uid), set = (d.doc && d.doc.settings) || {};
            const hist = Array.isArray(set.rateHistory) && set.rateHistory.length ? set.rateHistory : C.defaultState().settings.rateHistory;
            const prev = d.entries[R.date], input = prev ? { ...prev } : { start: set.shiftStart || null };
            Object.assign(input, vals);
            if (!prev && !input.lines && !input.actual) { toast(`${u.name}: в отчёте только %, а смены за этот день нет`); continue; }
            const r = C.buildEntry(input, prev ? prev.rate : C.rateFor(hist, R.date));
            if (!r.ok) { toast(`${u.name}: ${r.error}`); continue; }
            await A.setEntry(u.uid, R.date, r.entry);
            d.entries[R.date] = r.entry;
            A.clearImport(u.uid, R.date).catch(() => {});
            if (await Cl.social.adminPublish(u.uid, R.date, r.entry, d.entries).catch(() => false)) rank++;
            const f = (u.note && u.note.fields) || {};
            if (['lines', 'prod', 'actual'].some((k) => !!f[k] !== !!s.use[k])) { await A.setNote(u.uid, { fio: (u.note && u.note.fio) || '', fields: s.use }); u.note = { ...(u.note || {}), fields: { ...s.use } }; }
            ok++;
          } catch (ex) { toast(`${u.name}: ${Cl.errText(ex)}`); }
        }
        toast(`Внесено в календарь: ${ok} из ${list.length}${rank ? ` · рейтинг обновлён у ${rank}` : ''}`);
        await review(true);
      };
    }
    pick();
    if (!modalStack.length) openModal(sh, $('#backdrop'));
  }
  document.addEventListener('click', async (e) => {
    const el = e.target.closest('[data-act^="adm-"]'); if (!el) return;
    const Cl = CL(); if (!Cl) return;
    const a = el.dataset.act;
    try {
      if (a === 'adm-open') openAdmin();
      if (a === 'adm-verify') { await Cl.admin.sendVerification(); toast('Письмо отправлено на ' + Cl.util.ADMIN_EMAIL); }
      if (a === 'adm-verified') { const ok = await Cl.admin.refreshVerification(); toast(ok ? 'Почта подтверждена — права администратора включены' : 'Почта ещё не подтверждена: откройте ссылку из письма'); refreshAccountCard(); if (ok && Cl.account.profile) Cl.chat.start(Cl.account.user.uid); }
    } catch (ex) { toast(Cl.errText(ex)); }
  });

  // Подключение к облаку, когда загрузится cloud.js
  let cloudHooked = false;
  function hookCloud() {
    const Cl = CL(); if (!Cl || cloudHooked) return;
    cloudHooked = true;
    Cl.attach({
      get: () => state,
      set: (s) => { state = C.normalizeState(s).state; saveLocal(); applyTheme(); if (!modalStack.length) renderAll(); else updateChip(); },
      defaults: () => C.defaultState(),
      merge: (a, b) => C.mergeStates(a, b),
      exportData: (s) => C.exportData(s),
      acceptImports: () => acceptImports(),
      applyImport: (day, it) => applyImport(day, it),
    });
    let askedProfile = false;
    Cl.on((type, d) => {
      if (type === 'sync' && d.status === 'needs-choice') askSyncChoice();
      if (type === 'profile' && d.loaded && !d.profile && Cl.account.user && !askedProfile) {
        askedProfile = true;
        const ask = () => { if (!Cl.account.user || Cl.account.profile) return; if (modalStack.length) return setTimeout(ask, 700); if (!$('#sheet.show #pe-form')) openProfileEdit(true); };
        setTimeout(ask, 300);
      }
      if (type === 'auth' && !d.user) askedProfile = false;
      if (type === 'auth' && d.user) setTimeout(adminBackfill, 8000);
      if (type === 'error' && d.message) toast(d.message);
      if (type === 'imports' && d.applied && d.applied.length) importsApplied(d.applied);
      if (type === 'imports') refreshAccountCard();
      if (type === 'social' && 'my' in d && d.my && d.my.visible) publishBadges();
      if (type === 'social' && 'aliases' in d && ui.tab === 'crew' && !modalStack.length) { if (ui.crew.sub === 'chat') drawChat(false); else renderCrew(); }
      if (type === 'auth' || type === 'profile' || type === 'sync' || type === 'social') refreshAccountCard();
      // точки «в облаке» в календаре
      if ((type === 'sync' || type === 'auth') && ui.tab === 'cal' && !modalStack.length) renderCal();
      if (type === 'chat') { if (ui.tab === 'crew' && ui.crew.sub === 'chat') drawChat(false); updateChatBadge(); }
      if (type === 'auth' && !d.user) updateChatBadge();
      if ((type === 'auth' || type === 'profile' || (type === 'social' && 'my' in d)) && ui.tab === 'crew' && !modalStack.length && ui.crew.sub !== 'people' && (ui.crew.sub !== 'chat' || type === 'auth')) renderCrew();
    });
    refreshAccountCard();
  }
  document.addEventListener('cloud:ready', hookCloud);

  // ---------- Обновления: баннер сверху ----------
  // text — что пишем; btn — кнопка справа (необязательно); null — убрать баннер
  function updBanner(text, btn) {
    let b = $('#upd-banner');
    if (!text) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'upd-banner'; document.body.appendChild(b); }
    b.innerHTML = `<span>${esc(text)}</span>${btn ? `<button type="button">${esc(btn.text)}</button>` : ''}`;
    if (btn) b.querySelector('button').onclick = btn.run;
  }
  // Сайт: новая версия скачивается service worker'ом → «Обновление готово»
  function watchSiteUpdate(reg) {
    if (!reg) return;
    const had = !!navigator.serviceWorker.controller;
    reg.addEventListener('updatefound', () => {
      const w = reg.installing; if (!w || !had) return; // первый заход — не показываем
      updBanner('⬇️ Скачивается обновление сайта…');
      w.addEventListener('statechange', () => {
        if (w.state === 'activated') updBanner('✅ Обновление сайта скачано', { text: 'Обновить', run: () => location.reload() });
        if (w.state === 'redundant') updBanner(null);
      });
    });
  }
  // APK: обновление «по воздуху». Новая версия приложения скачивается с сайта (архив ota/<версия>.zip),
  // включается при следующем запуске. Без интернета работает последняя скачанная (или встроенная) версия.
  // Если новая версия не запустилась — плагин сам вернёт прежнюю (notifyAppReady не вызван).
  const BUILD_ID = '__BUILD_ID__';
  let otaBusy = false, otaLast = 0;
  document.addEventListener('click', (e) => { if (e.target.closest('[data-act="ota-check"]')) { const U = nativePlugin('CapacitorUpdater'); if (U) checkOta(U, true); } });
  // Администратор, один раз: дописать в рейтинг вес по уже внесённым сменам всех сборщиков
  const KG_FILL = 'zarplata2027:kg-backfill-1';
  async function adminBackfill() {
    const Cl = CL(); if (!Cl || !Cl.admin || !Cl.admin.isAdmin() || !navigator.onLine) return;
    try { if (localStorage.getItem(KG_FILL)) return; } catch { return; }
    try {
      const users = await Cl.admin.users(); let n = 0;
      for (const u of users) { if (u.uid === myUid() || !(u.stats && u.stats.visible)) continue; const d = await Cl.admin.userData(u.uid); n += await Cl.social.adminReconcile(u.uid, d.entries); }
      localStorage.setItem(KG_FILL, '1');
      if (n) toast(`Рейтинг сверен по сменам сборщиков: обновлено ${n} ${plural(n, 'день', 'дня', 'дней')}`);
    } catch {}
  }
  async function startOta() {
    const U = nativePlugin('CapacitorUpdater'); if (!U) return;
    try { await U.notifyAppReady(); } catch {}
    const check = () => { if (!document.hidden && navigator.onLine && Date.now() - otaLast > 30 * 60e3) checkOta(U); };
    setTimeout(check, 5000);
    document.addEventListener('visibilitychange', check);
    window.addEventListener('online', check);
  }
  // JSON с сайта: в APK — через нативный HTTP (без ограничений браузера на чужой адрес), в браузере — fetch
  async function getJson(url) {
    const H = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;
    if (isNative() && H && H.get) {
      const r = await H.get({ url, headers: { 'Cache-Control': 'no-cache' } });
      if (r.status !== 200) throw new Error('сайт ответил ' + r.status);
      return typeof r.data === 'string' ? JSON.parse(r.data) : r.data;
    }
    const r = await fetch(url, { cache: 'no-store' }); if (!r.ok) throw new Error('сайт ответил ' + r.status); return r.json();
  }
  // manual — проверка по нажатию на номер версии: сообщаем результат, даже если обновлений нет
  async function checkOta(U, manual) {
    const pid = window.Cloud && window.Cloud.projectId;
    if (!pid) { if (manual) toast('Не найден адрес сайта для обновлений'); return; }
    if (otaBusy) return;
    otaBusy = true; otaLast = Date.now();
    try {
      const base = `https://${pid}.web.app/`;
      if (manual) updBanner('🔎 Проверяю обновления…');
      const info = await getJson(base + 'version.json?t=' + Date.now());
      if (!info || !info.version || info.version === BUILD_ID) { if (manual) { updBanner(null); toast('У вас последняя версия'); } return; }
      // нужен модуль Android, которого нет в этом APK — по воздуху не обновить
      const cap = window.Capacitor, missing = (info.plugins || []).filter((n) => cap.isPluginAvailable && !cap.isPluginAvailable(n));
      if (missing.length) { updBanner('Есть новая версия — нужно скачать новый APK', { text: 'Понятно', run: () => updBanner(null) }); return; }
      const list = await U.list().then((r) => r.bundles || []).catch(() => []);
      let bundle = list.find((b) => b.version === info.version && b.status !== 'error');
      if (!bundle) {
        updBanner('⬇️ Скачивается обновление…');
        const h = await U.addListener('download', (e) => { if (e && e.percent != null) updBanner(`⬇️ Скачивается обновление… ${Math.round(e.percent)}%`); });
        // info.download — доп. параметры с сайта (контрольная сумма и т.п.): если плагину понадобится что-то новое,
        // это добавляется на сайте, и старым версиям приложения не нужен новый APK
        try { bundle = await U.download({ url: base + info.url, version: info.version, ...(info.download || {}) }); } finally { try { h.remove(); } catch {} }
      }
      await U.next({ id: bundle.id });
      updBanner('✅ Обновление скачано', { text: 'Применить', run: () => { updBanner('Обновляю…'); U.set({ id: bundle.id }).catch(() => updBanner(null)); } });
    } catch (e) {
      otaLast = Date.now() - 25 * 60e3; // повторим через 5 минут
      if (navigator.onLine || manual) {
        const why = String((e && (e.message || e.errorMessage || e.code)) || e || 'ошибка').slice(0, 120);
        updBanner(`Не удалось обновиться: ${why}`, { text: 'OK', run: () => updBanner(null) });
      } else updBanner(null);
    } finally { otaBusy = false; }
  }

  function init() {
    document.querySelectorAll('.tabbar button').forEach((b) => b.insertAdjacentHTML('afterbegin', icon(b.dataset.icon)));
    applyTheme();
    { const sv = savedTab(); if (sv.crew && ui.crew && ['rank', 'chat', 'people', 'compare'].includes(sv.crew)) ui.crew.sub = sv.crew; setTab(sv.tab); }
    showLock();
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const cap = window.Capacitor;
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !(cap && cap.isNativePlatform && cap.isNativePlatform())) {
      navigator.serviceWorker.register('sw.js').then(watchSiteUpdate).catch(() => {});
    }
    startOta();
    // Обновляем «сегодня» при возврате в приложение (например, на следующий день)
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !modalStack.length && !lockShown) renderAll(); });
    if (window.Pet) Pet.init({ getState: () => state, C, todayKey, M, N, plural, esc });
    hookCloud();
    // Ярлык «Внести смену» (долгое нажатие на иконку на Android) → сразу форма смены
    try { if (new URLSearchParams(location.search).get('go') === 'today') { history.replaceState(null, '', location.pathname); setTimeout(() => openDay(todayKey()), 300); } } catch {}
    window.__app = { get state() { return state; }, openDay, setTab, ui };
  }
  init();
})();
