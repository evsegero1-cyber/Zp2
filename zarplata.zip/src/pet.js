/* Питомец — кошка, которая живёт в приложении.
 * Ходит по карточкам и столбикам графиков, переходит между вкладками (приходит с той стороны, где была),
 * радуется хорошим результатам и грустит, когда месяц не задался. Только оформление: на расчёты не влияет.
 * Координаты — в координатах страницы (кошка прокручивается вместе с содержимым).
 */
const Pet = (() => {
  'use strict';
  const W = 64, H = 48;                 // размер кошки, px; (x, y) — середина лап
  const TABS = ['home', 'cal', 'stats', 'success', 'crew', 'settings'];
  let api = null, layer = null, cat = null, bubble = null;
  let x = -200, y = 0, face = 1, perch = null, mood = 'ok', info = null;
  let raf = 0, timer = 0, busyUntil = 0, enabled = true, visibleTab = 'home', scrollT = 0, moveId = 0;
  const night = () => { const h = new Date().getHours(); return h >= 0 && h < 6; };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const PH = () => (typeof window !== 'undefined' && window.PET_PHRASES) || {};
  const recent = [];
  // Случайная реплика по ситуации: время суток, день недели, вкладка, настроение, Новый год
  function line(...keys) {
    const P = PH(), d = new Date(), h = d.getHours(), wd = d.getDay();
    let pools = keys.length ? keys : ['idle', 'thoughts', 'work', h < 6 ? 'night' : h < 11 ? 'morning' : h < 18 ? 'day' : 'evening', 'tab_' + visibleTab];
    if (!keys.length) {
      if (h < 6) pools.push('night');
      if (wd === 0 || wd === 6) pools.push('weekend'); if (wd === 1) pools.push('monday'); if (wd === 5) pools.push('friday');
      if (mood === 'happy') pools.push('happy'); if (mood === 'sad') pools.push('sad', 'sad');
      if (d.getMonth() === 11 || (d.getMonth() === 0 && d.getDate() <= 14)) pools.push('xmas', 'xmas');
    }
    pools = pools.map((k) => P[k]).filter((a) => a && a.length);
    if (!pools.length) return '';
    for (let i = 0; i < 8; i++) { const t = pick(pick(pools)); if (!recent.includes(t)) { recent.push(t); if (recent.length > 40) recent.shift(); return t; } }
    return pick(pick(pools));
  }

  // ---------- Рисунок (смотрит вправо) ----------
  const SVG = `<svg viewBox="0 0 64 48" width="64" height="48" aria-hidden="true">
    <defs>
      <linearGradient id="ptFur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFBE73"/><stop offset=".55" stop-color="#F59B48"/><stop offset="1" stop-color="#E07F2F"/></linearGradient>
      <linearGradient id="ptFurD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EE9446"/><stop offset="1" stop-color="#C96D27"/></linearGradient>
      <radialGradient id="ptCream" cx=".5" cy=".35" r=".7"><stop offset="0" stop-color="#FFFDF8"/><stop offset="1" stop-color="#FBE3C6"/></radialGradient>
      <radialGradient id="ptIris" cx=".45" cy=".4" r=".6"><stop offset="0" stop-color="#C9EC7A"/><stop offset="1" stop-color="#5E9C2C"/></radialGradient>
    </defs>
    <g class="pt-flip">
      <g class="pt-tail">
        <path d="M17 32 C8 32 3.5 25 6 15.5 C6.8 12.5 8.4 10.5 10 9.5" fill="none" stroke="url(#ptFur)" stroke-width="5.4" stroke-linecap="round"/>
        <path d="M17 32 C8 32 3.5 25 6 15.5 C6.8 12.5 8.4 10.5 10 9.5" fill="none" stroke="#C96D27" stroke-width="5.4" stroke-dasharray="1.6 4.2" stroke-dashoffset="-3" opacity=".75"/>
      </g>
      <g class="pt-legs-back">
        <g class="pt-leg l1"><path d="M17 32 h6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h-0.4 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="20" cy="45.6" rx="3.1" ry="1.6" fill="#FFF3E2"/></g>
        <g class="pt-leg l2"><path d="M23.5 32 h6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h-0.4 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="26.5" cy="45.6" rx="3.1" ry="1.6" fill="#FFF3E2"/></g>
      </g>
      <ellipse class="pt-haunch" cx="21" cy="39" rx="9.5" ry="8"/>
      <g class="pt-legs-front">
        <g class="pt-leg l3"><path d="M36.5 32 h5.6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h0 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="39.3" cy="45.6" rx="3" ry="1.6" fill="#FFF8EE"/></g>
        <g class="pt-leg l4"><path d="M42.6 32 h5.6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h0 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="45.4" cy="45.6" rx="3" ry="1.6" fill="#FFF8EE"/></g>
      </g>
      <g class="pt-body">
        <path d="M13.5 30.5 C13 23.5 19.5 20.5 28 20.6 C36.5 20.7 44.5 21.5 47 27.5 C49.2 33.5 45.5 40.5 36 40.8 L23 40.8 C17 40.8 13.8 36.8 13.5 30.5 Z" fill="url(#ptFur)"/>
        <path d="M20 21.6 q2.6 4 .8 8.4 M26.2 20.8 q2.6 4.4 .6 9.4 M32.4 21 q2.4 4.2 .4 8.8" stroke="#D2742B" stroke-width="2.1" fill="none" stroke-linecap="round" opacity=".85"/>
        <ellipse cx="42.6" cy="33.5" rx="5.8" ry="7" fill="url(#ptCream)"/>
      </g>
      <g class="pt-head">
        <path d="M39.6 16 C39 10.5 40.2 6 42 3.2 C45.2 5 47.8 8 48.8 11.4 Z" fill="url(#ptFur)"/>
        <path d="M41.6 13 C41.4 10.2 42 7.8 42.8 6.4 C44.6 7.6 46 9.4 46.6 11.4 Z" fill="#F6A9A3"/>
        <g class="pt-ear-r"><path d="M50 11.4 C51.6 7.8 54.6 4.8 58 3.4 C59.2 6.6 59.6 11 58.8 16 Z" fill="url(#ptFur)"/><path d="M52.4 11.4 C53.6 9.4 55.2 7.8 57 7 C57.6 8.8 57.6 11 57.2 13.2 Z" fill="#F6A9A3"/></g>
        <path d="M37.6 20.6 C37.6 13.4 42.6 9.6 49 9.6 C55.4 9.6 60.4 13.4 60.4 20.6 C60.4 23.8 59.2 26.4 57.2 28 C55 29.8 52.2 30.6 49 30.6 C45.8 30.6 43 29.8 40.8 28 C38.8 26.4 37.6 23.8 37.6 20.6 Z" fill="url(#ptFur)"/>
        <path d="M45.4 10.6 q1 2.8 0 5 M49 10 v5.2 M52.6 10.6 q-1 2.8 0 5" stroke="#D2742B" stroke-width="1.6" fill="none" stroke-linecap="round"/>
        <path d="M37.9 21.6 l3 .4 M38.3 24 l2.8 -.2 M60.1 21.6 l-2.6 .4" stroke="#D2742B" stroke-width="1.3" stroke-linecap="round"/>
        <ellipse cx="51.8" cy="25.6" rx="3.6" ry="3" fill="url(#ptCream)"/><ellipse cx="56.2" cy="25.6" rx="3.6" ry="3" fill="url(#ptCream)"/><ellipse cx="54" cy="28" rx="3" ry="2" fill="url(#ptCream)"/>
        <g class="pt-eyes-ok">
          <g class="pt-blink"><ellipse cx="46.4" cy="19.4" rx="2.4" ry="2.9" fill="url(#ptIris)"/><ellipse cx="46.8" cy="19.5" rx=".9" ry="2.2" fill="#1E1A14"/><circle cx="47.4" cy="18.2" r=".75" fill="#fff"/></g>
          <g class="pt-blink"><ellipse cx="54" cy="19.4" rx="2.4" ry="2.9" fill="url(#ptIris)"/><ellipse cx="54.4" cy="19.5" rx=".9" ry="2.2" fill="#1E1A14"/><circle cx="55" cy="18.2" r=".75" fill="#fff"/></g>
        </g>
        <g class="pt-eyes-happy" fill="none" stroke="#2B2118" stroke-width="1.6" stroke-linecap="round"><path d="M44.4 20 q2 -2.8 4 0"/><path d="M52 20 q2 -2.8 4 0"/></g>
        <g class="pt-eyes-sad"><path d="M44.2 17.4 l3.6 -1.4 M56.2 17.4 l-3.6 -1.4" stroke="#2B2118" stroke-width="1.4" stroke-linecap="round" fill="none"/><ellipse cx="46.4" cy="20.2" rx="1.9" ry="2.2" fill="url(#ptIris)"/><ellipse cx="46.6" cy="20.4" rx=".8" ry="1.6" fill="#1E1A14"/><ellipse cx="54" cy="20.2" rx="1.9" ry="2.2" fill="url(#ptIris)"/><ellipse cx="54.2" cy="20.4" rx=".8" ry="1.6" fill="#1E1A14"/></g>
        <g class="pt-eyes-sleep" fill="none" stroke="#2B2118" stroke-width="1.5" stroke-linecap="round"><path d="M44.4 19.8 q2 1.8 4 0"/><path d="M52 19.8 q2 1.8 4 0"/></g>
        <ellipse class="pt-blush" cx="43.2" cy="24.4" rx="2.2" ry="1.4" fill="#FF8A8A" opacity=".5"/><ellipse class="pt-blush" cx="58.8" cy="24.4" rx="1.6" ry="1.4" fill="#FF8A8A" opacity=".5"/>
        <path d="M52.6 23 h2.8 c0 1 -.8 1.7 -1.4 2 c-.6 -.3 -1.4 -1 -1.4 -2 z" fill="#EE7F8C"/>
        <path class="pt-mouth-ok" d="M52.2 26 q.9 1 1.8 0 q.9 1 1.8 0" fill="none" stroke="#7A4A33" stroke-width="1" stroke-linecap="round"/>
        <path class="pt-mouth-happy" d="M52.2 25.8 q1.8 3.4 3.6 0 z" fill="#C2505F" stroke="#7A4A33" stroke-width=".7"/>
        <path class="pt-mouth-sad" d="M52.4 27.4 q1.6 -1.5 3.2 0" fill="none" stroke="#7A4A33" stroke-width="1" stroke-linecap="round"/>
        <path d="M58.6 25 h5 M58.6 26.6 l4.6 1.4 M45 25.2 h-5.4 M45 26.8 l-5 1.4" stroke="#8A6250" stroke-width=".5" opacity=".7" stroke-linecap="round"/>
      </g>
    </g></svg>`;

  // ---------- Настроение: по результатам текущего месяца ----------
  function computeMood() {
    const st = api.getState(), C = api.C, today = api.todayKey(), p = C.parseKey(today);
    const s = C.monthSummary(st, p.m, today, p.y);
    const keys = Object.keys(st.entries || {}).filter((k) => st.entries[k] && k <= today).sort();
    const last = keys.length ? st.entries[keys[keys.length - 1]] : null;
    const x0 = s.extras, thr = x0.cfg.prodThreshold;
    let score = 0;
    const facts = [];
    if (!keys.length) return { mood: 'ok', facts: ['Внеси первую смену — и я начну радоваться вместе с тобой.'], s };
    if (x0.prodAvg !== null) {
      if (x0.prodOk) { score += 2; facts.push(`Средняя производительность ${fmt(x0.prodAvg, 1)}% — премия будет! Мур.`); }
      else if (s.needProd !== null && s.needProd <= thr + 8) facts.push(`До премии нужно в среднем ${fmt(s.needProd, 1)}% в оставшиеся смены. Мы сможем.`);
      else { score -= 1; facts.push(`Производительность пока ${fmt(x0.prodAvg, 1)}% — до премии далековато…`); }
    }
    if (x0.zone === 'green') { score += 1; facts.push('Сервис в зелёной зоне. Горжусь!'); }
    if (x0.zone === 'yellow') { score -= 1; facts.push('Сервис в жёлтой зоне. Давай без пересортов, ладно?'); }
    if (x0.zone === 'red') { score -= 2; facts.push('Сервис в красной зоне… Мне грустно.'); }
    if (s.target) {
      const k = (s.projected || s.total) / s.target;
      if (k >= 1) { score += 1; facts.push('Идём к цели месяца с запасом!'); }
      else if (k < 0.85) { score -= 1; facts.push(`До цели не хватает. Нужно около ${api.M(s.needPerShift)} за смену.`); }
      else if (s.needPerShift) facts.push(`Чтобы выйти на цель: ${api.M(s.needPerShift)} за смену.`);
    }
    if (last && s.avgPerShift) {
      const t = C.total(last);
      if (t >= s.avgPerShift * 1.1) { score += 1; facts.push(`Последняя смена — ${api.M(t)}. Отличная ночь!`); }
      else if (t <= s.avgPerShift * 0.85) { score -= 1; facts.push('Последняя смена была тяжёлой. Отдохни как следует.'); }
    }
    const np = C.nextPayout(st, today);
    if (np) facts.push(np.daysLeft <= 0 ? `${np.name} — сегодня! Купишь мне корм?` : `${np.name} через ${np.daysLeft} ${api.plural(np.daysLeft, 'день', 'дня', 'дней')}. Жду не дождусь.`);
    if (s.shifts) facts.push(`В этом месяце уже ${s.shifts} ${api.plural(s.shifts, 'смена', 'смены', 'смен')} и ${fmt(s.lines)} линий.`);
    return { mood: score >= 2 ? 'happy' : score <= -2 ? 'sad' : 'ok', facts, s };
  }
  const fmt = (v, d = 0) => api.N(v, d);

  // ---------- Поверхности, по которым можно ходить ----------
  const TOP = () => { const t = document.querySelector('.topbar'); return t ? t.getBoundingClientRect().height : 60; };
  const BOTTOM = () => { const t = document.querySelector('.tabbar'); return t ? t.getBoundingClientRect().height : 70; };
  function perches() {
    const v = document.querySelector('.view.active'); if (!v) return [];
    const out = [];
    for (const el of new Set(v.querySelectorAll(':scope > div, .hero, .card, .tile, .cal, .cal-summary, .streak-card, .wrap-entry, rect.bar, circle.dot'))) {
      const r = el.getBoundingClientRect(), tg = el.tagName.toLowerCase(), bar = tg === 'rect' || tg === 'circle';
      if (r.height < 6 || (!bar && r.width < 120) || (bar && r.width < 3)) continue;
      out.push({ el, bar, l: r.left + scrollX, r: r.right + scrollX, y: r.top + scrollY, h: r.height });
    }
    // Запасная опора — верхний край нижней панели вкладок: есть всегда, даже если карточек на экране нет
    const tb = document.querySelector('.tabbar');
    if (tb) { const r = tb.getBoundingClientRect(); out.push({ el: tb, bar: false, floor: true, l: scrollX + 8, r: scrollX + innerWidth - 8, y: r.top + scrollY, h: 0 }); }
    return out;
  }
  const visible = (p) => p.floor || (p.y > scrollY + TOP() + H + 6 && p.y < scrollY + innerHeight - BOTTOM() - 8);
  const catVisible = () => y > scrollY + TOP() + 10 && y - H < scrollY + innerHeight - BOTTOM();
  function findPerch() { // на чём кошка стоит сейчас (после перерисовки элементы заменяются)
    return perches().find((p) => Math.abs(p.y - y) < 8 && x >= p.l - (p.bar ? 16 : 6) && x <= p.r + (p.bar ? 16 : 6)) || null;
  }
  const barX = (p) => { const c = (p.l + p.r) / 2; return c - 11 * (c >= x ? 1 : -1); }; // передние лапы — на столбике
  const xIn = (p) => (p.bar ? barX(p) : rnd(p.l + W / 2 + 4, Math.max(p.l + W / 2 + 5, p.r - W / 2 - 4)));

  // ---------- Отрисовка и движение ----------
  function fitLayer() { // слой обрезает кошку за краями экрана, чтобы страница не расползалась вширь
    const m = document.querySelector('main'), hgt = Math.max(innerHeight, m ? m.getBoundingClientRect().bottom + scrollY : 0);
    if (Math.abs(layer.offsetHeight - hgt) > 1) layer.style.height = Math.round(hgt) + 'px';
  }
  function place() {
    cat.style.transform = `translate(${Math.round(x - W / 2)}px, ${Math.round(y - H)}px)`;
    cat.classList.toggle('left', face < 0);
    if (bubble.classList.contains('show')) placeBubble();
  }
  function setPose(p) { cat.dataset.pose = p; }
  function setMood(m) { mood = m; cat.dataset.mood = m; }
  function stop() { cancelAnimationFrame(raf); raf = 0; clearTimeout(timer); moveId++; }
  function walkTo(tx, speed = 70) {
    return new Promise((res) => {
      const id = ++moveId; cancelAnimationFrame(raf);
      face = tx >= x ? 1 : -1; setPose(speed > 120 ? 'run' : 'walk');
      let t0 = performance.now();
      const step = (t) => {
        if (id !== moveId) return res(false);
        const dt = Math.min(0.05, (t - t0) / 1000); t0 = t;
        const d = tx - x, s = speed * dt;
        if (Math.abs(d) <= s) { x = tx; place(); return res(true); }
        x += Math.sign(d) * s; place(); raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    });
  }
  function jumpTo(tx, ty) {
    return new Promise((res) => {
      const id = ++moveId; cancelAnimationFrame(raf);
      const x0 = x, y0 = y, dur = 520 + Math.min(400, Math.abs(ty - y0) * 0.6), peak = Math.max(40, y0 - ty + 40);
      face = tx >= x ? 1 : -1; setPose('jump');
      const t0 = performance.now();
      const step = (t) => {
        if (id !== moveId) return res(false);
        const k = Math.min(1, (t - t0) / dur);
        x = x0 + (tx - x0) * k; y = y0 + (ty - y0) * k - peak * 4 * k * (1 - k); place();
        if (k < 1) raf = requestAnimationFrame(step); else { setPose('idle'); res(true); }
      };
      raf = requestAnimationFrame(step);
    });
  }
  // Прийти с края экрана на видимую карточку (side: 'left' | 'right')
  async function enter(side, fast) {
    fitLayer();
    const all = perches().filter((p) => !p.bar && visible(p)), cards = all.filter((p) => !p.floor), ps = cards.length ? cards : all;
    if (!ps.length) { layer.classList.add('hidden'); return schedule(1500); }
    layer.classList.remove('hidden');
    const p = ps[0];
    perch = p; y = p.y;
    x = side === 'left' ? scrollX - W : scrollX + innerWidth + W; place();
    const tx = side === 'left' ? Math.min(p.r - W / 2 - 4, p.l + rnd(70, 170)) : Math.max(p.l + W / 2 + 4, p.r - rnd(70, 170));
    const ok = await walkTo(tx, fast ? 170 : 90);
    if (ok) { setPose('idle'); schedule(rnd(600, 1400)); }
  }
  // Листаешь вниз — кошка спрыгивает сверху на карточку ниже; вверх — запрыгивает снизу
  async function scrollHop(dy) {
    if (Math.abs(dy) < 40) { if (!catVisible()) { stop(); enter(Math.random() < 0.5 ? 'left' : 'right'); } return; }
    const down = dy > 0, top = scrollY + TOP(), bottom = scrollY + innerHeight - BOTTOM();
    fitLayer();
    const ps = perches().filter((p) => !p.bar && visible(p) && !p.floor);
    const cands = ps.filter((p) => (down ? p.y > y + 8 : p.y < y - 8));
    if (catVisible() && !cands.length) return; // и так на виду, прыгать некуда
    const list = cands.length ? cands : ps;
    if (!list.length) { stop(); return enter(down ? 'left' : 'right'); }
    // вниз — ближайшая к верху экрана карточка ниже; вверх — ближайшая к низу карточка выше
    const p = list.sort((a, b) => (down ? a.y - b.y : b.y - a.y))[0];
    stop(); layer.classList.remove('hidden'); bubble.classList.remove('show');
    if (!catVisible()) { y = down ? top - 4 : bottom + H + 4; x = Math.min(Math.max(x, scrollX + W), scrollX + innerWidth - W); place(); }
    busyUntil = Date.now() + 1200;
    const ok = await jumpTo(xIn(p), p.y);
    if (!ok) return;
    perch = p; busyUntil = 0;
    if (Math.random() < 0.3) say(line(down ? 'scroll_down' : 'scroll_up'), 1800);
    schedule(rnd(900, 1800));
  }
  function schedule(ms) { clearTimeout(timer); timer = setTimeout(() => { fitLayer(); act(); }, ms); }

  // ---------- Поведение ----------
  async function act() {
    if (!enabled || document.hidden || Date.now() < busyUntil) return schedule(1000);
    if (!catVisible()) return enter(Math.random() < 0.5 ? 'left' : 'right');
    perch = findPerch();
    const ps = perches().filter(visible);
    if (!perch) { // карточку перерисовали или убрали — спрыгиваем на ближайшую
      const near = ps.sort((a, b) => Math.abs(a.y - y) - Math.abs(b.y - y))[0];
      if (!near) return enter('left');
      await jumpTo(Math.min(Math.max(x, near.l + W / 2), near.r - W / 2), near.y); perch = near; return schedule(800);
    }
    const r = Math.random();
    if (night() && r < 0.5) { setPose('sleep'); return schedule(rnd(8000, 15000)); }
    const bars = ps.filter((p) => p.bar);
    if (bars.length && r < 0.45) { // на графике — посидеть на самом высоком столбике
      const best = bars.sort((a, b) => a.y - b.y)[0];
      if (Math.abs(best.y - y) > 2 || Math.abs(Math.abs((best.l + best.r) / 2 - x) - 11) > 2) { await jumpTo(barX(best), best.y); perch = best; }
      setPose('sit'); if (Math.random() < 0.4) say(mood === 'happy' ? 'Вот это столбик! Лучший результат.' : 'Отсюда всё видно. Хочу ещё такой столбик.');
      return schedule(rnd(3500, 6000));
    }
    if (r < 0.45 && !perch.bar) { await walkTo(xIn(perch)); setPose('idle'); return schedule(rnd(1200, 3000)); }
    if (r < 0.65) { const other = ps.filter((p) => p.el !== perch.el && !p.bar); if (other.length) { const o = pick(other); await jumpTo(xIn(o), o.y); perch = o; return schedule(rnd(800, 1800)); } }
    if (r < 0.75) { setPose('groom'); return schedule(rnd(2500, 4000)); }
    setPose(mood === 'sad' ? 'sit' : Math.random() < 0.5 ? 'sit' : 'idle');
    schedule(rnd(2500, 5500));
  }

  // ---------- Реплики ----------
  function placeBubble() {
    const bw = bubble.offsetWidth, bx = Math.max(scrollX + 8, Math.min(scrollX + innerWidth - bw - 8, x - bw / 2));
    let by = y - H - bubble.offsetHeight - 8; const below = by < scrollY + TOP() + 6;
    if (below) by = y + 10; // у самого верха — показываем реплику под кошкой
    bubble.classList.toggle('below', below);
    bubble.style.transform = `translate(${Math.round(bx)}px, ${Math.round(by)}px)`;
    bubble.style.setProperty('--tail', Math.round(Math.max(14, Math.min(bw - 14, x - bx))) + 'px');
  }
  function say(text, ms = 4200) {
    bubble.innerHTML = `<b>${api.esc(petName())}</b>${api.esc(text)}`;
    bubble.classList.add('show'); placeBubble();
    clearTimeout(say.t); say.t = setTimeout(() => bubble.classList.remove('show'), ms);
  }
  function burst(kind) { // сердечки, слёзы, «зз»
    const n = kind === 'heart' ? 5 : 3;
    for (let i = 0; i < n; i++) {
      const s = document.createElement('span'); s.className = 'pt-fx ' + kind; s.textContent = kind === 'heart' ? '❤' : kind === 'tear' ? '💧' : 'z';
      s.style.left = Math.round(x + (face > 0 ? 10 : -10) + rnd(-14, 14)) + 'px'; s.style.top = Math.round(y - H + rnd(-4, 8)) + 'px';
      s.style.animationDelay = (i * 120) + 'ms'; layer.appendChild(s); setTimeout(() => s.remove(), 1800 + i * 120);
    }
  }
  const petName = () => { const s = api.getState().settings.pet; return (s && s.name) || 'Мурка'; };
  function onTap(e) {
    e.stopPropagation();
    // Кошка не должна мешать: если под ней кнопка или поле — нажимаем их
    if (e.clientX || e.clientY) {
      cat.style.pointerEvents = 'none'; const under = document.elementFromPoint(e.clientX, e.clientY); cat.style.pointerEvents = '';
      const ctl = under && under.closest('button, a, input, select, textarea, label, [data-act], [data-k], .bar, .dot');
      if (ctl && !layer.contains(ctl)) { if (/^(INPUT|SELECT|TEXTAREA)$/.test(ctl.tagName)) ctl.focus(); ctl.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: e.clientX, clientY: e.clientY })); return; }
    }
    info = computeMood(); setMood(info.mood);
    stop(); busyUntil = Date.now() + 2500;
    if (mood === 'happy') { setPose('joy'); burst('heart'); } else if (mood === 'sad') { setPose('sit'); burst('tear'); } else setPose('idle');
    const again = Date.now() - (onTap.last || 0) < 7000; onTap.last = Date.now();
    say(again && Math.random() < 0.6 ? line('petted') : info.facts.length && Math.random() < 0.35 ? pick(info.facts) : line() || pick(info.facts));
    schedule(2600);
  }

  // ---------- Внешние события ----------
  // Сохранили смену — реакция на её результат
  function react(key) {
    if (!enabled || !api) return;
    info = computeMood(); setMood(info.mood);
    const st = api.getState(), C = api.C, e = st.entries[key]; if (!e) return;
    const t = C.total(e), mk = key.slice(0, 7), thr = info.s.extras.cfg.prodThreshold;
    const rest = Object.keys(st.entries).filter((k) => k !== key && k.slice(0, 7) === mk).map((k) => C.total(st.entries[k]));
    const others = rest.length ? rest.reduce((a, b) => a + b, 0) / rest.length : null;
    const good = (e.prod != null && e.prod >= thr) || (others && t >= others * 1.05);
    const bad = (e.prod != null && e.prod < thr - 10) || (others && t < others * 0.85);
    const go = async () => {
      if (!catVisible()) { await enter(Math.random() < 0.5 ? 'left' : 'right', true); }
      stop(); busyUntil = Date.now() + 3200;
      if (good) { setPose('joy'); burst('heart'); say(e.prod != null && e.prod >= thr ? `${fmt(e.prod, 1)}%! Вот это смена, мур-р-р!` : `${api.M(t)} за ночь — лучше обычного!`); }
      else if (bad) { setPose('sit'); burst('tear'); say('Тяжёлая ночь… Ничего, следующая будет лучше.'); }
      else { setPose('idle'); say(`Записала: ${api.M(t)}. Ровно идём.`); }
      schedule(3400);
    };
    setTimeout(go, 450);
  }
  // Переход на другую вкладку: кошка приходит с той стороны, где была прошлая вкладка
  function tab(from, to) {
    if (!enabled || !api || from === to) { visibleTab = to; return; }
    const side = TABS.indexOf(to) > TABS.indexOf(from) ? 'left' : 'right';
    visibleTab = to; stop(); bubble.classList.remove('show');
    x = side === 'left' ? -W * 2 : innerWidth + W * 2; place();
    setTimeout(() => enter(side, true), 120);
  }
  // Данные изменились — обновить настроение; если под кошкой исчезла карточка, она сама спрыгнет
  function refresh() {
    if (!api) return;
    const s = api.getState().settings.pet || {}, was = enabled;
    enabled = s.on === true;
    layer.classList.toggle('off', !enabled);
    if (!enabled) { stop(); bubble.classList.remove('show'); return; }
    if (!was) setTimeout(() => enter('left'), 300);
    try { info = computeMood(); setMood(info.mood); } catch (e) { setMood('ok'); }
    requestAnimationFrame(fitLayer);
  }
  function init(a) {
    api = a;
    layer = document.createElement('div'); layer.className = 'pet-layer'; layer.setAttribute('aria-hidden', 'true');
    cat = document.createElement('button'); cat.type = 'button'; cat.className = 'pet'; cat.innerHTML = SVG; cat.setAttribute('aria-label', 'Питомец');
    bubble = document.createElement('div'); bubble.className = 'pet-bubble';
    layer.append(cat, bubble); document.body.appendChild(layer);
    cat.addEventListener('click', onTap);
    setPose('idle');
    refresh();
    let sy0 = scrollY;
    window.addEventListener('scroll', () => { clearTimeout(scrollT); scrollT = setTimeout(() => { const dy = scrollY - sy0; sy0 = scrollY; if (enabled && Date.now() > busyUntil) scrollHop(dy); }, 260); }, { passive: true });
    window.addEventListener('resize', () => { if (enabled) { stop(); schedule(400); } });
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else if (enabled) schedule(800); });
    if (enabled) setTimeout(() => enter('left'), 900);
  }
  return { init, tab, react, refresh, computeMood, state: () => ({ x, y, mood, pose: cat && cat.dataset.pose, enabled, face }) };
})();
if (typeof window !== 'undefined') window.Pet = Pet;
