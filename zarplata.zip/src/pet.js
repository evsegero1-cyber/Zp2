/* Питомец — кошка, которая живёт в приложении.
 * Ходит по карточкам и столбикам графиков, переходит между вкладками (приходит с той стороны, где была),
 * радуется хорошим результатам и грустит, когда месяц не задался. Только оформление: на расчёты не влияет.
 * Координаты — в координатах страницы (кошка прокручивается вместе с содержимым).
 */
const Pet = (() => {
  'use strict';
  const W = 64, H = 48;                 // размер кошки, px; (x, y) — середина лап
  const TABS = ['home', 'cal', 'stats', 'success', 'crew', 'settings'];
  let api = null, layer = null, cat = null, bubble = null;
  let x = -200, y = 0, face = 1, perch = null, mood = 'ok', info = null;
  let raf = 0, timer = 0, busyUntil = 0, enabled = true, visibleTab = 'home', scrollT = 0, moveId = 0;
  const night = () => { const h = new Date().getHours(); return h >= 0 && h < 6; };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const PH = () => (typeof window !== 'undefined' && window.PET_PHRASES) || {};
  const recent = [];
  // Случайная реплика по ситуации: время суток, день недели, вкладка, настроение, Новый год
  function line(...keys) {
    const P = PH(), d = new Date(), h = d.getHours(), wd = d.getDay();
    let pools = keys.length ? keys : ['idle', 'thoughts', 'work', h < 6 ? 'night' : h < 11 ? 'morning' : h < 18 ? 'day' : 'evening', 'tab_' + visibleTab];
    if (!keys.length) {
      if (h < 6) pools.push('night');
      if (wd === 0 || wd === 6) pools.push('weekend'); if (wd === 1) pools.push('monday'); if (wd === 5) pools.push('friday');
      if (mood === 'happy') pools.push('happy'); if (mood === 'sad') pools.push('sad', 'sad');
      if (d.getMonth() === 11 || (d.getMonth() === 0 && d.getDate() <= 14)) pools.push('xmas', 'xmas');
    }
    pools = pools.map((k) => P[k]).filter((a) => a && a.length);
    if (!pools.length) return '';
    for (let i = 0; i < 8; i++) { const t = pick(pick(pools)); if (!recent.includes(t)) { recent.push(t); if (recent.length > 40) recent.shift(); return t; } }
    return pick(pick(pools));
  }

  // ---------- Рисунок (смотрит вправо) ----------
  const SVG = `<svg viewBox="0 0 64 48" width="64" height="48" aria-hidden="true">
    <defs>
      <linearGradient id="ptFur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--pf1,#FFBE73)"/><stop offset=".55" style="stop-color:var(--pf2,#F59B48)"/><stop offset="1" style="stop-color:var(--pf3,#E07F2F)"/></linearGradient>
      <linearGradient id="ptFurD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--pd1,#EE9446)"/><stop offset="1" style="stop-color:var(--pd2,#C96D27)"/></linearGradient>
      <radialGradient id="ptCream" cx=".5" cy=".35" r=".7"><stop offset="0" style="stop-color:var(--pc1,#FFFDF8)"/><stop offset="1" style="stop-color:var(--pc2,#FBE3C6)"/></radialGradient>
      <radialGradient id="ptIris" cx=".45" cy=".4" r=".6"><stop offset="0" style="stop-color:var(--pi1,#C9EC7A)"/><stop offset="1" style="stop-color:var(--pi2,#5E9C2C)"/></radialGradient>
    </defs>
    <g class="pt-flip">
      <g class="pt-tail">
        <path d="M17 32 C8 32 3.5 25 6 15.5 C6.8 12.5 8.4 10.5 10 9.5" fill="none" stroke="url(#ptFur)" stroke-width="5.4" stroke-linecap="round"/>
        <path d="M17 32 C8 32 3.5 25 6 15.5 C6.8 12.5 8.4 10.5 10 9.5" fill="none" class="pt-stripe" stroke="#C96D27" stroke-width="5.4" stroke-dasharray="1.6 4.2" stroke-dashoffset="-3" style="stroke:var(--pst,#C96D27);opacity:calc(var(--pso,1) * .75)"/>
      </g>
      <g class="pt-legs-back">
        <g class="pt-leg l1"><path d="M17 32 h6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h-0.4 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="20" cy="45.6" rx="3.1" ry="1.6" fill="#FFF3E2"/></g>
        <g class="pt-leg l2"><path d="M23.5 32 h6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h-0.4 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="26.5" cy="45.6" rx="3.1" ry="1.6" fill="#FFF3E2"/></g>
      </g>
      <ellipse class="pt-haunch" cx="21" cy="39" rx="9.5" ry="8"/>
      <g class="pt-legs-front">
        <g class="pt-leg l3"><path d="M36.5 32 h5.6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h0 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="39.3" cy="45.6" rx="3" ry="1.6" fill="#FFF8EE"/></g>
        <g class="pt-leg l4"><path d="M42.6 32 h5.6 v12.2 a2.8 2.8 0 0 1 -2.8 2.8 h0 a2.8 2.8 0 0 1 -2.8 -2.8 z"/><ellipse cx="45.4" cy="45.6" rx="3" ry="1.6" fill="#FFF8EE"/></g>
      </g>
      <g class="pt-body">
        <path d="M13.5 30.5 C13 23.5 19.5 20.5 28 20.6 C36.5 20.7 44.5 21.5 47 27.5 C49.2 33.5 45.5 40.5 36 40.8 L23 40.8 C17 40.8 13.8 36.8 13.5 30.5 Z" fill="url(#ptFur)"/>
        <path d="M20 21.6 q2.6 4 .8 8.4 M26.2 20.8 q2.6 4.4 .6 9.4 M32.4 21 q2.4 4.2 .4 8.8" class="pt-stripe" stroke="#D2742B" stroke-width="2.1" fill="none" stroke-linecap="round" style="stroke:var(--pst,#D2742B);opacity:calc(var(--pso,1) * .85)"/>
        <g class="pt-patch"><path d="M16 26 C18 21 25 20.5 29 22 C30 26 27 30 21 30 C18 30 16 28.5 16 26 Z" fill="#E8893A"/><path d="M31 21.5 C35 21 40 22 41.5 25 C40 29 35 30 32 28 C30.5 26 30.5 23.5 31 21.5 Z" fill="#2B2B30"/><path d="M15 33 C17 36 21 38.5 25 38 C24 35 20 33 15 33 Z" fill="#2B2B30"/></g>
        <ellipse cx="42.6" cy="33.5" rx="5.8" ry="7" fill="url(#ptCream)"/>
        <g class="pt-acc-neck">
          <g class="pa pa-scarf"><path d="M38.5 26.5 C42 29.5 47 29.5 50 27 L50.5 30.5 C47 33 41.5 33 38 30 Z" fill="#E03131"/><path d="M41 30 L39.5 38.5 L43.5 38 L44 31 Z" fill="#C92A2A"/><path d="M39.8 34 h3.6 M39.6 36.2 h3.6" stroke="#fff" stroke-width=".7" opacity=".7"/></g>
          <g class="pa pa-vest"><path d="M30.5 21.6 C36 21.2 41.6 22.6 44.6 26.6 L45.4 37.6 C41 39.6 35 40.2 30.8 39.4 Z" fill="#FF922B"/><path d="M34.6 22 L34.4 39.8 M40.4 23.6 L40.8 39.2" stroke="#E9ECEF" stroke-width="1.6"/><path d="M31 31 C35.5 31.6 40.5 31.4 45 30.4" stroke="#E9ECEF" stroke-width="1.3" fill="none"/></g>
          <g class="pa pa-medal"><path d="M41 27.4 L44.2 33 M48 27.2 L45 33" stroke="#1C7ED6" stroke-width="2"/><path d="M41.6 27.4 L44.4 32.4" stroke="#E03131" stroke-width=".8"/><circle cx="44.6" cy="34.4" r="2.6" fill="#FCC419" stroke="#E67700" stroke-width=".6"/><path d="M44.6 33 l.5 1 1 .1-.8.7.3 1-.9-.6-.9.6.3-1-.8-.7 1-.1z" fill="#E67700"/></g>
          <g class="pa pa-bell"><path d="M38.8 27.5 C42 30 47 30 50 27.6" fill="none" stroke="#1C7ED6" stroke-width="2.2" stroke-linecap="round"/><circle cx="44.6" cy="31.6" r="2.2" fill="#FCC419" stroke="#E67700" stroke-width=".5"/><path d="M43.6 32.4 h2" stroke="#7a4a00" stroke-width=".5"/></g>
        </g>
      </g>
      <g class="pt-head">
        <path d="M39.6 16 C39 10.5 40.2 6 42 3.2 C45.2 5 47.8 8 48.8 11.4 Z" fill="url(#ptFur)"/>
        <path d="M41.6 13 C41.4 10.2 42 7.8 42.8 6.4 C44.6 7.6 46 9.4 46.6 11.4 Z" fill="#F6A9A3"/>
        <g class="pt-ear-r"><path d="M50 11.4 C51.6 7.8 54.6 4.8 58 3.4 C59.2 6.6 59.6 11 58.8 16 Z" fill="url(#ptFur)"/><path d="M52.4 11.4 C53.6 9.4 55.2 7.8 57 7 C57.6 8.8 57.6 11 57.2 13.2 Z" fill="#F6A9A3"/></g>
        <path d="M37.6 20.6 C37.6 13.4 42.6 9.6 49 9.6 C55.4 9.6 60.4 13.4 60.4 20.6 C60.4 23.8 59.2 26.4 57.2 28 C55 29.8 52.2 30.6 49 30.6 C45.8 30.6 43 29.8 40.8 28 C38.8 26.4 37.6 23.8 37.6 20.6 Z" fill="url(#ptFur)"/>
        <g class="pt-patch"><path d="M39 17 C39.5 12.5 43 10 47 10 C47.5 13 46 16.5 42 18.5 C40.5 19 39.4 18.6 39 17 Z" fill="#E8893A"/><path d="M52 10.2 C56 10.5 59.6 13.5 60.2 18 C57.5 18 54.6 15.5 52 10.2 Z" fill="#2B2B30"/></g>
        <path d="M45.4 10.6 q1 2.8 0 5 M49 10 v5.2 M52.6 10.6 q-1 2.8 0 5" class="pt-stripe" stroke="#D2742B" stroke-width="1.6" fill="none" stroke-linecap="round" style="stroke:var(--pst,#D2742B);opacity:var(--pso,1)"/>
        <path d="M37.9 21.6 l3 .4 M38.3 24 l2.8 -.2 M60.1 21.6 l-2.6 .4" class="pt-stripe" stroke="#D2742B" stroke-width="1.3" stroke-linecap="round" style="stroke:var(--pst,#D2742B);opacity:var(--pso,1)"/>
        <ellipse cx="51.8" cy="25.6" rx="3.6" ry="3" fill="url(#ptCream)"/><ellipse cx="56.2" cy="25.6" rx="3.6" ry="3" fill="url(#ptCream)"/><ellipse cx="54" cy="28" rx="3" ry="2" fill="url(#ptCream)"/>
        <g class="pt-mask"><ellipse cx="53.6" cy="23.6" rx="7" ry="5.6" fill="#5A3D2E" opacity=".82"/><path d="M41.6 13 C41.4 10.2 42 7.8 42.8 6.4 C44.6 7.6 46 9.4 46.6 11.4 Z M52.4 11.4 C53.6 9.4 55.2 7.8 57 7 C57.6 8.8 57.6 11 57.2 13.2 Z" fill="#5A3D2E" opacity=".9"/></g>
        <g class="pt-eyes-ok">
          <g class="pt-blink"><ellipse cx="46.4" cy="19.4" rx="2.4" ry="2.9" fill="url(#ptIris)"/><ellipse cx="46.8" cy="19.5" rx=".9" ry="2.2" fill="#1E1A14"/><circle cx="47.4" cy="18.2" r=".75" fill="#fff"/></g>
          <g class="pt-blink"><ellipse cx="54" cy="19.4" rx="2.4" ry="2.9" fill="url(#ptIris)"/><ellipse cx="54.4" cy="19.5" rx=".9" ry="2.2" fill="#1E1A14"/><circle cx="55" cy="18.2" r=".75" fill="#fff"/></g>
        </g>
        <g class="pt-eyes-happy" fill="none" stroke="#2B2118" stroke-width="1.6" stroke-linecap="round"><path d="M44.4 20 q2 -2.8 4 0"/><path d="M52 20 q2 -2.8 4 0"/></g>
        <g class="pt-eyes-sad"><path d="M44.2 17.4 l3.6 -1.4 M56.2 17.4 l-3.6 -1.4" stroke="#2B2118" stroke-width="1.4" stroke-linecap="round" fill="none"/><ellipse cx="46.4" cy="20.2" rx="1.9" ry="2.2" fill="url(#ptIris)"/><ellipse cx="46.6" cy="20.4" rx=".8" ry="1.6" fill="#1E1A14"/><ellipse cx="54" cy="20.2" rx="1.9" ry="2.2" fill="url(#ptIris)"/><ellipse cx="54.2" cy="20.4" rx=".8" ry="1.6" fill="#1E1A14"/></g>
        <g class="pt-eyes-sleep" fill="none" stroke="#2B2118" stroke-width="1.5" stroke-linecap="round"><path d="M44.4 19.8 q2 1.8 4 0"/><path d="M52 19.8 q2 1.8 4 0"/></g>
        <ellipse class="pt-blush" cx="43.2" cy="24.4" rx="2.2" ry="1.4" fill="#FF8A8A" opacity=".5"/><ellipse class="pt-blush" cx="58.8" cy="24.4" rx="1.6" ry="1.4" fill="#FF8A8A" opacity=".5"/>
        <path d="M52.6 23 h2.8 c0 1 -.8 1.7 -1.4 2 c-.6 -.3 -1.4 -1 -1.4 -2 z" fill="#EE7F8C"/>
        <path class="pt-mouth-ok" d="M52.2 26 q.9 1 1.8 0 q.9 1 1.8 0" fill="none" stroke="#7A4A33" stroke-width="1" stroke-linecap="round"/>
        <path class="pt-mouth-happy" d="M52.2 25.8 q1.8 3.4 3.6 0 z" fill="#C2505F" stroke="#7A4A33" stroke-width=".7"/>
        <path class="pt-mouth-sad" d="M52.4 27.4 q1.6 -1.5 3.2 0" fill="none" stroke="#7A4A33" stroke-width="1" stroke-linecap="round"/>
        <path d="M58.6 25 h5 M58.6 26.6 l4.6 1.4 M45 25.2 h-5.4 M45 26.8 l-5 1.4" stroke="#8A6250" stroke-width=".5" opacity=".7" stroke-linecap="round"/>
        <g class="pt-acc-head">
          <g class="pa pa-bow"><path d="M50.5 11.2 L46.6 8.2 L46.8 13.4 Z M50.5 11.2 L54.6 8.6 L54.2 13.6 Z" fill="#F06595" stroke="#C2255C" stroke-width=".5" stroke-linejoin="round"/><circle cx="50.5" cy="11.1" r="1.4" fill="#C2255C"/></g>
          <g class="pa pa-glasses"><rect x="43.4" y="16.8" width="6.2" height="4.8" rx="1.8" fill="#22324F" stroke="#C9CFD6" stroke-width=".6"/><rect x="51" y="16.8" width="6.2" height="4.8" rx="1.8" fill="#22324F" stroke="#C9CFD6" stroke-width=".6"/><path d="M49.6 18.2 h1.4 M43.4 18 l-3.4 -1" stroke="#C9CFD6" stroke-width=".8"/><path d="M44.4 17.8 l1.6 0 M52 17.8 l1.6 0" stroke="#fff" stroke-width=".6" opacity=".7" stroke-linecap="round"/></g>
          <g class="pa pa-crown"><path d="M42.5 10.8 L41.8 4.2 L45.4 7.4 L48.6 2.6 L51.6 7.2 L55.2 4 L55 10.8 Z" fill="#FCC419" stroke="#E67700" stroke-width=".6" stroke-linejoin="round"/><circle cx="48.6" cy="7.8" r="1" fill="#E03131"/><circle cx="45" cy="9" r=".7" fill="#1C7ED6"/><circle cx="52.4" cy="9" r=".7" fill="#2F9E44"/></g>
          <g class="pa pa-santa"><path d="M40.6 11.6 C42 5 47 1.6 53 2.6 C56.5 3.3 58.5 5.5 59.5 8 L57.6 11.6 Z" fill="#E03131"/><circle cx="59.6" cy="8.4" r="2" fill="#fff"/><rect x="39.8" y="10" width="19" height="3.4" rx="1.7" fill="#fff"/></g>
          <g class="pa pa-cap"><path d="M40.2 12.4 C40 6.4 44.4 3.6 49.2 3.6 C54 3.6 58 6.4 58.2 11.6 Z" fill="#1C7ED6"/><path d="M55 11 C59 10.4 62.6 11 64.2 12.8 C61 13.6 57.4 13.4 54.4 12.8 Z" fill="#1864AB"/><circle cx="49.2" cy="3.8" r="1" fill="#1864AB"/><path d="M44 5.6 C45.4 4.6 47 4.1 48.4 4" stroke="#fff" stroke-width=".7" opacity=".5" fill="none"/></g>
          <g class="pa pa-flower"><g transform="translate(44.6 9.4)">${[0, 72, 144, 216, 288].map((a) => `<ellipse rx="1.5" ry="2.6" cy="-2.2" fill="#FFF3BF" stroke="#FAB005" stroke-width=".4" transform="rotate(${a})"/>`).join('')}<circle r="1.4" fill="#F59F00"/></g></g>
          <g class="pa pa-phones"><path d="M40.4 17 C40.4 8 44.4 4.6 49.2 4.6 C54 4.6 58 8 58 17" fill="none" stroke="#343A40" stroke-width="1.8"/><ellipse cx="40.2" cy="17.6" rx="2.2" ry="3.4" fill="#E03131"/><ellipse cx="58.2" cy="17.6" rx="2.2" ry="3.4" fill="#E03131"/></g>
          <g class="pa pa-tophat"><rect x="44" y="-1" width="10.4" height="11" rx="1" fill="#212529"/><rect x="44" y="6.6" width="10.4" height="2" fill="#C92A2A"/><rect x="40.6" y="9.6" width="17.2" height="2.2" rx="1.1" fill="#212529"/></g>
          <g class="pa pa-party"><path d="M44 11.2 L49.6 -3 L55.2 11.2 Z" fill="#7950F2"/><path d="M46 6.4 L53.2 6.4 M47.4 2.6 L51.8 2.6 M45 9.4 L54.2 9.4" stroke="#FCC419" stroke-width="1.2"/><circle cx="49.6" cy="-3.2" r="1.7" fill="#FF6B6B"/></g>
          <g class="pa pa-helmet"><path d="M40 12.6 C40 6.4 44.5 3.6 49.2 3.6 C54 3.6 58.4 6.4 58.4 12.6 Z" fill="#FCC419"/><path d="M48 3.8 h2.4 v8.6 h-2.4 z" fill="#F59F00"/><rect x="38.6" y="11.4" width="21.4" height="2.4" rx="1.2" fill="#F59F00"/><path d="M43 6.8 C44 5.4 45.6 4.6 47 4.4" stroke="#fff" stroke-width=".8" opacity=".6" fill="none" stroke-linecap="round"/></g>
        </g>
      </g>
    </g></svg>`;

  // ---------- Настроение: по результатам текущего месяца ----------
  function computeMood() {
    const st = api.getState(), C = api.C, today = api.todayKey(), p = C.parseKey(today);
    const s = C.monthSummary(st, p.m, today, p.y);
    const keys = Object.keys(st.entries || {}).filter((k) => st.entries[k] && k <= today).sort();
    const last = keys.length ? st.entries[keys[keys.length - 1]] : null;
    const x0 = s.extras, thr = x0.cfg.prodThreshold;
    let score = 0;
    const facts = [];
    if (!keys.length) return { mood: 'ok', facts: ['Внеси первую смену — и я начну радоваться вместе с тобой.'], s };
    if (x0.prodAvg !== null) {
      if (x0.prodOk) { score += 2; facts.push(`Средняя производительность ${fmt(x0.prodAvg, 1)}% — премия будет! Мур.`); }
      else if (s.needProd !== null && s.needProd <= thr + 8) facts.push(`До премии нужно в среднем ${fmt(s.needProd, 1)}% в оставшиеся смены. Мы сможем.`);
      else { score -= 1; facts.push(`Производительность пока ${fmt(x0.prodAvg, 1)}% — до премии далековато…`); }
    }
    if (x0.zone === 'green') { score += 1; facts.push('Сервис в зелёной зоне. Горжусь!'); }
    if (x0.zone === 'yellow') { score -= 1; facts.push('Сервис в жёлтой зоне. Давай без пересортов, ладно?'); }
    if (x0.zone === 'red') { score -= 2; facts.push('Сервис в красной зоне… Мне грустно.'); }
    if (s.target) {
      const k = (s.projected || s.total) / s.target;
      if (k >= 1) { score += 1; facts.push('Идём к цели месяца с запасом!'); }
      else if (k < 0.85) { score -= 1; facts.push(`До цели не хватает. Нужно около ${api.M(s.needPerShift)} за смену.`); }
      else if (s.needPerShift) facts.push(`Чтобы выйти на цель: ${api.M(s.needPerShift)} за смену.`);
    }
    if (last && s.avgPerShift) {
      const t = C.total(last);
      if (t >= s.avgPerShift * 1.1) { score += 1; facts.push(`Последняя смена — ${api.M(t)}. Отличная ночь!`); }
      else if (t <= s.avgPerShift * 0.85) { score -= 1; facts.push('Последняя смена была тяжёлой. Отдохни как следует.'); }
    }
    const np = C.nextPayout(st, today);
    if (np) facts.push(np.daysLeft <= 0 ? `${np.name} — сегодня! Купишь мне корм?` : `${np.name} через ${np.daysLeft} ${api.plural(np.daysLeft, 'день', 'дня', 'дней')}. Жду не дождусь.`);
    if (s.shifts) facts.push(`В этом месяце уже ${s.shifts} ${api.plural(s.shifts, 'смена', 'смены', 'смен')} и ${fmt(s.lines)} линий.`);
    return { mood: score >= 2 ? 'happy' : score <= -2 ? 'sad' : 'ok', facts, s };
  }
  const fmt = (v, d = 0) => api.N(v, d);
  // ---------- Полезное: короткие выводы по данным, каждый со своей эмоцией ----------
  // m: 'happy' — кошка радуется, 'sad' — расстраивается, 'ok' — просто рассказывает
  function insights() {
    const st = api.getState(), C = api.C, today = api.todayKey(), p = C.parseKey(today), E = st.entries || {};
    const out = [], add = (t, m = 'ok') => out.push({ t, m });
    const keys = Object.keys(E).filter((k) => E[k] && k <= today).sort();
    if (!keys.length) { add('Внеси первую смену — и я начну считать вместе с тобой.'); return out; }
    const s = C.monthSummary(st, p.m, today, p.y), x0 = s.extras, thr = x0.cfg.prodThreshold, M = api.M, pl = api.plural;
    const mon = C.MONTHS[p.m].toLowerCase();
    // заработок месяца и сравнение с прошлым месяцем к этому же числу
    if (s.shifts) {
      add(`За ${mon} уже ${M(s.total)} за ${s.shifts} ${pl(s.shifts, 'смену', 'смены', 'смен')}${s.projected ? `, прогноз на месяц — ${M(s.projected)}` : ''}.`);
      const pm = p.m ? p.m - 1 : 11, py = p.m ? p.y : p.y - 1;
      if (C.inYear(C.key(py, pm, 1))) {
        const pk = C.monthKeys(pm, py).filter((k) => +k.slice(8) <= p.d && E[k]);
        const prevSum = pk.reduce((a, k) => a + C.total(E[k]), 0);
        if (prevSum > 0) {
          const ch = (s.total - prevSum) / prevSum;
          if (ch >= 0.05) add(`К ${p.d} числу ты заработал на ${fmt(ch * 100)}% больше, чем в прошлом месяце. Мур-р!`, 'happy');
          else if (ch <= -0.05) add(`Пока на ${fmt(-ch * 100)}% меньше, чем в прошлом месяце к этому дню. Догоним!`, 'sad');
          else add('Идём почти вровень с прошлым месяцем.');
        }
      }
    }
    // премия за производительность
    if (x0.prodAvg !== null) {
      if (x0.prodOk) add(`Средняя производительность ${fmt(x0.prodAvg, 1)}% — премия${x0.cfg.prodAmount ? ' ' + M(x0.cfg.prodAmount) : ''} твоя!`, 'happy');
      else if (s.needProd !== null && s.needProd <= 200) add(`Средняя ${fmt(x0.prodAvg, 1)}%. Для премии нужно держать ${fmt(s.needProd, 1)}% в оставшиеся смены.`, s.needProd <= thr + 10 ? 'ok' : 'sad');
      else add(`Средняя производительность ${fmt(x0.prodAvg, 1)}% — до премии в этом месяце уже не дотянуть…`, 'sad');
    }
    if (x0.zone === 'green') add('Сервис в зелёной зоне. Ни одного пересорта — горжусь!', 'happy');
    if (x0.zone === 'yellow') add('Сервис в жёлтой зоне. Давай внимательнее с количеством, ладно?', 'sad');
    if (x0.zone === 'red') add('Сервис в красной зоне… Мне грустно. Перепроверяй заказы.', 'sad');
    // последняя смена
    const lk = keys[keys.length - 1], last = E[lk], prevK = keys[keys.length - 2], prev = prevK && E[prevK];
    const r = C.records(st);
    if (r.lines && r.lines.key === lk && keys.length > 3) add(`${C.fmtDateLong(lk)} — твой рекорд: ${fmt(last.lines)} линий! Это надо отметить.`, 'happy');
    else if (r.lines && last.lines && r.lines.value - last.lines <= 40 && keys.length > 3) add(`В последней смене до рекорда не хватило всего ${fmt(r.lines.value - last.lines)} ${pl(r.lines.value - last.lines, 'линии', 'линий', 'линий')}!`);
    if (prev && last.lines && prev.lines) {
      const d = last.lines - prev.lines;
      if (d >= 30) add(`Последняя смена: ${fmt(last.lines)} линий — на ${fmt(d)} больше, чем в прошлый раз.`, 'happy');
      else if (d <= -30) add(`Последняя смена вышла на ${fmt(-d)} линий меньше прошлой. Бывает — отдохни.`, 'sad');
    }
    if (last.prod != null) add(last.prod >= thr ? `Последняя смена — ${fmt(last.prod, 1)}%. Премиальная!` : `Последняя смена — ${fmt(last.prod, 1)}%, ниже ${thr}%. Следующая будет лучше.`, last.prod >= thr ? 'happy' : 'sad');
    if (last.hours && last.lines) add(`В последнюю смену — ${fmt(last.lines / last.hours, 1)} лин/ч.`);
    // неделя
    const mon0 = C.addDays(today, -C.weekdayMon(today)), wk = C.rangeKeys(mon0, today).filter((k) => E[k]);
    if (wk.length) {
      const wl = wk.reduce((a, k) => a + (E[k].lines || 0), 0);
      const pw = C.rangeKeys(C.addDays(mon0, -7), C.addDays(today, -7)).filter((k) => E[k]).reduce((a, k) => a + (E[k].lines || 0), 0);
      add(`На этой неделе ${wk.length} ${pl(wk.length, 'смена', 'смены', 'смен')} и ${fmt(wl)} линий${pw ? ` (к этому дню прошлой недели было ${fmt(pw)})` : ''}.`, pw && wl >= pw * 1.05 ? 'happy' : pw && wl <= pw * 0.9 ? 'sad' : 'ok');
    }
    // серия премиальных смен
    const sr = C.streaks(st, thr);
    if (sr.current >= 2) add(`${sr.current} ${pl(sr.current, 'смена', 'смены', 'смен')} подряд от ${thr}%! Не сбавляем.`, 'happy');
    // ближайшее достижение
    try {
      const a = C.achievements(st, {}).filter((x) => !x.done && x.target > 1 && x.value / x.target >= 0.6).sort((u, v) => v.value / v.target - u.value / u.target)[0];
      if (a) add(`До достижения «${a.title}» совсем чуть-чуть: ${fmt(a.value)} из ${fmt(a.target)}.`);
    } catch (e) { /* без достижений */ }
    // цель
    if (s.target) {
      const k = (s.projected || s.total) / s.target;
      if (k >= 1) add('К цели месяца идём с запасом!', 'happy');
      else if (s.needPerShift) add(`Чтобы выйти на цель: ${M(s.needPerShift)} за смену.`, k < 0.85 ? 'sad' : 'ok');
    }
    // выплата
    const np = C.nextPayout(st, today);
    if (np) add(np.daysLeft <= 0 ? `${np.name} — сегодня! Купишь мне корм?` : `${np.name} через ${np.daysLeft} ${pl(np.daysLeft, 'день', 'дня', 'дней')}.`, np.daysLeft <= 2 ? 'happy' : 'ok');
    // вес
    const kg = C.monthKeys(p.m, p.y).reduce((a, k) => a + ((E[k] && E[k].weight) || 0), 0);
    if (kg > 0) { const like = C.weightLike ? C.weightLike(kg) : null; add(`В этом месяце ты перенёс ${kg >= 1000 ? fmt(kg / 1000, 1) + ' т' : fmt(kg) + ' кг'}${like ? ` — как ${fmt(like.n, like.n < 10 ? 1 : 0)} ${like.word}` : ''}!`, 'happy'); }
    // выходные
    const wd = C.weekdayMon(today);
    if (wd === 4) add('Сегодня пятница — последняя смена недели, потом два дня отдыха!', 'happy');
    if (wd >= 5) add('Выходной! Отдыхай — склад подождёт.', 'happy');
    return out;
  }
  // Очередь выводов: по нажатию показываем следующий, а не одно и то же
  let queue = [], queueAt = 0;
  function nextInsight() {
    if (!queue.length || Date.now() - queueAt > 5 * 60e3) {
      queue = insights(); queueAt = Date.now();
      for (let i = queue.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [queue[i], queue[j]] = [queue[j], queue[i]]; }
    }
    return queue.shift();
  }
  // Показать реплику с эмоцией
  function emote(it, ms) {
    if (!it) return;
    if (it.m === 'happy') { setPose('joy'); burst('heart'); } else if (it.m === 'sad') { setPose('sit'); burst('tear'); } else setPose(Math.random() < 0.3 ? 'wave' : 'idle');
    say(it.t, ms || 5200);
  }
  // Сама что-то говорит: раз в 45–100 секунд, когда на экране и ничем не мешает
  let nextTalk = 0;
  function chatter() {
    if (!enabled || document.hidden || !catVisible() || Date.now() < nextTalk || Date.now() < busyUntil) return;
    const s = api.getState().settings.pet || {};
    if (s.chat === false) return;
    const ae = document.activeElement;
    if (document.querySelector('#sheet.show, #dialog.show, .modal.show') || (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName))) { nextTalk = Date.now() + 15000; return; }
    nextTalk = Date.now() + rnd(45000, 100000);
    if (bubble.classList.contains('show')) return;
    const r = Math.random();
    stop(); busyUntil = Date.now() + 2600;
    if (r < 0.45) emote(nextInsight());
    else if (r < 0.6) { setPose('sit'); say(line('catfacts'), 6000); }
    else if (r < 0.72) { setPose('idle'); say(line('tips'), 6000); }
    else { setPose(pick(['idle', 'sit', 'wave'])); say(line(), 4800); }
    schedule(3000);
  }

  // ---------- Поверхности, по которым можно ходить ----------
  const TOP = () => { const t = document.querySelector('.topbar'); return t ? t.getBoundingClientRect().height : 60; };
  const BOTTOM = () => { const t = document.querySelector('.tabbar'); return t ? t.getBoundingClientRect().height : 70; };
  function perches() {
    const v = document.querySelector('.view.active'); if (!v) return [];
    const out = [];
    for (const el of new Set(v.querySelectorAll(':scope > div, .hero, .card, .tile, .cal, .cal-summary, .streak-card, .wrap-entry, rect.bar, circle.dot'))) {
      const r = el.getBoundingClientRect(), tg = el.tagName.toLowerCase(), bar = tg === 'rect' || tg === 'circle';
      if (r.height < 6 || (!bar && r.width < 120) || (bar && r.width < 3)) continue;
      out.push({ el, bar, l: r.left + scrollX, r: r.right + scrollX, y: r.top + scrollY, h: r.height });
    }
    // Запасная опора — верхний край нижней панели вкладок: есть всегда, даже если карточек на экране нет
    const tb = document.querySelector('.tabbar');
    if (tb) { const r = tb.getBoundingClientRect(); out.push({ el: tb, bar: false, floor: true, l: scrollX + 8, r: scrollX + innerWidth - 8, y: r.top + scrollY, h: 0 }); }
    return out;
  }
  const visible = (p) => p.floor || (p.y > scrollY + TOP() + H + 6 && p.y < scrollY + innerHeight - BOTTOM() - 8);
  const catVisible = () => y > scrollY + TOP() + 10 && y - H < scrollY + innerHeight - BOTTOM();
  function findPerch() { // на чём кошка стоит сейчас (после перерисовки элементы заменяются)
    return perches().find((p) => Math.abs(p.y - y) < 8 && x >= p.l - (p.bar ? 16 : 6) && x <= p.r + (p.bar ? 16 : 6)) || null;
  }
  const barX = (p) => { const c = (p.l + p.r) / 2; return c - 11 * (c >= x ? 1 : -1); }; // передние лапы — на столбике
  const xIn = (p) => (p.bar ? barX(p) : rnd(p.l + W / 2 + 4, Math.max(p.l + W / 2 + 5, p.r - W / 2 - 4)));

  // ---------- Отрисовка и движение ----------
  function fitLayer() { // слой обрезает кошку за краями экрана, чтобы страница не расползалась вширь
    const m = document.querySelector('main'), hgt = Math.max(innerHeight, m ? m.getBoundingClientRect().bottom + scrollY : 0);
    if (Math.abs(layer.offsetHeight - hgt) > 1) layer.style.height = Math.round(hgt) + 'px';
  }
  function place() {
    cat.style.transform = `translate(${Math.round(x - W / 2)}px, ${Math.round(y - H)}px)`;
    cat.classList.toggle('left', face < 0);
    if (bubble.classList.contains('show')) placeBubble();
  }
  function setPose(p) { cat.dataset.pose = p; }
  function setMood(m) { mood = m; cat.dataset.mood = m; }
  function stop() { cancelAnimationFrame(raf); raf = 0; clearTimeout(timer); moveId++; }
  function walkTo(tx, speed = 70) {
    return new Promise((res) => {
      const id = ++moveId; cancelAnimationFrame(raf);
      face = tx >= x ? 1 : -1; setPose(speed > 120 ? 'run' : 'walk');
      let t0 = performance.now();
      const step = (t) => {
        if (id !== moveId) return res(false);
        const dt = Math.min(0.05, (t - t0) / 1000); t0 = t;
        const d = tx - x, s = speed * dt;
        if (Math.abs(d) <= s) { x = tx; place(); return res(true); }
        x += Math.sign(d) * s; place(); raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    });
  }
  function jumpTo(tx, ty) {
    return new Promise((res) => {
      const id = ++moveId; cancelAnimationFrame(raf);
      const x0 = x, y0 = y, dur = 520 + Math.min(400, Math.abs(ty - y0) * 0.6), peak = Math.max(40, y0 - ty + 40);
      face = tx >= x ? 1 : -1; setPose('jump');
      const t0 = performance.now();
      const step = (t) => {
        if (id !== moveId) return res(false);
        const k = Math.min(1, (t - t0) / dur);
        x = x0 + (tx - x0) * k; y = y0 + (ty - y0) * k - peak * 4 * k * (1 - k); place();
        if (k < 1) raf = requestAnimationFrame(step); else { setPose('idle'); res(true); }
      };
      raf = requestAnimationFrame(step);
    });
  }
  // Прийти с края экрана на видимую карточку (side: 'left' | 'right')
  async function enter(side, fast) {
    fitLayer();
    const all = perches().filter((p) => !p.bar && visible(p)), cards = all.filter((p) => !p.floor), ps = cards.length ? cards : all;
    if (!ps.length) { layer.classList.add('hidden'); return schedule(1500); }
    layer.classList.remove('hidden');
    const p = ps[0];
    perch = p; y = p.y;
    x = side === 'left' ? scrollX - W : scrollX + innerWidth + W; place();
    const tx = side === 'left' ? Math.min(p.r - W / 2 - 4, p.l + rnd(70, 170)) : Math.max(p.l + W / 2 + 4, p.r - rnd(70, 170));
    const ok = await walkTo(tx, fast ? 170 : 90);
    if (ok) { setPose('idle'); schedule(rnd(600, 1400)); }
  }
  // Листаешь вниз — кошка спрыгивает сверху на карточку ниже; вверх — запрыгивает снизу
  async function scrollHop(dy) {
    if (Math.abs(dy) < 40) { if (!catVisible()) { stop(); enter(Math.random() < 0.5 ? 'left' : 'right'); } return; }
    const down = dy > 0, top = scrollY + TOP(), bottom = scrollY + innerHeight - BOTTOM();
    fitLayer();
    const ps = perches().filter((p) => !p.bar && visible(p) && !p.floor);
    const cands = ps.filter((p) => (down ? p.y > y + 8 : p.y < y - 8));
    if (catVisible() && !cands.length) return; // и так на виду, прыгать некуда
    const list = cands.length ? cands : ps;
    if (!list.length) { stop(); return enter(down ? 'left' : 'right'); }
    // вниз — ближайшая к верху экрана карточка ниже; вверх — ближайшая к низу карточка выше
    const p = list.sort((a, b) => (down ? a.y - b.y : b.y - a.y))[0];
    stop(); layer.classList.remove('hidden'); bubble.classList.remove('show');
    if (!catVisible()) { y = down ? top - 4 : bottom + H + 4; x = Math.min(Math.max(x, scrollX + W), scrollX + innerWidth - W); place(); }
    busyUntil = Date.now() + 1200;
    const ok = await jumpTo(xIn(p), p.y);
    if (!ok) return;
    perch = p; busyUntil = 0;
    if (Math.random() < 0.3) say(line(down ? 'scroll_down' : 'scroll_up'), 1800);
    schedule(rnd(900, 1800));
  }
  function schedule(ms) { clearTimeout(timer); timer = setTimeout(() => { fitLayer(); act(); }, ms); }

  // ---------- Поведение ----------
  async function act() {
    if (!enabled || document.hidden || Date.now() < busyUntil) return schedule(1000);
    if (!catVisible()) return enter(Math.random() < 0.5 ? 'left' : 'right');
    perch = findPerch();
    const ps = perches().filter(visible);
    if (!perch) { // карточку перерисовали или убрали — спрыгиваем на ближайшую
      const near = ps.sort((a, b) => Math.abs(a.y - y) - Math.abs(b.y - y))[0];
      if (!near) return enter('left');
      await jumpTo(Math.min(Math.max(x, near.l + W / 2), near.r - W / 2), near.y); perch = near; return schedule(800);
    }
    const r = Math.random();
    if (night() && r < 0.5) { setPose('sleep'); return schedule(rnd(8000, 15000)); }
    const bars = ps.filter((p) => p.bar);
    if (bars.length && r < 0.45) { // на графике — посидеть на самом высоком столбике
      const best = bars.sort((a, b) => a.y - b.y)[0];
      if (Math.abs(best.y - y) > 2 || Math.abs(Math.abs((best.l + best.r) / 2 - x) - 11) > 2) { await jumpTo(barX(best), best.y); perch = best; }
      setPose('sit'); if (Math.random() < 0.4) say(mood === 'happy' ? 'Вот это столбик! Лучший результат.' : 'Отсюда всё видно. Хочу ещё такой столбик.');
      return schedule(rnd(3500, 6000));
    }
    if (r < 0.45 && !perch.bar) { await walkTo(xIn(perch)); setPose('idle'); return schedule(rnd(1200, 3000)); }
    if (r < 0.65) { const other = ps.filter((p) => p.el !== perch.el && !p.bar); if (other.length) { const o = pick(other); await jumpTo(xIn(o), o.y); perch = o; return schedule(rnd(800, 1800)); } }
    if (r < 0.72) { setPose('groom'); return schedule(rnd(2500, 4000)); }
    if (r < 0.86) { // разные движения: потягивается, буханка, зевает, машет лапой, ловит хвост, оглядывается
      const f = pick(['stretch', 'loaf', 'yawn', 'wave', 'spin', 'look', 'loaf', 'look']);
      setPose(f); return schedule(f === 'loaf' ? rnd(5000, 9000) : f === 'spin' ? 1700 : rnd(2200, 3600));
    }
    setPose(mood === 'sad' ? 'sit' : Math.random() < 0.5 ? 'sit' : 'idle');
    schedule(rnd(2500, 5500));
  }

  // ---------- Реплики ----------
  function placeBubble() {
    const bw = bubble.offsetWidth, bx = Math.max(scrollX + 8, Math.min(scrollX + innerWidth - bw - 8, x - bw / 2));
    let by = y - H - bubble.offsetHeight - 8; const below = by < scrollY + TOP() + 6;
    if (below) by = y + 10; // у самого верха — показываем реплику под кошкой
    bubble.classList.toggle('below', below);
    bubble.style.transform = `translate(${Math.round(bx)}px, ${Math.round(by)}px)`;
    bubble.style.setProperty('--tail', Math.round(Math.max(14, Math.min(bw - 14, x - bx))) + 'px');
  }
  function say(text, ms = 4200) {
    bubble.innerHTML = `<b>${api.esc(petName())}</b>${api.esc(text)}`;
    bubble.classList.add('show'); placeBubble();
    clearTimeout(say.t); say.t = setTimeout(() => bubble.classList.remove('show'), ms);
  }
  function burst(kind) { // сердечки, слёзы, «зз»
    const n = kind === 'heart' ? 5 : 3;
    for (let i = 0; i < n; i++) {
      const s = document.createElement('span'); s.className = 'pt-fx ' + kind; s.textContent = kind === 'heart' ? '❤' : kind === 'tear' ? '💧' : 'z';
      s.style.left = Math.round(x + (face > 0 ? 10 : -10) + rnd(-14, 14)) + 'px'; s.style.top = Math.round(y - H + rnd(-4, 8)) + 'px';
      s.style.animationDelay = (i * 120) + 'ms'; layer.appendChild(s); setTimeout(() => s.remove(), 1800 + i * 120);
    }
  }
  const petName = () => { const s = api.getState().settings.pet; return (s && s.name) || 'Мурка'; };
  function onTap(e) {
    e.stopPropagation();
    // Кошка не должна мешать: если под ней кнопка или поле — нажимаем их
    if (e.clientX || e.clientY) {
      cat.style.pointerEvents = 'none'; const under = document.elementFromPoint(e.clientX, e.clientY); cat.style.pointerEvents = '';
      const ctl = under && under.closest('button, a, input, select, textarea, label, [data-act], [data-k], .bar, .dot');
      if (ctl && !layer.contains(ctl)) { if (/^(INPUT|SELECT|TEXTAREA)$/.test(ctl.tagName)) ctl.focus(); ctl.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: e.clientX, clientY: e.clientY })); return; }
    }
    info = computeMood(); setMood(info.mood);
    stop(); busyUntil = Date.now() + 3000;
    // по нажатию — в основном полезное по твоим данным (каждый раз следующее), иногда тема дня или кошачий факт;
    // мурчит, только если гладить много раз подряд
    const quick = Date.now() - (onTap.last || 0) < 5000; onTap.last = Date.now();
    onTap.n = quick ? (onTap.n || 0) + 1 : 0;
    const r = Math.random();
    if (onTap.n >= 4 && r < 0.3) { setPose('joy'); burst('heart'); say(line('petted')); }
    else if (r < 0.7) emote(nextInsight());
    else if (r < 0.82) { setPose('sit'); say(line('catfacts'), 6000); }
    else if (r < 0.9) { setPose('idle'); say(line('tips'), 6000); }
    else { setPose('wave'); say(line(), 4800); }
    nextTalk = Math.max(nextTalk, Date.now() + 30000);
    schedule(3200);
  }

  // ---------- Внешние события ----------
  // Сохранили смену — реакция на её результат
  function react(key) {
    if (!enabled || !api) return;
    info = computeMood(); setMood(info.mood);
    const st = api.getState(), C = api.C, e = st.entries[key]; if (!e) return;
    const t = C.total(e), mk = key.slice(0, 7), thr = info.s.extras.cfg.prodThreshold;
    const rest = Object.keys(st.entries).filter((k) => k !== key && k.slice(0, 7) === mk).map((k) => C.total(st.entries[k]));
    const others = rest.length ? rest.reduce((a, b) => a + b, 0) / rest.length : null;
    const good = (e.prod != null && e.prod >= thr) || (others && t >= others * 1.05);
    const bad = (e.prod != null && e.prod < thr - 10) || (others && t < others * 0.85);
    const go = async () => {
      if (!catVisible()) { await enter(Math.random() < 0.5 ? 'left' : 'right', true); }
      stop(); busyUntil = Date.now() + 3200;
      if (good) { setPose('joy'); burst('heart'); say(e.prod != null && e.prod >= thr ? `${fmt(e.prod, 1)}%! Вот это смена, мур-р-р!` : `${api.M(t)} за ночь — лучше обычного!`); }
      else if (bad) { setPose('sit'); burst('tear'); say('Тяжёлая ночь… Ничего, следующая будет лучше.'); }
      else { setPose('idle'); say(`Записала: ${api.M(t)}. Ровно идём.`); }
      schedule(3400);
    };
    setTimeout(go, 450);
  }
  // Переход на другую вкладку: кошка приходит с той стороны, где была прошлая вкладка
  function tab(from, to) {
    if (!enabled || !api || from === to) { visibleTab = to; return; }
    const side = TABS.indexOf(to) > TABS.indexOf(from) ? 'left' : 'right';
    visibleTab = to; stop(); bubble.classList.remove('show');
    x = side === 'left' ? -W * 2 : innerWidth + W * 2; place();
    setTimeout(() => enter(side, true), 120);
    const s = api.getState().settings.pet || {};
    if (s.chat !== false && Math.random() < 0.35) setTimeout(() => { if (enabled && catVisible() && !bubble.classList.contains('show')) say(line('tab_' + to) || line(), 3800); }, 1700);
  }
  // Данные изменились — обновить настроение; если под кошкой исчезла карточка, она сама спрыгнет
  function refresh() {
    if (!api) return;
    const s = api.getState().settings.pet || {}, was = enabled;
    enabled = s.on === true;
    if (cat) { cat.dataset.coat = s.coat || 'ginger'; cat.dataset.acc = s.acc || 'none'; }
    layer.classList.toggle('off', !enabled);
    if (!enabled) { stop(); bubble.classList.remove('show'); return; }
    if (!was) setTimeout(() => enter('left'), 300);
    try { info = computeMood(); setMood(info.mood); } catch (e) { setMood('ok'); }
    requestAnimationFrame(fitLayer);
  }
  function init(a) {
    api = a;
    layer = document.createElement('div'); layer.className = 'pet-layer'; layer.setAttribute('aria-hidden', 'true');
    cat = document.createElement('button'); cat.type = 'button'; cat.className = 'pet'; cat.innerHTML = SVG; cat.setAttribute('aria-label', 'Питомец');
    bubble = document.createElement('div'); bubble.className = 'pet-bubble';
    layer.append(cat, bubble); document.body.appendChild(layer);
    cat.addEventListener('click', onTap);
    setPose('idle');
    refresh();
    let sy0 = scrollY;
    window.addEventListener('scroll', () => { clearTimeout(scrollT); scrollT = setTimeout(() => { const dy = scrollY - sy0; sy0 = scrollY; if (enabled && Date.now() > busyUntil) scrollHop(dy); }, 260); }, { passive: true });
    window.addEventListener('resize', () => { if (enabled) { stop(); schedule(400); } });
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else if (enabled) schedule(800); });
    if (enabled) setTimeout(() => enter('left'), 900);
    nextTalk = Date.now() + 20000;
    setInterval(() => { try { chatter(); } catch (e) { /* без реплики */ } }, 5000);
  }
  return { init, tab, react, refresh, computeMood, state: () => ({ x, y, mood, pose: cat && cat.dataset.pose, enabled, face }) };
})();
if (typeof window !== 'undefined') window.Pet = Pet;
