// 🥊 Боксёрская груша-манекен: 3D (Three.js), физика удара, лицо с фото.
// Загружается отдельным файлом только при открытии игры. Фото лица хранится только на этом устройстве.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';

const FACE_KEY = 'zarplata2027:punch-face';
const BEST_KEY = 'zarplata2027:punch-best';

// ---------- Размеры (метры) ----------
const BASE_H = 0.09, POLE_TOP = 0.56, PIVOT_Y = 0.76; // пружина: от верха стойки до низа корпуса
const BODY_H = 1.12;                                   // корпус от низа до макушки
const T_SHOULDER = 0.5, T_NECK = 0.705;                // границы частей по высоте (доли корпуса)

// Профиль корпуса снизу вверх: t (0…1) → полуширина, полуглубина, «квадратность» сечения
const PROFILE = [
  [0.00, 0.255, 0.170, 2.7], [0.06, 0.272, 0.182, 2.7], [0.20, 0.292, 0.196, 2.8], [0.36, 0.310, 0.204, 2.9],
  [0.48, 0.322, 0.204, 3.0], [0.56, 0.318, 0.192, 3.0], [0.615, 0.290, 0.176, 2.8], [0.655, 0.225, 0.160, 2.4],
  [0.69, 0.150, 0.142, 2.1], [0.715, 0.128, 0.134, 2.0], [0.76, 0.140, 0.146, 2.0], [0.84, 0.150, 0.152, 2.0],
  [0.92, 0.143, 0.145, 2.0], [0.965, 0.118, 0.118, 2.0], [0.99, 0.070, 0.070, 2.0], [1.00, 0.0, 0.0, 2.0],
];
// Монотонная кубическая интерполяция (без «волн» между точками)
function monotone(xs, ys) {
  const n = xs.length, d = [], m = [];
  for (let i = 0; i < n - 1; i++) d.push((ys[i + 1] - ys[i]) / (xs[i + 1] - xs[i]));
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) m[i] = 0;
  for (let i = 1; i < n - 1; i++) if (d[i - 1] * d[i] > 0) { const w1 = 2 * d[i] + d[i - 1], w2 = d[i] + 2 * d[i - 1]; m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]); }
  return (x) => {
    if (x <= xs[0]) return ys[0]; if (x >= xs[n - 1]) return ys[n - 1];
    let i = 0; while (x > xs[i + 1]) i++;
    const h = xs[i + 1] - xs[i], t = (x - xs[i]) / h, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * ys[i] + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * ys[i + 1] + (t3 - t2) * h * m[i + 1];
  };
}
const px = PROFILE.map((p) => p[0]);
const fW = monotone(px, PROFILE.map((p) => p[1])), fD = monotone(px, PROFILE.map((p) => p[2])), fN = monotone(px, PROFILE.map((p) => p[3]));
// Точка поверхности: θ=0 — лицом к зрителю (+z)
function surf(t, th, out) {
  const w = Math.max(0, fW(t)), d = Math.max(0, fD(t)), n = fN(t);
  const s = Math.sin(th), c = Math.cos(th), e = 2 / n;
  out.x = w * Math.sign(s) * Math.pow(Math.abs(s), e);
  out.z = d * Math.sign(c) * Math.pow(Math.abs(c), e);
  out.y = t * BODY_H;
  return out;
}

// ---------- Геометрия корпуса: одна сетка, разрезанная на торс / плечи / голову ----------
function buildBody(segU = 72, segV = 96) {
  const P = [], tmp = { x: 0, y: 0, z: 0 };
  // гуще у шеи и плеч, где профиль меняется быстрее
  const ts = []; for (let j = 0; j <= segV; j++) { const a = j / segV; ts.push(a); }
  for (let j = 0; j <= segV; j++) { const row = []; for (let i = 0; i <= segU; i++) { surf(ts[j], (i / segU) * Math.PI * 2 - Math.PI, tmp); row.push(new THREE.Vector3(tmp.x, tmp.y, tmp.z)); } P.push(row); }
  const N = [];
  for (let j = 0; j <= segV; j++) {
    const row = [];
    for (let i = 0; i <= segU; i++) {
      const ip = (i + 1) % segU, im = (i - 1 + segU) % segU;
      const du = new THREE.Vector3().subVectors(P[j][ip], P[j][im]);
      const j0 = Math.max(0, j - 1), j1 = Math.min(segV, j + 1);
      const dv = new THREE.Vector3().subVectors(P[j1][i], P[j0][i]);
      let n = new THREE.Vector3().crossVectors(du, dv).normalize();
      if (j === segV || n.lengthSq() < 0.5) n.set(0, 1, 0);
      if (j === 0) n.set(0, -0.3, 0).add(new THREE.Vector3(P[j][i].x, 0, P[j][i].z).normalize()).normalize();
      row.push(n);
    }
    N.push(row);
  }
  const part = (t0, t1) => {
    const j0 = Math.round(t0 * segV), j1 = Math.round(t1 * segV);
    const pos = [], nor = [], uv = [], idx = [];
    for (let j = j0; j <= j1; j++) for (let i = 0; i <= segU; i++) {
      const p = P[j][i], n = N[j][i]; pos.push(p.x, p.y, p.z); nor.push(n.x, n.y, n.z); uv.push(i / segU, ts[j]);
    }
    const W = segU + 1;
    for (let j = 0; j < j1 - j0; j++) for (let i = 0; i < segU; i++) { const a = j * W + i, b = a + W; idx.push(a, a + 1, b, b, a + 1, b + 1); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    return g;
  };
  return { torso: part(0, T_SHOULDER), shoulders: part(T_SHOULDER, T_NECK), head: part(T_NECK, 1) };
}

// ---------- Текстуры: потёртая кожа, круги мишени, лицо с фото ----------
function hash(x, y) { const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return s - Math.floor(s); }
function vnoise(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
const fbm = (x, y) => vnoise(x, y) * 0.5 + vnoise(x * 2.1, y * 2.1) * 0.25 + vnoise(x * 4.3, y * 4.3) * 0.15 + vnoise(x * 9.1, y * 9.1) * 0.1;
const smooth = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

const FACE = { cy: 0.858 * BODY_H, hw: 0.152, hh: 0.19 };       // овал лица на голове — почти во всю голову спереди
const RING = { cy: 0.40 * BODY_H, step: 0.068 };               // мишень на груди/животе

function makeTextures(face) {
  const W = 2048, H = 1024;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d'), img = g.createImageData(W, H), d = img.data;
  const bump = document.createElement('canvas'); bump.width = W / 2; bump.height = H / 2;
  const bg = bump.getContext('2d'), bimg = bg.createImageData(W / 2, H / 2), bd = bimg.data;
  let fd = null, fw = 0, fh = 0;
  if (face) { const c2 = document.createElement('canvas'); fw = c2.width = face.width; fh = c2.height = face.height; const x2 = c2.getContext('2d'); x2.drawImage(face, 0, 0); fd = x2.getImageData(0, 0, fw, fh).data; }
  const RED = [150, 34, 28], CREAM = [196, 182, 156], tmp = { x: 0, y: 0, z: 0 };
  for (let py = 0; py < H; py++) {
    const t = 1 - (py + 0.5) / H;
    for (let pxl = 0; pxl < W; pxl++) {
      const u = (pxl + 0.5) / W, th = u * Math.PI * 2 - Math.PI;
      surf(t, th, tmp);
      const front = tmp.z >= 0;
      let col;
      if (t > T_NECK - 0.012) {
        // голова: горизонтальные полосы
        col = Math.floor((tmp.y - 0.71 * BODY_H) / 0.052) % 2 === 0 ? RED : CREAM;
      } else {
        const r = Math.hypot(tmp.x, tmp.y - RING.cy) + (front ? 0 : 0.02);
        const k = Math.floor(r / RING.step);
        col = k % 2 === 0 ? RED : CREAM;
        // мягкая граница полос (не пиксельная лесенка)
        const edge = Math.abs((r / RING.step) - Math.round(r / RING.step));
        if (edge < 0.06) col = [(RED[0] + CREAM[0]) / 2, (RED[1] + CREAM[1]) / 2, (RED[2] + CREAM[2]) / 2];
      }
      let [r0, g0, b0] = col;
      // потёртость: пятна, выцветание к краям, грязь снизу
      const n = fbm(u * 38, t * 19), grime = fbm(u * 9 + 3, t * 6);
      const wear = 0.82 + n * 0.26 - (1 - t) * 0.06 - smooth(0.55, 0.85, grime) * 0.14;
      r0 *= wear; g0 *= wear; b0 *= wear;
      // ткань: мелкое плетение
      const weave = ((pxl % 4 < 2) ^ (py % 4 < 2) ? 1 : 0.94);
      r0 *= weave; g0 *= weave; b0 *= weave;
      // лицо с фото — проекция спереди, края растушёваны
      if (fd && front && t > T_NECK - 0.03) {
        const fx = tmp.x / (FACE.hw * 2) + 0.5, fy = (FACE.cy - tmp.y) / (FACE.hh * 2) + 0.5;
        const e = Math.pow(Math.abs((fx - 0.5) / 0.5) ** 4 + Math.abs((fy - 0.5) / 0.5) ** 4, 0.25);
        let a = 1 - smooth(0.9, 1.0, e);
        if (a > 0 && fx >= 0 && fx < 1 && fy >= 0 && fy < 1) {
          const si = ((Math.floor(fy * fh) * fw) + Math.floor(fx * fw)) * 4;
          a *= fd[si + 3] / 255; // прозрачный фон фото — видна ткань
          const ink = 0.9 + n * 0.12; // фото «напечатано» на ткани
          r0 = r0 * (1 - a) + fd[si] * ink * a; g0 = g0 * (1 - a) + fd[si + 1] * ink * a; b0 = b0 * (1 - a) + fd[si + 2] * ink * a;
        }
      }
      // окантовка (кант) по бокам и по низу
      const side = Math.min(Math.abs(u - 0.25), Math.abs(u - 0.75));
      if (side < 0.0028 || t < 0.012) { r0 = 30; g0 = 26; b0 = 23; }
      const o = (py * W + pxl) * 4;
      d[o] = r0; d[o + 1] = g0; d[o + 2] = b0; d[o + 3] = 255;
      if ((pxl & 1) === 0 && (py & 1) === 0) {
        const bo = ((py >> 1) * (W >> 1) + (pxl >> 1)) * 4;
        let hgt = 128 + (n - 0.5) * 70 + (weave < 1 ? -10 : 8);
        if (side < 0.004) hgt = 60;
        bd[bo] = bd[bo + 1] = bd[bo + 2] = hgt; bd[bo + 3] = 255;
      }
    }
  }
  g.putImageData(img, 0, 0); bg.putImageData(bimg, 0, 0);
  // царапины и трещины краски
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 140; i++) {
    const x = rnd() * W, y = 60 + rnd() * (H - 120), len = 10 + rnd() * 70, a = rnd() * Math.PI;
    g.strokeStyle = `rgba(245,238,225,${0.12 + rnd() * 0.3})`; g.lineWidth = 0.6 + rnd() * 1.2;
    g.beginPath(); g.moveTo(x, y);
    let cx = x, cy = y; for (let k = 0; k < 3; k++) { cx += Math.cos(a + (rnd() - 0.5)) * len / 3; cy += Math.sin(a + (rnd() - 0.5)) * len / 3; g.lineTo(cx, cy); }
    g.stroke();
    bg.strokeStyle = 'rgba(70,70,70,.8)'; bg.lineWidth = 1; bg.beginPath(); bg.moveTo(x / 2, y / 2); bg.lineTo(cx / 2, cy / 2); bg.stroke();
  }
  const map = new THREE.CanvasTexture(cv); map.colorSpace = THREE.SRGBColorSpace; map.anisotropy = 4;
  const bmp = new THREE.CanvasTexture(bump);
  return { map, bump: bmp };
}
function metalTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'), im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const n = fbm(x / 22, y / 22), rust = smooth(0.62, 0.8, fbm(x / 40 + 9, y / 40));
    const v = 58 + n * 40, o = (y * 256 + x) * 4;
    im.data[o] = v + rust * 55; im.data[o + 1] = v + rust * 18; im.data[o + 2] = v + 4 - rust * 10; im.data[o + 3] = 255;
  }
  g.putImageData(im, 0, 0);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,250,230,1)'); gr.addColorStop(0.25, 'rgba(255,200,120,.8)'); gr.addColorStop(1, 'rgba(255,120,40,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

// ---------- Модель целиком ----------
function buildModel(face) {
  const root = new THREE.Group(); root.name = 'Груша';
  const metalMap = metalTexture();
  const metal = new THREE.MeshStandardMaterial({ color: 0x8a8d90, map: metalMap, metalness: 0.85, roughness: 0.42 });
  const darkMetal = new THREE.MeshStandardMaterial({ color: 0x5a5d60, map: metalMap, metalness: 0.8, roughness: 0.55 });
  // Основание: тяжёлый диск с фаской
  const baseProf = [[0, 0], [0.36, 0], [0.375, 0.012], [0.372, 0.05], [0.345, 0.075], [0.20, 0.085], [0.17, BASE_H], [0, BASE_H]].map(([x, y]) => new THREE.Vector2(x, y));
  const base = new THREE.Mesh(new THREE.LatheGeometry(baseProf, 56), darkMetal); base.name = 'Основание';
  base.castShadow = base.receiveShadow = true; root.add(base);
  for (let i = 0; i < 4; i++) { // болты
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.012, 10), metal), a = i * Math.PI / 2 + Math.PI / 4;
    b.position.set(Math.cos(a) * 0.26, 0.083, Math.sin(a) * 0.26); base.add(b);
  }
  // Стойка
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.05, POLE_TOP - BASE_H, 24), metal); pole.name = 'Стойка';
  pole.position.y = (POLE_TOP + BASE_H) / 2; pole.castShadow = true; root.add(pole);
  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.03, 28), darkMetal); collar.position.y = POLE_TOP; collar.castShadow = true; pole.add(collar); collar.position.y = (POLE_TOP - BASE_H) / 2;
  // Пружина: спираль, которую каждый кадр изгибаем вслед за корпусом
  const L = PIVOT_Y - POLE_TOP, turns = 6, R = 0.062;
  class Helix extends THREE.Curve { getPoint(s, out = new THREE.Vector3()) { const a = s * turns * Math.PI * 2; return out.set(Math.cos(a) * R, s * L, Math.sin(a) * R); } }
  const springGeo = new THREE.TubeGeometry(new Helix(), turns * 40, 0.011, 8, false);
  const spring = new THREE.Mesh(springGeo, metal); spring.name = 'Пружина'; spring.castShadow = true;
  spring.position.y = POLE_TOP; root.add(spring);
  const springRest = springGeo.attributes.position.array.slice();
  // Корпус на шарнире над пружиной
  const pivot = new THREE.Group(); pivot.name = 'Шарнир'; pivot.position.y = PIVOT_Y; root.add(pivot);
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.026, 28), darkMetal); plate.position.y = 0.002; plate.castShadow = true; pivot.add(plate);
  const body = new THREE.Group(); body.name = 'Корпус'; body.position.y = 0.012; pivot.add(body);
  const geo = buildBody();
  const tex = makeTextures(face);
  const skin = new THREE.MeshStandardMaterial({ map: tex.map, bumpMap: tex.bump, bumpScale: 1.4, roughness: 0.78, metalness: 0.0 });
  const torso = new THREE.Mesh(geo.torso, skin); torso.name = 'Торс';
  const shoulders = new THREE.Mesh(geo.shoulders, skin); shoulders.name = 'Плечи';
  // Голова на своём шарнире у шеи — качается отдельно
  const neck = new THREE.Group(); neck.name = 'Шея'; neck.position.y = T_NECK * BODY_H; body.add(neck);
  const head = new THREE.Mesh(geo.head, skin); head.name = 'Голова'; head.position.y = -T_NECK * BODY_H; neck.add(head);
  const squash = new THREE.Group(); squash.add(torso, shoulders); body.add(squash);
  for (const m of [torso, shoulders, head]) { m.castShadow = true; m.receiveShadow = true; }
  // дно корпуса
  const bottom = new THREE.Mesh(new THREE.CircleGeometry(1, 40), new THREE.MeshStandardMaterial({ color: 0x1e1b18, roughness: 0.9 }));
  bottom.rotation.x = Math.PI / 2; bottom.scale.set(PROFILE[0][1], PROFILE[0][2], 1); bottom.position.y = 0.0005; squash.add(bottom);
  return { root, pivot, body, squash, neck, head, torso, shoulders, spring, springRest, springLen: L, skin, tex };
}

// ---------- Физика: перевёрнутый маятник на пружине + голова на своей пружине ----------
// Углы: x — вперёд/назад, z — вбок, y — поворот. Небольшие углы, интегрирование с подшагами.
function createPhysics() {
  const S = {
    body: { x: 0, z: 0, y: 0, vx: 0, vz: 0, vy: 0 },
    head: { x: 0, z: 0, vx: 0, vz: 0 },
    sq: 0, vsq: 0,
  };
  const P = {
    k: 62, c: 1.45, g: 11,                 // жёсткость пружины, затухание, «гравитация» (опрокидывающий момент): ≈1,1 колебания в секунду
    ky: 30, cy: 1.1,                       // поворот вокруг оси
    hk: 150, hc: 3.6, couple: 0.9,         // голова: жёсткость, затухание, отставание от корпуса
    sk: 900, sc: 18,                       // сжатие корпуса при ударе
    max: 0.62,                             // предельный наклон (рад) — дальше пружина резко жёстче
  };
  function step(dt) {
    const b = S.body, h = S.head;
    const ax0 = b.vx, az0 = b.vz;
    for (const [a, v] of [['x', 'vx'], ['z', 'vz']]) {
      const th = b[a];
      // пружина жёстче при большом наклоне, гравитация тянет дальше от вертикали
      const spring = P.k * th * (1 + 3 * (th / P.max) ** 2);
      const acc = -spring + P.g * Math.sin(th) - P.c * b[v];
      b[v] += acc * dt; b[a] += b[v] * dt;
      if (Math.abs(b[a]) > P.max * 1.15) { b[a] = Math.sign(b[a]) * P.max * 1.15; b[v] *= -0.3; }
    }
    b.vy += (-P.ky * b.y - P.cy * b.vy) * dt; b.y += b.vy * dt;
    // голова: инерция — отстаёт от разгона корпуса
    const bax = (b.vx - ax0) / dt, baz = (b.vz - az0) / dt;
    h.vx += (-P.hk * h.x - P.hc * h.vx - P.couple * bax) * dt; h.x += h.vx * dt;
    h.vz += (-P.hk * h.z - P.hc * h.vz - P.couple * baz) * dt; h.z += h.vz * dt;
    h.x = Math.max(-0.5, Math.min(0.5, h.x)); h.z = Math.max(-0.5, Math.min(0.5, h.z));
    S.vsq += (-P.sk * S.sq - P.sc * S.vsq) * dt; S.sq += S.vsq * dt;
  }
  return { S, P, step };
}

// ---------- Звук удара (синтез, без файлов) ----------
function makeAudio() {
  let ctx = null;
  return (power, isHead) => {
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const t = ctx.currentTime, len = 0.22;
      const buf = ctx.createBuffer(1, ctx.sampleRate * len, ctx.sampleRate), ch = buf.getChannelData(0);
      for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * (isHead ? 0.025 : 0.04)));
      const src = ctx.createBufferSource(); src.buffer = buf;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = isHead ? 1800 : 900;
      const g = ctx.createGain(); g.gain.value = 0.5 + power * 0.5;
      src.connect(lp).connect(g).connect(ctx.destination); src.start(t);
      const o = ctx.createOscillator(), og = ctx.createGain();
      o.frequency.setValueAtTime(isHead ? 160 : 95, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.18);
      og.gain.setValueAtTime(0.6 * power, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      o.connect(og).connect(ctx.destination); o.start(t); o.stop(t + 0.22);
    } catch { /* без звука */ }
  };
}

// ---------- Фото для лица: выбрать и подогнать (сдвиг пальцем, масштаб) ----------
export function cropFace(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onerror = () => reject(new Error('Не удалось открыть фото'));
    img.onload = () => {
      const ov = document.createElement('div'); ov.className = 'pf-crop';
      ov.innerHTML = `<div class="pf-box"><div class="pf-title">Подгоните лицо в овал</div>
        <div class="pf-frame"><canvas width="400" height="500"></canvas><div class="pf-oval"></div></div>
        <input type="range" min="1" max="4" step="0.01" value="1" class="pf-zoom" aria-label="Масштаб">
        <div class="pf-btns"><button class="btn btn-secondary" data-pf="no">Отмена</button><button class="btn btn-primary" data-pf="ok">Готово</button></div></div>`;
      document.body.appendChild(ov);
      const cv = ov.querySelector('canvas'), g = cv.getContext('2d'), zoom = ov.querySelector('.pf-zoom');
      const fit = Math.max(400 / img.width, 500 / img.height);
      let z = 1, ox = 0, oy = -img.height * fit * 0.12;
      const draw = () => {
        const s = fit * z, w = img.width * s, h = img.height * s;
        ox = Math.min((w - 400) / 2, Math.max(-(w - 400) / 2, ox)); oy = Math.min((h - 500) / 2, Math.max(-(h - 500) / 2, oy));
        g.fillStyle = '#222'; g.fillRect(0, 0, 400, 500); g.drawImage(img, 200 - w / 2 + ox, 250 - h / 2 + oy, w, h);
      };
      draw();
      zoom.oninput = () => { z = +zoom.value; draw(); };
      let drag = null;
      cv.onpointerdown = (e) => { drag = { x: e.clientX, y: e.clientY, ox, oy }; cv.setPointerCapture(e.pointerId); };
      cv.onpointermove = (e) => { if (!drag) return; const k = 400 / cv.getBoundingClientRect().width; ox = drag.ox + (e.clientX - drag.x) * k; oy = drag.oy + (e.clientY - drag.y) * k; draw(); };
      cv.onpointerup = () => { drag = null; };
      ov.onclick = (e) => {
        const b = e.target.closest('[data-pf]'); if (!b) return;
        ov.remove(); URL.revokeObjectURL(url);
        resolve(b.dataset.pf === 'ok' ? cv.toDataURL('image/jpeg', 0.88) : null);
      };
    };
    img.src = url;
  });
}
const loadImg = (src) => new Promise((res) => { if (!src) return res(null); const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });

// ---------- Экран игры ----------
export async function open(opts = {}) {
  const toast = opts.toast || ((t) => console.log(t));
  const ov = document.createElement('div'); ov.className = 'punch'; ov.id = 'punch';
  ov.innerHTML = `
    <canvas class="punch-cv"></canvas>
    <div class="punch-top">
      <button class="punch-btn" data-p="close" aria-label="Закрыть">×</button>
      <div class="punch-score"><b class="num" id="pc-hits">0</b><small>ударов</small></div>
      <div class="punch-score"><b class="num" id="pc-combo">×1</b><small>серия</small></div>
      <div class="punch-score"><b class="num" id="pc-best">0</b><small>рекорд</small></div>
    </div>
    <div class="punch-bottom">
      <button class="punch-btn wide" data-p="glb">⬇ GLB</button>
    </div>
    <div class="punch-hint" id="pc-hint">Тап — удар · палец — поворот · щипок — зум</div>`;
  document.body.appendChild(ov);
  const cv = ov.querySelector('canvas');
  const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.92;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x15171b);
  scene.fog = new THREE.Fog(0x15171b, 4.2, 8.5);
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = 0.55;
  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 30);
  const LOOK = new THREE.Vector3(0, 1.3, 0);
  let zoom = 1; // щипок двумя пальцами / колесо мыши: 0,6…1,6
  camera.position.set(0, 1.55, 2.5); camera.lookAt(LOOK);
  // Свет: ключевой с мягкой тенью, заполняющий тёплый, контровой холодный
  scene.add(new THREE.HemisphereLight(0xcfd8ff, 0x2a2018, 0.55));
  const key = new THREE.DirectionalLight(0xfff1dc, 2.0); key.position.set(1.6, 3.4, 2.4); key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024); key.shadow.camera.near = 1; key.shadow.camera.far = 8;
  Object.assign(key.shadow.camera, { left: -1.2, right: 1.2, top: 2.2, bottom: -0.4 }); key.shadow.radius = 5; key.shadow.bias = -0.0006; key.shadow.normalBias = 0.02;
  scene.add(key);
  const rim = new THREE.DirectionalLight(0x8fb4ff, 1.4); rim.position.set(-2, 2.2, -2.5); scene.add(rim);
  const fill = new THREE.PointLight(0xffb070, 0.9, 6); fill.position.set(-1.6, 1.0, 1.8); scene.add(fill);
  // Пол
  // пол растворяется в фоне к краям
  const fc = document.createElement('canvas'); fc.width = fc.height = 256;
  { const g = fc.getContext('2d'), gr = g.createRadialGradient(128, 128, 0, 128, 128, 128); gr.addColorStop(0, '#1f2125'); gr.addColorStop(0.4, '#16181b'); gr.addColorStop(1, '#101114'); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); }
  const ft = new THREE.CanvasTexture(fc); ft.colorSpace = THREE.SRGBColorSpace;
  const floor = new THREE.Mesh(new THREE.CircleGeometry(9, 48), new THREE.MeshStandardMaterial({ map: ft, roughness: 0.95 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

  // Лицо одно для всех — из приложения, поменять нельзя (своё фото, если ставили раньше, удаляем)
  try { localStorage.removeItem(FACE_KEY); } catch {}
  const DEFAULT_FACE = 'punch-face.webp'; // вырезано по контуру (фон прозрачный)
  let M = buildModel(await loadImg(DEFAULT_FACE));
  const stand = new THREE.Group(); stand.add(M.root); scene.add(stand);
  const phys = createPhysics();
  const sound = makeAudio();
  // Вспышка удара
  const glowTex = glowTexture();
  const flashes = [];
  function flash(p, power) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
    s.position.copy(p); s.scale.setScalar(0.12); scene.add(s);
    flashes.push({ s, t: 0, dur: 0.22, size: 0.25 + power * 0.25 });
    for (let i = 0; i < 6; i++) { // пыль из ткани
      const d = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0xd8c8a8, transparent: true, depthWrite: false, opacity: 0.5 }));
      d.position.copy(p); d.scale.setScalar(0.03); scene.add(d);
      flashes.push({ s: d, t: 0, dur: 0.45 + Math.random() * 0.25, size: 0.06, v: new THREE.Vector3((Math.random() - 0.5) * 0.8, Math.random() * 0.6, 0.3 + Math.random() * 0.6), dust: true });
    }
  }

  // ---------- Касания: удар (короткий тап) или вращение (протяжка) ----------
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  let yaw = -0.42, yawV = 0, down = null, shake = 0, hits = 0, combo = 1, lastHit = 0, best = 0;
  try { best = +localStorage.getItem(BEST_KEY) || 0; } catch {}
  const $ = (s) => ov.querySelector(s);
  $('#pc-best').textContent = best;
  function hit(clientX, clientY) {
    const r = cv.getBoundingClientRect();
    ndc.set(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const targets = [M.head, M.shoulders, M.torso];
    const hitInfo = ray.intersectObjects(targets, false)[0];
    if (!hitInfo) return false;
    const now = performance.now();
    combo = now - lastHit < 650 ? Math.min(combo + 1, 15) : 1; lastHit = now;
    const isHead = hitInfo.object === M.head;
    const power = Math.min(1.6, 0.85 + Math.random() * 0.25 + (combo - 1) * 0.04);
    // направление удара — от камеры, горизонтально
    const dir = ray.ray.direction.clone(); dir.y *= 0.25; dir.normalize();
    // в координаты корпуса (с учётом вращения пальцем)
    const inv = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, -yaw, 0));
    const dl = dir.clone().applyQuaternion(inv);
    const pivotW = new THREE.Vector3(); M.pivot.getWorldPosition(pivotW);
    const rArm = hitInfo.point.clone().sub(pivotW).applyQuaternion(inv);
    const J = (isHead ? 0.55 : 1.0) * power * 0.95;
    const L = new THREE.Vector3().crossVectors(rArm, dl.multiplyScalar(J));
    const b = phys.S.body;
    b.vx += L.x * 8; b.vz += L.z * 8; b.vy += L.y * 4.5;
    // в голову — голова запрокидывается сильнее корпуса
    if (isHead) { phys.S.head.vx += L.x * 20; phys.S.head.vz += L.z * 20; }
    phys.S.vsq += (isHead ? 0.8 : 2.0) * power;
    shake = Math.max(shake, isHead ? 0.5 * power : 0.25 * power + (power > 1.2 ? 0.25 : 0));
    flash(hitInfo.point.clone().addScaledVector(dir, -0.02), power);
    sound(Math.min(1, power / 1.3), isHead);
    if (navigator.vibrate) try { navigator.vibrate(isHead ? 22 : 14); } catch {}
    hits++; $('#pc-hits').textContent = hits; $('#pc-combo').textContent = '×' + combo;
    if (hits > best) { best = hits; $('#pc-best').textContent = best; try { localStorage.setItem(BEST_KEY, best); } catch {} }
    const hint = $('#pc-hint'); if (hint) hint.remove();
    return true;
  }
  const pts = new Map(); let pinch = null;
  cv.addEventListener('wheel', (e) => { e.preventDefault(); zoom = Math.min(1.6, Math.max(0.6, zoom * (e.deltaY < 0 ? 1.08 : 1 / 1.08))); }, { passive: false });
  cv.addEventListener('pointerdown', (e) => { pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), z: zoom }; down = null; return; } }, true);
  cv.addEventListener('pointermove', (e) => {
    if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && pts.size === 2) { const [a, b] = [...pts.values()]; zoom = Math.min(1.6, Math.max(0.6, pinch.z * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d)); e.stopImmediatePropagation(); }
  }, true);
  const lift = (e) => { pts.delete(e.pointerId); if (pts.size < 2) { if (pinch) { pinch = null; down = null; e.stopImmediatePropagation(); } } };
  cv.addEventListener('pointerup', lift, true); cv.addEventListener('pointercancel', lift, true);
  cv.addEventListener('pointerdown', (e) => { if (pinch) return; down = { x: e.clientX, y: e.clientY, t: performance.now(), lx: e.clientX, moved: false }; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', (e) => {
    if (!down) return;
    if (Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y) > 10) down.moved = true;
    if (down.moved) { const dx = e.clientX - down.lx; yaw += dx * 0.008; yawV = dx * 0.008 * 60; yaw = Math.max(-1.5, Math.min(1.5, yaw)); down.lx = e.clientX; }
  });
  cv.addEventListener('pointerup', (e) => { if (down && !down.moved) hit(e.clientX, e.clientY); down = null; });
  cv.addEventListener('pointercancel', () => { down = null; });

  // ---------- Кадр ----------
  const tmpQ = new THREE.Quaternion(), tmpV = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  function bendSpring() {
    // пружина: низ закреплён, верх повёрнут вместе с корпусом; ось — кривая Безье, витки сжаты с внутренней стороны
    const q = M.pivot.quaternion, Ls = M.springLen;
    const topUp = up.clone().applyQuaternion(q);
    const P0 = new THREE.Vector3(0, 0, 0), P2 = new THREE.Vector3(0, Ls, 0), P1 = P2.clone().addScaledVector(topUp, -Ls * 0.5);
    const pos = M.spring.geometry.attributes.position, a = pos.array, rest = M.springRest;
    for (let i = 0; i < a.length; i += 3) {
      const s = Math.min(1, Math.max(0, rest[i + 1] / Ls)), u = 1 - s;
      const cx = u * u * P0.x + 2 * u * s * P1.x + s * s * P2.x, cy = u * u * P0.y + 2 * u * s * P1.y + s * s * P2.y, cz = u * u * P0.z + 2 * u * s * P1.z + s * s * P2.z;
      tmpQ.identity().slerp(q, s * s);
      tmpV.set(rest[i], 0, rest[i + 2]).applyQuaternion(tmpQ);
      a[i] = cx + tmpV.x; a[i + 1] = cy + tmpV.y; a[i + 2] = cz + tmpV.z;
    }
    pos.needsUpdate = true; M.spring.geometry.computeVertexNormals();
  }
  function resize() {
    const w = ov.clientWidth, h = ov.clientHeight;
    renderer.setSize(w, h, false); camera.aspect = w / h;
    // на узком экране отодвигаем камеру, чтобы манекен помещался целиком
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize); resize();
  let last = performance.now(), raf = 0, alive = true;
  function frame(now) {
    if (!alive) return;
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const sub = 6; for (let i = 0; i < sub; i++) phys.step(dt / sub);
    const S = phys.S;
    // углы — прямо в повороты: импульс удара r×F уже даёт правильное направление (от игрока)
    M.pivot.rotation.set(S.body.x, S.body.y, S.body.z);
    M.neck.rotation.set(S.head.x, 0, S.head.z);
    const sq = Math.max(-0.06, Math.min(0.06, S.sq * 0.035));
    M.squash.scale.set(1 + sq * 0.5, 1 - sq, 1 + sq * 0.5);
    bendSpring();
    // вращение пальцем с инерцией
    if (!down) { yaw += yawV * dt; yawV *= Math.pow(0.04, dt); yaw = Math.max(-1.5, Math.min(1.5, yaw)); }
    stand.rotation.y = yaw;
    // тряска камеры при сильном ударе
    shake *= Math.pow(0.0008, dt);
    // ближе к манекену: видна верхняя часть с головой; на узком экране чуть дальше
    const dist = 2.5 * Math.max(1, 0.5 / camera.aspect) / zoom;
    camera.position.x = (Math.random() - 0.5) * shake * 0.05; camera.position.y = 1.5 + (Math.random() - 0.5) * shake * 0.04; camera.position.z = dist;
    camera.lookAt(LOOK);
    for (let i = flashes.length - 1; i >= 0; i--) {
      const f = flashes[i]; f.t += dt; const k = f.t / f.dur;
      if (k >= 1) { scene.remove(f.s); f.s.material.dispose(); flashes.splice(i, 1); continue; }
      if (f.dust) { f.s.position.addScaledVector(f.v, dt); f.v.y -= 1.5 * dt; f.s.material.opacity = 0.5 * (1 - k); f.s.scale.setScalar(f.size * (0.6 + k)); }
      else { f.s.material.opacity = 1 - k; f.s.scale.setScalar(f.size * (0.4 + k * 0.9)); }
    }
    if (now - lastHit > 1200 && combo > 1) { combo = 1; $('#pc-combo').textContent = '×1'; }
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(frame);
  const vis = () => { if (document.hidden) { cancelAnimationFrame(raf); } else { last = performance.now(); raf = requestAnimationFrame(frame); } };
  document.addEventListener('visibilitychange', vis);

  function close() {
    alive = false; cancelAnimationFrame(raf);
    window.removeEventListener('resize', resize); document.removeEventListener('visibilitychange', vis);
    scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { const ms = [].concat(o.material); ms.forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); }); } });
    pmrem.dispose(); renderer.dispose(); ov.remove();
    if (opts.onClose) opts.onClose();
  }
  function exportGlb() {
    new GLTFExporter().parse(M.root, (glb) => {
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([glb], { type: 'model/gltf-binary' }));
      a.download = 'grusha.glb'; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    }, (e) => toast('Экспорт не удался: ' + e.message), { binary: true, maxTextureSize: 2048 });
  }
  ov.addEventListener('click', (e) => {
    const b = e.target.closest('[data-p]'); if (!b) return;
    if (b.dataset.p === 'close') close();
    if (b.dataset.p === 'glb') exportGlb();
  });
  const api = { close, hit, scene, model: M, physics: phys, exportGlb, renderer, camera };
  window.__punch = api; // для проверок
  return api;
}

window.Punch = { open, cropFace };
