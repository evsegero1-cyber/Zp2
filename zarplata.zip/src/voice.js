// Голосовой ввод смены: разбор фразы «344 линии 153,32 производительность» в поля формы.
// Распознавание речи — системное (браузер или Android); здесь только разбор текста, без сети.
(function (root) {
  'use strict';

  const UNITS = { ноль: 0, нуль: 0, один: 1, одна: 1, одно: 1, два: 2, две: 2, три: 3, четыре: 4, пять: 5, шесть: 6, семь: 7, восемь: 8, девять: 9,
    десять: 10, одиннадцать: 11, двенадцать: 12, тринадцать: 13, четырнадцать: 14, пятнадцать: 15, шестнадцать: 16, семнадцать: 17,
    восемнадцать: 18, девятнадцать: 19 };
  const TENS = { двадцать: 20, тридцать: 30, сорок: 40, пятьдесят: 50, шестьдесят: 60, семьдесят: 70, восемьдесят: 80, девяносто: 90 };
  const HUNDREDS = { сто: 100, двести: 200, триста: 300, четыреста: 400, пятьсот: 500, шестьсот: 600, семьсот: 700, восемьсот: 800, девятьсот: 900 };
  const THOUSAND = /^тысяч/;

  // «триста сорок четыре» → «344»; «сто пятьдесят три целых тридцать две» → «153 целых 32»
  function wordsToDigits(text) {
    const out = [];
    let cur = null, total = 0, lastKind = '';
    const flush = () => { if (cur !== null || total) { out.push(String(total + (cur || 0))); } cur = null; total = 0; lastKind = ''; };
    for (const w of text.split(/\s+/)) {
      if (!w) continue;
      let v = null, kind = '';
      if (w in UNITS) { v = UNITS[w]; kind = 'u'; } else if (w in TENS) { v = TENS[w]; kind = 't'; } else if (w in HUNDREDS) { v = HUNDREDS[w]; kind = 'h'; }
      if (THOUSAND.test(w)) { total = (total + (cur === null ? 1 : cur)) * 1000; cur = null; lastKind = 'k'; continue; }
      if (v === null) { flush(); out.push(w); continue; }
      // Новое число начинается, если разряд не может продолжить текущее («сорок пять» — одно, «пять сорок» — два)
      const order = { h: 3, t: 2, u: 1 };
      const canJoin = cur === null ? true
        : (lastKind === 'h' && (kind === 't' || kind === 'u')) || (lastKind === 't' && kind === 'u' && v < 10);
      if (!canJoin) flush();
      cur = (cur || 0) + v; lastKind = kind;
      if (order[kind] === 1 && v >= 10) lastKind = 'u';
    }
    flush();
    return out.join(' ');
  }

  // Числа из текста: «153,32», «153.32», «153 и 32», «153 целых 32», «1 200»
  function numbers(text) {
    const res = [];
    const re = /(?:\d{1,2}(?:[  ]\d{3})+(?!\d)|\d+)(?:\s*(?:[.,]|(?<![а-я])(?:и|целых|целая|запятая|точка)(?![а-я]))\s*\d{1,2}(?!\d))?/g;
    let m;
    while ((m = re.exec(text))) {
      const raw = m[0];
      const dec = raw.match(/^(.*?)\s*(?:[.,]|(?<![а-я])(?:и|целых|целая|запятая|точка)(?![а-я]))\s*(\d{1,2})$/);
      let int = dec ? dec[1] : raw, frac = dec ? dec[2] : '';
      int = int.replace(/[  ]/g, '');
      // «тысяча двести» уже числом; «1 200» — тысячи через пробел только если группа ровно из 3 цифр
      const val = Number(int + (frac ? '.' + frac : ''));
      if (Number.isFinite(val)) res.push({ val, at: m.index, end: m.index + raw.length, decimal: !!frac });
    }
    return res;
  }

  const KEYS = [
    { field: 'lines', re: /линий|линии|линия|линию|лини|строк|позици|пик/g },
    { field: 'prod', re: /производ\S*|процент\S*|%/g },
    { field: 'actual', re: /заработ\S*|рубл\S*|факт\S*|₽/g },
    { field: 'hours', re: /(?<![а-я])час(?:а|ов)?(?![а-я])/g },
  ];

  // Разбор фразы → {lines, prod, actual, hours, comment}; поля, которых нет во фразе, — null
  function parseShift(input) {
    const res = { lines: null, prod: null, actual: null, hours: null, comment: '' };
    let text = String(input || '').toLowerCase().replace(/ё/g, 'е');
    const cm = text.match(/(?<![а-я])(?:комментарий|коммент|заметка)(?![а-я])[:\s]*(.*)$/);
    if (cm) { res.comment = cm[1].trim(); text = text.slice(0, cm.index); }
    text = wordsToDigits(text.replace(/[«»"!?;]/g, ' ').replace(/(\d)\s*%/g, '$1 процентов '));
    const nums = numbers(text);
    if (!nums.length) return res;
    const keys = [];
    for (const k of KEYS) { k.re.lastIndex = 0; let m; while ((m = k.re.exec(text))) keys.push({ field: k.field, at: m.index, end: m.index + m[0].length }); }
    keys.sort((a, b) => a.at - b.at);
    const used = new Set();
    // Ключевое слово получает ближайшее свободное число: сначала стоящее перед ним вплотную («344 линии»), иначе после («линий 410»)
    for (const k of keys) {
      if (res[k.field] !== null) continue;
      let best = null, bestD = Infinity;
      nums.forEach((n, i) => {
        if (used.has(i)) return;
        const before = n.end <= k.at, gap = before ? k.at - n.end : n.at - k.end;
        if (gap < 0) return;
        // число перед словом связано с ним сильнее; между ними не должно быть другого ключевого слова
        const between = keys.some((o) => o !== k && (before ? o.at >= n.end && o.end <= k.at : o.at >= k.end && o.end <= n.at));
        if (between) return;
        const d = gap + (before ? 0 : 0.5);
        if (d < bestD) { bestD = d; best = i; }
      });
      if (best !== null) { used.add(best); res[k.field] = nums[best].val; }
    }
    // Числа без слов: целое побольше — линии, дробное или второе — производительность
    for (let i = 0; i < nums.length; i++) {
      if (used.has(i)) continue;
      const n = nums[i];
      if (res.lines === null && !n.decimal && Number.isInteger(n.val) && n.val >= 1 && n.val <= 5000) { res.lines = n.val; used.add(i); }
      else if (res.prod === null && n.val > 0 && n.val <= 400) { res.prod = n.val; used.add(i); }
    }
    if (res.lines !== null && !Number.isInteger(res.lines)) res.lines = Math.round(res.lines);
    return res;
  }

  const api = { parseShift, wordsToDigits, numbers };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Voice = api;
})(typeof window !== 'undefined' ? window : globalThis);
